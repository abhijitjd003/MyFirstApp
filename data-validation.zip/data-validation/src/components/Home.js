import React, { Component } from 'react';
import clsx from 'clsx';
import PersonIcon from '@material-ui/icons/Person';
import './common/Common.css';
import Popup from "reactjs-popup";
import {
    Button, TextField, Grid, withStyles, AppBar, Toolbar, CssBaseline,
    Typography
} from '@material-ui/core';
import './common/CommonModal.css';
import { withRouter } from 'react-router-dom';
import Loader from './loader/Loader';

const useStyles = theme => ({
    root: {
        display: 'flex',
    },
    appBar: {
        zIndex: theme.zIndex.drawer + 1,
        transition: theme.transitions.create(['width', 'margin'], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen,
        }),
    },
    appBarShift: {
        marginLeft: 0,
        width: `calc(100% - ${0}px)`,
        transition: theme.transitions.create(['width', 'margin'], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.enteringScreen,
        }),
    },
    toolbar: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'flex-end',
        padding: theme.spacing(0, 1),
        ...theme.mixins.toolbar,
    },
    content: {
        flexGrow: 1,
        padding: theme.spacing(3),
    },
    alignment: {
        flexGrow: 1,
    },
    leftIcon: {
        marginRight: theme.spacing.unit,
    },
    topMargin: {
        marginTop: 40,
    },
});

const validateForm = (errors) => {
    let valid = true;
    Object.keys(errors).map(function (e) {
        if (errors[e].length > 0) {
            valid = false;
        }
    });
    return valid;
}

const validateInput = (error) => {
    let valid = true;    
    if (error.length > 0) {
        valid = false;
    }
    return valid;
}

const cache = {}
const validEmailRegex = RegExp(/^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i);

class Home extends Component {
    constructor(props) {
        super(props);
        this.state = {
            open: false, email: null, mobileNo: null, OTP: null, errorMessage: null, loading: false, validOTP: 0,
            errors: {
                email: '',
                OTP: '',
                mobileNo: ''
            }
        };
        this.openLogin = this.openLogin.bind(this);
        this.closeLogin = this.closeLogin.bind(this);
        this.popupOnClose = this.popupOnClose.bind(this);
    }

    openLogin() {
        this.setState({ open: true });
    }
    closeLogin() {
        let errors = this.state.errors;
        errors.email = errors.OTP = errors.mobileNo = '';
        this.setState({ errors, open: false, errorMessage: null });
    }
    popupOnClose() { }

    getOTP = (event) => {
        event.preventDefault();
        if (validateInput(this.state.errors.mobileNo) && this.state.mobileNo) {
            let OTP = Math.floor(100000 + Math.random() * 999999);
            this.setState({ loading: true });            
            this.sendOTP(this.state.mobileNo, OTP);
        } else {
            let errors = this.state.errors;            
            if (!this.state.mobileNo) {
                errors.mobileNo = 'Mobile number is required';
            }
            this.setState({ errors, errorMessage: null });
        }
    }

    loginToDashboard = (event) => {
        event.preventDefault();
        if (validateForm(this.state.errors) && this.state.email && this.state.OTP && this.state.mobileNo
            && this.state.validOTP === Number(this.state.OTP)) {
                this.setState({ loading: true });
                this.validateUser(this.state.mobileNo);                
        } else {
            let errors = this.state.errors;
            if (!this.state.email) {
                errors.email = 'Email is required';
            }
            if (!this.state.OTP) {
                errors.OTP = 'OTP is required';
            }
            if (!this.state.mobileNo) {
                errors.mobileNo = 'Mobile number is required';
            }
            if (this.state.validOTP !== Number(this.state.OTP)) {
                errors.OTP = 'OTP is invalid';
            }
            this.setState({ errors, errorMessage: null });
        }
    }

    sendOTP(mobileNo, OTP) {
        var values = { MobileNo: mobileNo, OTP: OTP };
        fetch('http://localhost:55002/api/DataValidation/User/SendOTP', {
            method: 'POST',
            mode: 'cors',
            body: JSON.stringify(values),
            headers: { 'Content-Type': 'application/json' }
        }).then((response) => response.json())
            .then((responseJson) => {
                if (responseJson) {  
                    console.log('OTP : ' + OTP);                  
                    this.setState({ loading: false, validOTP: OTP, mobileNo: mobileNo });
                }
            })
    }

    validateUser(mobileNo) {
        var values = { MobileNo: mobileNo };

        fetch('http://localhost:55002/api/DataValidation/User/ValidateUser', {
            method: 'POST',
            mode: 'cors',
            body: JSON.stringify(values),
            headers: { 'Content-Type': 'application/json' }
        }).then((response) => response.json())
            .then((responseJson) => {
                if (responseJson) {
                    sessionStorage.setItem('isAdminUser', 'Y');
                } else{
                    sessionStorage.setItem('isAdminUser', 'N');
                }
                sessionStorage.setItem('userEmail', this.state.email);
                sessionStorage.setItem('userMobileNo', this.state.mobileNo);
                const { history } = this.props;
                if (history) history.push('/MyProfile');
            })
    }

    handleChange = (event) => {
        event.preventDefault();
        const { name, value } = event.target;
        let errors = this.state.errors;

        switch (name) {
            case 'email':
                this.state.email = value;
                errors.email = value.length <= 0
                    ? 'Email is required' : !validEmailRegex.test(value) ? 'Email is not valid' : '';
                break;
            case 'mobileNo':
                this.state.mobileNo = value;                
                errors.mobileNo = value.length <= 0
                    ? 'Mobile number is required' : !Number(value) ? 'Mobile number is not valid' : '';
                break;
            case 'OTP':
                this.state.OTP = value;
                errors.OTP = value.length <= 0
                    ? 'OTP is required' : '';
                break;
            default:
                break;
        }
        this.setState({ errors, [name]: value });
    }

    render() {
        const { classes } = this.props;
        return (
            <div>
                <div className={classes.root}>
                    <CssBaseline />
                    <AppBar style={{ backgroundColor: 'white' }}
                        position="fixed"
                        className={clsx(classes.appBar, {
                            [classes.appBarShift]: this.state.open,
                        })}>
                        <Toolbar>
                            <Typography variant="h6" className={classes.alignment}>
                                <span className="header-font">Data Validation</span>
                            </Typography>
                            <div>
                                <Button style={{ backgroundColor: '#0079c2', color: 'white' }}
                                    onClick={this.openLogin}>
                                    <PersonIcon className={classes.leftIcon} />
                                    LOGIN
                                </Button>
                            </div>
                        </Toolbar>
                    </AppBar>
                </div>

                {this.state.loading ? (
                    <Loader />
                ) : (
                        <div>
                            <div className="home-body-message">
                                Welcome to Abhinava Events
                            </div>
                            <Popup contentStyle={{ width: "500px", height: "420px", borderRadius: "5px" }} open={this.state.open}
                                className="popup-modal-container-box"
                                modal onOpen={e => this.popupOnClose(e)} onClose={this.popupOnClose} lockScroll={true}
                                closeOnDocumentClick={false}>
                                <div className="modal-custom">
                                    <a className="close close-icon" onClick={this.closeLogin}>
                                        &times;
                                    </a>
                                    <div className="content">
                                        <form onSubmit={this.loginToDashboard} noValidate>
                                            <Grid container spacing={1}>
                                                <Grid item xs={12} style={{ fontSize: '22px', color: '#ff9800' }}>Login to Dashboard</Grid>
                                                <Grid item xs={12}>
                                                    <TextField required="true" name="mobileNo" fullWidth id="txtMobileNo" label="Mobile Number"
                                                        onChange={this.handleChange} noValidate value={this.state.mobileNo} />
                                                    {this.state.errors.mobileNo.length > 0 &&
                                                        <span className='error'>{this.state.errors.mobileNo}</span>}
                                                </Grid>
                                                <Grid item xs={12}>
                                                    <div className="marginTop">
                                                        <Button fullWidth style={{ backgroundColor: '#0079c2' }} variant="contained"
                                                            color="primary" onClick={this.getOTP}>GET OTP</Button>
                                                    </div>
                                                </Grid>
                                                <Grid item xs={12}>
                                                    <TextField required="true" name="email" fullWidth id="txtEmail" label="Email"
                                                        onChange={this.handleChange} noValidate />
                                                    {this.state.errors.email.length > 0 &&
                                                        <span className='error'>{this.state.errors.email}</span>}
                                                </Grid>
                                                <Grid item xs={12}>
                                                    <TextField fullWidth required="true" name="OTP" id="txtOTP" label="OTP"
                                                        onChange={this.handleChange} noValidate />
                                                    {this.state.errors.OTP.length > 0 &&
                                                        <span className='error'>{this.state.errors.OTP}</span>}
                                                </Grid>
                                                <Grid item xs={12}>
                                                    <div className="marginTop">
                                                        <Button fullWidth style={{ backgroundColor: '#0079c2' }} variant="contained"
                                                            color="primary" onClick={this.loginToDashboard}>SIGN IN</Button>
                                                    </div>
                                                </Grid>
                                                {this.state.errorMessage &&
                                                    <Grid item xs={12} className='error-main'>{this.state.errorMessage}</Grid>}
                                            </Grid>
                                        </form>
                                    </div>
                                </div>
                            </Popup>
                        </div>
                    )}
            </div>
        );
    }
}

export default withRouter(withStyles(useStyles)(Home))