const express = require('express');
const bodyParser = require('body-parser');
const routesHandler = require('./routes/handler.js');
var cors = require('cors');

const app = express();
app.use(cors());
//app.use(bodyParser.urlencoded({extended:false}));
//app.use(bodyParser.json);
app.use('/', routesHandler);

const PORT = 4001;
app.listen(PORT, () => {
    console.log(`server is running on port ${PORT}.`);
})