import React, { Component, Fragment } from 'react';
import { 
    Grid, withStyles, Button, Card, CardContent, AppBar, Typography, CardHeader, IconButton, Divider, Toolbar, Avatar,
    Backdrop, CircularProgress
} from '@material-ui/core';
import { useStyles } from './common/useStyles';
import './common/Common.css'
import classNames from 'classnames';
import VisibilityIcon from '@material-ui/icons/Visibility';
import Add1 from './images/add1.jpg';
import Add2 from './images/add2.jpg';
import Img1 from './images/img1.jpg';
import MenuIcon from './images/menu_icon.png';
import AddQuestionIcon from './images/Add-a-Question.png';
import QuestionIcon from './images/Question.png';
import MessageIcon from './images/mesage.png';
import LikeIcon from './images/like.png';
import VoteIcon from './images/votes_icon.png';
import PollIcon from './images/poll.png';
import api from './common/APIValues';
import InfiniteScroll from "react-infinite-scroll-component";
import EDWhatLogo from './images/logo.png';

class Topics extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            userTopics: [], loader: false, disableAddQue: false, currentPage: 1, isPopular: 0, pages: 0,
        }
    }

    componentDidMount() {
        sessionStorage.setItem('topic_id', '');
        this.setState({ 
            disableAddQue: this.props.userEmail && this.props.userAliasName ? false : true
        });
        this.loadUserTopics(0);
    }

    componentDidUpdate = (prevProps, prevState) => {
        if (this.props.userEmail !== prevProps.userEmail || this.props.userAliasName !== prevProps.userAliasName) {            
            this.setState({ 
                disableAddQue: this.props.userEmail && this.props.userAliasName ? false : true
            });
        }

        if(this.props.isPopular !== prevProps.isPopular) {
            this.loadUserTopics(this.props.isPopular);
        }
    }

    loadUserTopics(sortInd) {
        this.setState({ loader: true });
        fetch(api.partialURL + 'UserTopic/GetUserTopics?SORT_IND=' + sortInd + '&PAGE_NUM=' + this.state.currentPage)
            .then(res => res.json())
            .then(result => {
                this.setState({ userTopics: [] });
                this.setState({ 
                    userTopics: result.userTopics, loader: false, pages: result.pages
                });
            })
            .catch(err => console.log(err));
    }

    viewTopicDetails = (topicId, topicPostType, topicTitle) => {
        const { history } = this.props;
        //sessionStorage.setItem('topic_id', topicId);
        if (history) history.push({
            pathname: topicPostType === 'QUESTION' ? '/topics/question/comments/' + topicId + '/' + topicTitle.toLowerCase().replace(/ /g, '-')
                : '/topics/poll/comments/' + topicId + '/' + topicTitle.toLowerCase().replace(/ /g, '-')
        });
    }

    fetchMoreData = () => {
        if(this.state.pages - this.state.currentPage !== 0) {
            this.setState({ currentPage: this.state.currentPage + 1 });
            this.loadUserTopics(this.state.isPopular);
        }
    };

    render() {
        const { classes } = this.props;
        const subHeader = classNames(classes.posTop, classes.subHeader);
        const wrapIcon = classNames(classes.wrapIcon, classes.subHeader);
        const buttonSpacing = classNames(classes.customButtonError, classes.buttonSpacing);

        return (
            <Fragment>
                <Backdrop className={classes.backdrop} open={this.state.loader}>
                    <CircularProgress color="inherit" />
                </Backdrop>

                <Grid container spacing={1} style={{ marginTop: '45px' }}>
                    <Grid item xs={9}>
                            <InfiniteScroll style={{ overflow: 'hidden' }}
                                dataLength={this.state.userTopics.length}
                                next={this.fetchMoreData}
                                hasMore={this.state.pages - this.state.currentPage !== 0}
                                //loader={<h4>Loading...</h4>}
                            >
                                <Grid container spacing={1}>
                                { this.state.userTopics.map((topic, row) => (
                                    <Grid item xs={12} key={topic.TOPIC_ID}>
                                        <Card>
                                            <CardHeader style={{ cursor: 'pointer' }} classes={{ title: classes.title, subheader: classes.subTitle }}
                                                onClick={() => this.viewTopicDetails(topic.TOPIC_ID, topic.TOPIC_POST_TYPE, topic.TOPIC_TITLE)}
                                                title={topic.TOPIC_TITLE}
                                                action={
                                                <IconButton aria-label="questions">                                                
                                                    { topic.TOPIC_POST_TYPE === 'QUESTION' ?
                                                        <img src={QuestionIcon} height={20} alt="QuestionIcon" /> :
                                                        <img src={PollIcon} height={20} alt="PollIcon" />
                                                    }
                                                </IconButton>
                                                }
                                                subheader={ 'posted by ' + topic.TOPIC_UPDT_USER_NM + ' ' + topic.TOPIC_UPDT_DTM + ' ago' }
                                            />
                                            <CardContent>
                                                <div onClick={() => this.viewTopicDetails(topic.TOPIC_ID, topic.TOPIC_POST_TYPE, topic.TOPIC_TITLE)}
                                                    style={{ cursor: 'pointer' }}>
                                                    <Typography className={subHeader} gutterBottom color="textSecondary">                                                    
                                                        <div dangerouslySetInnerHTML={{ __html: topic.TOPIC_DESC }} />
                                                    </Typography>
                                                    { topic.TOPIC_POST_TYPE === 'QUESTION' && topic.TOPIC_IMG_URL &&
                                                        <Typography>
                                                            <img src={topic.TOPIC_IMG_URL} 
                                                                style={{width: '100%', padding: '10px 40px 10px 40px'}} />
                                                        </Typography>
                                                    }
                                                </div>
                                                <Typography style={{ marginTop: topic.TOPIC_POST_TYPE === 'POLL' ? '10px' : '0px' }}
                                                    className={wrapIcon} color="textSecondary">
                                                    <img src={ topic.TOPIC_POST_TYPE === 'QUESTION' ? LikeIcon : VoteIcon } height={17} style={{ marginRight: '5px' }} /> 
                                                        {topic.TOPIC_LIKE_VOTE} {topic.TOPIC_POST_TYPE === 'QUESTION' ? 'Likes' : 'Votes'}                                                
                                                    <Divider orientation="vertical" flexItem className={classes.marginLeftRight} />
                                                    
                                                    { topic.TOPIC_POST_TYPE === 'POLL' &&
                                                        <div>
                                                            <img src={ LikeIcon } height={17} style={{ marginRight: '5px' }} /> 
                                                                {topic.TOPIC_POLL_LIKE + ' Likes'}
                                                        </div>
                                                    }
                                                    { topic.TOPIC_POST_TYPE === 'POLL' &&
                                                        <Divider orientation="vertical" flexItem className={classes.marginLeftRight} />
                                                    }

                                                    <img src={MessageIcon} height={17} style={{ marginRight: '5px' }} alt="MessageIcon" /> 500 Comments
                                                    <Divider orientation="vertical" flexItem className={classes.marginLeftRight} />

                                                    <VisibilityIcon className={classes.iconSize} style={{ marginRight: '5px' }} /> {topic.TOPIC_VIEW}
                                                </Typography>
                                            </CardContent>
                                        </Card>
                                    </Grid>
                                ))}
                                </Grid>
                            </InfiniteScroll>
                    </Grid>
                    <Grid item xs={3}>
                        <Grid container spacing={1}>
                            <Grid item xs={12}>
                                <Card>
                                    <CardContent>
                                        <Typography>
                                            <img src={Add1} alt="Logo" style={{ 
                                                width: '100%', marginBottom: '-8px' }} />
                                        </Typography>
                                    </CardContent>
                                </Card>
                            </Grid>
                            <Grid item xs={12}>
                                <Card>
                                    <CardContent>
                                        <Typography>
                                            <img src={Add2} alt="Logo" style={{ 
                                                width: '100%', marginBottom: '-8px' }} />
                                        </Typography>
                                    </CardContent>
                                </Card>
                            </Grid>
                        </Grid>
                    </Grid>                    
                </Grid>
            </Fragment>
        );
    }
}

export default withStyles(useStyles)(Topics)