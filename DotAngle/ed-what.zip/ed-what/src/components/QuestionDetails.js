import React, { Component, Fragment } from 'react';
import { 
    Grid, withStyles, Button, Breadcrumbs, Card, CardContent, AppBar, Typography, CardHeader, IconButton, Toolbar, TextField,
    CircularProgress, Backdrop, Link
} from '@material-ui/core';
import { useStyles } from './common/useStyles';
import './common/Common.css'
import classNames from 'classnames';
import VisibilityIcon from '@material-ui/icons/Visibility';
import Add1 from './images/add1.jpg';
import Add2 from './images/add2.jpg';
import Img1 from './images/img1.jpg';
import ShareIcon from '@material-ui/icons/Share';
import AddQuestionIcon from './images/Add-a-Question.png';
import MessageIcon from './images/mesage.png';
import LikeIcon from './images/like.png';
import api from './common/APIValues';
import FlagIcon from '@material-ui/icons/Flag';
import axios from 'axios';
import NavigateNextIcon from '@material-ui/icons/NavigateNext';
import EDWhatLogo from './images/logo.png';

class QuestionDetails extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            userTopic: {}, comment_text: '', userTopicComments: [], loader: false, disableAddQue: false,
            likesInd: true, viewInd: true,
        }
    }

    componentDidMount() {
        //let TOPIC_ID = sessionStorage.getItem('topic_id');
        let topicId = this.props.match.params.topicId;
        this.setState({ 
            disableAddQue: this.props.userEmail && this.props.userAliasName ? false : true
        });
        this.loadUserTopicComments(topicId);
    }

    componentDidUpdate = (prevProps, prevState) => {
        if (this.props.userEmail !== prevProps.userEmail || this.props.userAliasName !== prevProps.userAliasName) {            
            this.setState({ 
                disableAddQue: this.props.userEmail && this.props.userAliasName ? false : true
            });
        }
    }

    loadUserTopicComments(topicId) {
        this.setState({ loader: true });
        fetch(api.partialURL + 'UserQueTopic/GetUserQueTopic?TOPIC_ID=' + topicId + '&USER_ID=' + this.props.userEmail + '&USER_NM=' + this.props.userAliasName)
            .then(res => res.json())
            .then(result => { 
                this.setState({ 
                    userTopic: result, loader: false, 
                    likesInd: result.TOPIC_LIKE_IND === 1 ? false : true,
                    viewInd: result.TOPIC_VIEW_IND === 1 ? false : true
                });                
            })
            .catch(err => console.log(err));
    }

    saveUserQueLike = () => {
        if(this.state.likesInd && this.props.userEmail && this.props.userAliasName) {
            this.setState({ loader: true });
            let rowData = {
                TOPIC_ID: this.state.userTopic.TOPIC_ID,
                TOPIC_UPDT_USER_ID: this.props.userEmail,
                TOPIC_UPDT_USER_NM: this.props.userAliasName
            }

            axios({
                method: 'post',
                url: api.partialURL + 'UserQueTopic/SaveUserQueLike',
                data: JSON.stringify(rowData),
                headers: { 'Content-Type': 'application/json' },
                mode: 'cors',
            })
            .then(res => {
                if(res) {                
                    if (res.data === 'success') {
                        this.loadUserTopicComments(this.state.userTopic.TOPIC_ID);
                    }
                }
            })
            .catch(function (response) {
                this.setState({ err_msg: response, loader: false });
            });
        }
    }

    render() {
        const { classes } = this.props;
        const subHeader = classNames(classes.posTop, classes.subHeader);
        const wrapIcon = classNames(classes.wrapIcon, classes.subHeader);
        
        return (
            <Fragment>
                <Backdrop className={classes.backdrop} open={this.state.loader}>
                    <CircularProgress color="inherit" />
                </Backdrop>

                <Grid container spacing={1} style={{ marginTop: '45px' }}>
                    <Grid item xs={9}>
                        <Grid container spacing={1}>
                                <Grid item xs={12} key={this.state.userTopic.TOPIC_ID}>
                                    <Card>
                                        <CardHeader classes={{ title: classes.title, subheader: classes.subTitle }}
                                            title={this.state.userTopic.TOPIC_TITLE}                                            
                                            subheader={ 'posted by ' + this.state.userTopic.TOPIC_UPDT_USER_NM + ' ' + 
                                                this.state.userTopic.TOPIC_UPDT_DTM + ' ago' }
                                        />
                                        <CardContent>
                                            <Typography className={subHeader} gutterBottom color="textSecondary">                                                
                                                <div dangerouslySetInnerHTML={{ __html: this.state.userTopic.TOPIC_DESC }} />
                                            </Typography>
                                            { this.state.userTopic.TOPIC_IMG_URL &&
                                                <Typography>
                                                    <img src={this.state.userTopic.TOPIC_IMG_URL}
                                                        style={{width: '100%', padding: '10px 40px 10px 40px'}} />
                                                </Typography>
                                            }
                                            <Typography>
                                                <TextField fullWidth name="comment_text" label="Write your comment" required
                                                    onChange={this.handleChange} noValidate value={this.state.comment_text}
                                                    variant="outlined" style={{ backgroundColor: '#f6f7f2' }} />
                                            </Typography>
                                            <Typography style={{ marginTop: '20px' }} className={wrapIcon} color="textSecondary">
                                                <img src={MessageIcon} height={17} style={{ marginRight: '5px' }} alt="message" />
                                                    500 Comments
                                                <IconButton onClick={this.saveUserQueLike} style={{ padding: 0, fontSize: '0.8rem', marginLeft:'10px' }} 
                                                    aria-label="share" >
                                                    <img src={LikeIcon} height={17} style={{marginRight:'5px'}} alt="likes" />
                                                        {this.state.userTopic.TOPIC_LIKE} Likes
                                                </IconButton>
                                                <VisibilityIcon className={classes.iconSize} style={{marginRight:'5px',marginLeft:'10px'}} /> 
                                                    {this.state.userTopic.TOPIC_VIEW}
                                                <IconButton style={{ padding: 0, fontSize: '0.8rem', marginLeft:'10px' }} aria-label="share" >
                                                    <ShareIcon className={classes.iconSize} style={{marginRight:'5px'}} /> 
                                                        Share
                                                </IconButton>
                                                <IconButton style={{ padding: 0, fontSize: '0.8rem', marginLeft:'10px' }} aria-label="report" >
                                                    <FlagIcon className={classes.iconSize} style={{marginRight:'5px'}} />
                                                        Report
                                                </IconButton>
                                            </Typography>
                                        </CardContent>
                                    </Card>
                                </Grid>
                        </Grid>
                    </Grid>
                    <Grid item xs={3}>
                        <Grid container spacing={1}>
                            <Grid item xs={12}>
                                <Card>
                                    <CardContent>
                                        <Typography>
                                            <img src={Add1} alt="Logo" style={{ 
                                                width: '100%', marginBottom: '-8px' }} />
                                        </Typography>
                                    </CardContent>
                                </Card>
                            </Grid>
                            <Grid item xs={12}>
                                <Card>
                                    <CardContent>
                                        <Typography>
                                            <img src={Add2} alt="Logo" style={{ 
                                                width: '100%', marginBottom: '-8px' }} />
                                        </Typography>
                                    </CardContent>
                                </Card>
                            </Grid>
                        </Grid>
                    </Grid>                    
                </Grid>
            </Fragment>
        );
    }
}

export default withStyles(useStyles)(QuestionDetails)