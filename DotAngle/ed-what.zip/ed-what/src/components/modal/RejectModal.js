import React, { Component } from 'react';
import CloseIcon from '@material-ui/icons/Close';
import Popup from "reactjs-popup";
import { Button, TextField, Grid, withStyles } from '@material-ui/core';
import './Modal.css';
import PropTypes from 'prop-types';
import ThumbDownIcon from '@material-ui/icons/ThumbDown';
import { useStyles } from '../common/useStyles';

// const useStyles = theme => ({
//     leftIcon: {
//         marginRight: theme.spacing.unit,
//     },
//     root: {
//         fontSize: 12, height: '2.1rem',
//         backgroundColor: "#0079c2",
//         "&:hover": {
//             backgroundColor: "#0079c2"
//         },
//         "&:disabled": {
//             backgroundColor: "rgba(0, 0, 0, 0.12)"
//         },
//     },
// });

const validateForm = (errors) => {
    let valid = true;
    Object.keys(errors).map(function (e) {
        if (errors[e].length > 0) {
            valid = false;
        }        
    });
    return valid;
}

class RejectModal extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            open: false, rejectReason: null,
            errors: {
                rejectReason: '',
            }
        };
        this.openModal = this.openModal.bind(this);
        this.closeModal = this.closeModal.bind(this);
        this.popupOnClose = this.popupOnClose.bind(this);
    }

    openModal() {        
        this.setState({ open: true });
    }

    closeModal() {
        let errors = this.state.errors;
        errors.rejectReason = '';
        this.setState({ open: false, errors });
    }
    popupOnClose() { }

    approveRejectDisableVendor = () => {
        if (validateForm(this.state.errors) && this.state.rejectReason) {
            if (typeof this.props.onClick === 'function') {
                this.props.onClick('Rejected', this.state.rejectReason);
                this.closeModal();
            }
        } else {
            let errors = this.state.errors;
            if (!this.state.rejectReason) {
                errors.rejectReason = 'Reject reason is required.';
            }
            this.setState({ errors, errorMessage: null });
        }
    }

    handleChange = (event) => {
        event.preventDefault();
        const { name, value } = event.target;
        let errors = this.state.errors;

        switch (name) {
            case 'rejectReason':
                this.state.rejectReason = value;
                errors.rejectReason = value.length <= 0 ? 'Reject reason is required.' : '';
                break;
        }
        this.setState({ errors, [name]: value });
    }

    render() {
        const { classes } = this.props;

        return (
            <div>
                <Popup contentStyle={{ width: "500px", height: "220px", borderRadius: "5px" }} open={this.state.open}
                    className="popup-modal-container-box" modal onOpen={e => this.popupOnClose(e)}
                    onClose={this.popupOnClose} lockScroll={true} closeOnDocumentClick={false}>
                    <div className="modal-custom">
                        <div className="header">Confirmation</div>
                        <div className="content-reject">
                            <Grid container spacing={0}>                                                            
                                <Grid item xs={12}>
                                    <TextField fullWidth required="true" name="rejectReason" id="txtRejectReason" 
                                        label="Reject Reason" onChange={this.handleChange} noValidate value={this.state.rejectReason} />
                                    {this.state.errors.rejectReason.length > 0 &&
                                        <span className='error'>{this.state.errors.rejectReason}</span>}
                                </Grid>                                
                            </Grid>
                        </div>
                        <Grid className="actions" container spacing={1}>
                            <Grid item xs={6}>                                
                            </Grid>
                            <Grid item xs={3}>
                                <Button className={classes.rootModal} color="primary" variant="contained" 
                                    onClick={() => this.approveRejectDisableVendor()}>
                                    <ThumbDownIcon className={classes.leftIcon} />Reject</Button>
                            </Grid>
                            <Grid item xs={3}>
                                <Button className={classes.rootModal} color="primary" variant="contained" onClick={this.closeModal}>
                                    <CloseIcon className={classes.leftIcon} />Close</Button>
                            </Grid>
                        </Grid>
                    </div>
                </Popup>
            </div>
        );
    }
}

RejectModal.propTypes = {
    onClick: PropTypes.func
};

export default withStyles(useStyles)(RejectModal)