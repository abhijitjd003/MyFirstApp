import React, { Component } from 'react';
import CloseIcon from '@material-ui/icons/Close';
import Popup from "reactjs-popup";
import { Button, TextField, Grid, withStyles, MenuItem, Select } from '@material-ui/core';
import './Modal.css';
import PropTypes from 'prop-types';
import DoneIcon from '@material-ui/icons/Done';
import api from '../common/APIValues';
import { useStyles } from '../common/useStyles';

// const useStyles = theme => ({
//     leftIcon: {
//         marginRight: theme.spacing.unit,
//     },
//     root: {
//         fontSize: 12, height: '2.1rem',
//         backgroundColor: "#0079c2",
//         "&:hover": {
//             backgroundColor: "#0079c2"
//         },
//         "&:disabled": {
//             backgroundColor: "rgba(0, 0, 0, 0.12)"
//         },
//     },
// });

const validateForm = (errors) => {
    let valid = true;
    Object.keys(errors).map(function (e) {
        if (errors[e].length > 0) {
            valid = false;
        }        
    });
    return valid;
}

class RouteModal extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            open: false, rejectReason: null, routes: [], routeCategory: '0',
            errors: {
                routeCategory: '',
            }
        };
        this.openModal = this.openModal.bind(this);
        this.closeModal = this.closeModal.bind(this);
        this.popupOnClose = this.popupOnClose.bind(this);
        this.onRouteChanged = this.onRouteChanged.bind(this);
    }

    openModal() {        
        this.setState({ open: true });
    }

    closeModal() {
        let errors = this.state.errors;
        errors.routeCategory = '';
        this.setState({ open: false, routeCategory: '0', errors });
    }
    popupOnClose() { }

    assignRoute = () => {
        if (validateForm(this.state.errors) && this.state.routeCategory !== '0') {
            if (typeof this.props.onClick === 'function') {
                this.props.onClick(this.state.routeCategory);
                this.closeModal();
            }
        } else {
            let errors = this.state.errors;
            if (this.state.routeCategory === '0') {
                errors.routeCategory = 'Select route category.';
            }
            this.setState({ errors, errorMessage: null });
        }
    }

    loadRoutes(){
        let partialUrl = api.URL;
        fetch(partialUrl + 'Customer/GetRoutes')
            .then(res => res.json())
            .then(result => this.setState({ routes: result, }))
            .catch(err => console.log(err));
    }

    componentDidMount() {        
        this.loadRoutes();        
    }

    onRouteChanged(e) {
        let route = e.target.value;
        let errors = this.state.errors;
        if(route === '0'){
            errors.routeCategory = 'Select route category';
        }else{
            errors.routeCategory = '';
        }        
        this.setState({ routeCategory: route, errors });
    };

    render() {
        const { classes } = this.props;
        let _routes = this.state.routes;
        let routes = _routes.map((route) =>
                <MenuItem value={route.RouteCategory}>{route.RouteName}</MenuItem>
            );

        return (
            <div>
                <Popup contentStyle={{ width: "500px", height: "220px", borderRadius: "5px" }} open={this.state.open}
                    className="popup-modal-container-box" modal onOpen={e => this.popupOnClose(e)}
                    onClose={this.popupOnClose} lockScroll={true} closeOnDocumentClick={false}>
                    <div className="modal-custom">
                        <div className="header">Assign Route</div>
                        <div className="content-reject">
                            <Grid container spacing={0}>                                                                                            
                                <Grid item xs={12}>
                                    <Select fullWidth id="ddRoute" value={this.state.routeCategory} onChange={ this.onRouteChanged }
                                        className="selectTopMargin">
                                        {routes}
                                    </Select>
                                    {this.state.errors.routeCategory.length > 0 &&
                                        <span className='error'>{this.state.errors.routeCategory}</span>}
                                </Grid>                                
                            </Grid>
                        </div>
                        <Grid className="actions" container spacing={1}>
                            <Grid item xs={6}>                                
                            </Grid>
                            <Grid item xs={3}>
                                <Button className={classes.rootModal} color="primary" variant="contained" 
                                    onClick={() => this.assignRoute()}>
                                    <DoneIcon className={classes.leftIcon} />Assign</Button>
                            </Grid>
                            <Grid item xs={3}>
                                <Button className={classes.rootModal} color="primary" variant="contained" onClick={this.closeModal}>
                                    <CloseIcon className={classes.leftIcon} />Close</Button>
                            </Grid>
                        </Grid>
                    </div>
                </Popup>
            </div>
        );
    }
}

RouteModal.propTypes = {
    onClick: PropTypes.func
};

export default withStyles(useStyles)(RouteModal)