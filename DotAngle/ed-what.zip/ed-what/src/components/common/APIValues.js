export default {
    partialURL: 'http://myveggiebox.in/api/'
    //partialURL: 'http://demo.farmar.in/api/'
    //partialURL: 'http://localhost:51878/api/'
    //partialURL: 'http://conferencepresentations.in/api/'
}