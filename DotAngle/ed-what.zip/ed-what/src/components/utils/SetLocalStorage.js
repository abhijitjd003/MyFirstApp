export const setLoginInfo = (name, email) => {
    localStorage.setItem('user_name', name);
    localStorage.setItem('user_email', email);
}

export const setUserAliasName = (aliasName) => {
    localStorage.setItem('user_alias_name', aliasName);
}