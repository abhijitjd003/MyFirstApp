import React, { Component } from 'react';
import { Route } from 'react-router';
import Layout from './components/Layout';
import Topics from './components/Topics';
import QuestionDetails from './components/QuestionDetails';
import PollDetails from './components/PollDetails';
import SocialLogin from './components/navmenu/SocialLogin';
import { setLoginInfo, setUserAliasName } from './components/utils/SetLocalStorage';
import MyProfile from './components/MyProfile';
import AddQuestion from './components/AddQuestion';
import { DialogContent, IconButton, Grid, Dialog, TextField, DialogActions, Button } from '@material-ui/core';
import CloseIcon from '@material-ui/icons/Close';

export default class App extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            open: false,
            email: '',
            showAlias: false,
            showProfile: false,
            alias_name: '',
            alias_name_err: '',
            prev_page: '',
            isPopular: 0,
        };
    }

    userLogin = () => {
        this.setState({ open: true });
        let name = localStorage.getItem('user_name');
        let email = localStorage.getItem('user_email');
        let alias_name = localStorage.getItem('user_alias_name');

        if(name && email && !alias_name) {
            this.setState({ showAlias: true });
        } else if(name && email && alias_name) {
            const { history } = this.props;
            if (history) history.push({ pathname: '/myprofile' });
        }
    }

    handleClose = () => {
        this.setState({ open: false });
    };

    handleAliasClose = () => {
        this.setState({ showAlias: false });
    }

    handleChange = (event) => {
        this.setState({ 
            alias_name: event.target.value,
            alias_name_err: event.target.value.length <= 0 ? 'Please enter alias name' : ''
        });
    }

    saveChanges = () => {
        if(this.validateAllInputs() && !this.state.alias_name_err) {
            setUserAliasName(this.state.alias_name);
            this.setState({ showAlias: false });
        } else {
            if (!this.state.alias_name) {
                this.setState({ alias_name_err: 'Please enter alias name' });
            }
        }
    }

    validateAllInputs = () => {
        if(!this.state.alias_name) {
            return false; 
        }
        else{ return true; }
    }

    onGoogleLoginSuccess = (res) => {
        if(res.profileObj) {
            console.log('[Login Success] currentUser: ', res);
            setLoginInfo(res.profileObj.name, res.profileObj.email);
            this.setState({ email: res.profileObj.email, open: false, showAlias: true });
        }
    };

    onGoogleLoginFailure = (res) => {
        console.log('[Login Failed] res: ', res);
        localStorage.clear();
    }

    componentDidMount() {
        this.setState({ 
            email: localStorage.getItem('user_email'),
            alias_name: localStorage.getItem('user_alias_name')
        });
    }

    addQuestion = () => {        
        let name = localStorage.getItem('user_name');
        let email = localStorage.getItem('user_email');
        let alias_name = localStorage.getItem('user_alias_name');

        if(!name && !email && !alias_name) {
            this.setState({ open: true });
        } else if(name && email && !alias_name) {
            this.setState({ showAlias: true });
        } else if(name && email && alias_name) {
            const { history } = this.props;
            //sessionStorage.setItem('redirect_screen_nm', this.props.location.pathname);
            this.setState({ prev_page: this.props.location.pathname });
            if (history) history.push({
                pathname: '/topics/askEDWhat'
            });
        }
    }

    sortByPopular = () => {
        this.setState({isPopular: 1});        
    }

    sortByNew = () => {
        this.setState({isPopular: 0});        
    }

    render() {
        const name = localStorage.getItem('user_name');
        const email = localStorage.getItem('user_email');
        const alias_name = localStorage.getItem('user_alias_name');

        return (
            <Layout userLogin={this.userLogin} 
                    userEmail={email} 
                    userName={name}
                    userAliasName={alias_name} 
                    sortByPopular={this.sortByPopular}
                    sortByNew={this.sortByNew}
                    prev_page={this.state.prev_page}
                    addQuestion={this.addQuestion}>
                
                {/* Social Login (Google/Facebook) */}
                { this.state.open && !name && !email &&
                    <SocialLogin open={this.state.open}
                        handleClose={this.handleClose}
                        onGoogleLoginSuccess={this.onGoogleLoginSuccess}
                        onGoogleLoginFailure={this.onGoogleLoginFailure}
                    />
                }

                {/* If Login Success, Set User Alias Name */}
                { this.state.showAlias && name && email && !alias_name &&
                    <React.Fragment>
                        <Dialog fullWidth open={this.state.showAlias}
                            onClose={this.handleAliasClose} disableBackdropClick
                            aria-labelledby="alert-dialog-title"
                            aria-describedby="alert-dialog-description"
                        >
                            <DialogContent style={{ backgroundColor: '#f6f7f2' }}>
                                <Grid container spacing={0}>
                                    <Grid item xs={11}></Grid>
                                    <Grid item xs={1}>
                                        <IconButton style={{ marginLeft: '22px', marginTop: '-20px' }} onClick={this.handleAliasClose} 
                                            aria-label="settings">
                                            <CloseIcon />
                                        </IconButton>
                                    </Grid>
                                </Grid>
                                <TextField fullWidth name="alias_name" label="Enter alias name" required onChange={this.handleChange} 
                                    noValidate onKeyUp={this.handleKeyPress}
                                    value={alias_name} variant="outlined" style={{ backgroundColor: 'white' }}
                                />
                                { this.state.alias_name_err.length > 0 && 
                                    <span className='error'>{this.state.alias_name_err}</span> }
                            </DialogContent>
                            <DialogActions style={{ backgroundColor: '#f6f7f2' }}>
                                <Button onClick={this.saveChanges} color="primary">
                                    Save
                                </Button>
                            </DialogActions>
                        </Dialog>
                    </React.Fragment>
                }

                <Route exact path='/' render={(props) => 
                    <Topics {...props} userEmail={email} userAliasName={alias_name} isPopular={this.state.isPopular} />} />
                <Route exact path='/topics' render={(props) => 
                    <Topics {...props} userEmail={email} userAliasName={alias_name} isPopular={this.state.isPopular} />} />
                <Route exact path='/topics/question/comments/:topicId/:title' render={(props) => 
                    <QuestionDetails {...props} userEmail={email} userAliasName={alias_name} />} />
                <Route exact path='/topics/poll/comments/:topicId/:title' render={(props) => 
                    <PollDetails {...props} userEmail={email} userAliasName={alias_name} />} />
                <Route exact path='/myprofile' render={(props) => 
                    <MyProfile {...props} userEmail={email} userAliasName={alias_name} />} />
                <Route exact path='/topics/askEDWhat' render={(props) => 
                    <AddQuestion {...props} userEmail={email} userAliasName={alias_name} />} />                
            </Layout>
        );
    }
}
