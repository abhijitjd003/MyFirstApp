-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 182.50.133.79:3306
-- Generation Time: Aug 11, 2020 at 10:34 PM
-- Server version: 5.5.51-38.1-log
-- PHP Version: 7.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `FarmarMarket`
--
CREATE DATABASE IF NOT EXISTS `FarmarMarket` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `FarmarMarket`;

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `UspAddCustomer`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspAddCustomer` (IN `p_ShopId` INT, IN `p_ShopName` VARCHAR(50), IN `p_ContactPerson` VARCHAR(50), IN `p_MobileNo` BIGINT, IN `p_Email` VARCHAR(30), IN `p_Address` VARCHAR(100), IN `p_Location` VARCHAR(400), IN `p_GSTNo` VARCHAR(30), IN `p_ReferralCode` VARCHAR(20), IN `p_AlternateContactNo` BIGINT, IN `p_CreatedDateTime` DATETIME, IN `p_UpdatedDateTime` DATETIME, IN `p_UserId` VARCHAR(50), IN `p_ShopImage1` VARCHAR(200), IN `p_ShopImage2` VARCHAR(200), IN `p_ShopImage3` VARCHAR(200), IN `p_PinCode` BIGINT)  BEGIN
	IF p_ShopId = 0 THEN
    BEGIN
		SET @DuplicateShop := 0;
		SELECT @DuplicateShop := ShopId FROM ShopDetails
		WHERE MobileNo = p_MobileNo;
        
        IF @DuplicateShop = 0 THEN
        BEGIN
			INSERT INTO ShopDetails
			(				
				ShopName,
				Address,
                GSTNo,
                ReferralCode,
                MobileNo,
                Status,
                Location,
				CreatedDateTime,
				UpdatedDateTime,
                UpdatedUserId,
				CreatedUserId,				
                AlternateContactNo,
                Email,
                ContactPerson,
                PinCode
			)
			SELECT
				p_ShopName,
				p_Address,
                p_GSTNo,
                p_ReferralCode,
                p_MobileNo,
                'InProgress',
                p_Location,
				p_CreatedDateTime,
				p_UpdatedDateTime,
                p_UserId,
				p_UserId,				
                p_AlternateContactNo,
                p_Email,
                p_ContactPerson,
                p_PinCode;
			
            INSERT INTO ShopImages
            (
				Image1, 
                Image2, 
                Image3,
                ShopId
            )
            SELECT 
				p_ShopImage1,
                p_ShopImage2,
                p_ShopImage3,
                last_insert_id();
            
            UPDATE ShopImages
            SET Image1 = replace(Image1, 'shop_id', last_insert_id()),
				Image2 = replace(Image2, 'shop_id', last_insert_id()),
                Image3 = replace(Image3, 'shop_id', last_insert_id())
            WHERE ShopId = last_insert_id();
            
			SELECT 'success' Message, last_insert_id() ShopId;
		END;
        ELSE
        BEGIN
			SELECT 'error' Message, 0 ShopId;
        END;
        END IF;
	END;
    ELSE
    BEGIN		
        UPDATE ShopDetails
		SET ShopName = p_ShopName,
			Address = p_Address,
			GSTNo = p_GSTNo,
			ReferralCode = p_ReferralCode,
			MobileNo = p_MobileNo,			
			Location = p_Location,			
			UpdatedDateTime = p_UpdatedDateTime,
			UpdatedUserId = p_UserId,			
			AlternateContactNo = p_AlternateContactNo,
			Email = p_Email,
			ContactPerson = p_ContactPerson,
            Status = 'InProgress',
            PinCode = p_PinCode
		WHERE ShopId = p_ShopId;
        
        UPDATE ShopImages
		SET Image1 = CASE WHEN p_ShopImage1 IS NULL OR p_ShopImage1 = '' 
				THEN Image1 ELSE p_ShopImage1 END,
			Image2 = CASE WHEN p_ShopImage2 IS NULL OR p_ShopImage2 = '' 
				THEN Image2 ELSE p_ShopImage2 END,
			Image3 =  CASE WHEN p_ShopImage3 IS NULL OR p_ShopImage3 = '' 
				THEN Image3 ELSE p_ShopImage3 END
		WHERE ShopId = p_ShopId;
        
        UPDATE ShopImages
		SET Image1 = replace(Image1, 'shop_id', p_ShopId),
			Image2 = replace(Image2, 'shop_id', p_ShopId),
			Image3 = replace(Image3, 'shop_id', p_ShopId)
		WHERE ShopId = p_ShopId;
        
        SELECT * FROM ShopImages
        WHERE ShopId = p_ShopId;
        
        SELECT 'success' Message;
    END;
    END IF;
END$$

DROP PROCEDURE IF EXISTS `UspApproveRejectDisableCustomer`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspApproveRejectDisableCustomer` (IN `p_ShopId` INT, IN `p_Status` VARCHAR(30), IN `p_UpdatedDateTime` DATETIME, IN `p_UserId` VARCHAR(50), IN `p_RejectReason` VARCHAR(100))  BEGIN
	UPDATE ShopDetails
    SET Status = p_Status,
		RejectedReason = p_RejectReason,
        UpdatedDateTime = p_UpdatedDateTime,
        UpdatedUserId = p_UserId
	WHERE ShopId = p_ShopId;
END$$

DROP PROCEDURE IF EXISTS `UspAssignRouteToOrder`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspAssignRouteToOrder` (IN `p_OrderNo` BIGINT, IN `p_RouteCategory` VARCHAR(30))  BEGIN
	UPDATE Orders
    SET Route = p_RouteCategory
	WHERE OrderNo = p_OrderNo;
END$$

DROP PROCEDURE IF EXISTS `UspCreateOrders`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspCreateOrders` (IN `p_OrderNo` BIGINT, IN `p_PassCode` INT, IN `p_OrderedDateTime` DATETIME, IN `p_ShopId` INT, IN `p_UserId` VARCHAR(50), IN `p_OrderMode` VARCHAR(30))  BEGIN
	INSERT INTO Orders
    (		
        PassCode,
        OrderedDateTime,
        ShopId,
        Status,
        CreatedUserId,
        UpdatedUserId,
        UpdatedDateTime,
        DeliveryDate,
        DeliveryTime,
        OrderMode,
        PaymentStatus
    )
	SELECT		
        p_PassCode,
        p_OrderedDateTime,
        p_ShopId,
        'Initiated',
        p_UserId,
        p_UserId,
        p_OrderedDateTime,
        DATE_ADD(now(), INTERVAL 2190 MINUTE),
        '07:00 AM - 10:00 AM',
        p_OrderMode,
        'Pending';
        
	UPDATE Orders SET OrderNo = CONCAT(YEAR(NOW()), CASE WHEN LENGTH(MONTH(NOW())) = 1 
			THEN CONCAT(0, MONTH(NOW())) ELSE MONTH(NOW()) END, 
            CASE WHEN LENGTH(LAST_INSERT_ID()) = 1 THEN CONCAT(0, 0, 0, 0, LAST_INSERT_ID())
				 WHEN LENGTH(LAST_INSERT_ID()) = 2 THEN CONCAT(0, 0, 0, LAST_INSERT_ID())
                 WHEN LENGTH(LAST_INSERT_ID()) = 3 THEN CONCAT(0, 0, LAST_INSERT_ID())
                 WHEN LENGTH(LAST_INSERT_ID()) = 4 THEN CONCAT(0, LAST_INSERT_ID())
			ELSE LAST_INSERT_ID() END)
	WHERE OrderRefId = LAST_INSERT_ID();
        
	SELECT DATE_ADD(now(), INTERVAL 2190 MINUTE) DeliveryDate,
		CONCAT(YEAR(NOW()), CASE WHEN LENGTH(MONTH(NOW())) = 1 
			THEN CONCAT(0, MONTH(NOW())) ELSE MONTH(NOW()) END, 
            CASE WHEN LENGTH(LAST_INSERT_ID()) = 1 THEN CONCAT(0, 0, 0, 0, LAST_INSERT_ID())
				 WHEN LENGTH(LAST_INSERT_ID()) = 2 THEN CONCAT(0, 0, 0, LAST_INSERT_ID())
                 WHEN LENGTH(LAST_INSERT_ID()) = 3 THEN CONCAT(0, 0, LAST_INSERT_ID())
                 WHEN LENGTH(LAST_INSERT_ID()) = 4 THEN CONCAT(0, LAST_INSERT_ID())
			ELSE LAST_INSERT_ID() END) OrderNo;
END$$

DROP PROCEDURE IF EXISTS `UspCreateProduct`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspCreateProduct` (IN `p_ProductId` INT, IN `p_CategoryId` INT, IN `p_ProductName` VARCHAR(100), IN `p_RatePerKg` DECIMAL(10,2), IN `p_MinPurchaseQuantity` DECIMAL(10,2), IN `p_CreatedDateTime` DATETIME, IN `p_UpdatedDateTime` DATETIME, IN `p_UserId` VARCHAR(50), IN `p_ProductImagePath` VARCHAR(100), IN `p_UnitType` VARCHAR(10))  BEGIN
	SET @ProductId := 0;
    SELECT @ProductId := ProductId FROM Products
    WHERE ProductId = p_ProductId AND RatePerKg = p_RatePerKg;
    
	IF p_ProductId = 0 THEN
    BEGIN
		SET @DuplicateProduct := 0;
		SELECT @DuplicateProduct := ProductId FROM Products
		WHERE CategoryId = p_CategoryId AND Name = p_ProductName;
        
        IF @DuplicateProduct = 0 THEN
        BEGIN
			INSERT INTO Products
			(
				CategoryId,
				Name,
				RatePerKG,
				MinPurchaseQuantity,
				CreatedDateTime,
				UpdatedDateTime,
				CreatedUserId,
				UpdateduserId,
                Deactivate,                
                ProductImagePath,
                UnitType
			)
			SELECT
				p_CategoryId,
				p_ProductName,
				p_RatePerKg,
				p_MinPurchaseQuantity,
				p_CreatedDateTime,
				p_UpdatedDateTime,
				p_UserId,
				p_UserId,
                'NO',
                p_ProductImagePath,
                p_UnitType;
                
			SELECT 'success' Message;
		END;
        ELSE
        BEGIN
			SELECT 'error' Message;
        END;
        END IF;
	END;
    ELSE
    BEGIN
		IF @ProductId = 0 THEN
        BEGIN
			INSERT INTO ProductHistory
			(
				ProductId,
				CategoryId,
				Name,
				RatePerKG,
				MinPurchaseQuantity,
				CreatedDateTime,
				UpdatedDateTime,
				CreatedUserId,
				UpdatedUserId,
                StatusCode
			)
			SELECT
				ProductId,
				CategoryId,
				Name,
				RatePerKg,
				MinPurchaseQuantity,
				CreatedDateTime,
				p_UpdatedDateTime,
				CreatedUserId,
				p_UserId,
                'U'
			FROM Products
            WHERE ProductId = p_ProductId;
        END;        
        END IF;
        UPDATE Products
		SET CategoryId = p_CategoryId,
			Name = p_ProductName,
			RatePerKg = p_RatePerKg,
			MinPurchaseQuantity = p_MinPurchaseQuantity,
			UpdatedDateTime = p_UpdatedDateTime,
			UpdateduserId = p_UserId,            
            UnitType = p_UnitType,
            ProductImagePath = CASE WHEN p_ProductImagePath IS NULL OR p_ProductImagePath = '' 
				THEN ProductImagePath ELSE p_ProductImagePath END
		WHERE ProductId = p_ProductId;
        
        SELECT 'success' Message, ProductImagePath
        FROM Products
        WHERE ProductId = p_ProductId;
    END;
    END IF;
END$$

DROP PROCEDURE IF EXISTS `UspCreateProductCategory`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspCreateProductCategory` (IN `p_CategoryId` INT, IN `p_CategoryName` VARCHAR(50), IN `p_CreatedDateTime` DATETIME, IN `p_Deactivate` TINYINT, IN `p_UserId` VARCHAR(50))  BEGIN
	IF p_CategoryId = 0 THEN
    BEGIN
		SET @DuplicateCategory := 0;
		SELECT @DuplicateCategory := CategoryId FROM ProductCategories
		WHERE Name = p_CategoryName;
        
        IF @DuplicateCategory = 0 THEN
        BEGIN
			INSERT INTO ProductCategories
			(				
				Name,				
				CreatedDateTime,				
				CreatedUserId,				
                Deactivate
			)
			SELECT
				p_CategoryName,				
				p_CreatedDateTime,				
				p_UserId,
                p_Deactivate;
                
			SELECT 'success' Message;
		END;
        ELSE
        BEGIN
			SELECT 'error' Message;
        END;
        END IF;
	END;
    ELSE
    BEGIN		
        UPDATE ProductCategories
		SET Name = p_CategoryName,			
            Deactivate = p_Deactivate,
            CreatedDateTime = p_CreatedDateTime,
            CreatedUserId = p_UserId
		WHERE CategoryId = p_CategoryId;
        
        SELECT 'success' Message;
    END;
    END IF;
END$$

DROP PROCEDURE IF EXISTS `UspCreateStock`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspCreateStock` (IN `p_VendorId` INT, IN `p_StockId` INT, IN `p_ProductId` INT, IN `p_TotalWeight` DECIMAL(10,2), IN `p_GradeAWeight` DECIMAL(10,2), IN `p_GradeBWeight` DECIMAL(10,2), IN `p_CreatedDateTime` DATETIME, IN `p_DumpWeight` DECIMAL(10,2), IN `p_CreatedUserId` VARCHAR(50))  BEGIN
	IF p_StockId = 0 THEN
    BEGIN
		SET @DuplicateStock := 0;
		SELECT @DuplicateStock := StockId FROM Stocks
		WHERE VendorId = p_VendorId AND ProductId = p_ProductId 
			AND DATE(CreatedDateTime) = DATE(p_CreatedDateTime);
        
        IF @DuplicateStock = 0 THEN
        BEGIN
			INSERT INTO Stocks
			(				
				VendorId,
                ProductId,
                TotalWeight,
                GradeAWeight,
                GradeBWeight,
				CreatedDateTime,
				CreatedUserId,				
                DumpWeight
			)
			SELECT
				p_VendorId,	
                p_ProductId,
                p_TotalWeight,
                p_GradeAWeight,	
                p_GradeBWeight,
				p_CreatedDateTime,				
				p_CreatedUserId,
                p_DumpWeight;
                
			SELECT 'success' Message;
            		
			UPDATE Products
			SET TotalStock = TotalStock + p_GradeAWeight,
				GradeBStock = GradeBStock + p_GradeBWeight
			WHERE ProductId = p_ProductId;
		END;
        ELSE
        BEGIN
			SELECT 'error' Message;
        END;
        END IF;
	END;
    ELSE
    BEGIN
		SET @PrevGradeAWeight := 0, @PrevGradeBWeight := 0;
        SELECT @PrevGradeAWeight := GradeAWeight, @PrevGradeBWeight := GradeBWeight
        FROM Stocks
        WHERE StockId = p_StockId;
        
        UPDATE Stocks
		SET VendorId = p_VendorId,
			ProductId = p_ProductId,
			TotalWeight = p_TotalWeight,
            GradeAWeight = p_GradeAWeight,
            GradeBWeight = p_GradeBWeight,
            DumpWeight = p_DumpWeight,
            CreatedDateTime = p_CreatedDateTime,
            CreatedUserId = p_CreatedUserId
		WHERE StockId = p_StockId;
        
        SELECT 'success' Message;
        
        UPDATE Products
		SET TotalStock = TotalStock + (p_GradeAWeight - @PrevGradeAWeight),
			GradeBStock = GradeBStock + (p_GradeBWeight - @PrevGradeBWeight)
		WHERE ProductId = p_ProductId;
    END;
    END IF;
END$$

DROP PROCEDURE IF EXISTS `UspCreateUser`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspCreateUser` (IN `p_UserId` INT, IN `p_FullName` VARCHAR(50), IN `p_Email` VARCHAR(30), IN `p_MobileNo` BIGINT, IN `p_Role` VARCHAR(20), IN `p_Password` VARCHAR(20))  BEGIN
	IF p_UserId = 0 THEN
    BEGIN
		SET @DuplicateUser := 0;
		SELECT @DuplicateUser := UserId FROM Users
		WHERE MobileNo = p_MobileNo AND Role = p_Role;
        
        IF @DuplicateUser = 0 THEN
        BEGIN
			INSERT INTO Users
			(				
				FullName,				
				MobileNo,				
				Email,				
                Password,
                Role
			)
			SELECT
				p_FullName,				
				p_MobileNo,				
				p_Email,
                p_Password,
                p_Role;
                
			SELECT 'success' Message;
		END;
        ELSE
        BEGIN
			SELECT 'error' Message;
        END;
        END IF;
	END;
    ELSE
    BEGIN		
        UPDATE Users
		SET FullName = p_FullName,			
            MobileNo = p_MobileNo,
            Email = p_Email,
            Password = p_Password,
            Role = p_Role
		WHERE UserId = p_UserId;
        
        SELECT 'success' Message;
    END;
    END IF;
END$$

DROP PROCEDURE IF EXISTS `UspCreateVendor`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspCreateVendor` (IN `p_VendorId` INT, IN `p_TypeId` INT, IN `p_ContactName` VARCHAR(50), IN `p_MobileNo` BIGINT, IN `p_Address` VARCHAR(200), IN `p_CreatedDateTime` DATETIME, IN `p_Disable` TINYINT, IN `p_CreatedUserId` VARCHAR(50))  BEGIN
	IF p_VendorId = 0 THEN
    BEGIN
		SET @DuplicateVendor := 0;
		SELECT @DuplicateVendor := VendorId FROM Vendors
		WHERE MobileNo = p_MobileNo AND TypeId = p_TypeId;
        
        IF @DuplicateVendor = 0 THEN
        BEGIN
			INSERT INTO Vendors
			(				
				TypeId,
                ContactName,
                MobileNo,
                Address,
				CreatedDateTime,				
				CreatedUserId,				
                Disable
			)
			SELECT
				p_TypeId,	
                p_ContactName,
                p_MobileNo,	
                p_Address,
				p_CreatedDateTime,				
				p_CreatedUserId,
                p_Disable;
                
			SELECT 'success' Message;
		END;
        ELSE
        BEGIN
			SELECT 'error' Message;
        END;
        END IF;
	END;
    ELSE
    BEGIN		
        UPDATE Vendors
		SET TypeId = p_TypeId,
			ContactName = p_ContactName,
            MobileNo = p_MobileNo,
            Address = p_Address,
            Disable = p_Disable,
            CreatedDateTime = p_CreatedDateTime,
            CreatedUserId = p_CreatedUserId
		WHERE VendorId = p_VendorId;
        
        SELECT 'success' Message;
    END;
    END IF;
END$$

DROP PROCEDURE IF EXISTS `UspCreateVendorType`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspCreateVendorType` (IN `p_TypeId` INT, IN `p_TypeName` VARCHAR(50), IN `p_Description` VARCHAR(1024), IN `p_CreatedDateTime` DATETIME, IN `p_Disable` TINYINT, IN `p_CreatedUserId` VARCHAR(50))  BEGIN
	IF p_TypeId = 0 THEN
    BEGIN
		SET @DuplicateType := 0;
		SELECT @DuplicateType := TypeId FROM VendorTypes
		WHERE TypeName = p_TypeName;
        
        IF @DuplicateType = 0 THEN
        BEGIN
			INSERT INTO VendorTypes
			(				
				TypeName,
                Description,
				CreatedDateTime,				
				CreatedUserId,				
                Disable
			)
			SELECT
				p_TypeName,	
                p_Description,
				p_CreatedDateTime,				
				p_CreatedUserId,
                p_Disable;
                
			SELECT 'success' Message;
		END;
        ELSE
        BEGIN
			SELECT 'error' Message;
        END;
        END IF;
	END;
    ELSE
    BEGIN		
        UPDATE VendorTypes
		SET TypeName = p_TypeName,			
            Disable = p_Disable,
            Description = p_Description,
            CreatedDateTime = p_CreatedDateTime,
            CreatedUserId = p_CreatedUserId
		WHERE TypeId = p_TypeId;
        
        SELECT 'success' Message;
    END;
    END IF;
END$$

DROP PROCEDURE IF EXISTS `UspDeleteProduct`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspDeleteProduct` (IN `p_ProductId` INT, IN `p_UpdatedDateTime` DATETIME, IN `p_UserId` VARCHAR(50))  BEGIN
	INSERT INTO ProductHistory
	(
		ProductId,
		CategoryId,
		Name,
		RatePerKG,
		MinPurchaseQuantity,
		CreatedDateTime,
		UpdatedDateTime,
		CreatedUserId,
		UpdateduserId,
		StatusCode,
        TotalStock
	)
	SELECT
		ProductId,
		CategoryId,
		Name,
		RatePerKg,
		MinPurchaseQuantity,
		CreatedDateTime,
		p_UpdatedDateTime,
		CreatedUserId,
		p_UserId,
		'D',
        TotalStock
	FROM Products
	WHERE ProductId = p_ProductId;
    
    DELETE FROM Products WHERE ProductId = p_ProductId;
END$$

DROP PROCEDURE IF EXISTS `UspDeleteProductCategory`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspDeleteProductCategory` (IN `p_CategoryId` INT)  BEGIN
	DELETE FROM ProductCategories WHERE CategoryId = p_CategoryId;
END$$

DROP PROCEDURE IF EXISTS `UspDeleteStock`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspDeleteStock` (IN `p_StockId` INT)  BEGIN
	DELETE FROM Stocks
    WHERE StockId = p_StockId;
END$$

DROP PROCEDURE IF EXISTS `UspDeleteUser`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspDeleteUser` (IN `p_UserId` INT)  BEGIN
	DELETE FROM Users WHERE UserId = p_UserId;
END$$

DROP PROCEDURE IF EXISTS `UspDeleteVendor`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspDeleteVendor` (IN `p_VendorId` INT)  BEGIN
	DELETE FROM Vendors
    WHERE VendorId = p_VendorId;
END$$

DROP PROCEDURE IF EXISTS `UspDeleteVendorType`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspDeleteVendorType` (IN `p_TypeId` INT)  BEGIN
	DELETE FROM VendorTypes
    WHERE TypeId = p_TypeId;
END$$

DROP PROCEDURE IF EXISTS `UspGetCategories`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetCategories` ()  BEGIN
	SELECT CategoryId, Name, Deactivate, DATE_FORMAT(CreatedDateTime, "%d/%m/%Y") CreatedDateTime,
		CreatedUserId
    FROM ProductCategories;
END$$

DROP PROCEDURE IF EXISTS `UspGetConfigData`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetConfigData` ()  BEGIN
	SELECT * FROM Configurations;
END$$

DROP PROCEDURE IF EXISTS `UspGetCratesDetails`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetCratesDetails` (IN `p_OrderedDate` VARCHAR(20), IN `p_ProductId` INT)  BEGIN
	SELECT SUM(Weight) TotalWeight, P.Name ProductName, P.ProductImagePath,
		CASE WHEN FLOOR(SUM(Weight)/20) >= 1 THEN FLOOR(SUM(Weight)/20) ELSE 0 END Crates20, 
        CASE WHEN FLOOR((SUM(Weight)%20)/10) >= 1 THEN FLOOR((SUM(Weight)%20)/10) ELSE 0 END Crates10,         
		CASE WHEN ((SUM(Weight)%20)%10) < 6 AND ((SUM(Weight)%20)%10) > 0 THEN 1
			 WHEN ((SUM(Weight)%20)%10) < 10 AND ((SUM(Weight)%20)%10) > 5 THEN 2
        ELSE 0 END Crates5, P.UnitType
	FROM OrderProducts OP
    INNER JOIN Products P ON P.ProductId = OP.ProductId
	INNER JOIN Orders O ON OP.OrderNo = O.OrderNo
    WHERE DATE_FORMAT(OrderedDateTime, "%d/%m/%Y") = p_OrderedDate
		AND OP.ProductId = p_ProductId
	GROUP BY OP.ProductId, DATE(OrderedDateTime);
    
    CREATE TEMPORARY TABLE OrderSummaryCrates
    (
		OrderedDate DATE NULL,		
        TotalWeight DECIMAL(10,2) NULL
	);
	
    INSERT INTO OrderSummaryCrates (OrderedDate)
	SELECT DISTINCT DATE(OrderedDateTime) OrderedDate
    FROM Orders;
    
    UPDATE OrderSummaryCrates OS
    LEFT JOIN (
		SELECT DISTINCT SUM(Weight) TotalWeight, DATE(OrderedDateTime) OrderedDate
        FROM Orders O
        INNER JOIN OrderProducts OP ON OP.OrderNo = O.OrderNo
        INNER JOIN Products P ON P.ProductId = OP.ProductId AND P.UnitType = 'KG'
        WHERE P.UnitType = 'KG'
		GROUP BY DATE(OrderedDateTime)
    ) O ON O.OrderedDate = OS.OrderedDate
    SET OS.TotalWeight = O.TotalWeight;
    
    SELECT DATE_FORMAT(OrderedDate, "%d/%m/%Y") OrderedDate, 
        CASE WHEN TotalWeight IS NULL THEN 0 ELSE TotalWeight END OverallWeight
    FROM OrderSummaryCrates
    WHERE DATE_FORMAT(OrderedDate, "%d/%m/%Y") = p_OrderedDate;
    
    DROP TABLE OrderSummaryCrates;
    
    SELECT OP.Weight, COUNT(ProductId) OrderCount 
	FROM FarmarMarket.OrderProducts OP
	INNER JOIN FarmarMarket.Orders O ON OP.OrderNo = O.OrderNo
    WHERE DATE_FORMAT(OrderedDateTime, "%d/%m/%Y") = p_OrderedDate
		AND OP.ProductId = p_ProductId
	GROUP BY Weight
    ORDER BY Weight;
END$$

DROP PROCEDURE IF EXISTS `UspGetCustomer`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetCustomer` (IN `p_ShopId` INT)  BEGIN
	SET @OrderedDate := '';
    SET @Outstanding := 0;
    
	SELECT @OrderedDate := DATE_FORMAT(MAX(OrderedDateTime), "%d/%m/%Y") OrderedDate
	FROM Orders
    WHERE ShopId = p_ShopId;
    
    SELECT @Outstanding := SUM(OP.PricePerKg) Outstanding
	FROM Orders O
    INNER JOIN OrderProducts OP ON OP.OrderNo = O.OrderNo
    WHERE ShopId = p_ShopId AND PaymentStatus = 'Pending';
    
	SELECT *, IFNULL(@OrderedDate,'') LastOrderedDate, IFNULL(@Outstanding,0) Outstanding 
    FROM ShopDetails
    WHERE ShopId = p_ShopId;
END$$

DROP PROCEDURE IF EXISTS `UspGetCustomers`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetCustomers` (IN `p_Status` VARCHAR(30))  BEGIN
	SELECT ShopId, ShopName, Address, GSTNo, ReferralCode, MobileNo, Status, RejectedReason,
		Location, DATE_FORMAT(UpdatedDateTime, "%d/%m/%Y") UpdatedDateTime, UpdatedUserId, 
        AlternateContactNo, Email, ContactPerson, Route, PinCode
    FROM ShopDetails
    WHERE Status = p_Status
    ORDER BY UpdatedDateTime DESC;
END$$

DROP PROCEDURE IF EXISTS `UspGetDeliveryUsers`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetDeliveryUsers` ()  BEGIN
	SELECT 0 UserId, 'Choose Delivery Person' FullName
    UNION
	SELECT UserId, FullName FROM Users
    WHERE Role = 'Delivery';
END$$

DROP PROCEDURE IF EXISTS `UspGetDisplayInterval`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetDisplayInterval` ()  BEGIN
	SELECT DisplayInterval FROM Configurations;
END$$

DROP PROCEDURE IF EXISTS `UspGetGradeBStocks`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetGradeBStocks` ()  BEGIN
	SELECT Name ProductName, GradeBStock, Deactivate, TotalStock FROM Products
    ORDER BY Name;
END$$

DROP PROCEDURE IF EXISTS `UspGetOrderProducts`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetOrderProducts` (IN `p_OrderNo` BIGINT)  BEGIN
	SELECT PricePerKg * Weight TotalPrice, Weight TotalWeight, Name ProductName, OP.ProductId
		, PricePerKg, P.ProductImagePath, P.UnitType
	FROM OrderProducts OP
    INNER JOIN Products P ON P.ProductId = OP.ProductId
    WHERE OrderNo = p_OrderNo
    ORDER BY P.UnitType;
    
    SELECT O.OrderNo, SD.ShopName, O.Status, OrderedDateTime, DATE_FORMAT(DeliveryDate, "%d/%m/%Y") DeliveryDate
		, DeliveryTime, IFNULL(OverallTotalPrice, 0) OverallTotalPrice, IFNULL(OverallTotalWeight, 0) OverallTotalWeight, 
        O.PaymentStatus, SD.ContactPerson, SD.MobileNo, IFNULL(TotalPiece, 0) TotalPiece, O.OrderMode,
        IFNULL(TotalPiecePrice, 0) TotalPiecePrice
    FROM Orders O
    INNER JOIN ShopDetails SD ON SD.ShopId = O.ShopId
    INNER JOIN (
		SELECT SUM(PricePerKg * Weight) OverallTotalPrice, OrderNo,
			SUM(CASE WHEN P.UnitType = 'KG' THEN Weight END) OverallTotalWeight,
            SUM(CASE WHEN P.UnitType = 'Piece' THEN Weight END) TotalPiece,
            CEIL(SUM(CASE WHEN P.UnitType = 'Piece' THEN (PricePerKg * Weight) END) / 100) TotalPiecePrice
        FROM OrderProducts OP
        INNER JOIN Products P ON OP.ProductId = P.ProductId
        GROUP BY OrderNo
    ) OP ON OP.OrderNo = O.OrderNo    
    WHERE O.OrderNo = p_OrderNo;
    
    SELECT * FROM OrderPickupDetails;
END$$

DROP PROCEDURE IF EXISTS `UspGetOrders`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetOrders` (IN `p_ShopId` INT)  BEGIN
	SELECT O.OrderNo, SD.ShopName, PassCode, O.Status, SD.ShopId, SD.Location, SD.PinCode,
		DATE_FORMAT(OrderedDateTime, "%d/%m/%Y %h:%i:%s %p") OrderedDateTime, O.Route,
		DATE_FORMAT(DeliveryDate, "%d/%m/%Y") DeliveryDate, DeliveryTime,
		IFNULL(OP.TotalPrice, 0) TotalPrice, IFNULL(OP.TotalWeight, 0) TotalWeight, IFNULL(OP.TotalPieces, 0) TotalPieces, 
        U.FullName DeliveryUser, O.PaymentStatus, O.OrderMode, SD.ReferralCode,
        DATE_FORMAT(OrderedDateTime, "%d/%m/%Y") OrderedDate, O.UpdatedUserId
    FROM Orders O
    INNER JOIN ShopDetails SD ON SD.ShopId = O.ShopId
    INNER JOIN (
		SELECT SUM(PricePerKg * Weight) TotalPrice, OrderNo,
			SUM(CASE WHEN P.UnitType = 'KG' THEN Weight END) TotalWeight,
            SUM(CASE WHEN P.UnitType = 'Piece' THEN Weight END) TotalPieces
        FROM OrderProducts OP
        INNER JOIN Products P ON OP.ProductId = P.ProductId
        GROUP BY OrderNo
    ) OP ON OP.OrderNo = O.OrderNo
    LEFT JOIN Users U ON U.UserId = O.DeliveryUserId
    WHERE SD.ShopId = CASE WHEN p_ShopId = 0 THEN SD.ShopId ELSE p_ShopId END
    ORDER BY OrderedDateTime DESC;
    
    SELECT IFNULL(SUM(PricePerKg * Weight), 0) TotalPrice
    FROM Orders O 
    INNER JOIN OrderProducts OP ON OP.OrderNo = O.OrderNo
    WHERE ShopId = p_ShopId AND PaymentStatus = 'Completed';
    
    SELECT IFNULL(SUM(PricePerKg * Weight), 0) TotalOutstanding
    FROM Orders O
    INNER JOIN OrderProducts OP ON OP.OrderNo = O.OrderNo
    WHERE ShopId = p_ShopId AND PaymentStatus = 'Pending';
END$$

DROP PROCEDURE IF EXISTS `UspGetOrderSummary`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetOrderSummary` ()  BEGIN
	CREATE TEMPORARY TABLE OrderSummary
    (
		OrderedDate DATE NULL,
		TotalVendorsOrdered INT NULL,
        TotalOrders INT NULL,
        TotalVegetables INT NULL,
        TotalWeight DECIMAL(10,2) NULL,
        TotalPieces INT NULL,
        TotalPrice DECIMAL(10.2) NULL
	);
	
    INSERT INTO OrderSummary (OrderedDate)
	SELECT DISTINCT DATE(OrderedDateTime) OrderedDate
    FROM Orders
    WHERE Status <> 'Cancelled';
    
    UPDATE OrderSummary OS
    LEFT JOIN (
		SELECT DISTINCT COUNT(ShopId) TotalVendorsOrdered, DATE(OrderedDateTime) OrderedDate
        FROM Orders
        WHERE Status <> 'Cancelled'
		GROUP BY DATE(OrderedDateTime)
    ) O ON O.OrderedDate = OS.OrderedDate
    SET OS.TotalVendorsOrdered = O.TotalVendorsOrdered;
    
    UPDATE OrderSummary OS
    LEFT JOIN (
		SELECT DISTINCT COUNT(OrderNo) TotalOrders, DATE(OrderedDateTime) OrderedDate
        FROM Orders
        WHERE Status <> 'Cancelled'
		GROUP BY DATE(OrderedDateTime)
    ) O ON O.OrderedDate = OS.OrderedDate
    SET OS.TotalOrders = O.TotalOrders;
    
    UPDATE OrderSummary OS
    LEFT JOIN (
		SELECT DISTINCT COUNT(ProductId) TotalVegetables, DATE(OrderedDateTime) OrderedDate
        FROM Orders O
        INNER JOIN OrderProducts OP ON OP.OrderNo = O.OrderNo
        WHERE O.Status <> 'Cancelled'
		GROUP BY DATE(OrderedDateTime)
    ) O ON O.OrderedDate = OS.OrderedDate
    SET OS.TotalVegetables = O.TotalVegetables;
    
    UPDATE OrderSummary OS
    LEFT JOIN (
		SELECT DISTINCT SUM(Weight) TotalWeight, DATE(OrderedDateTime) OrderedDate
        FROM Orders O
        INNER JOIN OrderProducts OP ON OP.OrderNo = O.OrderNo
        INNER JOIN Products P ON P.ProductId = OP.ProductId AND P.UnitType = 'KG'
        WHERE P.UnitType = 'KG' AND O.Status <> 'Cancelled'
		GROUP BY DATE(OrderedDateTime)
    ) O ON O.OrderedDate = OS.OrderedDate
    SET OS.TotalWeight = O.TotalWeight;
    
	UPDATE OrderSummary OS
    LEFT JOIN (
		SELECT DISTINCT SUM(Weight) TotalPieces, DATE(OrderedDateTime) OrderedDate
        FROM Orders O
        INNER JOIN OrderProducts OP ON OP.OrderNo = O.OrderNo
        INNER JOIN Products P ON P.ProductId = OP.ProductId AND P.UnitType = 'Piece'
        WHERE P.UnitType = 'Piece' AND O.Status <> 'Cancelled'
		GROUP BY DATE(OrderedDateTime)
    ) O ON O.OrderedDate = OS.OrderedDate
    SET OS.TotalPieces = O.TotalPieces;
    
    UPDATE OrderSummary OS
    LEFT JOIN (
		SELECT DISTINCT SUM(PricePerKg * Weight) TotalPrice, DATE(OrderedDateTime) OrderedDate
        FROM Orders O
        INNER JOIN OrderProducts OP ON OP.OrderNo = O.OrderNo
        WHERE O.Status <> 'Cancelled'
		GROUP BY DATE(OrderedDateTime)
    ) O ON O.OrderedDate = OS.OrderedDate
    SET OS.TotalPrice = O.TotalPrice;
    
    SELECT DATE_FORMAT(OrderedDate, "%d/%m/%Y") OrderedDate, 
		CASE WHEN TotalVendorsOrdered IS NULL THEN 0 ELSE TotalVendorsOrdered END TotalVendorsOrdered, 
        CASE WHEN TotalOrders IS NULL THEN 0 ELSE TotalOrders END TotalOrders,
		CASE WHEN TotalPrice IS NULL THEN 0 ELSE TotalPrice END TotalPrice, 
        CASE WHEN TotalWeight IS NULL THEN 0 ELSE TotalWeight END TotalWeight, 
        CASE WHEN TotalVegetables IS NULL THEN 0 ELSE TotalVegetables END TotalVegetables, 
        CASE WHEN TotalPieces IS NULL THEN 0 ELSE TotalPieces END TotalPieces
    FROM OrderSummary
    ORDER BY OrderedDate DESC;
    
    DROP TABLE OrderSummary;
END$$

DROP PROCEDURE IF EXISTS `UspGetProductCategories`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetProductCategories` ()  BEGIN
	SELECT 0 CategoryId, 'Choose Category' Name
    UNION
	SELECT CategoryId, Name 
    FROM ProductCategories
    WHERE Deactivate = 0 OR Deactivate IS NULL;
END$$

DROP PROCEDURE IF EXISTS `UspGetProducts`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetProducts` ()  BEGIN
	SELECT P.CategoryId, PC.Name CategoryName, P.Name ProductName, RatePerKg, MinPurchaseQuantity, 
		DATE_FORMAT(UpdatedDateTime, "%d/%m/%Y %h:%i:%s %p") UpdatedDateTime, P.ProductId, UpdatedUserId, 
        P.Deactivate, TotalStock, ProductImagePath, UnitType
    FROM Products P
    INNER JOIN ProductCategories PC ON P.CategoryId = PC.CategoryId
    ORDER BY P.Name;
END$$

DROP PROCEDURE IF EXISTS `UspGetProductsHistory`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetProductsHistory` (IN `p_UpdatedDate` VARCHAR(20))  BEGIN
	SELECT H1.Name ProductName, H1.RatePerKg, DATE_FORMAT(UpdatedDateTime, "%d/%m/%Y") UpdatedDate 
	FROM ProductHistory H1
	INNER JOIN (
		SELECT Name, MAX(UpdatedDateTime) UpdatedDate
		FROM ProductHistory
		GROUP BY Name, DATE(UpdatedDateTime)
	) H2 ON H1.Name = H2.Name AND H2.UpdatedDate = H1.UpdatedDateTime
    WHERE DATE_FORMAT(UpdatedDateTime, "%d/%m/%Y") = CASE WHEN p_UpdatedDate IS NULL OR p_UpdatedDate = ''
		THEN DATE_FORMAT(UpdatedDateTime, "%d/%m/%Y") ELSE p_UpdatedDate END
	ORDER BY DATE(UpdatedDateTime) DESC;
END$$

DROP PROCEDURE IF EXISTS `UspGetRemovedGradeAStocks`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetRemovedGradeAStocks` ()  BEGIN
	SELECT ProductName, Weight, ReasonType, RemovedUserId, 
		DATE_FORMAT(RemovedDateTime, "%d/%m/%Y") RemovedDateTime
    FROM RemovedGradeAStock;
END$$

DROP PROCEDURE IF EXISTS `UspGetRemovedGradeBStocks`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetRemovedGradeBStocks` ()  BEGIN
	SELECT ProductName, Weight, BuyerName, RemovedUserId, 
		DATE_FORMAT(RemovedDateTime, "%d/%m/%Y") RemovedDateTime
    FROM RemovedGradeBStock;
END$$

DROP PROCEDURE IF EXISTS `UspGetRoutes`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetRoutes` ()  BEGIN
	SELECT '0' RouteCategory, 'Choose Route' Route
    UNION
	SELECT RouteCategory, RouteCategory Route FROM Routes;
END$$

DROP PROCEDURE IF EXISTS `UspGetStocks`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetStocks` ()  BEGIN
	SELECT StockId, S.VendorId, ContactName VendorName, S.ProductId, Name ProductName, TotalWeight,
		GradeAWeight, GradeBWeight, DumpWeight, DATE_FORMAT(S.CreatedDateTime, "%d/%m/%Y") CreatedDateTime,
		S.CreatedUserId
    FROM Stocks S
    INNER JOIN Vendors V ON V.VendorId = S.VendorId
    INNER JOIN Products P ON P.ProductId = S.ProductId
    ORDER BY S.CreatedDateTime DESC;
END$$

DROP PROCEDURE IF EXISTS `UspGetTotalWeightPerProduct`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetTotalWeightPerProduct` (IN `p_OrderedDate` VARCHAR(20))  BEGIN
    SELECT SUM(Weight) TotalWeight, P.Name ProductName, P.TotalStock,
		CASE WHEN P.TotalStock > 0 THEN 0 ELSE (0 - P.TotalStock) END Indent,
        OP.ProductId, DATE_FORMAT(OrderedDateTime, "%d/%m/%Y") OrderedDateTime
	FROM OrderProducts OP
    INNER JOIN Products P ON P.ProductId = OP.ProductId
	INNER JOIN Orders O ON OP.OrderNo = O.OrderNo
    WHERE DATE_FORMAT(OrderedDateTime, "%d/%m/%Y") = p_OrderedDate
		AND O.Status <> 'Cancelled'
	GROUP BY OP.ProductId, DATE(OrderedDateTime);
END$$

DROP PROCEDURE IF EXISTS `UspGetUsers`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetUsers` ()  BEGIN
	SELECT * FROM Users;
END$$

DROP PROCEDURE IF EXISTS `UspGetVendors`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetVendors` ()  BEGIN
	SELECT VendorId, V.TypeId, TypeName, V.Disable, DATE_FORMAT(V.CreatedDateTime, "%d/%m/%Y") CreatedDateTime,
		V.CreatedUserId, Address, ContactName, MobileNo
    FROM Vendors V
    INNER JOIN VendorTypes VT ON V.TypeId = VT.TypeId
    ORDER BY ContactName;
END$$

DROP PROCEDURE IF EXISTS `UspGetVendorTypes`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetVendorTypes` ()  BEGIN
	SELECT TypeId, TypeName, Disable, DATE_FORMAT(CreatedDateTime, "%d/%m/%Y") CreatedDateTime,
		CreatedUserId, Description
    FROM VendorTypes
    ORDER BY TypeName;
END$$

DROP PROCEDURE IF EXISTS `UspRemoveCreatedOrder`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspRemoveCreatedOrder` (IN `p_OrderNo` BIGINT)  BEGIN
	SET @CurrentStatus := '';
    
    SELECT @CurrentStatus := Status FROM Orders 
    WHERE OrderNo = p_OrderNo;
    
    IF @CurrentStatus = 'Initiated' THEN
    BEGIN
		UPDATE Products P
		INNER JOIN OrderProducts OP ON OP.ProductId = P.ProductId
		SET P.TotalStock = P.TotalStock + OP.Weight
		WHERE OP.OrderNo = p_OrderNo;
        
        INSERT INTO OrdersHistory
		(
			OrderNo,
			PassCode,
			OrderedDateTime,
			ShopId,
			Status,
			CreatedUserId,
			UpdatedUserId,
			UpdatedDateTime,
			DeliveryDate,
			DeliveryTime
		)
		SELECT
			OrderNo,
			PassCode,
			OrderedDateTime,
			ShopId,
			Status,
			CreatedUserId,
			UpdatedUserId,
			UpdatedDateTime,
			DeliveryDate,
			DeliveryTime
		FROM Orders
        WHERE OrderNo = p_OrderNo AND Status = 'Initiated';
        
        INSERT INTO OrderProductsHistory 
        (
			OrderNo, 
            PricePerKg, 
            Weight, 
            ProductId
		)
        SELECT
			OrderNo, 
            PricePerKg, 
            Weight, 
            ProductId
		FROM OrderProducts
        WHERE OrderNo = p_OrderNo;
			
		DELETE OP FROM OrderProducts OP
		INNER JOIN Orders O ON OP.OrderNo = O.OrderNo
		WHERE OP.OrderNo = p_OrderNo AND O.Status = 'Initiated';
		
		DELETE FROM Orders WHERE OrderNo = p_OrderNo AND Status = 'Initiated';
        
        SELECT 'success' Message;
	END;
    ELSE
    BEGIN
		SELECT 'error' Message;
    END;
    END IF;
END$$

DROP PROCEDURE IF EXISTS `UspRemoveGradeAStock`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspRemoveGradeAStock` (IN `p_ProductId` INT, IN `p_TotalWeight` DECIMAL(10,2), IN `p_ReasonType` VARCHAR(50), IN `p_CreatedDateTime` DATETIME, IN `p_CreatedUserId` VARCHAR(50))  BEGIN
	SET @AvaialableStock := 0;
	SELECT @AvaialableStock := ProductId FROM Products
	WHERE ProductId = p_ProductId;
	
    IF @AvaialableStock >= p_TotalWeight THEN
    BEGIN
		INSERT INTO RemovedGradeAStock
		(
			ProductName,
			Weight,
			ReasonType,
			RemovedDateTime,
			RemovedUserId
		)
		SELECT
			(SELECT Name FROM Products WHERE ProductId = p_ProductId),
			p_TotalWeight,
			p_ReasonType,
			p_CreatedDateTime,
			p_CreatedUserId;
            
		UPDATE Products
		SET TotalStock = TotalStock - p_TotalWeight
		WHERE ProductId = p_ProductId;
		
        SELECT 'success' Message;
	END;
    ELSE
    BEGIN
		SELECT 'error' Message;
    END;
    END IF;
END$$

DROP PROCEDURE IF EXISTS `UspRemoveGradeBStock`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspRemoveGradeBStock` (IN `p_ProductId` INT, IN `p_TotalWeight` DECIMAL(10,2), IN `p_BuyerName` VARCHAR(50), IN `p_CreatedDateTime` DATETIME, IN `p_CreatedUserId` VARCHAR(50))  BEGIN
		INSERT INTO RemovedGradeBStock
		(
			ProductName,
			Weight,
			BuyerName,
			RemovedDateTime,
			RemovedUserId
		)
		SELECT
			(SELECT Name FROM Products WHERE ProductId = p_ProductId),
			p_TotalWeight,
			p_BuyerName,
			p_CreatedDateTime,
			p_CreatedUserId;
            
		UPDATE Products
		SET GradeBStock = GradeBStock - p_TotalWeight
		WHERE ProductId = p_ProductId;
		
        SELECT 'success' Message;
END$$

DROP PROCEDURE IF EXISTS `UspUpdateConfigData`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspUpdateConfigData` (IN `p_PickupAddress` VARCHAR(200), IN `p_ContactNo1` BIGINT, IN `p_ContactNo2` BIGINT, IN `p_DeliveryCharges` DECIMAL(10,2), IN `p_OrderFromTime` DATETIME, IN `p_OrderToTime` DATETIME, IN `p_CancelFromTime` DATETIME, IN `p_CancelToTime` DATETIME, IN `p_Interval` INT, IN `p_OrderMode` VARCHAR(20), IN `p_MinOrderWeight` DECIMAL(10,2))  BEGIN
	UPDATE Configurations
    SET PickupAddress = p_PickupAddress,
		ContactNo1 = p_ContactNo1,
        ContactNo2 = p_ContactNo2,
        DeliveryCharges = p_DeliveryCharges,
        OrderFromTime = CASE WHEN OrderFromTime <> p_OrderFromTime 
			THEN DATE_ADD(p_OrderFromTime, INTERVAL 330 MINUTE) ELSE OrderFromTime END,
        OrderToTime = CASE WHEN OrderToTime <> p_OrderToTime 
			THEN DATE_ADD(p_OrderToTime, INTERVAL 330 MINUTE) ELSE OrderToTime END,
        CancelFromTime = CASE WHEN CancelFromTime <> p_CancelFromTime 
			THEN DATE_ADD(p_CancelFromTime, INTERVAL 330 MINUTE) ELSE CancelFromTime END,
        CancelToTime = CASE WHEN CancelToTime <> p_CancelToTime 
			THEN DATE_ADD(p_CancelToTime, INTERVAL 330 MINUTE) ELSE CancelToTime END,
        OrderMode = p_OrderMode,
        DisplayInterval = p_Interval,
        MinOrderWeight = p_MinOrderWeight;
END$$

DROP PROCEDURE IF EXISTS `UspUpdateCreatedOrders`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspUpdateCreatedOrders` (IN `p_OrderNo` BIGINT, IN `p_UserId` VARCHAR(50), IN `p_UpdatedDateTime` DATETIME)  BEGIN
	INSERT INTO OrderProductsTemp
    (
		OrderNo,
        PricePerKg,
        Weight,
        ProductId
    )
    SELECT 
		OrderNo,
        PricePerKg,
        Weight,
        ProductId
	FROM OrderProducts
    WHERE OrderNo = p_OrderNo;
    
	DELETE FROM OrderProducts
    WHERE OrderNo = p_OrderNo;
    
    UPDATE Orders
    SET UpdatedUserId = p_UserId,
        UpdatedDateTime = p_UpdatedDateTime
	WHERE OrderNo = p_OrderNo;
END$$

DROP PROCEDURE IF EXISTS `UspUpdateOrder`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspUpdateOrder` (IN `p_OrderNo` BIGINT, IN `p_Status` VARCHAR(20), IN `p_DeliveredDate` DATE, IN `p_DeliveryTime` VARCHAR(30), IN `p_DeliveryUserId` INT)  BEGIN
	UPDATE Orders
    SET Status = CASE WHEN p_Status IS NULL OR p_Status = '' THEN Status ELSE p_Status END,
		DeliveryDate = CASE WHEN p_DeliveredDate IS NULL OR p_DeliveredDate = '' OR p_DeliveredDate like '%0001%'
			THEN DeliveryDate ELSE p_DeliveredDate END,
        DeliveryTime = CASE WHEN p_DeliveryTime IS NULL OR p_DeliveryTime = '' THEN DeliveryTime 
			ELSE p_DeliveryTime END,
		DeliveryUserId = CASE WHEN p_DeliveryUserId IS NULL OR p_DeliveryUserId = 0 
			THEN DeliveryUserId ELSE p_DeliveryUserId END
	WHERE OrderNo = p_OrderNo;
    
    IF p_Status = 'Cancelled' THEN
    BEGIN
		UPDATE Products P
		INNER JOIN OrderProducts OP ON OP.ProductId = P.ProductId
		SET P.TotalStock = P.TotalStock + OP.Weight
		WHERE OP.OrderNo = p_OrderNo;
    END;
    END IF;
END$$

DROP PROCEDURE IF EXISTS `UspUpdateProducts`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspUpdateProducts` (IN `p_ProductId` INT, IN `p_RatePerKg` DECIMAL(10,2), IN `p_UpdatedDateTime` DATETIME, IN `p_Deactivate` VARCHAR(4), IN `p_UserId` VARCHAR(50))  BEGIN
	SET @ProductId := 0;
    SELECT @ProductId := ProductId FROM Products
    WHERE ProductId = p_ProductId AND RatePerKg = p_RatePerKg;
    
	IF @ProductId = 0 THEN
        BEGIN
			INSERT INTO ProductHistory
			(
				ProductId,
				CategoryId,
				Name,
				RatePerKG,
				MinPurchaseQuantity,
				CreatedDateTime,
				UpdatedDateTime,
				CreatedUserId,
				UpdatedUserId,
                StatusCode,
                TotalStock
			)
			SELECT
				ProductId,
				CategoryId,
				Name,
				RatePerKg,
				MinPurchaseQuantity,
				CreatedDateTime,
				p_UpdatedDateTime,
				CreatedUserId,
				p_UserId,
                'U',
                TotalStock
			FROM Products
            WHERE ProductId = p_ProductId;
        END;        
        END IF;
        UPDATE Products
		SET RatePerKg = p_RatePerKg,			
			UpdatedDateTime = p_UpdatedDateTime,
			UpdateduserId = p_UserId,
            Deactivate = p_Deactivate
		WHERE ProductId = p_ProductId;
END$$

DROP PROCEDURE IF EXISTS `UspUpdateProductsStock`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspUpdateProductsStock` (IN `p_CondOper` INT, IN `p_OrderNo` BIGINT)  BEGIN
	IF p_CondOper = 1 THEN
    BEGIN
		UPDATE Products P
		INNER JOIN OrderProducts OP ON OP.ProductId = P.ProductId
		INNER JOIN OrderProductsTemp T ON T.ProductId = OP.ProductId AND T.OrderNo = OP.OrderNo
		SET P.TotalStock = P.TotalStock - (OP.Weight - T.Weight)
		WHERE OP.OrderNo = p_OrderNo AND T.OrderNo = p_OrderNo;
        
        DELETE FROM OrderProductsTemp WHERE OrderNo = p_OrderNo;
	END;
    ELSE
    BEGIN
		UPDATE Products P
		INNER JOIN OrderProducts OP ON OP.ProductId = P.ProductId
		SET P.TotalStock = P.TotalStock - OP.Weight
		WHERE OP.OrderNo = p_OrderNo;
    END;
    END IF;
END$$

DROP PROCEDURE IF EXISTS `UspValidateLoginCustomer`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspValidateLoginCustomer` (IN `p_MobileNo` BIGINT)  BEGIN
	SELECT * FROM ShopDetails S1
    INNER JOIN ShopImages S2 ON S1.ShopId = S2.ShopId
    WHERE MobileNo = p_MobileNo;
END$$

DROP PROCEDURE IF EXISTS `UspValidateLoginUser`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspValidateLoginUser` (IN `p_Email` VARCHAR(30), IN `p_Password` VARCHAR(20))  BEGIN
    SELECT Role FROM Users
    WHERE Email = p_Email AND Password = p_Password;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `Configurations`
--

DROP TABLE IF EXISTS `Configurations`;
CREATE TABLE IF NOT EXISTS `Configurations` (
  `PickupAddress` varchar(200) NOT NULL,
  `ContactNo1` bigint(20) NOT NULL,
  `ContactNo2` bigint(20) DEFAULT NULL,
  `DeliveryCharges` decimal(10,2) DEFAULT '0.00',
  `OrderFromTime` datetime NOT NULL,
  `OrderToTime` datetime NOT NULL,
  `CancelFromTime` datetime NOT NULL,
  `CancelToTime` datetime NOT NULL,
  `DisplayInterval` int(11) DEFAULT '0',
  `OrderMode` varchar(20) NOT NULL,
  `MinOrderWeight` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Configurations`
--

INSERT INTO `Configurations` (`PickupAddress`, `ContactNo1`, `ContactNo2`, `DeliveryCharges`, `OrderFromTime`, `OrderToTime`, `CancelFromTime`, `CancelToTime`, `DisplayInterval`, `OrderMode`, `MinOrderWeight`) VALUES
('Near K.E.B Junction,Ring Road, Dattagalli, 3rd stage,Mysore', 7760375777, 7760375777, '1.00', '2020-08-08 10:00:41', '2020-08-08 21:00:50', '2020-08-08 18:00:02', '2020-08-08 19:00:56', 10, 'Delivery', '20.00');

-- --------------------------------------------------------

--
-- Table structure for table `OrderPickupDetails`
--

DROP TABLE IF EXISTS `OrderPickupDetails`;
CREATE TABLE IF NOT EXISTS `OrderPickupDetails` (
  `PickupAddress` varchar(200) NOT NULL,
  `ContactNo1` bigint(20) NOT NULL,
  `ContactNo2` bigint(20) DEFAULT NULL,
  `DeliveryCharges` decimal(10,2) DEFAULT '0.00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `OrderPickupDetails`
--

INSERT INTO `OrderPickupDetails` (`PickupAddress`, `ContactNo1`, `ContactNo2`, `DeliveryCharges`) VALUES
('Near K.E.B Junction,Ring Road, Dattagalli, 3rd stage,Mysore', 7760375777, 0, '1.00');

-- --------------------------------------------------------

--
-- Table structure for table `OrderProducts`
--

DROP TABLE IF EXISTS `OrderProducts`;
CREATE TABLE IF NOT EXISTS `OrderProducts` (
  `OrderNo` bigint(20) NOT NULL,
  `PricePerKg` decimal(10,2) NOT NULL,
  `Weight` decimal(10,2) NOT NULL,
  `ProductId` int(11) NOT NULL,
  KEY `FK_OrderNo` (`OrderNo`),
  KEY `FK_ProductId` (`ProductId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `OrderProducts`
--

INSERT INTO `OrderProducts` (`OrderNo`, `PricePerKg`, `Weight`, `ProductId`) VALUES
(598331285, '8.00', '10.00', 72),
(598331285, '33.00', '6.00', 7),
(598331285, '25.00', '3.00', 61),
(598331285, '68.00', '3.00', 10),
(598331285, '22.00', '6.00', 31),
(598331285, '26.00', '3.00', 62),
(598331285, '4.00', '15.00', 67),
(598331285, '20.00', '6.00', 28),
(598331285, '2.00', '10.00', 68),
(598331285, '46.00', '3.00', 44),
(598331285, '110.00', '3.00', 18),
(598331285, '32.00', '6.00', 20),
(598331285, '24.00', '3.00', 36),
(598331285, '24.00', '3.00', 63),
(598331285, '18.00', '3.00', 34),
(598331285, '18.00', '3.00', 29),
(598331285, '3.00', '5.00', 69),
(598331285, '42.00', '3.00', 16),
(598331285, '32.00', '10.00', 11),
(598331285, '15.00', '3.00', 35),
(598331285, '28.00', '3.00', 45),
(795802606, '45.00', '3.00', 8),
(795802606, '12.00', '3.00', 30),
(795802606, '68.00', '3.00', 10),
(795802606, '38.00', '3.00', 9),
(795802606, '4.00', '5.00', 67),
(795802606, '65.00', '3.00', 19),
(795802606, '18.00', '3.00', 34),
(795802606, '4.50', '5.00', 73),
(795802606, '3.00', '5.00', 69),
(795802606, '15.00', '10.00', 15),
(795802606, '2.50', '5.00', 70),
(795802606, '32.00', '6.00', 11),
(795802606, '28.00', '5.00', 14),
(668280896, '8.00', '10.00', 72),
(668280896, '45.00', '6.00', 8),
(668280896, '33.00', '6.00', 7),
(668280896, '25.00', '3.00', 61),
(668280896, '39.00', '3.00', 64),
(668280896, '16.00', '3.00', 27),
(668280896, '16.00', '3.00', 25),
(668280896, '12.00', '3.00', 30),
(668280896, '68.00', '3.00', 10),
(668280896, '38.00', '6.00', 9),
(668280896, '22.00', '3.00', 31),
(668280896, '26.00', '3.00', 62),
(668280896, '4.00', '10.00', 67),
(668280896, '20.00', '3.00', 28),
(668280896, '2.00', '10.00', 68),
(668280896, '46.00', '3.00', 44),
(668280896, '32.00', '3.00', 20),
(668280896, '24.00', '3.00', 36),
(668280896, '24.00', '3.00', 63),
(668280896, '18.00', '3.00', 34),
(668280896, '15.00', '5.00', 15),
(668280896, '32.00', '6.00', 11),
(668280896, '15.00', '3.00', 35),
(668280896, '28.00', '3.00', 45),
(668280896, '28.00', '5.00', 14),
(668280896, '18.00', '5.00', 13),
(921691087, '8.00', '5.00', 72),
(921691087, '33.00', '3.00', 7),
(921691087, '39.00', '3.00', 64),
(921691087, '16.00', '3.00', 27),
(921691087, '12.00', '6.00', 30),
(921691087, '68.00', '3.00', 10),
(921691087, '22.00', '3.00', 31),
(921691087, '26.00', '3.00', 62),
(921691087, '20.00', '10.00', 28),
(921691087, '110.00', '3.00', 18),
(921691087, '32.00', '3.00', 20),
(921691087, '24.00', '3.00', 63),
(921691087, '32.00', '10.00', 11),
(921691087, '11.00', '10.00', 65),
(921691087, '15.00', '3.00', 35),
(921691087, '28.00', '3.00', 45),
(921691087, '28.00', '10.00', 14),
(921691087, '18.00', '10.00', 13),
(263991964, '33.00', '3.00', 7),
(263991964, '38.00', '3.00', 9),
(263991964, '32.00', '3.00', 20),
(263991964, '24.00', '3.00', 63),
(263991964, '18.00', '3.00', 34),
(263991964, '15.00', '5.00', 15),
(263991964, '18.00', '15.00', 13),
(279662879, '26.00', '3.00', 62),
(279662879, '4.00', '10.00', 67),
(279662879, '20.00', '6.00', 28),
(279662879, '2.00', '5.00', 68),
(279662879, '46.00', '3.00', 44),
(279662879, '24.00', '3.00', 36),
(279662879, '18.00', '3.00', 34),
(279662879, '4.50', '5.00', 73),
(279662879, '3.00', '5.00', 69),
(240150903, '45.00', '3.00', 8),
(240150903, '68.00', '3.00', 10),
(240150903, '38.00', '3.00', 9),
(240150903, '2.00', '5.00', 68),
(240150903, '18.00', '10.00', 13),
(745638191, '33.00', '3.00', 7),
(745638191, '38.00', '3.00', 9),
(745638191, '22.00', '3.00', 31),
(745638191, '20.00', '3.00', 28),
(745638191, '32.00', '6.00', 20),
(745638191, '18.00', '3.00', 34),
(745638191, '42.00', '3.00', 16),
(745638191, '15.00', '3.00', 35),
(745638191, '28.00', '10.00', 14),
(745638191, '18.00', '10.00', 13),
(915257022, '16.00', '3.00', 25),
(915257022, '4.00', '20.00', 67),
(915257022, '3.00', '10.00', 69),
(915257022, '28.00', '3.00', 45),
(944568297, '68.00', '3.00', 10),
(944568297, '22.00', '3.00', 31),
(944568297, '65.00', '3.00', 19),
(304608596, '68.00', '6.00', 10),
(304608596, '38.00', '3.00', 9),
(649077131, '25.00', '3.00', 61),
(649077131, '38.00', '3.00', 9),
(649077131, '20.00', '3.00', 28),
(649077131, '110.00', '3.00', 18),
(649077131, '32.00', '3.00', 20),
(649077131, '18.00', '5.00', 13),
(898981732, '25.00', '3.00', 61),
(898981732, '20.00', '3.00', 28),
(898981732, '32.00', '3.00', 20),
(898981732, '28.00', '3.00', 45),
(898981732, '18.00', '5.00', 13),
(507996314, '33.00', '3.00', 7),
(507996314, '68.00', '3.00', 10),
(507996314, '18.00', '3.00', 34),
(507996314, '32.00', '3.00', 11),
(507996314, '28.00', '3.00', 14),
(613777972, '26.00', '6.00', 62),
(613777972, '32.00', '15.00', 20),
(613777972, '24.00', '6.00', 63),
(190335164, '39.00', '3.00', 64),
(190335164, '38.00', '3.00', 9),
(190335164, '32.00', '3.00', 20),
(190335164, '28.00', '3.00', 45),
(285496990, '45.00', '6.00', 8),
(285496990, '16.00', '3.00', 27),
(285496990, '16.00', '6.00', 25),
(285496990, '28.00', '20.00', 14),
(497180440, '33.00', '3.00', 7),
(497180440, '68.00', '3.00', 10),
(497180440, '26.00', '3.00', 62),
(497180440, '4.00', '20.00', 67),
(497180440, '20.00', '3.00', 28),
(497180440, '24.00', '3.00', 63),
(497180440, '18.00', '3.00', 34),
(497180440, '4.50', '5.00', 73),
(497180440, '3.00', '5.00', 69),
(497180440, '2.50', '5.00', 70),
(497180440, '2.50', '5.00', 71),
(497180440, '28.00', '5.00', 14),
(562476398, '38.00', '10.00', 9),
(562476398, '26.00', '3.00', 62),
(225045675, '40.00', '25.00', 8),
(225045675, '33.00', '10.00', 7),
(225045675, '42.00', '20.00', 9),
(225045675, '26.00', '15.00', 62),
(225045675, '20.00', '30.00', 28),
(225045675, '110.00', '5.00', 18),
(225045675, '34.00', '10.00', 20),
(225045675, '24.00', '7.00', 63),
(225045675, '18.00', '25.00', 34),
(225045675, '48.00', '10.00', 16),
(121292552, '16.00', '3.00', 25),
(121292552, '34.00', '3.00', 20),
(121292552, '24.00', '3.00', 36),
(121292552, '32.00', '10.00', 11),
(688570904, '8.00', '6.00', 72),
(688570904, '25.00', '3.00', 61),
(688570904, '39.00', '3.00', 64),
(688570904, '26.00', '3.00', 62),
(688570904, '24.00', '3.00', 63),
(688570904, '18.00', '3.00', 34),
(688570904, '55.00', '2.00', 21),
(688570904, '11.00', '10.00', 65),
(838120760, '15.00', '10.00', 29),
(838120760, '16.00', '3.00', 35),
(953890826, '8.00', '21.00', 72),
(953890826, '25.00', '3.00', 61),
(953890826, '65.00', '3.00', 10),
(953890826, '20.00', '3.00', 31),
(953890826, '16.00', '3.00', 35),
(930485149, '25.00', '3.00', 61),
(930485149, '20.00', '3.00', 31),
(930485149, '65.00', '2.00', 19),
(930485149, '15.00', '5.00', 15),
(930485149, '32.00', '6.00', 11),
(930485149, '28.00', '5.00', 14),
(336993578, '16.00', '3.00', 27),
(336993578, '16.00', '3.00', 25),
(336993578, '20.00', '3.00', 31),
(336993578, '4.50', '10.00', 67),
(336993578, '2.00', '10.00', 68),
(336993578, '15.00', '3.00', 29),
(336993578, '4.50', '5.00', 73),
(336993578, '3.00', '5.00', 71),
(432117450, '8.00', '10.00', 72),
(432117450, '40.00', '3.00', 8),
(432117450, '39.00', '3.00', 64),
(432117450, '16.00', '3.00', 25),
(432117450, '40.00', '9.00', 9),
(432117450, '20.00', '3.00', 31),
(432117450, '26.00', '3.00', 62),
(432117450, '2.00', '10.00', 68),
(432117450, '65.00', '3.00', 19),
(432117450, '34.00', '3.00', 20),
(432117450, '24.00', '3.00', 36),
(432117450, '18.00', '3.00', 34),
(432117450, '15.00', '3.00', 29),
(432117450, '3.00', '5.00', 69),
(432117450, '16.00', '3.00', 35),
(432117450, '28.00', '3.00', 45),
(658432162, '40.00', '6.00', 9),
(658432162, '32.00', '10.00', 11),
(374480347, '40.00', '3.00', 8),
(374480347, '65.00', '3.00', 10),
(374480347, '26.00', '3.00', 62),
(374480347, '20.00', '3.00', 28),
(374480347, '50.00', '3.00', 44),
(374480347, '28.00', '3.00', 45),
(374480347, '28.00', '3.00', 14),
(153358554, '8.00', '10.00', 72),
(153358554, '33.00', '3.00', 7),
(153358554, '25.00', '3.00', 61),
(153358554, '16.00', '3.00', 27),
(153358554, '12.00', '3.00', 30),
(153358554, '40.00', '3.00', 9),
(153358554, '20.00', '6.00', 28),
(153358554, '4.50', '10.00', 73),
(153358554, '3.00', '5.00', 69),
(153358554, '28.00', '3.00', 45),
(372863474, '40.00', '3.00', 8),
(372863474, '39.00', '3.00', 64),
(372863474, '40.00', '3.00', 9),
(372863474, '20.00', '3.00', 31),
(372863474, '65.00', '3.00', 19),
(372863474, '55.00', '2.00', 21),
(372863474, '32.00', '3.00', 11),
(598361624, '33.00', '3.00', 7),
(598361624, '40.00', '3.00', 9),
(598361624, '4.50', '10.00', 67),
(598361624, '20.00', '6.00', 28),
(598361624, '34.00', '2.00', 20),
(598361624, '18.00', '3.00', 34),
(598361624, '3.00', '10.00', 69),
(589984637, '33.00', '3.00', 7),
(589984637, '16.00', '3.00', 25),
(589984637, '20.00', '3.00', 28),
(589984637, '65.00', '3.00', 19),
(589984637, '18.00', '5.00', 13),
(580774837, '16.00', '3.00', 25),
(580774837, '12.00', '3.00', 30),
(580774837, '34.00', '6.00', 20),
(391484462, '8.00', '21.00', 72),
(391484462, '25.00', '3.00', 61),
(391484462, '39.00', '3.00', 64),
(391484462, '65.00', '3.00', 10),
(391484462, '40.00', '9.00', 9),
(391484462, '26.00', '3.00', 62),
(391484462, '20.00', '10.00', 28),
(391484462, '50.00', '3.00', 44),
(391484462, '24.00', '3.00', 63),
(391484462, '48.00', '3.00', 16),
(391484462, '16.00', '3.00', 35),
(391484462, '28.00', '6.00', 45),
(391484462, '28.00', '10.00', 14),
(391484462, '18.00', '20.00', 13),
(157560572, '40.00', '9.00', 8),
(157560572, '16.00', '3.00', 27),
(157560572, '65.00', '9.00', 19),
(157560572, '24.00', '3.00', 36),
(157560572, '24.00', '6.00', 63),
(157560572, '28.00', '40.00', 14),
(462739742, '34.00', '6.00', 20),
(462739742, '28.00', '3.00', 45),
(331483899, '110.00', '6.00', 18),
(331483899, '65.00', '6.00', 19),
(309609630, '30.00', '10.00', 88),
(309609630, '36.00', '3.00', 75),
(309609630, '30.00', '3.00', 7),
(309609630, '25.00', '3.00', 61),
(309609630, '12.00', '3.00', 47),
(309609630, '16.00', '3.00', 27),
(309609630, '16.00', '3.00', 25),
(309609630, '65.00', '3.00', 10),
(309609630, '58.00', '4.00', 9),
(309609630, '22.00', '3.00', 31),
(309609630, '26.00', '3.00', 62),
(309609630, '50.00', '3.00', 83),
(309609630, '22.00', '3.00', 77),
(309609630, '20.00', '10.00', 28),
(309609630, '34.00', '3.00', 20),
(309609630, '16.00', '3.00', 34),
(309609630, '15.00', '5.00', 29),
(309609630, '15.00', '10.00', 15),
(309609630, '32.00', '10.00', 11),
(309609630, '11.00', '5.00', 65),
(309609630, '28.00', '3.00', 45),
(309609630, '16.00', '3.00', 46),
(309609630, '21.00', '10.00', 14),
(309609630, '15.00', '10.00', 13),
(585856804, '16.00', '3.00', 25),
(585856804, '4.00', '10.00', 67),
(585856804, '2.00', '5.00', 68),
(585856804, '34.00', '3.00', 20),
(585856804, '15.00', '5.00', 13),
(479879105, '65.00', '3.00', 10),
(479879105, '58.00', '3.00', 9),
(479879105, '4.00', '5.00', 67),
(479879105, '15.00', '10.00', 15),
(479879105, '32.00', '6.00', 11),
(479879105, '15.00', '10.00', 13),
(243527127, '16.00', '3.00', 27),
(243527127, '16.00', '3.00', 25),
(243527127, '11.00', '3.00', 30),
(243527127, '65.00', '2.00', 10),
(243527127, '22.00', '3.00', 31),
(243527127, '4.00', '5.00', 67),
(243527127, '20.00', '6.00', 28),
(243527127, '2.00', '5.00', 68),
(243527127, '50.00', '2.00', 44),
(243527127, '24.00', '4.00', 36),
(243527127, '24.00', '3.00', 63),
(243527127, '16.00', '3.00', 34),
(243527127, '3.00', '2.00', 69),
(900649030, '16.00', '3.00', 25),
(900649030, '4.00', '20.00', 67),
(900649030, '20.00', '5.00', 28),
(900649030, '2.00', '5.00', 68),
(900649030, '65.00', '2.00', 19),
(900649030, '34.00', '3.00', 20),
(900649030, '55.00', '2.00', 21),
(900649030, '28.00', '3.00', 45),
(900649030, '21.00', '5.00', 14),
(920837107, '8.00', '20.00', 72),
(920837107, '25.00', '3.00', 61),
(920837107, '39.00', '6.00', 64),
(920837107, '32.00', '6.00', 26),
(920837107, '16.00', '6.00', 25),
(920837107, '58.00', '6.00', 9),
(920837107, '26.00', '3.00', 62),
(920837107, '20.00', '10.00', 28),
(920837107, '50.00', '3.00', 44),
(920837107, '24.00', '3.00', 63),
(920837107, '16.00', '6.00', 34),
(920837107, '16.00', '3.00', 35),
(920837107, '28.00', '6.00', 45),
(920837107, '16.00', '3.00', 46),
(920837107, '21.00', '20.00', 14),
(920837107, '15.00', '20.00', 13),
(433485640, '8.00', '10.00', 72),
(433485640, '30.00', '3.00', 7),
(433485640, '12.00', '3.00', 47),
(433485640, '16.00', '3.00', 27),
(433485640, '16.00', '3.00', 25),
(433485640, '65.00', '3.00', 10),
(433485640, '58.00', '3.00', 9),
(433485640, '26.00', '3.00', 62),
(433485640, '4.00', '20.00', 67),
(433485640, '50.00', '3.00', 44),
(433485640, '34.00', '6.00', 20),
(433485640, '16.00', '6.00', 34),
(433485640, '15.00', '3.00', 29),
(433485640, '16.00', '3.00', 35),
(433485640, '28.00', '3.00', 45),
(744674770, '40.00', '3.00', 8),
(744674770, '11.00', '3.00', 30),
(744674770, '58.00', '3.00', 9),
(744674770, '32.00', '10.00', 11),
(675061206, '36.00', '18.00', 75),
(675061206, '8.00', '30.00', 72),
(675061206, '25.00', '12.00', 87),
(675061206, '40.00', '25.00', 8),
(675061206, '30.00', '25.00', 7),
(675061206, '25.00', '20.00', 61),
(675061206, '39.00', '25.00', 64),
(675061206, '12.00', '20.00', 47),
(675061206, '32.00', '10.00', 26),
(675061206, '16.00', '10.00', 27),
(675061206, '16.00', '8.00', 25),
(675061206, '65.00', '14.00', 10),
(675061206, '58.00', '30.00', 9),
(675061206, '22.00', '24.00', 31),
(675061206, '26.00', '20.00', 62),
(675061206, '22.00', '8.00', 77),
(675061206, '20.00', '40.00', 28),
(675061206, '50.00', '6.00', 44),
(675061206, '110.00', '10.00', 18),
(675061206, '65.00', '12.00', 19),
(675061206, '34.00', '10.00', 20),
(675061206, '27.00', '10.00', 42),
(675061206, '24.00', '10.00', 36),
(675061206, '24.00', '20.00', 63),
(675061206, '16.00', '20.00', 34),
(675061206, '32.00', '40.00', 11),
(675061206, '28.00', '20.00', 45),
(736629179, '40.00', '3.00', 8),
(736629179, '39.00', '3.00', 64),
(736629179, '12.00', '3.00', 47),
(736629179, '65.00', '3.00', 10),
(736629179, '58.00', '5.00', 9),
(736629179, '26.00', '3.00', 62),
(736629179, '20.00', '3.00', 28),
(736629179, '34.00', '2.00', 20),
(736629179, '24.00', '3.00', 63),
(736629179, '48.00', '5.00', 16),
(736629179, '16.00', '3.00', 35),
(736629179, '15.00', '5.00', 13),
(770523651, '8.00', '10.00', 72),
(770523651, '25.00', '3.00', 61),
(770523651, '58.00', '3.00', 9),
(770523651, '26.00', '3.00', 62),
(770523651, '4.00', '10.00', 67),
(770523651, '50.00', '3.00', 44),
(770523651, '24.00', '3.00', 36),
(770523651, '16.00', '3.00', 34),
(770523651, '4.50', '10.00', 73),
(770523651, '3.00', '10.00', 69),
(770523651, '2.50', '5.00', 70),
(770523651, '16.00', '3.00', 35),
(770523651, '28.00', '2.00', 45),
(770523651, '3.00', '5.00', 71),
(770523651, '16.00', '3.00', 46),
(770523651, '15.00', '10.00', 13),
(593605440, '15.00', '10.00', 29),
(272607587, '8.00', '5.00', 72),
(272607587, '25.00', '3.00', 61),
(272607587, '16.00', '3.00', 25),
(272607587, '58.00', '3.00', 9),
(272607587, '22.00', '3.00', 31),
(272607587, '4.00', '5.00', 67),
(272607587, '2.00', '5.00', 68),
(272607587, '34.00', '3.00', 20),
(272607587, '15.00', '5.00', 29),
(272607587, '3.00', '5.00', 69),
(272607587, '28.00', '3.00', 45),
(350333430, '8.00', '6.00', 72),
(350333430, '30.00', '3.00', 7),
(350333430, '16.00', '3.00', 25),
(350333430, '65.00', '3.00', 10),
(350333430, '58.00', '3.00', 9),
(350333430, '22.00', '5.00', 31),
(350333430, '4.00', '20.00', 67),
(350333430, '34.00', '3.00', 20),
(350333430, '16.00', '3.00', 35),
(350333430, '28.00', '6.00', 45),
(277669468, '58.00', '3.00', 9),
(277669468, '110.00', '2.00', 18),
(277669468, '65.00', '2.00', 19),
(277669468, '24.00', '3.00', 36),
(277669468, '24.00', '3.00', 63),
(277669468, '28.00', '3.00', 45),
(277669468, '21.00', '10.00', 14),
(683503786, '30.00', '3.00', 7),
(683503786, '4.00', '20.00', 67),
(683503786, '3.00', '15.00', 69),
(683503786, '2.50', '5.00', 70),
(683503786, '11.00', '6.00', 65),
(683503786, '28.00', '3.00', 45),
(339562688, '58.00', '3.00', 9),
(339562688, '22.00', '3.00', 31),
(339562688, '32.00', '3.00', 11),
(339562688, '15.00', '3.00', 13),
(772067421, '40.00', '3.00', 8),
(772067421, '16.00', '3.00', 34),
(772067421, '28.00', '3.00', 45),
(888559829, '15.00', '10.00', 15),
(888559829, '32.00', '10.00', 11),
(386468796, '39.00', '20.00', 64),
(386468796, '18.00', '30.00', 26),
(386468796, '16.00', '20.00', 27),
(386468796, '16.00', '20.00', 25),
(386468796, '16.00', '40.00', 34),
(386468796, '16.00', '30.00', 35),
(386468796, '28.00', '60.00', 45),
(728874170, '16.00', '3.00', 25),
(728874170, '60.00', '3.00', 10),
(728874170, '58.00', '3.00', 9),
(728874170, '4.00', '15.00', 67),
(728874170, '16.00', '3.00', 34),
(728874170, '3.00', '5.00', 69),
(728874170, '28.00', '3.00', 45),
(567000901, '8.00', '6.00', 72),
(567000901, '16.00', '3.00', 25),
(567000901, '16.00', '3.00', 34),
(119335853, '16.00', '3.00', 25),
(119335853, '60.00', '3.00', 10),
(119335853, '22.00', '3.00', 31),
(119335853, '34.00', '3.00', 20),
(119335853, '16.00', '3.00', 34),
(119335853, '16.00', '6.00', 29),
(248120307, '16.00', '3.00', 25),
(248120307, '4.00', '10.00', 67),
(248120307, '32.00', '5.00', 11),
(248120307, '18.00', '5.00', 13),
(949478189, '30.00', '6.00', 87),
(949478189, '40.00', '6.00', 8),
(949478189, '22.00', '3.00', 61),
(949478189, '60.00', '3.00', 10),
(949478189, '58.00', '6.00', 9),
(949478189, '22.00', '9.00', 31),
(949478189, '22.00', '3.00', 62),
(949478189, '55.00', '3.00', 83),
(949478189, '24.00', '3.00', 36),
(949478189, '16.00', '3.00', 35),
(949478189, '28.00', '6.00', 45),
(949478189, '18.00', '20.00', 13),
(325972536, '30.00', '3.00', 7),
(325972536, '60.00', '3.00', 10),
(325972536, '28.00', '3.00', 45),
(325972536, '18.00', '10.00', 13),
(811201292, '18.00', '3.00', 26),
(811201292, '22.00', '6.00', 31),
(811201292, '55.00', '3.00', 83),
(811201292, '4.00', '20.00', 67),
(811201292, '65.00', '3.00', 19),
(811201292, '34.00', '3.00', 20),
(811201292, '3.00', '20.00', 69),
(954419935, '8.00', '10.00', 72),
(954419935, '40.00', '9.00', 8),
(954419935, '22.00', '9.00', 61),
(954419935, '18.00', '6.00', 47),
(954419935, '16.00', '3.00', 25),
(954419935, '22.00', '3.00', 62),
(954419935, '55.00', '6.00', 83),
(954419935, '20.00', '20.00', 28),
(954419935, '65.00', '3.00', 19),
(954419935, '24.00', '9.00', 63),
(954419935, '28.00', '6.00', 45),
(954419935, '18.00', '40.00', 13),
(808494877, '8.00', '5.00', 72),
(808494877, '12.00', '5.00', 30),
(808494877, '58.00', '3.00', 9),
(808494877, '22.00', '3.00', 31),
(808494877, '4.00', '10.00', 67),
(808494877, '2.00', '10.00', 68),
(808494877, '65.00', '2.00', 19),
(808494877, '34.00', '3.00', 20),
(808494877, '24.00', '3.00', 63),
(808494877, '3.00', '10.00', 69),
(808494877, '16.00', '3.00', 35),
(470949890, '40.00', '3.00', 8),
(470949890, '12.00', '3.00', 30),
(470949890, '60.00', '3.00', 10),
(470949890, '58.00', '3.00', 9),
(470949890, '4.00', '5.00', 67),
(470949890, '20.00', '3.00', 28),
(470949890, '16.00', '3.00', 34),
(470949890, '4.50', '10.00', 73),
(470949890, '3.00', '5.00', 69),
(470949890, '15.00', '20.00', 15),
(470949890, '2.50', '10.00', 70),
(470949890, '32.00', '6.00', 11),
(470949890, '28.00', '3.00', 45),
(470949890, '22.00', '5.00', 14),
(470949890, '18.00', '5.00', 13),
(633699272, '8.00', '10.00', 72),
(633699272, '40.00', '3.00', 8),
(633699272, '30.00', '3.00', 7),
(633699272, '39.00', '3.00', 76),
(633699272, '16.00', '3.00', 25),
(633699272, '60.00', '3.00', 10),
(633699272, '58.00', '3.00', 9),
(633699272, '22.00', '3.00', 62),
(633699272, '4.00', '20.00', 67),
(633699272, '20.00', '6.00', 28),
(633699272, '2.00', '5.00', 68),
(633699272, '34.00', '3.00', 20),
(633699272, '24.00', '3.00', 36),
(633699272, '24.00', '3.00', 63),
(633699272, '16.00', '3.00', 34),
(633699272, '3.00', '5.00', 69),
(633699272, '16.00', '3.00', 35),
(633699272, '28.00', '3.00', 45),
(633699272, '18.00', '10.00', 13),
(627804473, '18.00', '3.00', 26),
(627804473, '16.00', '3.00', 27),
(627804473, '55.00', '3.00', 83),
(627804473, '50.00', '3.00', 44),
(627804473, '16.00', '3.00', 34),
(627804473, '22.00', '5.00', 14),
(483789834, '40.00', '3.00', 8),
(483789834, '16.00', '3.00', 25),
(483789834, '58.00', '3.00', 9),
(483789834, '55.00', '2.00', 83),
(483789834, '4.00', '15.00', 67),
(483789834, '2.00', '5.00', 68),
(483789834, '34.00', '3.00', 20),
(483789834, '28.00', '3.00', 45),
(483789834, '22.00', '5.00', 14),
(483789834, '18.00', '10.00', 13),
(792899659, '34.00', '6.00', 20),
(792899659, '32.00', '10.00', 11),
(792899659, '28.00', '3.00', 45),
(386281175, '58.00', '3.00', 9),
(386281175, '55.00', '3.00', 83),
(386281175, '20.00', '3.00', 28),
(386281175, '50.00', '3.00', 44),
(386281175, '16.00', '3.00', 34),
(386281175, '28.00', '3.00', 45),
(386281175, '22.00', '5.00', 14),
(386281175, '18.00', '5.00', 13),
(641787028, '22.00', '3.00', 62),
(641787028, '16.00', '3.00', 34),
(641787028, '16.00', '3.00', 35),
(641787028, '28.00', '3.00', 45),
(554648060, '16.00', '3.00', 25),
(554648060, '58.00', '3.00', 9),
(554648060, '20.00', '3.00', 28),
(554648060, '28.00', '3.00', 45),
(554648060, '22.00', '5.00', 14),
(554648060, '18.00', '5.00', 13),
(988960842, '30.00', '3.00', 7),
(988960842, '18.00', '3.00', 26),
(988960842, '16.00', '3.00', 27),
(988960842, '16.00', '3.00', 25),
(988960842, '60.00', '3.00', 10),
(988960842, '58.00', '3.00', 9),
(988960842, '22.00', '3.00', 31),
(988960842, '55.00', '2.00', 83),
(988960842, '4.00', '10.00', 67),
(988960842, '20.00', '3.00', 28),
(988960842, '2.00', '5.00', 68),
(988960842, '50.00', '3.00', 44),
(988960842, '65.00', '3.00', 19),
(988960842, '34.00', '3.00', 20),
(988960842, '55.00', '2.00', 21),
(988960842, '4.50', '5.00', 73),
(988960842, '3.00', '5.00', 69),
(988960842, '2.50', '5.00', 70),
(988960842, '16.00', '3.00', 35),
(988960842, '28.00', '3.00', 45),
(988960842, '3.00', '5.00', 71),
(898343334, '8.00', '5.00', 72),
(898343334, '60.00', '3.00', 10),
(898343334, '22.00', '3.00', 31),
(898343334, '16.00', '3.00', 34),
(898343334, '3.00', '10.00', 69),
(373483394, '30.00', '3.00', 7),
(373483394, '39.00', '3.00', 64),
(373483394, '18.00', '3.00', 47),
(373483394, '16.00', '3.00', 27),
(373483394, '12.00', '3.00', 30),
(373483394, '60.00', '3.00', 10),
(373483394, '58.00', '3.00', 9),
(373483394, '4.00', '10.00', 67),
(373483394, '20.00', '3.00', 28),
(373483394, '2.00', '10.00', 68),
(373483394, '50.00', '2.00', 44),
(373483394, '18.00', '10.00', 13),
(459348714, '8.00', '10.00', 72),
(459348714, '40.00', '3.00', 8),
(459348714, '18.00', '3.00', 47),
(459348714, '16.00', '3.00', 25),
(459348714, '55.00', '3.00', 83),
(459348714, '16.00', '3.00', 29),
(459348714, '4.50', '10.00', 73),
(459348714, '2.50', '10.00', 70),
(459348714, '32.00', '30.00', 11),
(459348714, '28.00', '3.00', 45),
(999190154, '45.00', '3.00', 8),
(999190154, '18.00', '3.00', 25),
(999190154, '60.00', '3.00', 10),
(999190154, '4.50', '15.00', 67),
(999190154, '20.00', '5.00', 28),
(999190154, '50.00', '2.00', 44),
(999190154, '65.00', '2.00', 19),
(999190154, '34.00', '3.00', 20),
(999190154, '24.00', '3.00', 36),
(999190154, '17.00', '3.00', 34),
(999190154, '18.00', '3.00', 29),
(999190154, '3.00', '5.00', 69),
(999190154, '27.00', '5.00', 14),
(999190154, '22.00', '10.00', 13),
(948173601, '18.00', '3.00', 25),
(948173601, '4.50', '10.00', 67),
(948173601, '2.00', '5.00', 68),
(948173601, '50.00', '3.00', 44),
(948173601, '110.00', '3.00', 18),
(948173601, '5.00', '5.00', 73),
(948173601, '48.00', '3.00', 16),
(948173601, '2.50', '5.00', 70),
(948173601, '28.00', '3.00', 45),
(948173601, '3.00', '5.00', 71),
(538654933, '33.00', '3.00', 7),
(538654933, '24.00', '3.00', 61),
(538654933, '39.00', '3.00', 64),
(538654933, '18.00', '5.00', 47),
(538654933, '18.00', '3.00', 26),
(538654933, '16.00', '3.00', 27),
(538654933, '60.00', '3.00', 10),
(538654933, '58.00', '3.00', 9),
(538654933, '22.00', '3.00', 62),
(538654933, '20.00', '5.00', 28),
(538654933, '24.00', '3.00', 36),
(538654933, '24.00', '3.00', 63),
(538654933, '17.00', '3.00', 35),
(538654933, '28.00', '3.00', 45),
(597676851, '33.00', '3.00', 7),
(597676851, '24.00', '3.00', 61),
(597676851, '39.00', '3.00', 64),
(597676851, '18.00', '3.00', 47),
(597676851, '18.00', '3.00', 25),
(597676851, '16.00', '3.00', 27),
(597676851, '58.00', '3.00', 9),
(597676851, '23.00', '3.00', 31),
(597676851, '22.00', '3.00', 62),
(597676851, '4.50', '20.00', 67),
(597676851, '2.00', '5.00', 68),
(597676851, '50.00', '2.00', 44),
(597676851, '65.00', '2.00', 19),
(597676851, '34.00', '3.00', 20),
(597676851, '5.00', '5.00', 73),
(597676851, '3.00', '5.00', 69),
(597676851, '2.50', '5.00', 70),
(597676851, '28.00', '3.00', 45),
(597676851, '3.00', '5.00', 71),
(773696656, '34.00', '6.00', 20),
(773696656, '32.00', '15.00', 11),
(372781835, '33.00', '3.00', 7),
(372781835, '23.00', '3.00', 31),
(372781835, '4.50', '10.00', 67),
(372781835, '24.00', '3.00', 63),
(372781835, '55.00', '2.00', 21),
(372781835, '15.00', '10.00', 15),
(372781835, '17.00', '3.00', 35),
(771529066, '45.00', '3.00', 8),
(771529066, '18.00', '3.00', 26),
(771529066, '23.00', '3.00', 31),
(983054428, '20.00', '3.00', 28),
(983054428, '50.00', '3.00', 44),
(983054428, '34.00', '3.00', 20),
(983054428, '24.00', '3.00', 36),
(983054428, '28.00', '3.00', 45),
(983054428, '22.00', '5.00', 13),
(670014429, '23.00', '3.00', 31),
(670014429, '22.00', '3.00', 62),
(670014429, '55.00', '3.00', 83),
(670014429, '65.00', '3.00', 19),
(670014429, '55.00', '3.00', 21),
(670014429, '28.00', '3.00', 45),
(173181318, '39.00', '3.00', 64),
(173181318, '12.00', '5.00', 30),
(173181318, '22.00', '3.00', 62),
(173181318, '55.00', '3.00', 83),
(173181318, '28.00', '3.00', 77),
(173181318, '50.00', '3.00', 44),
(173181318, '110.00', '6.00', 18),
(173181318, '65.00', '6.00', 19),
(173181318, '27.00', '3.00', 42),
(173181318, '24.00', '3.00', 63),
(173181318, '17.00', '3.00', 34),
(173181318, '27.00', '10.00', 14),
(173181318, '22.00', '5.00', 13),
(882029274, '33.00', '3.00', 7),
(882029274, '60.00', '3.00', 10),
(882029274, '23.00', '3.00', 31),
(882029274, '34.00', '3.00', 20),
(882029274, '32.00', '3.00', 11),
(882029274, '17.00', '3.00', 35),
(882029274, '27.00', '3.00', 14),
(882029274, '22.00', '5.00', 13),
(534169831, '33.00', '3.00', 7),
(534169831, '18.00', '3.00', 25),
(534169831, '58.00', '3.00', 9),
(534169831, '4.50', '20.00', 67),
(534169831, '20.00', '6.00', 28),
(534169831, '2.00', '5.00', 68),
(534169831, '50.00', '3.00', 44),
(534169831, '17.00', '3.00', 34),
(534169831, '18.00', '3.00', 29),
(534169831, '3.00', '5.00', 69),
(534169831, '48.00', '3.00', 16),
(534169831, '17.00', '3.00', 35),
(534169831, '28.00', '3.00', 45),
(946089538, '4.50', '6.00', 67),
(946089538, '34.00', '3.00', 20),
(946089538, '15.00', '6.00', 15),
(946089538, '32.00', '6.00', 11),
(104521501, '8.00', '10.00', 72),
(104521501, '50.00', '3.00', 44),
(104521501, '18.00', '5.00', 29),
(104521501, '12.00', '10.00', 65),
(104521501, '28.00', '6.00', 45),
(321387177, '45.00', '3.00', 8),
(321387177, '24.00', '3.00', 61),
(321387177, '39.00', '3.00', 64),
(321387177, '18.00', '3.00', 25),
(321387177, '16.00', '3.00', 27),
(321387177, '60.00', '3.00', 10),
(321387177, '58.00', '6.00', 9),
(321387177, '23.00', '9.00', 31),
(321387177, '22.00', '3.00', 62),
(321387177, '28.00', '3.00', 77),
(321387177, '20.00', '10.00', 28),
(321387177, '50.00', '3.00', 44),
(321387177, '27.00', '3.00', 42),
(321387177, '24.00', '3.00', 36),
(321387177, '24.00', '3.00', 63),
(321387177, '17.00', '6.00', 34),
(321387177, '18.00', '10.00', 29),
(321387177, '32.00', '50.00', 11),
(321387177, '17.00', '3.00', 35),
(321387177, '28.00', '6.00', 45),
(321387177, '22.00', '20.00', 13),
(519314342, '45.00', '1.00', 8),
(519314342, '24.00', '1.00', 61),
(519314342, '12.00', '2.00', 30),
(519314342, '60.00', '1.00', 10),
(519314342, '58.00', '2.00', 9),
(519314342, '23.00', '1.00', 31),
(519314342, '4.50', '2.00', 67),
(519314342, '20.00', '1.00', 28),
(519314342, '2.00', '10.00', 68),
(519314342, '110.00', '1.00', 18),
(519314342, '65.00', '1.00', 19),
(519314342, '34.00', '1.00', 20),
(519314342, '17.00', '1.00', 34),
(519314342, '55.00', '1.00', 21),
(519314342, '3.00', '10.00', 69),
(519314342, '15.00', '5.00', 15),
(519314342, '2.50', '10.00', 70),
(519314342, '32.00', '2.00', 11),
(273961678, '33.00', '9.00', 7),
(273961678, '45.00', '9.00', 8),
(273961678, '39.00', '3.00', 64),
(273961678, '55.00', '9.00', 83),
(273961678, '65.00', '6.00', 19),
(273961678, '48.00', '5.00', 16),
(273961678, '17.00', '3.00', 35),
(273961678, '28.00', '6.00', 45),
(968856066, '25.00', '3.00', 75),
(968856066, '33.00', '3.00', 7),
(968856066, '45.00', '3.00', 8),
(968856066, '58.00', '3.00', 9),
(968856066, '4.50', '10.00', 67),
(968856066, '20.00', '3.00', 28),
(968856066, '27.00', '3.00', 42),
(968856066, '24.00', '3.00', 36),
(968856066, '24.00', '3.00', 63),
(968856066, '17.00', '3.00', 34),
(968856066, '5.00', '10.00', 73),
(968856066, '3.00', '10.00', 69),
(968856066, '2.50', '10.00', 70),
(968856066, '17.00', '3.00', 35),
(968856066, '28.00', '3.00', 45),
(968856066, '3.00', '10.00', 71),
(968856066, '22.00', '10.00', 13),
(994364757, '20.00', '3.00', 28),
(994364757, '110.00', '3.00', 18),
(994364757, '70.00', '3.00', 19),
(994364757, '34.00', '2.00', 20),
(943095685, '32.00', '10.00', 11),
(943095685, '22.00', '10.00', 13),
(484101199, '32.00', '10.00', 11),
(104229517, '38.00', '3.00', 8),
(104229517, '20.00', '3.00', 34),
(104229517, '12.00', '3.00', 65),
(696474489, '20.00', '3.00', 61),
(696474489, '20.00', '3.00', 34),
(696474489, '19.00', '3.00', 25),
(696474489, '23.00', '3.00', 31),
(696474489, '4.00', '20.00', 67),
(696474489, '34.00', '3.00', 20),
(696474489, '22.00', '3.00', 63),
(696474489, '15.00', '3.00', 35),
(696474489, '19.00', '3.00', 47),
(696474489, '25.00', '10.00', 14),
(696474489, '22.00', '10.00', 13),
(730433965, '38.00', '3.00', 8),
(730433965, '20.00', '3.00', 34),
(730433965, '65.00', '3.00', 10),
(730433965, '58.00', '6.00', 9),
(730433965, '4.00', '50.00', 67),
(730433965, '70.00', '3.00', 19),
(730433965, '30.00', '3.00', 77),
(730433965, '3.00', '10.00', 69),
(730433965, '3.00', '30.00', 71),
(730433965, '23.00', '3.00', 62),
(730433965, '22.00', '20.00', 13),
(730433965, '23.00', '3.00', 36),
(825198255, '36.00', '3.00', 7),
(825198255, '38.00', '3.00', 8),
(825198255, '30.00', '3.00', 77),
(825198255, '27.00', '3.00', 42),
(825198255, '22.00', '3.00', 63),
(825198255, '55.00', '3.00', 44),
(825198255, '15.00', '3.00', 35),
(825198255, '23.00', '3.00', 62),
(825198255, '19.00', '3.00', 47),
(169545937, '23.00', '3.00', 62),
(169545937, '25.00', '3.00', 14),
(169545937, '22.00', '5.00', 13),
(169545937, '23.00', '3.00', 36),
(285179618, '18.00', '3.00', 26),
(285179618, '59.00', '3.00', 83),
(285179618, '4.00', '5.00', 67),
(285179618, '20.00', '3.00', 28),
(285179618, '2.50', '5.00', 68),
(285179618, '110.00', '2.00', 18),
(285179618, '32.00', '3.00', 11),
(285179618, '3.00', '5.00', 69),
(285179618, '15.00', '3.00', 35),
(405810177, '20.00', '3.00', 34),
(405810177, '19.00', '6.00', 25),
(405810177, '18.00', '6.00', 26),
(405810177, '16.00', '6.00', 27),
(405810177, '65.00', '3.00', 10),
(405810177, '58.00', '6.00', 9),
(405810177, '23.00', '9.00', 31),
(405810177, '59.00', '3.00', 83),
(405810177, '20.00', '10.00', 28),
(405810177, '34.00', '3.00', 20),
(405810177, '38.00', '3.00', 64),
(405810177, '25.00', '10.00', 14),
(405810177, '22.00', '20.00', 13),
(405810177, '23.00', '30.00', 36),
(780460754, '12.00', '5.00', 65),
(780460754, '18.00', '10.00', 29),
(814175436, '58.00', '3.00', 9),
(814175436, '18.00', '3.00', 29),
(814175436, '15.00', '3.00', 35),
(889959599, '36.00', '3.00', 7),
(889959599, '12.00', '5.00', 30),
(889959599, '58.00', '3.00', 9),
(889959599, '23.00', '3.00', 31),
(889959599, '4.00', '10.00', 67),
(889959599, '34.00', '2.00', 20),
(889959599, '32.00', '6.00', 11),
(889959599, '3.00', '10.00', 69),
(889959599, '25.00', '5.00', 14),
(889959599, '22.00', '10.00', 13),
(514601354, '36.00', '9.00', 7),
(514601354, '38.00', '6.00', 8),
(514601354, '20.00', '12.00', 34),
(514601354, '59.00', '6.00', 83),
(514601354, '34.00', '6.00', 20),
(514601354, '15.00', '20.00', 15),
(514601354, '19.00', '6.00', 46),
(849669499, '36.00', '3.00', 7),
(849669499, '65.00', '3.00', 10),
(849669499, '58.00', '3.00', 9),
(849669499, '34.00', '2.00', 20),
(849669499, '15.00', '10.00', 15),
(849669499, '22.00', '10.00', 13),
(438043339, '34.00', '6.00', 20),
(241982051, '4.00', '15.00', 67),
(241982051, '34.00', '2.00', 20),
(241982051, '55.00', '5.00', 21),
(241982051, '5.00', '5.00', 73),
(241982051, '3.00', '10.00', 69),
(241982051, '22.00', '10.00', 13),
(105734677, '36.00', '3.00', 7),
(105734677, '38.00', '3.00', 8),
(105734677, '20.00', '3.00', 61),
(105734677, '19.00', '3.00', 25),
(105734677, '58.00', '3.00', 9),
(105734677, '55.00', '3.00', 44),
(105734677, '22.00', '5.00', 13),
(536662002, '20.00', '6.00', 34),
(536662002, '34.00', '6.00', 20),
(536662002, '19.00', '3.00', 47),
(507383228, '20.00', '3.00', 34),
(507383228, '12.00', '6.00', 30),
(507383228, '15.00', '3.00', 35),
(507383228, '19.00', '3.00', 47),
(817897634, '36.00', '3.00', 7),
(817897634, '19.00', '3.00', 25),
(817897634, '58.00', '3.00', 9),
(817897634, '4.00', '10.00', 67),
(817897634, '2.50', '5.00', 68),
(176321059, '38.00', '3.00', 8),
(176321059, '58.00', '3.00', 9),
(176321059, '30.00', '3.00', 77),
(176321059, '23.00', '3.00', 62),
(176321059, '22.00', '5.00', 13),
(734994428, '8.00', '10.00', 72),
(734994428, '36.00', '3.00', 7),
(734994428, '38.00', '3.00', 8),
(734994428, '20.00', '3.00', 34),
(734994428, '19.00', '3.00', 25),
(734994428, '16.00', '3.00', 27),
(734994428, '12.00', '10.00', 30),
(734994428, '58.00', '6.00', 9),
(734994428, '23.00', '3.00', 31),
(734994428, '20.00', '6.00', 28),
(734994428, '2.50', '10.00', 68),
(734994428, '34.00', '6.00', 20),
(734994428, '22.00', '3.00', 63),
(734994428, '18.00', '3.00', 29),
(734994428, '55.00', '3.00', 44),
(734994428, '3.00', '5.00', 69),
(734994428, '15.00', '3.00', 35),
(734994428, '23.00', '3.00', 62),
(179924154, '4.00', '15.00', 67),
(179924154, '20.00', '6.00', 28),
(179924154, '2.50', '5.00', 68),
(179924154, '55.00', '3.00', 44),
(605908701, '36.00', '3.00', 7),
(605908701, '12.00', '5.00', 30),
(605908701, '58.00', '3.00', 9),
(605908701, '23.00', '5.00', 31),
(605908701, '4.00', '10.00', 67),
(605908701, '3.00', '5.00', 69),
(390017781, '38.00', '3.00', 8),
(390017781, '20.00', '3.00', 61),
(390017781, '20.00', '3.00', 34),
(390017781, '16.00', '3.00', 27),
(390017781, '12.00', '3.00', 30),
(390017781, '58.00', '3.00', 9),
(390017781, '23.00', '3.00', 31),
(390017781, '4.00', '20.00', 67),
(390017781, '20.00', '2.00', 28),
(390017781, '2.50', '5.00', 68),
(390017781, '34.00', '3.00', 20),
(390017781, '38.00', '3.00', 64),
(390017781, '5.00', '5.00', 73),
(390017781, '55.00', '2.00', 44),
(390017781, '2.50', '5.00', 70),
(390017781, '3.00', '5.00', 69),
(390017781, '3.00', '5.00', 71),
(390017781, '19.00', '3.00', 47),
(390017781, '25.00', '10.00', 14),
(390017781, '22.00', '20.00', 13),
(197565040, '8.00', '5.00', 72),
(197565040, '23.00', '3.00', 31),
(197565040, '18.00', '3.00', 29),
(327459603, '25.00', '3.00', 75),
(327459603, '8.00', '10.00', 72),
(327459603, '20.00', '3.00', 61),
(327459603, '19.00', '3.00', 25),
(327459603, '65.00', '3.00', 10),
(327459603, '58.00', '3.00', 9),
(327459603, '4.00', '10.00', 67),
(327459603, '20.00', '3.00', 28),
(327459603, '2.50', '5.00', 68),
(327459603, '70.00', '2.00', 19),
(327459603, '34.00', '3.00', 20),
(327459603, '22.00', '3.00', 63),
(327459603, '55.00', '1.00', 21),
(327459603, '5.00', '5.00', 73),
(327459603, '19.00', '3.00', 46),
(327459603, '2.50', '5.00', 70),
(327459603, '3.00', '5.00', 69),
(327459603, '15.00', '3.00', 35),
(327459603, '3.00', '5.00', 71),
(327459603, '23.00', '3.00', 62),
(327459603, '23.00', '2.00', 36),
(492919716, '20.00', '3.00', 28),
(972948965, '36.00', '10.00', 7),
(972948965, '38.00', '10.00', 8),
(219634109, '25.00', '15.00', 75),
(219634109, '8.00', '17.00', 72),
(219634109, '36.00', '20.00', 7),
(219634109, '38.00', '15.00', 8),
(219634109, '20.00', '20.00', 61),
(219634109, '20.00', '40.00', 34),
(219634109, '19.00', '10.00', 25),
(219634109, '18.00', '8.00', 26),
(219634109, '16.00', '10.00', 27),
(219634109, '65.00', '20.00', 10),
(219634109, '58.00', '40.00', 9),
(219634109, '23.00', '20.00', 31),
(219634109, '59.00', '7.00', 83),
(219634109, '20.00', '30.00', 28),
(219634109, '110.00', '10.00', 18),
(219634109, '30.00', '15.00', 77),
(219634109, '34.00', '5.00', 20),
(219634109, '38.00', '20.00', 64),
(219634109, '27.00', '3.00', 42),
(219634109, '55.00', '8.00', 44),
(219634109, '15.00', '15.00', 35),
(219634109, '23.00', '25.00', 62),
(219634109, '23.00', '25.00', 36),
(20200800231, '45.00', '3.00', 8),
(20200800231, '17.00', '3.00', 61),
(20200800231, '20.00', '3.00', 34),
(20200800231, '11.00', '3.00', 30),
(20200800231, '65.00', '3.00', 10),
(20200800231, '58.00', '3.00', 9),
(20200800231, '23.00', '3.00', 31),
(20200800231, '4.00', '10.00', 67),
(20200800231, '21.00', '3.00', 28),
(20200800231, '2.50', '15.00', 68),
(20200800231, '78.00', '3.00', 19),
(20200800231, '34.00', '3.00', 20),
(20200800231, '22.00', '3.00', 63),
(20200800231, '18.00', '3.00', 29),
(20200800231, '15.00', '15.00', 15),
(20200800231, '32.50', '6.00', 11),
(20200800231, '3.00', '5.00', 69),
(20200800231, '15.00', '3.00', 35),
(20200800231, '23.00', '3.00', 62),
(20200800231, '25.00', '3.00', 14),
(20200800231, '22.00', '3.00', 13),
(20200800232, '11.00', '3.00', 30),
(20200800232, '65.00', '3.00', 10),
(20200800232, '58.00', '3.00', 9),
(20200800232, '23.00', '3.00', 31),
(20200800232, '59.00', '3.00', 83),
(20200800232, '4.00', '10.00', 67),
(20200800232, '2.50', '10.00', 68),
(20200800232, '55.00', '2.00', 21),
(20200800232, '45.00', '3.00', 16),
(20200800232, '2.50', '5.00', 70),
(20200800232, '3.00', '5.00', 69),
(20200800232, '3.00', '5.00', 71),
(20200800233, '15.00', '10.00', 15),
(20200800233, '32.50', '5.00', 11),
(20200800234, '34.00', '3.00', 20),
(20200800234, '45.00', '6.00', 16),
(20200800235, '36.00', '3.00', 7),
(20200800235, '45.00', '3.00', 8),
(20200800235, '17.00', '3.00', 61),
(20200800235, '20.00', '3.00', 34),
(20200800235, '19.00', '3.00', 25),
(20200800235, '11.00', '3.00', 30),
(20200800235, '65.00', '3.00', 10),
(20200800235, '58.00', '3.00', 9),
(20200800235, '34.00', '3.00', 20),
(20200800235, '22.00', '3.00', 63),
(20200800235, '55.00', '3.00', 21),
(20200800235, '18.00', '6.00', 29),
(20200800235, '15.00', '10.00', 15),
(20200800235, '32.50', '3.00', 11),
(20200800235, '15.00', '3.00', 35),
(20200800235, '23.00', '3.00', 62),
(20200800235, '25.00', '5.00', 14),
(20200800235, '22.00', '10.00', 13),
(20200800236, '36.00', '6.00', 7),
(20200800236, '20.00', '3.00', 34),
(20200800236, '19.00', '3.00', 25),
(20200800236, '23.00', '5.00', 31),
(20200800237, '8.00', '10.00', 72),
(20200800237, '36.00', '3.00', 7),
(20200800237, '45.00', '3.00', 8),
(20200800237, '20.00', '3.00', 34),
(20200800237, '19.00', '3.00', 25),
(20200800237, '65.00', '3.00', 10),
(20200800237, '58.00', '6.00', 9),
(20200800237, '23.00', '3.00', 31),
(20200800237, '4.00', '20.00', 67),
(20200800237, '2.50', '5.00', 68),
(20200800237, '34.00', '6.00', 20),
(20200800237, '38.00', '3.00', 64),
(20200800237, '18.00', '3.00', 29),
(20200800237, '55.00', '3.00', 44),
(20200800237, '15.00', '3.00', 35),
(20200800237, '23.00', '3.00', 62),
(20200800237, '22.00', '10.00', 13),
(20200800239, '8.00', '20.00', 72),
(20200800239, '36.00', '3.00', 7),
(20200800239, '45.00', '3.00', 8),
(20200800239, '17.00', '3.00', 61),
(20200800239, '20.00', '6.00', 34),
(20200800239, '65.00', '3.00', 10),
(20200800239, '58.00', '6.00', 9),
(20200800239, '23.00', '9.00', 31),
(20200800239, '59.00', '3.00', 83),
(20200800239, '21.00', '10.00', 28),
(20200800239, '38.00', '6.00', 64),
(20200800239, '22.00', '3.00', 63),
(20200800239, '15.00', '3.00', 35),
(20200800239, '23.00', '3.00', 62),
(20200800239, '25.00', '10.00', 14),
(20200800239, '22.00', '20.00', 13),
(20200800239, '22.00', '3.00', 36),
(20200800240, '20.00', '2.00', 34),
(20200800240, '19.00', '2.00', 25),
(20200800240, '11.00', '2.00', 30),
(20200800240, '23.00', '2.00', 31),
(20200800240, '12.00', '2.00', 65),
(20200800240, '32.50', '2.00', 11),
(20200800242, '34.00', '6.00', 20),
(20200800242, '45.00', '3.00', 16),
(20200800242, '32.50', '15.00', 11),
(20200800243, '17.00', '3.00', 61),
(20200800243, '20.00', '3.00', 34),
(20200800243, '58.00', '3.00', 9),
(20200800243, '4.00', '10.00', 67),
(20200800243, '22.00', '5.00', 13),
(20200800244, '36.00', '3.00', 7),
(20200800244, '20.00', '3.00', 34),
(20200800244, '19.00', '3.00', 25),
(20200800244, '65.00', '3.00', 10),
(20200800244, '58.00', '3.00', 9),
(20200800244, '59.00', '3.00', 83),
(20200800244, '34.00', '3.00', 20),
(20200800245, '65.00', '6.00', 10),
(20200800245, '45.00', '3.00', 16),
(20200800245, '32.50', '10.00', 11),
(20200800241, '45.00', '3.00', 8),
(20200800241, '58.00', '3.00', 9),
(20200800241, '4.00', '15.00', 67),
(20200800241, '2.50', '5.00', 68),
(20200800241, '78.00', '3.00', 19),
(20200800241, '3.00', '5.00', 69),
(20200800241, '22.00', '10.00', 13),
(20200800246, '20.00', '3.00', 34),
(20200800246, '34.00', '3.00', 20),
(20200800246, '12.00', '3.00', 65),
(20200800246, '15.00', '3.00', 35),
(20200800247, '25.00', '5.00', 75),
(20200800247, '36.00', '3.00', 7),
(20200800247, '20.00', '3.00', 34),
(20200800247, '34.00', '3.00', 20),
(20200800247, '30.00', '3.00', 42),
(20200800247, '18.00', '6.00', 29),
(20200800247, '25.00', '5.00', 14),
(20200800238, '58.00', '3.00', 9),
(20200800238, '23.00', '3.00', 31),
(20200800238, '59.00', '3.00', 83),
(20200800238, '4.00', '15.00', 67),
(20200800238, '21.00', '6.00', 28),
(20200800238, '78.00', '2.00', 19),
(20200800238, '34.00', '3.00', 20),
(20200800238, '55.00', '3.00', 21),
(20200800238, '32.50', '10.00', 11),
(20200800248, '59.00', '10.00', 83),
(20200800248, '108.00', '6.00', 18),
(20200800248, '78.00', '3.00', 19),
(20200800248, '32.50', '20.00', 11),
(20200800249, '8.00', '12.00', 72),
(20200800249, '4.00', '30.00', 67),
(20200800249, '15.00', '3.00', 35),
(20200800249, '22.00', '10.00', 13),
(20200800250, '36.00', '3.00', 7),
(20200800250, '17.00', '3.00', 61),
(20200800250, '23.00', '3.00', 31),
(20200800250, '4.00', '10.00', 67),
(20200800250, '2.50', '10.00', 68),
(20200800250, '34.00', '3.00', 20),
(20200800250, '22.00', '3.00', 63),
(20200800250, '55.00', '3.00', 44),
(20200800250, '2.50', '10.00', 70),
(20200800250, '3.00', '15.00', 69),
(20200800250, '15.00', '3.00', 35),
(20200800250, '3.00', '10.00', 71),
(20200800250, '23.00', '3.00', 62),
(20200800252, '18.00', '3.00', 26),
(20200800252, '19.00', '2.00', 46),
(20200800252, '32.50', '10.00', 11),
(20200800252, '25.00', '5.00', 14),
(20200800253, '34.00', '6.00', 20),
(20200800254, '45.00', '6.00', 8),
(20200800254, '34.00', '3.00', 20),
(20200800254, '25.00', '10.00', 14),
(20200800255, '25.00', '3.00', 75),
(20200800255, '36.00', '3.00', 7),
(20200800255, '17.00', '3.00', 61),
(20200800255, '20.00', '3.00', 34),
(20200800255, '18.00', '3.00', 26),
(20200800255, '18.00', '3.00', 27),
(20200800255, '11.00', '5.00', 30),
(20200800255, '65.00', '3.00', 10),
(20200800255, '58.00', '3.00', 9),
(20200800255, '59.00', '2.00', 83),
(20200800255, '4.00', '20.00', 67),
(20200800255, '21.00', '5.00', 28),
(20200800255, '2.50', '15.00', 68),
(20200800255, '34.00', '3.00', 20),
(20200800255, '30.00', '2.00', 42),
(20200800255, '22.00', '3.00', 63),
(20200800255, '18.00', '5.00', 29),
(20200800255, '15.00', '10.00', 15),
(20200800255, '19.00', '3.00', 46),
(20200800255, '3.00', '15.00', 69),
(20200800255, '15.00', '3.00', 35),
(20200800255, '25.00', '10.00', 14),
(20200800256, '20.00', '3.00', 34),
(20200800256, '18.00', '3.00', 27),
(20200800256, '59.00', '3.00', 83),
(20200800256, '3.00', '10.00', 69),
(20200800258, '36.00', '3.00', 7),
(20200800258, '45.00', '3.00', 8),
(20200800258, '20.00', '3.00', 34),
(20200800258, '23.00', '3.00', 31),
(20200800258, '21.00', '3.00', 28),
(20200800258, '55.00', '3.00', 44),
(20200800258, '25.00', '5.00', 14),
(20200800259, '20.00', '3.00', 34),
(20200800259, '18.00', '3.00', 27),
(20200800259, '58.00', '3.00', 9),
(20200800259, '22.00', '5.00', 13),
(20200800260, '19.00', '3.00', 25),
(20200800260, '23.00', '3.00', 31),
(20200800260, '59.00', '2.00', 83),
(20200800260, '45.00', '3.00', 16),
(20200800261, '23.00', '3.00', 31),
(20200800261, '38.00', '3.00', 64),
(20200800262, '4.00', '2.00', 67),
(20200800262, '34.00', '1.00', 20),
(20200800262, '22.00', '3.00', 63),
(20200800262, '15.00', '2.00', 15),
(20200800262, '45.00', '1.00', 16),
(20200800262, '3.00', '2.00', 71),
(20200800262, '23.00', '3.00', 62),
(20200800264, '36.00', '6.00', 7),
(20200800264, '45.00', '6.00', 8),
(20200800264, '20.00', '6.00', 34),
(20200800264, '34.00', '6.00', 20),
(20200800264, '38.00', '6.00', 64),
(20200800265, '45.00', '3.00', 8),
(20200800265, '20.00', '3.00', 34),
(20200800265, '19.00', '3.00', 25),
(20200800265, '23.00', '3.00', 31),
(20200800265, '59.00', '3.00', 83),
(20200800265, '21.00', '3.00', 28),
(20200800265, '34.00', '3.00', 20),
(20200800265, '22.00', '3.00', 63),
(20200800265, '22.00', '10.00', 13),
(20200800266, '4.00', '10.00', 67),
(20200800266, '2.50', '10.00', 68),
(20200800266, '34.00', '3.00', 20),
(20200800266, '32.50', '5.00', 11),
(20200800266, '22.00', '5.00', 13),
(20200800267, '25.00', '3.00', 75),
(20200800267, '45.00', '3.00', 8),
(20200800267, '58.00', '3.00', 9),
(20200800267, '38.00', '3.00', 64),
(20200800267, '22.00', '3.00', 63),
(20200800267, '15.00', '3.00', 35),
(20200800267, '23.00', '3.00', 62),
(20200800267, '22.00', '5.00', 13),
(20200800268, '17.00', '3.00', 61),
(20200800268, '20.00', '3.00', 34),
(20200800268, '21.00', '3.00', 28),
(20200800268, '34.00', '3.00', 20),
(20200800268, '55.00', '2.00', 44),
(20200800268, '22.00', '5.00', 13),
(20200800269, '11.00', '3.00', 30),
(20200800269, '58.00', '3.00', 9),
(20200800269, '32.50', '10.00', 11),
(20200800270, '11.00', '3.00', 30),
(20200800270, '21.00', '3.00', 28),
(20200800270, '34.00', '3.00', 20),
(20200800270, '18.00', '3.00', 29),
(20200800257, '45.00', '3.00', 8),
(20200800257, '4.00', '5.00', 67),
(20200800257, '34.00', '2.00', 20),
(20200800257, '22.00', '3.00', 63),
(20200800257, '12.00', '3.00', 65),
(20200800257, '25.00', '5.00', 14),
(20200800257, '22.00', '5.00', 13),
(20200800271, '45.00', '6.00', 8),
(20200800271, '20.00', '6.00', 34),
(20200800271, '65.00', '3.00', 10),
(20200800271, '58.00', '6.00', 9),
(20200800271, '23.00', '9.00', 31),
(20200800271, '59.00', '3.00', 83),
(20200800271, '34.00', '3.00', 20),
(20200800271, '25.00', '20.00', 14),
(20200800271, '22.00', '20.00', 13),
(20200800271, '22.00', '3.00', 36),
(20200800272, '20.00', '6.00', 34),
(20200800272, '4.00', '15.00', 67),
(20200800272, '18.00', '3.00', 29),
(20200800273, '8.00', '8.00', 72),
(20200800273, '36.00', '5.00', 7),
(20200800273, '17.00', '3.00', 61),
(20200800273, '20.00', '3.00', 34),
(20200800273, '19.00', '3.00', 25),
(20200800273, '18.00', '3.00', 26),
(20200800273, '18.00', '3.00', 27),
(20200800273, '11.00', '3.00', 30),
(20200800273, '65.00', '3.00', 10),
(20200800273, '58.00', '4.00', 9),
(20200800273, '23.00', '3.00', 31),
(20200800273, '59.00', '3.00', 83),
(20200800273, '4.00', '20.00', 67),
(20200800273, '34.00', '5.00', 20),
(20200800273, '22.00', '3.00', 63),
(20200800273, '55.00', '2.00', 21),
(20200800273, '18.00', '3.00', 29),
(20200800273, '55.00', '2.00', 44),
(20200800273, '15.00', '30.00', 15),
(20200800273, '19.00', '3.00', 46),
(20200800273, '2.50', '10.00', 70),
(20200800273, '3.00', '10.00', 71),
(20200800273, '23.00', '3.00', 62),
(20200800273, '22.00', '3.00', 36),
(20200800274, '45.00', '3.00', 8),
(20200800274, '20.00', '3.00', 34),
(20200800274, '58.00', '6.00', 9),
(20200800274, '23.00', '3.00', 31),
(20200800274, '4.00', '20.00', 67),
(20200800274, '21.00', '6.00', 28),
(20200800274, '2.50', '5.00', 68),
(20200800274, '30.00', '3.00', 77),
(20200800274, '3.00', '5.00', 69),
(20200800274, '15.00', '3.00', 35),
(20200800274, '23.00', '3.00', 62),
(20200800275, '45.00', '3.00', 8),
(20200800275, '34.00', '3.00', 20),
(20200800275, '15.00', '3.00', 35),
(20200800276, '58.00', '2.00', 9),
(20200800276, '59.00', '2.00', 83),
(20200800276, '25.00', '3.00', 14),
(20200800276, '22.00', '3.00', 13),
(20200800277, '32.50', '10.00', 11),
(20200800278, '45.00', '3.00', 8),
(20200800278, '20.00', '3.00', 34),
(20200800278, '65.00', '3.00', 10),
(20200800278, '58.00', '3.00', 9),
(20200800278, '23.00', '3.00', 31),
(20200800278, '59.00', '2.00', 83),
(20200800278, '4.00', '15.00', 67),
(20200800278, '21.00', '3.00', 28),
(20200800278, '34.00', '3.00', 20),
(20200800278, '3.00', '10.00', 69),
(20200800278, '15.00', '3.00', 35),
(20200800278, '3.00', '5.00', 71),
(20200800278, '25.00', '10.00', 14),
(20200800279, '17.00', '3.00', 61),
(20200800279, '23.00', '10.00', 31),
(20200800279, '30.00', '3.00', 77),
(20200800279, '22.00', '6.00', 36),
(20200800280, '20.00', '6.00', 34),
(20200800280, '18.00', '3.00', 26),
(20200800280, '18.00', '3.00', 27),
(20200800280, '65.00', '3.00', 10),
(20200800280, '23.00', '3.00', 31),
(20200800280, '22.00', '3.00', 63),
(20200800280, '55.00', '3.00', 44),
(20200800280, '15.00', '3.00', 35),
(20200800281, '19.00', '10.00', 25),
(20200800281, '11.00', '100.00', 30),
(20200800281, '4.00', '10.00', 67),
(20200800281, '2.50', '10.00', 68),
(20200800281, '34.00', '25.00', 20),
(20200800281, '3.00', '10.00', 69),
(20200800281, '15.00', '10.00', 35),
(20200800281, '23.00', '25.00', 62),
(20200800281, '22.00', '20.00', 13),
(20200800283, '55.00', '3.00', 8),
(20200800283, '20.00', '3.00', 34),
(20200800283, '21.00', '3.00', 28),
(20200800283, '55.00', '3.00', 44),
(20200800283, '22.00', '5.00', 13),
(20200800284, '20.00', '3.00', 34),
(20200800284, '20.00', '3.00', 31),
(20200800284, '21.00', '3.00', 28),
(20200800284, '25.00', '5.00', 14),
(20200800286, '17.00', '3.00', 61),
(20200800286, '20.00', '3.00', 34),
(20200800286, '56.00', '3.00', 10),
(20200800286, '58.00', '3.00', 9),
(20200800286, '20.00', '3.00', 31),
(20200800286, '21.00', '3.00', 28),
(20200800286, '78.00', '2.00', 19),
(20200800286, '22.00', '3.00', 63),
(20200800286, '16.00', '3.00', 35),
(20200800286, '24.00', '3.00', 62),
(20200800286, '25.00', '5.00', 14),
(20200800286, '22.00', '5.00', 13),
(20200800287, '36.00', '3.00', 7),
(20200800287, '20.00', '3.00', 34),
(20200800287, '56.00', '3.00', 10),
(20200800287, '58.00', '3.00', 9),
(20200800287, '20.00', '3.00', 31),
(20200800287, '21.00', '5.00', 28),
(20200800287, '39.00', '3.00', 64),
(20200800287, '55.00', '3.00', 44),
(20200800287, '33.00', '5.00', 11),
(20200800287, '22.00', '10.00', 13),
(20200800288, '9.00', '10.00', 72),
(20200800288, '36.00', '6.00', 7),
(20200800288, '17.00', '3.00', 61),
(20200800288, '20.00', '3.00', 34),
(20200800288, '20.00', '3.00', 25),
(20200800288, '19.00', '3.00', 27),
(20200800288, '12.00', '3.00', 30),
(20200800288, '58.00', '3.00', 9),
(20200800288, '5.00', '10.00', 67),
(20200800288, '21.00', '3.00', 28),
(20200800288, '2.50', '10.00', 68),
(20200800288, '32.00', '3.00', 20),
(20200800288, '39.00', '3.00', 64),
(20200800288, '22.00', '3.00', 63),
(20200800288, '19.00', '3.00', 46),
(20200800288, '2.50', '5.00', 70),
(20200800288, '33.00', '6.00', 11),
(20200800288, '3.00', '10.00', 69),
(20200800288, '16.00', '3.00', 35),
(20200800288, '3.00', '5.00', 71),
(20200800288, '24.00', '3.00', 62),
(20200800288, '22.00', '6.00', 13),
(20200800289, '12.00', '10.00', 65),
(20200800289, '15.00', '10.00', 29),
(20200800289, '19.00', '3.00', 46),
(20200800290, '55.00', '3.00', 8),
(20200800290, '20.00', '6.00', 34),
(20200800290, '22.00', '3.00', 63),
(20200800290, '55.00', '3.00', 44),
(20200800290, '45.00', '2.00', 16),
(20200800290, '33.00', '10.00', 11),
(20200800291, '20.00', '3.00', 34),
(20200800291, '58.00', '3.00', 9),
(20200800291, '20.00', '3.00', 31),
(20200800291, '60.00', '2.00', 83),
(20200800291, '30.00', '2.00', 77),
(20200800291, '39.00', '3.00', 64),
(20200800291, '39.00', '3.00', 76),
(20200800291, '30.00', '2.00', 42),
(20200800291, '22.00', '3.00', 63),
(20200800291, '12.00', '5.00', 65),
(20200800291, '55.00', '2.00', 21),
(20200800291, '55.00', '3.00', 44),
(20200800291, '45.00', '2.00', 16),
(20200800291, '33.00', '10.00', 11),
(20200800291, '24.00', '3.00', 62),
(20200800291, '22.00', '10.00', 13),
(20200800292, '9.00', '10.00', 72),
(20200800292, '36.00', '3.00', 7),
(20200800292, '55.00', '3.00', 8),
(20200800292, '17.00', '3.00', 61),
(20200800292, '20.00', '3.00', 34),
(20200800292, '20.00', '3.00', 25),
(20200800292, '19.00', '3.00', 27),
(20200800292, '56.00', '3.00', 10),
(20200800292, '58.00', '3.00', 9),
(20200800292, '21.00', '6.00', 28),
(20200800292, '32.00', '3.00', 20),
(20200800292, '22.00', '3.00', 63),
(20200800292, '15.00', '3.00', 29),
(20200800292, '16.00', '3.00', 35),
(20200800292, '24.00', '3.00', 62),
(20200800292, '22.00', '10.00', 13);
INSERT INTO `OrderProducts` (`OrderNo`, `PricePerKg`, `Weight`, `ProductId`) VALUES
(20200800293, '9.00', '3.00', 72),
(20200800293, '55.00', '3.00', 8),
(20200800293, '17.00', '3.00', 61),
(20200800293, '20.00', '3.00', 34),
(20200800293, '20.00', '3.00', 25),
(20200800293, '12.00', '3.00', 30),
(20200800293, '56.00', '3.00', 10),
(20200800293, '58.00', '3.00', 9),
(20200800293, '20.00', '3.00', 31),
(20200800293, '5.00', '10.00', 67),
(20200800293, '21.00', '3.00', 28),
(20200800293, '2.50', '10.00', 68),
(20200800293, '32.00', '3.00', 20),
(20200800293, '22.00', '3.00', 63),
(20200800293, '55.00', '2.00', 21),
(20200800293, '15.00', '3.00', 29),
(20200800293, '15.00', '10.00', 15),
(20200800293, '2.50', '10.00', 70),
(20200800293, '33.00', '5.00', 11),
(20200800293, '3.00', '10.00', 69),
(20200800293, '16.00', '3.00', 35),
(20200800293, '24.00', '3.00', 62),
(20200800293, '25.00', '5.00', 14),
(20200800293, '22.00', '5.00', 13),
(20200800294, '55.00', '3.00', 8),
(20200800294, '17.00', '3.00', 61),
(20200800294, '20.00', '3.00', 31),
(20200800294, '21.00', '3.00', 28),
(20200800294, '39.00', '3.00', 64),
(20200800294, '22.00', '3.00', 63),
(20200800294, '16.00', '3.00', 35),
(20200800294, '24.00', '3.00', 62),
(20200800294, '25.00', '3.00', 14),
(20200800294, '22.00', '6.00', 13),
(20200800295, '36.00', '6.00', 7),
(20200800295, '17.00', '3.00', 61),
(20200800295, '20.00', '3.00', 34),
(20200800295, '20.00', '6.00', 25),
(20200800295, '12.00', '3.00', 30),
(20200800295, '58.00', '3.00', 9),
(20200800295, '5.00', '5.00', 67),
(20200800295, '21.00', '3.00', 28),
(20200800295, '2.50', '5.00', 68),
(20200800295, '15.00', '3.00', 29),
(20200800295, '3.00', '5.00', 69),
(20200800295, '16.00', '3.00', 35),
(20200800296, '33.00', '10.00', 11),
(20200800296, '22.00', '20.00', 13),
(20200800297, '9.00', '10.00', 72),
(20200800297, '55.00', '3.00', 8),
(20200800297, '17.00', '3.00', 61),
(20200800297, '20.00', '6.00', 25),
(20200800297, '24.00', '6.00', 26),
(20200800297, '12.00', '10.00', 30),
(20200800297, '56.00', '3.00', 10),
(20200800297, '58.00', '6.00', 9),
(20200800297, '20.00', '9.00', 31),
(20200800297, '60.00', '3.00', 83),
(20200800297, '32.00', '6.00', 20),
(20200800297, '39.00', '6.00', 64),
(20200800297, '55.00', '3.00', 44),
(20200800297, '19.00', '3.00', 46),
(20200800297, '16.00', '3.00', 35),
(20200800297, '24.00', '3.00', 62),
(20200800297, '25.00', '10.00', 14),
(20200800297, '22.00', '20.00', 13),
(20200800299, '36.00', '3.00', 7),
(20200800299, '55.00', '3.00', 8),
(20200800299, '17.00', '3.00', 61),
(20200800299, '20.00', '3.00', 34),
(20200800299, '20.00', '3.00', 25),
(20200800299, '56.00', '3.00', 10),
(20200800299, '5.00', '60.00', 67),
(20200800299, '2.50', '30.00', 68),
(20200800299, '78.00', '3.00', 19),
(20200800299, '39.00', '3.00', 64),
(20200800299, '55.00', '2.00', 21),
(20200800299, '3.00', '20.00', 69),
(20200800299, '16.00', '3.00', 35),
(20200800299, '3.00', '10.00', 71),
(20200800299, '22.00', '25.00', 13),
(20200800300, '20.00', '3.00', 25),
(20200800300, '56.00', '3.00', 10),
(20200800300, '60.00', '3.00', 83),
(20200800300, '5.00', '15.00', 67),
(20200800300, '2.50', '10.00', 68),
(20200800300, '78.00', '3.00', 19),
(20200800300, '39.00', '3.00', 64),
(20200800300, '39.00', '3.00', 76),
(20200800300, '22.00', '3.00', 63),
(20200800300, '55.00', '3.00', 44),
(20200800300, '45.00', '3.00', 16),
(20200800300, '2.50', '8.00', 70),
(20200800300, '16.00', '3.00', 35),
(20200800300, '3.00', '8.00', 71),
(20200800300, '24.00', '3.00', 62),
(20200800300, '22.00', '6.00', 13),
(20200800285, '20.00', '6.00', 34),
(20200800285, '56.00', '3.00', 10),
(20200800285, '20.00', '3.00', 31),
(20200800285, '60.00', '3.00', 83),
(20200800285, '108.00', '6.00', 18),
(20200800285, '22.00', '6.00', 63),
(20200800285, '16.00', '3.00', 35),
(20200800301, '55.00', '3.00', 8),
(20200800301, '20.00', '3.00', 34),
(20200800301, '20.00', '3.00', 25),
(20200800301, '58.00', '3.00', 9),
(20200800301, '20.00', '3.00', 31),
(20200800301, '21.00', '3.00', 28),
(20200800301, '32.00', '6.00', 20),
(20200800301, '55.00', '3.00', 44),
(20200800301, '16.00', '3.00', 35),
(20200800301, '22.00', '10.00', 13),
(20200800302, '5.00', '15.00', 67),
(20200800302, '2.50', '5.00', 68),
(20200800302, '3.00', '5.00', 69),
(20200800302, '22.00', '10.00', 13),
(20200800298, '36.00', '9.00', 7),
(20200800298, '17.00', '6.00', 61),
(20200800298, '20.00', '6.00', 34),
(20200800298, '20.00', '6.00', 25),
(20200800298, '12.00', '10.00', 30),
(20200800298, '56.00', '6.00', 10),
(20200800298, '58.00', '18.00', 9),
(20200800298, '20.00', '3.00', 31),
(20200800298, '5.00', '50.00', 67),
(20200800298, '2.50', '25.00', 68),
(20200800298, '108.00', '6.00', 18),
(20200800298, '78.00', '3.00', 19),
(20200800298, '55.00', '1.00', 21),
(20200800298, '15.00', '6.00', 29),
(20200800298, '15.00', '44.00', 15),
(20200800298, '19.00', '3.00', 46),
(20200800298, '2.50', '25.00', 70),
(20200800298, '33.00', '25.00', 11),
(20200800298, '3.00', '50.00', 69),
(20200800298, '16.00', '6.00', 35),
(20200800298, '3.00', '25.00', 71),
(20200800298, '24.00', '9.00', 62),
(20200800298, '22.00', '40.00', 13),
(20200800303, '15.00', '10.00', 15),
(20200800304, '20.00', '3.00', 34),
(20200800304, '48.00', '3.00', 10),
(20200800304, '55.00', '3.00', 9),
(20200800304, '22.00', '3.00', 31),
(20200800304, '39.00', '3.00', 64),
(20200800304, '24.00', '3.00', 63),
(20200800304, '15.00', '10.00', 15),
(20200800304, '16.00', '3.00', 35),
(20200800304, '24.00', '10.00', 13),
(20200800305, '42.00', '1.00', 8),
(20200800305, '12.00', '2.00', 30),
(20200800305, '48.00', '2.00', 10),
(20200800305, '55.00', '1.00', 9),
(20200800305, '22.00', '2.00', 31),
(20200800305, '4.50', '4.00', 67),
(20200800305, '25.00', '2.00', 28),
(20200800305, '108.00', '1.00', 18),
(20200800305, '75.00', '1.00', 19),
(20200800305, '30.00', '1.00', 20),
(20200800305, '55.00', '1.00', 21),
(20200800305, '15.00', '3.00', 15),
(20200800305, '2.50', '4.00', 70),
(20200800305, '33.00', '2.00', 11),
(20200800305, '3.00', '2.00', 69),
(20200800305, '26.00', '2.00', 14),
(20200800306, '42.00', '3.00', 8),
(20200800306, '75.00', '2.00', 19),
(20200800306, '24.00', '3.00', 63),
(20200800306, '15.00', '10.00', 15),
(20200800306, '33.00', '3.00', 11),
(20200800307, '38.00', '9.00', 7),
(20200800307, '17.00', '12.00', 61),
(20200800307, '12.00', '9.00', 30),
(20200800307, '48.00', '6.00', 10),
(20200800307, '25.00', '6.00', 28),
(20200800307, '55.00', '3.00', 44),
(20200800307, '33.00', '20.00', 11),
(20200800308, '9.00', '8.00', 72),
(20200800308, '20.00', '3.00', 25),
(20200800308, '12.00', '3.00', 30),
(20200800308, '22.00', '3.00', 31),
(20200800308, '30.00', '3.00', 20),
(20200800308, '24.00', '3.00', 63),
(20200800308, '16.00', '3.00', 35),
(20200800310, '17.00', '3.00', 61),
(20200800310, '20.00', '6.00', 34),
(20200800310, '108.00', '6.00', 18),
(20200800310, '24.00', '6.00', 63),
(20200800310, '55.00', '3.00', 44),
(20200800310, '45.00', '3.00', 16),
(20200800310, '19.00', '3.00', 46),
(20200800310, '16.00', '3.00', 35),
(20200800311, '20.00', '6.00', 34),
(20200800311, '19.00', '3.00', 27),
(20200800311, '60.00', '3.00', 83),
(20200800311, '39.00', '3.00', 64),
(20200800312, '9.00', '30.00', 72),
(20200800312, '38.00', '15.00', 7),
(20200800312, '42.00', '20.00', 8),
(20200800312, '17.00', '15.00', 61),
(20200800312, '20.00', '20.00', 34),
(20200800312, '20.00', '10.00', 25),
(20200800312, '24.00', '10.00', 26),
(20200800312, '19.00', '10.00', 27),
(20200800312, '48.00', '20.00', 10),
(20200800312, '55.00', '35.00', 9),
(20200800312, '22.00', '20.00', 31),
(20200800312, '60.00', '10.00', 83),
(20200800312, '25.00', '40.00', 28),
(20200800312, '108.00', '5.00', 18),
(20200800312, '75.00', '20.00', 19),
(20200800312, '30.00', '8.00', 77),
(20200800312, '30.00', '30.00', 20),
(20200800312, '39.00', '20.00', 64),
(20200800312, '39.00', '8.00', 76),
(20200800312, '24.00', '20.00', 63),
(20200800312, '16.00', '20.00', 29),
(20200800312, '55.00', '10.00', 44),
(20200800312, '19.00', '10.00', 46),
(20200800312, '16.00', '20.00', 35),
(20200800312, '24.00', '25.00', 62),
(20200800314, '9.00', '10.00', 72),
(20200800314, '38.00', '3.00', 7),
(20200800314, '42.00', '3.00', 8),
(20200800314, '20.00', '3.00', 34),
(20200800314, '20.00', '3.00', 25),
(20200800314, '55.00', '6.00', 9),
(20200800314, '22.00', '3.00', 31),
(20200800314, '4.50', '20.00', 67),
(20200800314, '25.00', '6.00', 28),
(20200800314, '2.50', '10.00', 68),
(20200800314, '30.00', '3.00', 20),
(20200800314, '24.00', '3.00', 63),
(20200800314, '16.00', '3.00', 29),
(20200800314, '3.00', '5.00', 69),
(20200800314, '16.00', '3.00', 35),
(20200800314, '24.00', '3.00', 62),
(20200800314, '24.00', '10.00', 13),
(20200800315, '17.00', '3.00', 61),
(20200800315, '48.00', '3.00', 10),
(20200800315, '30.00', '3.00', 77),
(20200800315, '33.00', '6.00', 11),
(20200800316, '20.00', '6.00', 34),
(20200800316, '24.00', '3.00', 26),
(20200800316, '12.00', '10.00', 30),
(20200800316, '22.00', '6.00', 31),
(20200800316, '24.00', '6.00', 63),
(20200800316, '16.00', '3.00', 35),
(20200800313, '48.00', '3.00', 10),
(20200800313, '55.00', '3.00', 9),
(20200800313, '22.00', '3.00', 31),
(20200800313, '25.00', '3.00', 28),
(20200800313, '39.00', '3.00', 64),
(20200800313, '24.00', '3.00', 63),
(20200800313, '24.00', '5.00', 13),
(20200800317, '9.00', '5.00', 72),
(20200800317, '20.00', '3.00', 34),
(20200800317, '20.00', '3.00', 25),
(20200800317, '48.00', '3.00', 10),
(20200800317, '55.00', '3.00', 9),
(20200800317, '4.50', '6.00', 67),
(20200800317, '24.00', '3.00', 63),
(20200800317, '15.00', '10.00', 15),
(20200800317, '3.00', '5.00', 69),
(20200800317, '24.00', '5.00', 13),
(20200800309, '25.00', '3.00', 75),
(20200800309, '38.00', '3.00', 7),
(20200800309, '20.00', '3.00', 25),
(20200800309, '48.00', '3.00', 10),
(20200800309, '55.00', '3.00', 9),
(20200800309, '22.00', '3.00', 31),
(20200800309, '4.50', '5.00', 67),
(20200800309, '30.00', '3.00', 20),
(20200800309, '39.00', '3.00', 64),
(20200800309, '24.00', '3.00', 63),
(20200800309, '55.00', '2.00', 21),
(20200800309, '3.00', '5.00', 69),
(20200800309, '3.00', '5.00', 71),
(20200800309, '26.00', '3.00', 14),
(20200800309, '24.00', '3.00', 13),
(20200800318, '25.00', '3.00', 75),
(20200800318, '38.00', '3.00', 7),
(20200800318, '17.00', '3.00', 61),
(20200800318, '20.00', '3.00', 34),
(20200800318, '12.00', '3.00', 30),
(20200800318, '22.00', '3.00', 31),
(20200800318, '4.50', '20.00', 67),
(20200800318, '2.50', '8.00', 68),
(20200800318, '24.00', '3.00', 63),
(20200800318, '19.00', '3.00', 46),
(20200800318, '2.50', '8.00', 70),
(20200800318, '3.00', '8.00', 69),
(20200800318, '3.00', '8.00', 71),
(20200800318, '24.00', '3.00', 62),
(20200800319, '12.00', '3.00', 30),
(20200800319, '48.00', '3.00', 10),
(20200800319, '75.00', '6.00', 19),
(20200800319, '16.00', '3.00', 35),
(20200800319, '24.00', '5.00', 13),
(20200800320, '38.00', '3.00', 7),
(20200800320, '20.00', '3.00', 25),
(20200800320, '55.00', '3.00', 9),
(20200800320, '22.00', '3.00', 31),
(20200800320, '25.00', '3.00', 28),
(20200800320, '24.00', '3.00', 62),
(20200800320, '24.00', '5.00', 13),
(20200800321, '17.00', '15.00', 61),
(20200800321, '16.00', '15.00', 29),
(20200800322, '20.00', '3.00', 25),
(20200800322, '48.00', '3.00', 10),
(20200800322, '108.00', '6.00', 18),
(20200800322, '26.00', '10.00', 14),
(20200800322, '24.00', '10.00', 13),
(20200800323, '55.00', '3.00', 9),
(20200800323, '22.00', '3.00', 31),
(20200800323, '60.00', '3.00', 83),
(20200800323, '4.50', '10.00', 67),
(20200800323, '25.00', '3.00', 28),
(20200800323, '30.00', '3.00', 77),
(20200800323, '39.00', '3.00', 64),
(20200800323, '26.00', '10.00', 14),
(20200800323, '24.00', '10.00', 13),
(20200800324, '20.00', '3.00', 34),
(20200800324, '20.00', '3.00', 25),
(20200800324, '12.00', '3.00', 30),
(20200800324, '55.00', '3.00', 9),
(20200800324, '25.00', '3.00', 28),
(20200800324, '108.00', '2.00', 18),
(20200800324, '30.00', '2.00', 20),
(20200800325, '42.00', '3.00', 8),
(20200800325, '20.00', '3.00', 25),
(20200800325, '48.00', '3.00', 10),
(20200800325, '4.50', '15.00', 67),
(20200800325, '25.00', '3.00', 28),
(20200800325, '19.00', '3.00', 46),
(20200800325, '24.00', '5.00', 13);

-- --------------------------------------------------------

--
-- Table structure for table `OrderProductsHistory`
--

DROP TABLE IF EXISTS `OrderProductsHistory`;
CREATE TABLE IF NOT EXISTS `OrderProductsHistory` (
  `OrderNo` bigint(20) NOT NULL,
  `PricePerKg` decimal(10,2) NOT NULL,
  `Weight` decimal(10,2) NOT NULL,
  `ProductId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `OrderProductsHistory`
--

INSERT INTO `OrderProductsHistory` (`OrderNo`, `PricePerKg`, `Weight`, `ProductId`) VALUES
(20200800251, '16.00', '1.00', 88),
(20200800251, '25.00', '1.00', 75),
(20200800251, '8.00', '1.00', 72),
(20200800263, '65.00', '3.00', 10),
(20200800263, '58.00', '3.00', 9),
(20200800282, '25.00', '3.00', 75);

-- --------------------------------------------------------

--
-- Table structure for table `OrderProductsTemp`
--

DROP TABLE IF EXISTS `OrderProductsTemp`;
CREATE TABLE IF NOT EXISTS `OrderProductsTemp` (
  `OrderNo` bigint(20) NOT NULL,
  `PricePerKg` decimal(10,2) NOT NULL,
  `Weight` decimal(10,2) NOT NULL,
  `ProductId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `OrderProductsTemp`
--

INSERT INTO `OrderProductsTemp` (`OrderNo`, `PricePerKg`, `Weight`, `ProductId`) VALUES
(588843494, '8.00', '9.00', 72),
(588843494, '45.00', '6.00', 8),
(588843494, '25.00', '3.00', 61),
(588843494, '68.00', '3.00', 10),
(588843494, '22.00', '6.00', 31),
(588843494, '26.00', '3.00', 62),
(588843494, '4.00', '15.00', 67),
(588843494, '20.00', '6.00', 28),
(588843494, '2.00', '10.00', 68),
(588843494, '46.00', '3.00', 44),
(588843494, '110.00', '2.00', 18),
(588843494, '32.00', '6.00', 20),
(588843494, '24.00', '3.00', 36),
(588843494, '24.00', '3.00', 63),
(588843494, '18.00', '3.00', 34),
(588843494, '18.00', '3.00', 29),
(588843494, '3.00', '5.00', 69),
(588843494, '42.00', '3.00', 16),
(588843494, '32.00', '9.00', 11),
(588843494, '15.00', '3.00', 35),
(588843494, '28.00', '3.00', 45),
(588843494, '8.00', '10.00', 72),
(588843494, '33.00', '6.00', 7),
(588843494, '25.00', '9.00', 61),
(588843494, '68.00', '9.00', 10),
(588843494, '22.00', '18.00', 31),
(588843494, '26.00', '9.00', 62),
(588843494, '4.00', '75.00', 67),
(588843494, '20.00', '18.00', 28),
(588843494, '2.00', '50.00', 68),
(588843494, '46.00', '9.00', 44),
(588843494, '110.00', '3.00', 18),
(588843494, '32.00', '6.00', 20),
(588843494, '24.00', '9.00', 36),
(588843494, '24.00', '9.00', 63),
(588843494, '18.00', '9.00', 34),
(588843494, '18.00', '9.00', 29),
(588843494, '3.00', '25.00', 69),
(588843494, '42.00', '9.00', 16),
(588843494, '32.00', '10.00', 11),
(588843494, '15.00', '9.00', 35),
(588843494, '28.00', '9.00', 45),
(225045675, '40.00', '25.00', 8),
(225045675, '33.00', '10.00', 7),
(225045675, '42.00', '20.00', 9),
(225045675, '26.00', '15.00', 62),
(225045675, '20.00', '30.00', 28),
(225045675, '110.00', '5.00', 18),
(225045675, '34.00', '10.00', 20),
(225045675, '24.00', '7.00', 63),
(225045675, '18.00', '25.00', 34),
(225045675, '48.00', '10.00', 16);

-- --------------------------------------------------------

--
-- Table structure for table `Orders`
--

DROP TABLE IF EXISTS `Orders`;
CREATE TABLE IF NOT EXISTS `Orders` (
  `OrderNo` bigint(20) NOT NULL,
  `PassCode` bigint(20) NOT NULL,
  `OrderedDateTime` datetime NOT NULL,
  `DeliveryDate` datetime DEFAULT NULL,
  `DeliveryTime` varchar(30) DEFAULT NULL,
  `Status` varchar(20) NOT NULL,
  `ShopId` int(11) NOT NULL,
  `DeliveryUserId` int(11) DEFAULT NULL,
  `PaymentStatus` varchar(10) NOT NULL,
  `UpdatedDateTime` datetime NOT NULL,
  `CreatedUserId` varchar(50) NOT NULL,
  `UpdatedUserId` varchar(50) NOT NULL,
  `OrderRefId` bigint(20) NOT NULL AUTO_INCREMENT,
  `OrderMode` varchar(20) NOT NULL,
  `Route` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`OrderNo`),
  UNIQUE KEY `OrderRefId` (`OrderRefId`),
  KEY `FK_ShopId` (`ShopId`)
) ENGINE=InnoDB AUTO_INCREMENT=326 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Orders`
--

INSERT INTO `Orders` (`OrderNo`, `PassCode`, `OrderedDateTime`, `DeliveryDate`, `DeliveryTime`, `Status`, `ShopId`, `DeliveryUserId`, `PaymentStatus`, `UpdatedDateTime`, `CreatedUserId`, `UpdatedUserId`, `OrderRefId`, `OrderMode`, `Route`) VALUES
(104229517, 226780, '2020-08-07 19:42:58', '2020-08-08 19:43:03', '07:00 AM - 10:00 AM', 'Initiated', 70, NULL, '', '2020-08-07 19:42:58', 'devaraj@farmar.in', 'devaraj@farmar.in', 1, 'Delivery', NULL),
(104521501, 814814, '2020-08-06 21:43:53', '2020-08-07 21:43:58', '07:00 AM - 10:00 AM', 'Initiated', 76, NULL, '', '2020-08-06 21:43:53', 'anjan@farmar.in', 'anjan@farmar.in', 2, 'Delivery', NULL),
(105734677, 954895, '2020-08-07 21:17:43', '2020-08-08 21:17:48', '07:00 AM - 10:00 AM', 'Initiated', 84, NULL, '', '2020-08-07 21:17:43', '9343066668', '9343066668', 3, 'Delivery', NULL),
(119335853, 475547, '2020-08-05 20:17:19', '2020-08-06 20:17:23', '07:00 AM - 10:00 AM', 'Initiated', 38, NULL, '', '2020-08-05 20:17:19', 'anjan@farmar.in', 'anjan@farmar.in', 4, 'Delivery', NULL),
(121292552, 493191, '2020-08-03 20:12:59', '2020-08-04 20:13:03', '07:00 AM - 10:00 AM', 'Initiated', 118, NULL, '', '2020-08-03 20:12:59', 'devaraj@farmar.in', 'devaraj@farmar.in', 5, 'Delivery', NULL),
(153358554, 188353, '2020-08-03 23:18:11', '2020-08-04 23:18:15', '07:00 AM - 10:00 AM', 'Initiated', 81, NULL, '', '2020-08-03 23:18:11', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 6, 'Delivery', NULL),
(157560572, 943866, '2020-08-03 23:21:05', '2020-08-04 23:21:09', '07:00 AM - 10:00 AM', 'Initiated', 30, NULL, '', '2020-08-03 23:24:43', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 7, 'Delivery', NULL),
(169545937, 152163, '2020-08-07 20:33:18', '2020-08-08 20:33:22', '07:00 AM - 10:00 AM', 'Initiated', 48, NULL, '', '2020-08-07 20:33:18', 'devaraj@farmar.in', 'devaraj@farmar.in', 8, 'Delivery', NULL),
(173181318, 505014, '2020-08-06 21:34:55', '2020-08-07 21:34:59', '07:00 AM - 10:00 AM', 'Initiated', 77, NULL, '', '2020-08-06 21:34:55', 'anjan@farmar.in', 'anjan@farmar.in', 9, 'Delivery', NULL),
(176321059, 334107, '2020-08-07 21:27:49', '2020-08-08 21:27:53', '07:00 AM - 10:00 AM', 'Initiated', 151, NULL, '', '2020-08-07 21:27:49', 'devaraj@farmar.in', 'devaraj@farmar.in', 10, 'Delivery', NULL),
(179924154, 634859, '2020-08-07 21:38:51', '2020-08-08 21:38:55', '07:00 AM - 10:00 AM', 'Initiated', 60, NULL, '', '2020-08-07 21:38:51', 'devaraj@farmar.in', 'devaraj@farmar.in', 11, 'Delivery', NULL),
(190335164, 804667, '2020-08-02 23:11:10', '2020-08-03 23:11:14', '07:00 AM - 10:00 AM', 'Initiated', 57, NULL, '', '2020-08-02 23:11:10', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 12, 'Delivery', NULL),
(197565040, 463222, '2020-08-07 21:51:32', '2020-08-08 21:51:37', '07:00 AM - 10:00 AM', 'Initiated', 33, NULL, '', '2020-08-07 21:51:32', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 13, 'Delivery', NULL),
(219634109, 491118, '2020-08-07 23:35:07', '2020-08-08 23:35:12', '07:00 AM - 10:00 AM', 'Initiated', 150, NULL, '', '2020-08-07 23:37:06', 'devaraj@farmar.in', 'devaraj@farmar.in', 14, 'Delivery', NULL),
(225045675, 952718, '2020-08-03 12:31:09', '2020-08-04 12:31:13', '07:00 AM - 10:00 AM', 'Initiated', 150, NULL, '', '2020-08-03 13:12:22', 'test@gmail.com', 'kanthraj@dotangle.com', 15, 'Delivery', NULL),
(240150903, 143900, '2020-08-02 22:54:16', '2020-08-03 22:54:20', '07:00 AM - 10:00 AM', 'Initiated', 65, NULL, '', '2020-08-02 22:54:16', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 16, 'Delivery', NULL),
(241982051, 691396, '2020-08-07 21:11:10', '2020-08-08 21:11:15', '07:00 AM - 10:00 AM', 'Initiated', 155, NULL, '', '2020-08-07 21:16:32', '9886768789', 'kanthraj@dotangle.com', 17, 'Delivery', NULL),
(243527127, 491305, '2020-08-04 20:38:06', '2020-08-05 20:38:10', '07:00 AM - 10:00 AM', 'Initiated', 152, NULL, '', '2020-08-04 20:38:06', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 18, 'Delivery', NULL),
(248120307, 493242, '2020-08-05 20:20:08', '2020-08-06 20:20:12', '07:00 AM - 10:00 AM', 'Initiated', 64, NULL, '', '2020-08-05 20:20:08', 'anjan@farmar.in', 'anjan@farmar.in', 19, 'Delivery', NULL),
(263991964, 519182, '2020-08-02 22:52:07', '2020-08-03 22:52:11', '07:00 AM - 10:00 AM', 'Initiated', 106, NULL, '', '2020-08-02 22:52:07', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 20, 'Delivery', NULL),
(272607587, 647132, '2020-08-04 21:55:09', '2020-08-05 21:55:13', '07:00 AM - 10:00 AM', 'Initiated', 11, NULL, '', '2020-08-04 21:55:09', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 21, 'Delivery', NULL),
(273961678, 383396, '2020-08-06 21:14:13', '2020-08-07 21:14:18', '07:00 AM - 10:00 AM', 'Initiated', 30, NULL, '', '2020-08-06 22:32:45', 'anjan@farmar.in', 'devaraj@farmar.in', 22, 'Delivery', NULL),
(277669468, 733810, '2020-08-04 22:06:49', '2020-08-05 22:06:53', '07:00 AM - 10:00 AM', 'Initiated', 46, NULL, '', '2020-08-04 22:06:49', 'revanna@farmar.in', 'revanna@farmar.in', 23, 'Delivery', NULL),
(279662879, 234979, '2020-08-02 22:53:23', '2020-08-03 22:53:27', '07:00 AM - 10:00 AM', 'Initiated', 11, NULL, '', '2020-08-02 22:53:23', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 24, 'Delivery', NULL),
(285179618, 984753, '2020-08-07 20:34:18', '2020-08-08 20:34:22', '07:00 AM - 10:00 AM', 'Initiated', 11, NULL, '', '2020-08-07 20:34:18', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 25, 'Delivery', NULL),
(285496990, 711185, '2020-08-02 23:16:08', '2020-08-03 23:16:12', '07:00 AM - 10:00 AM', 'Initiated', 30, NULL, '', '2020-08-02 23:16:08', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 26, 'Delivery', NULL),
(304608596, 592099, '2020-08-02 22:59:00', '2020-08-03 22:59:04', '07:00 AM - 10:00 AM', 'Initiated', 124, NULL, '', '2020-08-02 22:59:00', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 27, 'Delivery', NULL),
(309609630, 995975, '2020-08-04 18:49:11', '2020-08-05 18:49:15', '07:00 AM - 10:00 AM', 'Initiated', 68, NULL, '', '2020-08-04 20:13:17', 'revanna@farmar.in', 'kanthraj@dotangle.com', 28, 'Delivery', NULL),
(321387177, 503146, '2020-08-06 21:24:45', '2020-08-07 21:24:49', '07:00 AM - 10:00 AM', 'Initiated', 47, NULL, '', '2020-08-06 22:14:52', 'devaraj@farmar.in', 'devaraj@farmar.in', 29, 'Delivery', NULL),
(325972536, 309726, '2020-08-05 20:45:56', '2020-08-06 20:46:00', '07:00 AM - 10:00 AM', 'Initiated', 78, NULL, '', '2020-08-05 20:45:56', 'anjan@farmar.in', 'anjan@farmar.in', 30, 'Delivery', NULL),
(327459603, 362321, '2020-08-07 21:57:01', '2020-08-08 21:57:06', '07:00 AM - 10:00 AM', 'Initiated', 16, NULL, '', '2020-08-07 21:57:01', '9986678798', '9986678798', 31, 'Delivery', NULL),
(331483899, 550297, '2020-08-04 19:44:10', '2020-08-05 19:44:14', '07:00 AM - 10:00 AM', 'Initiated', 77, NULL, '', '2020-08-04 19:44:10', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 32, 'Delivery', NULL),
(336993578, 707099, '2020-08-03 23:08:07', '2020-08-04 23:08:11', '07:00 AM - 10:00 AM', 'Initiated', 60, NULL, '', '2020-08-03 23:13:54', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 33, 'Delivery', NULL),
(339562688, 946752, '2020-08-04 22:23:23', '2020-08-05 22:23:27', '07:00 AM - 10:00 AM', 'Initiated', 97, NULL, '', '2020-08-04 22:23:23', 'anjan@farmar.in', 'anjan@farmar.in', 34, 'Delivery', NULL),
(350333430, 800830, '2020-08-04 19:46:59', '2020-08-05 19:47:03', '07:00 AM - 10:00 AM', 'Initiated', 35, NULL, '', '2020-08-04 21:57:07', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 35, 'Delivery', NULL),
(372781835, 994362, '2020-08-06 21:08:44', '2020-08-07 21:08:48', '07:00 AM - 10:00 AM', 'Initiated', 11, NULL, '', '2020-08-06 21:08:44', 'anjan@farmar.in', 'anjan@farmar.in', 36, 'Delivery', NULL),
(372863474, 405942, '2020-08-03 23:18:58', '2020-08-04 23:19:02', '07:00 AM - 10:00 AM', 'Initiated', 48, NULL, '', '2020-08-03 23:18:58', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 37, 'Delivery', NULL),
(373483394, 563152, '2020-08-05 22:07:48', '2020-08-06 22:07:53', '07:00 AM - 10:00 AM', 'Initiated', 73, NULL, '', '2020-08-05 22:07:48', 'devaraj@farmar.in', 'devaraj@farmar.in', 38, 'Delivery', NULL),
(374480347, 281916, '2020-08-03 23:17:18', '2020-08-04 23:17:22', '07:00 AM - 10:00 AM', 'Initiated', 149, NULL, '', '2020-08-03 23:17:18', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 39, 'Delivery', NULL),
(386281175, 698148, '2020-08-05 21:39:56', '2020-08-06 21:40:01', '07:00 AM - 10:00 AM', 'Initiated', 84, NULL, '', '2020-08-05 21:39:56', 'anjan@farmar.in', 'anjan@farmar.in', 40, 'Delivery', NULL),
(386468796, 893985, '2020-08-05 19:58:26', '2020-08-06 19:58:30', '07:00 AM - 10:00 AM', 'Initiated', 104, NULL, '', '2020-08-05 19:58:26', 'devaraj@farmar.in', 'devaraj@farmar.in', 41, 'Delivery', NULL),
(390017781, 946367, '2020-08-07 21:50:21', '2020-08-08 21:50:26', '07:00 AM - 10:00 AM', 'Initiated', 73, NULL, '', '2020-08-07 21:50:21', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 42, 'Delivery', NULL),
(391484462, 318012, '2020-08-03 23:24:04', '2020-08-04 23:24:08', '07:00 AM - 10:00 AM', 'Initiated', 47, NULL, '', '2020-08-03 23:24:04', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 43, 'Delivery', NULL),
(405810177, 655174, '2020-08-07 20:41:50', '2020-08-08 20:41:54', '07:00 AM - 10:00 AM', 'Initiated', 47, NULL, '', '2020-08-07 20:41:50', 'devaraj@farmar.in', 'devaraj@farmar.in', 44, 'Delivery', NULL),
(432117450, 989626, '2020-08-03 23:15:37', '2020-08-04 23:15:41', '07:00 AM - 10:00 AM', 'Initiated', 28, NULL, '', '2020-08-03 23:15:37', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 45, 'Delivery', NULL),
(433485640, 414636, '2020-08-04 21:21:59', '2020-08-05 21:22:03', '07:00 AM - 10:00 AM', 'Initiated', 28, NULL, '', '2020-08-04 21:21:59', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 46, 'Delivery', NULL),
(438043339, 474860, '2020-08-07 21:15:55', '2020-08-08 21:16:00', '07:00 AM - 10:00 AM', 'Initiated', 118, NULL, '', '2020-08-07 21:15:55', 'devaraj@farmar.in', 'devaraj@farmar.in', 47, 'Delivery', NULL),
(459348714, 516568, '2020-08-05 22:12:15', '2020-08-06 22:12:19', '07:00 AM - 10:00 AM', 'Initiated', 81, NULL, '', '2020-08-05 22:12:15', 'devaraj@farmar.in', 'devaraj@farmar.in', 48, 'Delivery', NULL),
(462739742, 162049, '2020-08-04 19:42:35', '2020-08-05 19:42:40', '07:00 AM - 10:00 AM', 'Initiated', 118, NULL, '', '2020-08-04 19:42:35', 'devaraj@farmar.in', 'devaraj@farmar.in', 49, 'Delivery', NULL),
(470949890, 782505, '2020-08-05 21:07:13', '2020-08-06 21:07:17', '07:00 AM - 10:00 AM', 'Initiated', 103, NULL, '', '2020-08-05 21:07:13', 'anjan@farmar.in', 'anjan@farmar.in', 50, 'Delivery', NULL),
(479879105, 222437, '2020-08-04 20:27:43', '2020-08-05 20:27:47', '07:00 AM - 10:00 AM', 'Initiated', 103, NULL, '', '2020-08-04 20:31:12', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 51, 'Delivery', NULL),
(483789834, 300592, '2020-08-05 21:25:08', '2020-08-06 21:25:12', '07:00 AM - 10:00 AM', 'Initiated', 65, NULL, '', '2020-08-05 21:25:08', 'devaraj@farmar.in', 'devaraj@farmar.in', 52, 'Delivery', NULL),
(484101199, 498745, '2020-08-07 19:16:24', '2020-08-08 19:16:28', '07:00 AM - 10:00 AM', 'Initiated', 128, NULL, '', '2020-08-07 19:16:24', 'devaraj@farmar.in', 'devaraj@farmar.in', 53, 'Delivery', NULL),
(492919716, 660305, '2020-08-07 22:04:07', '2020-08-08 22:04:12', '07:00 AM - 10:00 AM', 'Initiated', 149, NULL, '', '2020-08-07 22:04:07', 'devaraj@farmar.in', 'devaraj@farmar.in', 54, 'Delivery', NULL),
(497180440, 173810, '2020-08-02 23:18:18', '2020-08-03 23:18:22', '07:00 AM - 10:00 AM', 'Initiated', 81, NULL, '', '2020-08-02 23:18:18', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 55, 'Delivery', NULL),
(507383228, 994396, '2020-08-07 21:21:50', '2020-08-08 21:21:54', '07:00 AM - 10:00 AM', 'Initiated', 35, NULL, '', '2020-08-07 21:21:50', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 56, 'Delivery', NULL),
(507996314, 829613, '2020-08-02 23:09:27', '2020-08-03 23:09:31', '07:00 AM - 10:00 AM', 'Initiated', 97, NULL, '', '2020-08-02 23:09:27', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 57, 'Delivery', NULL),
(514601354, 962527, '2020-08-07 21:13:27', '2020-08-08 21:13:32', '07:00 AM - 10:00 AM', 'Initiated', 30, NULL, '', '2020-08-07 21:13:27', '8105452954', '8105452954', 58, 'Delivery', NULL),
(519314342, 572359, '2020-08-06 22:15:10', '2020-08-07 22:15:14', '07:00 AM - 10:00 AM', 'Initiated', 153, NULL, '', '2020-08-06 22:15:10', 'anjan@farmar.in', 'anjan@farmar.in', 59, 'Delivery', NULL),
(534169831, 948042, '2020-08-06 21:39:48', '2020-08-07 21:39:52', '07:00 AM - 10:00 AM', 'Initiated', 28, NULL, '', '2020-08-06 21:39:48', 'anjan@farmar.in', 'anjan@farmar.in', 60, 'Delivery', NULL),
(536662002, 572222, '2020-08-07 21:20:22', '2020-08-08 21:20:27', '07:00 AM - 10:00 AM', 'Initiated', 38, NULL, '', '2020-08-07 21:20:22', '9902375497', '9902375497', 61, 'Delivery', NULL),
(538654933, 735040, '2020-08-06 18:23:29', '2020-08-07 18:23:34', '07:00 AM - 10:00 AM', 'Initiated', 68, NULL, '', '2020-08-06 20:12:55', 'devaraj@farmar.in', 'devaraj@farmar.in', 62, 'Delivery', NULL),
(554648060, 155337, '2020-08-05 21:41:54', '2020-08-06 21:41:59', '07:00 AM - 10:00 AM', 'Initiated', 149, NULL, '', '2020-08-05 21:41:54', 'devaraj@farmar.in', 'devaraj@farmar.in', 63, 'Delivery', NULL),
(562476398, 927880, '2020-08-02 23:19:01', '2020-08-03 23:19:04', '07:00 AM - 10:00 AM', 'Initiated', 85, NULL, '', '2020-08-02 23:19:01', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 64, 'Delivery', NULL),
(567000901, 453004, '2020-08-05 20:14:56', '2020-08-06 20:15:01', '07:00 AM - 10:00 AM', 'Initiated', 11, NULL, '', '2020-08-05 20:14:56', 'anjan@farmar.in', 'anjan@farmar.in', 65, 'Delivery', NULL),
(580774837, 578633, '2020-08-03 23:22:37', '2020-08-04 23:22:41', '07:00 AM - 10:00 AM', 'Initiated', 73, NULL, '', '2020-08-03 23:22:37', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 66, 'Delivery', NULL),
(585856804, 784758, '2020-08-04 20:23:50', '2020-08-05 20:23:54', '07:00 AM - 10:00 AM', 'Initiated', 64, NULL, '', '2020-08-04 20:23:50', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 67, 'Delivery', NULL),
(589984637, 871108, '2020-08-03 23:21:50', '2020-08-04 23:21:54', '07:00 AM - 10:00 AM', 'Initiated', 84, NULL, '', '2020-08-03 23:21:50', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 68, 'Delivery', NULL),
(593605440, 396864, '2020-08-04 21:52:41', '2020-08-05 21:52:46', '07:00 AM - 10:00 AM', 'Initiated', 86, NULL, '', '2020-08-04 21:52:41', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 69, 'Delivery', NULL),
(597676851, 231839, '2020-08-06 20:29:31', '2020-08-07 20:29:36', '07:00 AM - 10:00 AM', 'Initiated', 16, NULL, '', '2020-08-06 20:29:31', 'devaraj@farmar.in', 'devaraj@farmar.in', 70, 'Delivery', NULL),
(598331285, 454976, '2020-08-02 22:35:09', '2020-08-03 22:35:13', '07:00 AM - 10:00 AM', 'Initiated', 28, NULL, '', '2020-08-02 22:35:09', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 71, 'Delivery', NULL),
(598361624, 757280, '2020-08-03 23:19:58', '2020-08-04 23:20:02', '07:00 AM - 10:00 AM', 'Initiated', 46, NULL, '', '2020-08-03 23:19:58', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 72, 'Delivery', NULL),
(605908701, 164073, '2020-08-07 21:50:19', '2020-08-08 21:50:24', '07:00 AM - 10:00 AM', 'Initiated', 154, NULL, '', '2020-08-07 21:50:19', 'devaraj@farmar.in', 'devaraj@farmar.in', 73, 'Delivery', NULL),
(613777972, 777895, '2020-08-02 23:10:25', '2020-08-03 23:10:29', '07:00 AM - 10:00 AM', 'Initiated', 42, NULL, '', '2020-08-02 23:10:25', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 74, 'Delivery', NULL),
(627804473, 855855, '2020-08-05 21:18:28', '2020-08-06 21:18:32', '07:00 AM - 10:00 AM', 'Initiated', 151, NULL, '', '2020-08-05 21:18:28', 'devaraj@farmar.in', 'devaraj@farmar.in', 75, 'Delivery', NULL),
(633699272, 735324, '2020-08-05 21:14:36', '2020-08-06 21:14:40', '07:00 AM - 10:00 AM', 'Initiated', 28, NULL, '', '2020-08-05 21:14:36', 'anjan@farmar.in', 'anjan@farmar.in', 76, 'Delivery', NULL),
(641787028, 879770, '2020-08-05 21:41:36', '2020-08-06 21:41:40', '07:00 AM - 10:00 AM', 'Initiated', 46, NULL, '', '2020-08-05 21:41:36', 'anjan@farmar.in', 'anjan@farmar.in', 77, 'Delivery', NULL),
(649077131, 600814, '2020-08-02 23:00:14', '2020-08-03 23:00:18', '07:00 AM - 10:00 AM', 'Initiated', 84, NULL, '', '2020-08-02 23:00:14', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 78, 'Delivery', NULL),
(658432162, 535058, '2020-08-03 23:16:25', '2020-08-04 23:16:29', '07:00 AM - 10:00 AM', 'Initiated', 114, NULL, '', '2020-08-03 23:16:25', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 79, 'Delivery', NULL),
(668280896, 941920, '2020-08-02 22:39:19', '2020-08-03 22:39:23', '07:00 AM - 10:00 AM', 'Initiated', 87, NULL, '', '2020-08-02 22:39:19', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 80, 'Delivery', NULL),
(670014429, 230306, '2020-08-06 21:19:56', '2020-08-07 21:20:00', '07:00 AM - 10:00 AM', 'Initiated', 149, NULL, '', '2020-08-06 21:19:56', 'anjan@farmar.in', 'anjan@farmar.in', 81, 'Delivery', NULL),
(675061206, 457405, '2020-08-04 18:57:15', '2020-08-05 18:57:19', '07:00 AM - 10:00 AM', 'Initiated', 150, NULL, '', '2020-08-04 21:38:39', 'devaraj@farmar.in', 'kanthraj@dotangle.com', 82, 'Delivery', NULL),
(683503786, 316614, '2020-08-04 22:12:33', '2020-08-05 22:12:37', '07:00 AM - 10:00 AM', 'Initiated', 60, NULL, '', '2020-08-04 22:12:33', 'anjan@farmar.in', 'anjan@farmar.in', 83, 'Delivery', NULL),
(688570904, 630532, '2020-08-03 23:07:07', '2020-08-04 23:07:11', '07:00 AM - 10:00 AM', 'Initiated', 68, NULL, '', '2020-08-03 23:07:07', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 84, 'Delivery', NULL),
(696474489, 735858, '2020-08-07 20:00:04', '2020-08-08 20:00:08', '07:00 AM - 10:00 AM', 'Initiated', 68, NULL, '', '2020-08-07 20:00:04', 'devaraj@farmar.in', 'devaraj@farmar.in', 85, 'Delivery', NULL),
(728874170, 762447, '2020-08-05 20:12:17', '2020-08-06 20:12:22', '07:00 AM - 10:00 AM', 'Initiated', 143, NULL, '', '2020-08-05 20:12:17', 'devaraj@farmar.in', 'devaraj@farmar.in', 86, 'Delivery', NULL),
(730433965, 771416, '2020-08-07 20:09:44', '2020-08-08 20:09:49', '07:00 AM - 10:00 AM', 'Initiated', 36, NULL, '', '2020-08-07 20:09:44', 'devaraj@farmar.in', 'devaraj@farmar.in', 87, 'Delivery', NULL),
(734994428, 476604, '2020-08-07 20:37:13', '2020-08-08 20:37:18', '07:00 AM - 10:00 AM', 'Initiated', 28, NULL, '', '2020-08-07 21:37:29', '9945100305', 'kanthraj@dotangle.com', 88, 'Delivery', NULL),
(736629179, 455774, '2020-08-04 21:47:13', '2020-08-05 21:47:18', '07:00 AM - 10:00 AM', 'Initiated', 151, NULL, '', '2020-08-04 21:47:13', 'devaraj@farmar.in', 'devaraj@farmar.in', 89, 'Delivery', NULL),
(744674770, 317130, '2020-08-04 21:28:26', '2020-08-05 21:28:31', '07:00 AM - 10:00 AM', 'Initiated', 54, NULL, '', '2020-08-04 21:28:26', 'devaraj@farmar.in', 'devaraj@farmar.in', 90, 'Delivery', NULL),
(745638191, 743975, '2020-08-02 22:55:36', '2020-08-03 22:55:40', '07:00 AM - 10:00 AM', 'Initiated', 73, NULL, '', '2020-08-02 22:55:36', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 91, 'Delivery', NULL),
(770523651, 142484, '2020-08-04 21:51:46', '2020-08-05 21:51:50', '07:00 AM - 10:00 AM', 'Initiated', 81, NULL, '', '2020-08-04 21:51:46', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 92, 'Delivery', NULL),
(771529066, 874225, '2020-08-06 21:12:52', '2020-08-07 21:12:56', '07:00 AM - 10:00 AM', 'Initiated', 151, NULL, '', '2020-08-06 21:12:52', 'devaraj@farmar.in', 'devaraj@farmar.in', 93, 'Delivery', NULL),
(772067421, 110219, '2020-08-05 19:03:41', '2020-08-06 19:03:46', '07:00 AM - 10:00 AM', 'Initiated', 99, NULL, '', '2020-08-05 19:03:41', 'devaraj@farmar.in', 'devaraj@farmar.in', 94, 'Delivery', NULL),
(773696656, 498115, '2020-08-06 17:10:21', '2020-08-07 17:10:25', '07:00 AM - 10:00 AM', 'Initiated', 118, NULL, '', '2020-08-06 20:58:32', 'devaraj@farmar.in', 'devaraj@farmar.in', 95, 'Delivery', NULL),
(780460754, 896433, '2020-08-07 20:42:43', '2020-08-08 20:42:48', '07:00 AM - 10:00 AM', 'Initiated', 86, NULL, '', '2020-08-07 20:42:43', '9731502088', '9731502088', 96, 'Delivery', NULL),
(792899659, 937106, '2020-08-05 21:26:18', '2020-08-06 21:26:23', '07:00 AM - 10:00 AM', 'Initiated', 118, NULL, '', '2020-08-05 21:26:18', 'devaraj@farmar.in', 'devaraj@farmar.in', 97, 'Delivery', NULL),
(795802606, 887728, '2020-08-02 22:36:40', '2020-08-03 22:36:44', '07:00 AM - 10:00 AM', 'Initiated', 103, NULL, '', '2020-08-02 22:36:40', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 98, 'Delivery', NULL),
(808494877, 177895, '2020-08-05 20:59:27', '2020-08-06 20:59:31', '07:00 AM - 10:00 AM', 'Initiated', 68, NULL, '', '2020-08-05 20:59:27', 'anjan@farmar.in', 'anjan@farmar.in', 99, 'Delivery', NULL),
(811201292, 477473, '2020-08-05 20:27:26', '2020-08-06 20:27:30', '07:00 AM - 10:00 AM', 'Initiated', 60, NULL, '', '2020-08-05 20:47:13', 'devaraj@farmar.in', 'devaraj@farmar.in', 100, 'Delivery', NULL),
(814175436, 281317, '2020-08-07 20:53:23', '2020-08-08 20:53:28', '07:00 AM - 10:00 AM', 'Initiated', 97, NULL, '', '2020-08-07 20:53:23', 'devaraj@farmar.in', 'devaraj@farmar.in', 101, 'Delivery', NULL),
(817897634, 580634, '2020-08-07 21:24:54', '2020-08-08 21:24:58', '07:00 AM - 10:00 AM', 'Initiated', 64, NULL, '', '2020-08-07 21:24:54', '9620476699', '9620476699', 102, 'Delivery', NULL),
(825198255, 450291, '2020-08-07 20:29:29', '2020-08-08 20:29:34', '07:00 AM - 10:00 AM', 'Initiated', 77, NULL, '', '2020-08-07 20:29:29', '9964392131', '9964392131', 103, 'Delivery', NULL),
(838120760, 461611, '2020-08-03 23:08:50', '2020-08-04 23:08:54', '07:00 AM - 10:00 AM', 'Initiated', 86, NULL, '', '2020-08-03 23:08:50', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 104, 'Delivery', NULL),
(849669499, 864294, '2020-08-07 21:15:12', '2020-08-08 21:15:17', '07:00 AM - 10:00 AM', 'Initiated', 46, NULL, '', '2020-08-07 21:15:12', '9482075384', '9482075384', 105, 'Delivery', NULL),
(882029274, 617745, '2020-08-06 21:39:01', '2020-08-07 21:39:05', '07:00 AM - 10:00 AM', 'Initiated', 97, NULL, '', '2020-08-06 21:39:01', 'devaraj@farmar.in', 'devaraj@farmar.in', 106, 'Delivery', NULL),
(888559829, 419993, '2020-08-05 19:50:17', '2020-08-06 19:50:21', '07:00 AM - 10:00 AM', 'Initiated', 15, NULL, '', '2020-08-05 19:50:17', 'anjan@farmar.in', 'anjan@farmar.in', 107, 'Delivery', NULL),
(889959599, 287772, '2020-08-07 17:48:02', '2020-08-08 17:48:06', '07:00 AM - 10:00 AM', 'Initiated', 29, NULL, '', '2020-08-07 21:01:11', 'devaraj@farmar.in', 'kanthraj@dotangle.com', 108, 'Delivery', NULL),
(898343334, 207029, '2020-08-05 21:52:18', '2020-08-06 21:52:22', '07:00 AM - 10:00 AM', 'Initiated', 33, NULL, '', '2020-08-05 21:52:18', 'anjan@farmar.in', 'anjan@farmar.in', 109, 'Delivery', NULL),
(898981732, 690279, '2020-08-02 23:08:37', '2020-08-03 23:08:41', '07:00 AM - 10:00 AM', 'Initiated', 149, NULL, '', '2020-08-02 23:08:37', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 110, 'Delivery', NULL),
(900649030, 988004, '2020-08-04 20:41:19', '2020-08-05 20:41:23', '07:00 AM - 10:00 AM', 'Initiated', 65, NULL, '', '2020-08-04 20:41:19', 'devaraj@farmar.in', 'devaraj@farmar.in', 111, 'Delivery', NULL),
(915257022, 760403, '2020-08-02 22:56:38', '2020-08-03 22:56:42', '07:00 AM - 10:00 AM', 'Initiated', 60, NULL, '', '2020-08-02 22:56:38', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 112, 'Delivery', NULL),
(920837107, 271919, '2020-08-04 21:01:07', '2020-08-05 21:01:11', '07:00 AM - 10:00 AM', 'Initiated', 47, NULL, '', '2020-08-04 21:15:48', 'devaraj@farmar.in', 'devaraj@farmar.in', 113, 'Delivery', NULL),
(921691087, 358866, '2020-08-02 22:51:01', '2020-08-03 22:51:05', '07:00 AM - 10:00 AM', 'Initiated', 68, NULL, '', '2020-08-02 22:51:01', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 114, 'Delivery', NULL),
(930485149, 362338, '2020-08-03 23:12:47', '2020-08-04 23:12:51', '07:00 AM - 10:00 AM', 'Initiated', 11, NULL, '', '2020-08-03 23:12:47', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 115, 'Delivery', NULL),
(943095685, 553092, '2020-08-07 17:45:42', '2020-08-08 17:45:47', '07:00 AM - 10:00 AM', 'Initiated', 45, NULL, '', '2020-08-07 17:45:42', 'devaraj@farmar.in', 'devaraj@farmar.in', 116, 'Delivery', NULL),
(944568297, 962653, '2020-08-02 22:57:45', '2020-08-03 22:57:49', '07:00 AM - 10:00 AM', 'Initiated', 77, NULL, '', '2020-08-02 22:57:45', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 117, 'Delivery', NULL),
(946089538, 224788, '2020-08-06 21:41:56', '2020-08-07 21:42:00', '07:00 AM - 10:00 AM', 'Initiated', 152, NULL, '', '2020-08-06 21:41:56', 'anjan@farmar.in', 'anjan@farmar.in', 118, 'Delivery', NULL),
(948173601, 379657, '2020-08-06 18:46:40', '2020-08-07 18:46:44', '07:00 AM - 10:00 AM', 'Initiated', 60, NULL, '', '2020-08-06 20:07:17', 'devaraj@farmar.in', 'devaraj@farmar.in', 119, 'Delivery', NULL),
(949478189, 775823, '2020-08-05 20:42:33', '2020-08-06 20:42:37', '07:00 AM - 10:00 AM', 'Initiated', 47, NULL, '', '2020-08-05 20:42:33', 'devaraj@farmar.in', 'devaraj@farmar.in', 120, 'Delivery', NULL),
(953890826, 272473, '2020-08-03 23:11:22', '2020-08-04 23:11:26', '07:00 AM - 10:00 AM', 'Initiated', 77, NULL, '', '2020-08-03 23:11:22', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 121, 'Delivery', NULL),
(954419935, 396442, '2020-08-05 20:53:58', '2020-08-06 20:54:02', '07:00 AM - 10:00 AM', 'Initiated', 30, NULL, '', '2020-08-05 20:53:58', 'anjan@farmar.in', 'anjan@farmar.in', 122, 'Delivery', NULL),
(968856066, 348211, '2020-08-06 23:04:51', '2020-08-07 23:04:55', '07:00 AM - 10:00 AM', 'Initiated', 81, NULL, '', '2020-08-06 23:04:51', 'md@spicetrip.com', 'md@spicetrip.com', 123, 'Delivery', NULL),
(972948965, 722638, '2020-08-07 22:25:53', '2020-08-08 22:25:57', '07:00 AM - 10:00 AM', 'Initiated', 85, NULL, '', '2020-08-07 22:25:53', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 124, 'Delivery', NULL),
(983054428, 246802, '2020-08-06 21:17:20', '2020-08-07 21:17:24', '07:00 AM - 10:00 AM', 'Initiated', 84, NULL, '', '2020-08-06 21:17:20', 'anjan@farmar.in', 'anjan@farmar.in', 125, 'Delivery', NULL),
(988960842, 434085, '2020-08-05 21:47:39', '2020-08-06 21:47:44', '07:00 AM - 10:00 AM', 'Initiated', 16, NULL, '', '2020-08-05 21:47:39', 'devaraj@farmar.in', 'devaraj@farmar.in', 126, 'Delivery', NULL),
(994364757, 678684, '2020-08-07 17:34:33', '2020-08-08 17:34:37', '07:00 AM - 10:00 AM', 'Initiated', 143, NULL, '', '2020-08-07 17:34:33', 'devaraj@farmar.in', 'devaraj@farmar.in', 127, 'Delivery', NULL),
(999190154, 247049, '2020-08-06 19:55:16', '2020-08-07 19:55:21', '07:00 AM - 10:00 AM', 'Initiated', 65, NULL, '', '2020-08-06 19:55:16', 'devaraj@farmar.in', 'devaraj@farmar.in', 128, 'Delivery', NULL),
(20200800231, 177289, '2020-08-08 19:14:58', '2020-08-09 19:15:03', '07:00 AM - 10:00 AM', 'Initiated', 103, NULL, '', '2020-08-08 19:14:58', 'anjan@farmar.in', 'anjan@farmar.in', 231, 'Delivery', NULL),
(20200800232, 201754, '2020-08-08 19:16:08', '2020-08-09 19:16:12', '07:00 AM - 10:00 AM', 'Initiated', 154, NULL, '', '2020-08-08 19:16:08', 'devaraj@farmar.in', 'devaraj@farmar.in', 232, 'Delivery', NULL),
(20200800233, 113276, '2020-08-08 19:16:56', '2020-08-09 19:17:00', '07:00 AM - 10:00 AM', 'Initiated', 29, NULL, '', '2020-08-08 19:16:56', 'anjan@farmar.in', 'anjan@farmar.in', 233, 'Delivery', NULL),
(20200800234, 242502, '2020-08-08 19:18:26', '2020-08-09 19:18:31', '07:00 AM - 10:00 AM', 'Initiated', 61, NULL, '', '2020-08-08 19:18:26', 'anjan@farmar.in', 'anjan@farmar.in', 234, 'Delivery', NULL),
(20200800235, 813755, '2020-08-08 19:23:23', '2020-08-09 19:23:28', '07:00 AM - 10:00 AM', 'Initiated', 12, NULL, '', '2020-08-08 19:23:23', 'anjan@farmar.in', 'anjan@farmar.in', 235, 'Delivery', NULL),
(20200800236, 264039, '2020-08-08 19:34:19', '2020-08-09 19:34:23', '07:00 AM - 10:00 AM', 'Initiated', 99, NULL, '', '2020-08-08 19:34:19', 'devaraj@farmar.in', 'devaraj@farmar.in', 236, 'Delivery', NULL),
(20200800237, 726794, '2020-08-08 19:44:52', '2020-08-09 19:44:57', '07:00 AM - 10:00 AM', 'Initiated', 28, NULL, '', '2020-08-08 19:44:52', 'anjan@farmar.in', 'anjan@farmar.in', 237, 'Delivery', NULL),
(20200800238, 491317, '2020-08-08 19:48:36', '2020-08-09 19:48:40', '07:00 AM - 10:00 AM', 'Initiated', 68, NULL, '', '2020-08-08 21:12:07', 'anjan@farmar.in', 'anjan@farmar.in', 238, 'Delivery', NULL),
(20200800239, 788602, '2020-08-08 19:50:59', '2020-08-09 19:51:03', '07:00 AM - 10:00 AM', 'Initiated', 47, NULL, '', '2020-08-08 19:50:59', 'devaraj@farmar.in', 'devaraj@farmar.in', 239, 'Delivery', NULL),
(20200800240, 168218, '2020-08-08 20:05:28', '2020-08-09 20:05:32', '07:00 AM - 10:00 AM', 'Initiated', 97, NULL, '', '2020-08-08 20:05:28', 'devaraj@farmar.in', 'devaraj@farmar.in', 240, 'Delivery', NULL),
(20200800241, 988289, '2020-08-08 20:14:49', '2020-08-09 20:14:53', '07:00 AM - 10:00 AM', 'Initiated', 143, NULL, '', '2020-08-08 20:52:33', 'devaraj@farmar.in', 'devaraj@farmar.in', 241, 'Delivery', NULL),
(20200800242, 532194, '2020-08-08 20:24:49', '2020-08-09 20:24:53', '07:00 AM - 10:00 AM', 'Initiated', 118, NULL, '', '2020-08-08 20:24:49', 'devaraj@farmar.in', 'devaraj@farmar.in', 242, 'Delivery', NULL),
(20200800243, 742084, '2020-08-08 20:44:19', '2020-08-09 20:44:24', '07:00 AM - 10:00 AM', 'Initiated', 11, NULL, '', '2020-08-08 20:44:19', 'anjan@farmar.in', 'anjan@farmar.in', 243, 'Delivery', NULL),
(20200800244, 872135, '2020-08-08 20:46:51', '2020-08-09 20:46:56', '07:00 AM - 10:00 AM', 'Initiated', 58, NULL, '', '2020-08-08 20:46:51', 'anjan@farmar.in', 'anjan@farmar.in', 244, 'Delivery', NULL),
(20200800245, 690800, '2020-08-08 20:49:39', '2020-08-09 20:49:43', '07:00 AM - 10:00 AM', 'Initiated', 124, NULL, '', '2020-08-08 20:49:39', 'devaraj@farmar.in', 'devaraj@farmar.in', 245, 'Delivery', NULL),
(20200800246, 653052, '2020-08-08 21:06:35', '2020-08-09 21:06:39', '07:00 AM - 10:00 AM', 'Initiated', 70, NULL, '', '2020-08-08 21:06:35', 'anjan@farmar.in', 'anjan@farmar.in', 246, 'Delivery', NULL),
(20200800247, 853732, '2020-08-08 21:09:11', '2020-08-09 21:09:16', '07:00 AM - 10:00 AM', 'Initiated', 77, NULL, '', '2020-08-08 21:09:11', 'anjan@farmar.in', 'anjan@farmar.in', 247, 'Delivery', NULL),
(20200800248, 130439, '2020-08-08 21:14:58', '2020-08-09 21:15:02', '07:00 AM - 10:00 AM', 'Initiated', 30, NULL, '', '2020-08-08 21:14:58', 'anjan@farmar.in', 'anjan@farmar.in', 248, 'Delivery', NULL),
(20200800249, 964738, '2020-08-08 21:18:30', '2020-08-09 21:18:34', '07:00 AM - 10:00 AM', 'Initiated', 35, NULL, '', '2020-08-08 21:18:30', 'anjan@farmar.in', 'anjan@farmar.in', 249, 'Delivery', NULL),
(20200800250, 933879, '2020-08-08 21:34:13', '2020-08-09 21:34:17', '07:00 AM - 10:00 AM', 'Initiated', 81, NULL, '', '2020-08-08 21:34:13', 'anjan@farmar.in', 'anjan@farmar.in', 250, 'Delivery', NULL),
(20200800252, 674222, '2020-08-09 18:16:28', '2020-08-10 18:16:33', '07:00 AM - 10:00 AM', 'Initiated', 114, NULL, '', '2020-08-09 18:16:28', 'devaraj@farmar.in', 'devaraj@farmar.in', 252, 'Delivery', NULL),
(20200800253, 470162, '2020-08-09 18:31:25', '2020-08-10 18:31:30', '07:00 AM - 10:00 AM', 'Initiated', 118, NULL, '', '2020-08-09 18:31:25', 'devaraj@farmar.in', 'devaraj@farmar.in', 253, 'Delivery', NULL),
(20200800254, 407289, '2020-08-09 18:38:51', '2020-08-10 18:38:56', '07:00 AM - 10:00 AM', 'Initiated', 49, NULL, '', '2020-08-09 18:38:51', 'anjan@farmar.in', 'anjan@farmar.in', 254, 'Delivery', NULL),
(20200800255, 295151, '2020-08-09 18:46:44', '2020-08-10 18:46:49', '07:00 AM - 10:00 AM', 'Initiated', 68, NULL, '', '2020-08-09 18:46:44', 'anjan@farmar.in', 'anjan@farmar.in', 255, 'Delivery', 'Route B'),
(20200800256, 376969, '2020-08-09 18:51:39', '2020-08-10 18:51:44', '07:00 AM - 10:00 AM', 'Initiated', 60, NULL, '', '2020-08-09 18:51:39', 'devaraj@farmar.in', 'devaraj@farmar.in', 256, 'Delivery', NULL),
(20200800257, 173671, '2020-08-09 18:56:21', '2020-08-10 18:56:26', '07:00 AM - 10:00 AM', 'Initiated', 11, NULL, '', '2020-08-09 20:16:18', 'anjan@farmar.in', 'anjan@farmar.in', 257, 'Delivery', NULL),
(20200800258, 486817, '2020-08-09 19:02:43', '2020-08-10 19:02:48', '07:00 AM - 10:00 AM', 'Initiated', 149, NULL, '', '2020-08-09 19:02:43', 'devaraj@farmar.in', 'devaraj@farmar.in', 258, 'Delivery', NULL),
(20200800259, 891585, '2020-08-09 19:16:37', '2020-08-10 19:16:42', '07:00 AM - 10:00 AM', 'Initiated', 84, NULL, '', '2020-08-09 19:16:37', 'anjan@farmar.in', 'anjan@farmar.in', 259, 'Delivery', NULL),
(20200800260, 898893, '2020-08-09 19:38:19', '2020-08-10 19:38:23', '07:00 AM - 10:00 AM', 'Initiated', 29, NULL, '', '2020-08-09 19:38:19', 'anjan@farmar.in', 'anjan@farmar.in', 260, 'Delivery', 'Route B'),
(20200800261, 346505, '2020-08-09 19:41:38', '2020-08-10 19:41:43', '07:00 AM - 10:00 AM', 'Initiated', 33, NULL, '', '2020-08-09 19:41:38', 'anjan@farmar.in', 'anjan@farmar.in', 261, 'Delivery', NULL),
(20200800262, 979407, '2020-08-09 19:45:04', '2020-08-10 19:45:09', '07:00 AM - 10:00 AM', 'Initiated', 157, NULL, '', '2020-08-09 19:45:04', 'anjan@farmar.in', 'anjan@farmar.in', 262, 'Delivery', NULL),
(20200800264, 193935, '2020-08-09 19:51:40', '2020-08-10 19:51:44', '07:00 AM - 10:00 AM', 'Initiated', 42, NULL, '', '2020-08-09 19:51:40', 'anjan@farmar.in', 'anjan@farmar.in', 264, 'Delivery', NULL),
(20200800265, 506903, '2020-08-09 19:57:37', '2020-08-10 19:57:42', '07:00 AM - 10:00 AM', 'Initiated', 158, NULL, '', '2020-08-09 19:57:37', 'anjan@farmar.in', 'anjan@farmar.in', 265, 'Delivery', NULL),
(20200800266, 780725, '2020-08-09 20:00:16', '2020-08-10 20:00:21', '07:00 AM - 10:00 AM', 'Initiated', 64, NULL, '', '2020-08-09 20:00:16', 'anjan@farmar.in', 'anjan@farmar.in', 266, 'Delivery', NULL),
(20200800267, 256500, '2020-08-09 20:02:27', '2020-08-10 20:02:32', '07:00 AM - 10:00 AM', 'Initiated', 151, NULL, '', '2020-08-09 20:02:27', 'anjan@farmar.in', 'anjan@farmar.in', 267, 'Delivery', NULL),
(20200800268, 728586, '2020-08-09 20:04:05', '2020-08-10 20:04:09', '07:00 AM - 10:00 AM', 'Initiated', 154, NULL, '', '2020-08-09 20:04:05', 'anjan@farmar.in', 'anjan@farmar.in', 268, 'Delivery', NULL),
(20200800269, 812711, '2020-08-09 20:08:35', '2020-08-10 20:08:40', '07:00 AM - 10:00 AM', 'Initiated', 54, NULL, '', '2020-08-09 20:08:35', 'anjan@farmar.in', 'anjan@farmar.in', 269, 'Delivery', NULL),
(20200800270, 529942, '2020-08-09 20:15:39', '2020-08-10 20:15:44', '07:00 AM - 10:00 AM', 'Initiated', 34, NULL, '', '2020-08-09 20:15:39', 'anjan@farmar.in', 'anjan@farmar.in', 270, 'Delivery', NULL),
(20200800271, 815306, '2020-08-09 20:23:26', '2020-08-10 20:23:31', '07:00 AM - 10:00 AM', 'Initiated', 47, NULL, '', '2020-08-09 20:23:26', 'anjan@farmar.in', 'anjan@farmar.in', 271, 'Delivery', NULL),
(20200800272, 866632, '2020-08-09 20:25:49', '2020-08-10 20:25:53', '07:00 AM - 10:00 AM', 'Initiated', 35, NULL, '', '2020-08-09 20:25:49', 'anjan@farmar.in', 'anjan@farmar.in', 272, 'Delivery', NULL),
(20200800273, 315227, '2020-08-09 20:37:48', '2020-08-10 20:37:53', '07:00 AM - 10:00 AM', 'Initiated', 16, NULL, '', '2020-08-09 20:39:21', 'anjan@farmar.in', 'anjan@farmar.in', 273, 'Delivery', NULL),
(20200800274, 941417, '2020-08-09 20:42:51', '2020-08-10 20:42:56', '07:00 AM - 10:00 AM', 'Initiated', 28, NULL, '', '2020-08-09 20:42:51', 'anjan@farmar.in', 'anjan@farmar.in', 274, 'Delivery', 'Route B'),
(20200800275, 513417, '2020-08-09 20:44:32', '2020-08-10 20:44:37', '07:00 AM - 10:00 AM', 'Initiated', 70, NULL, '', '2020-08-09 20:44:32', 'anjan@farmar.in', 'anjan@farmar.in', 275, 'Delivery', 'Route B'),
(20200800276, 696069, '2020-08-09 20:47:37', '2020-08-10 20:47:42', '07:00 AM - 10:00 AM', 'Initiated', 97, NULL, '', '2020-08-09 20:47:37', 'anjan@farmar.in', 'anjan@farmar.in', 276, 'Delivery', NULL),
(20200800277, 292886, '2020-08-09 20:50:45', '2020-08-10 20:50:50', '07:00 AM - 10:00 AM', 'Initiated', 15, NULL, '', '2020-08-09 20:50:45', 'anjan@farmar.in', 'anjan@farmar.in', 277, 'Delivery', 'Route A'),
(20200800278, 476380, '2020-08-09 21:13:54', '2020-08-10 21:13:59', '07:00 AM - 10:00 AM', 'Initiated', 73, NULL, '', '2020-08-09 21:13:54', 'devaraj@farmar.in', 'devaraj@farmar.in', 278, 'Delivery', 'Route A'),
(20200800279, 750112, '2020-08-09 21:16:06', '2020-08-10 21:16:11', '07:00 AM - 10:00 AM', 'Initiated', 30, NULL, '', '2020-08-09 21:16:06', 'devaraj@farmar.in', 'devaraj@farmar.in', 279, 'Delivery', 'Route A'),
(20200800280, 409983, '2020-08-09 21:23:33', '2020-08-10 21:23:38', '07:00 AM - 10:00 AM', 'Initiated', 77, NULL, '', '2020-08-09 21:23:33', 'devaraj@farmar.in', 'devaraj@farmar.in', 280, 'Delivery', 'Route A'),
(20200800281, 266913, '2020-08-09 21:28:39', '2020-08-10 21:28:44', '07:00 AM - 10:00 AM', 'Initiated', 155, NULL, '', '2020-08-09 21:28:39', 'devaraj@farmar.in', 'devaraj@farmar.in', 281, 'Delivery', 'Route A'),
(20200800283, 680318, '2020-08-10 19:19:20', '2020-08-11 19:19:25', '07:00 AM - 10:00 AM', 'Initiated', 84, NULL, 'Pending', '2020-08-10 19:19:20', 'anjan@farmar.in', 'anjan@farmar.in', 283, 'Delivery', NULL),
(20200800284, 883156, '2020-08-10 19:21:06', '2020-08-11 19:21:11', '07:00 AM - 10:00 AM', 'Initiated', 149, NULL, 'Pending', '2020-08-10 19:21:06', 'anjan@farmar.in', 'anjan@farmar.in', 284, 'Delivery', NULL),
(20200800285, 756403, '2020-08-10 19:23:12', '2020-08-11 19:23:17', '07:00 AM - 10:00 AM', 'Initiated', 77, NULL, 'Pending', '2020-08-10 21:43:04', 'anjan@farmar.in', 'kanthraj@dotangle.com', 285, 'Delivery', NULL),
(20200800286, 997884, '2020-08-10 19:43:01', '2020-08-11 19:43:06', '07:00 AM - 10:00 AM', 'Initiated', 154, NULL, 'Pending', '2020-08-10 19:43:01', 'anjan@farmar.in', 'anjan@farmar.in', 286, 'Delivery', NULL),
(20200800287, 196956, '2020-08-10 20:16:17', '2020-08-11 20:16:22', '07:00 AM - 10:00 AM', 'Initiated', 12, NULL, 'Pending', '2020-08-10 20:16:17', 'anjan@farmar.in', 'anjan@farmar.in', 287, 'Delivery', NULL),
(20200800288, 909723, '2020-08-10 20:25:21', '2020-08-11 20:25:26', '07:00 AM - 10:00 AM', 'Initiated', 87, NULL, 'Pending', '2020-08-10 20:25:21', 'anjan@farmar.in', 'anjan@farmar.in', 288, 'Delivery', NULL),
(20200800289, 837201, '2020-08-10 20:26:27', '2020-08-11 20:26:32', '07:00 AM - 10:00 AM', 'Initiated', 86, NULL, 'Pending', '2020-08-10 20:26:27', 'anjan@farmar.in', 'anjan@farmar.in', 289, 'Delivery', NULL),
(20200800290, 785239, '2020-08-10 20:30:40', '2020-08-11 20:30:45', '07:00 AM - 10:00 AM', 'Initiated', 38, NULL, 'Pending', '2020-08-10 20:30:40', 'anjan@farmar.in', 'anjan@farmar.in', 290, 'Delivery', NULL),
(20200800291, 150838, '2020-08-10 20:36:24', '2020-08-11 20:36:29', '07:00 AM - 10:00 AM', 'Initiated', 68, NULL, 'Pending', '2020-08-10 20:36:24', 'anjan@farmar.in', 'anjan@farmar.in', 291, 'Delivery', NULL),
(20200800292, 548273, '2020-08-10 20:39:57', '2020-08-11 20:40:02', '07:00 AM - 10:00 AM', 'Initiated', 28, NULL, 'Pending', '2020-08-10 20:39:57', 'anjan@farmar.in', 'anjan@farmar.in', 292, 'Delivery', NULL),
(20200800293, 720926, '2020-08-10 20:47:14', '2020-08-11 20:47:19', '07:00 AM - 10:00 AM', 'Initiated', 103, NULL, 'Pending', '2020-08-10 20:47:14', 'anjan@farmar.in', 'anjan@farmar.in', 293, 'Delivery', NULL),
(20200800294, 440868, '2020-08-10 20:58:16', '2020-08-11 20:58:21', '07:00 AM - 10:00 AM', 'Initiated', 151, NULL, 'Pending', '2020-08-10 20:58:16', 'devaraj@farmar.in', 'devaraj@farmar.in', 294, 'Delivery', NULL),
(20200800295, 224134, '2020-08-10 20:59:01', '2020-08-11 20:59:06', '07:00 AM - 10:00 AM', 'Initiated', 152, NULL, 'Pending', '2020-08-10 20:59:01', 'anjan@farmar.in', 'anjan@farmar.in', 295, 'Delivery', NULL),
(20200800296, 398799, '2020-08-10 21:05:33', '2020-08-11 21:05:38', '07:00 AM - 10:00 AM', 'Initiated', 114, NULL, 'Pending', '2020-08-10 21:05:33', 'devaraj@farmar.in', 'devaraj@farmar.in', 296, 'Delivery', NULL),
(20200800297, 788247, '2020-08-10 21:12:34', '2020-08-11 21:12:39', '07:00 AM - 10:00 AM', 'Initiated', 47, NULL, 'Pending', '2020-08-10 21:12:34', 'anjan@farmar.in', 'anjan@farmar.in', 297, 'Delivery', NULL),
(20200800298, 524377, '2020-08-10 21:12:57', '2020-08-11 21:13:02', '07:00 AM - 10:00 AM', 'Initiated', 159, NULL, 'Pending', '2020-08-10 21:54:34', 'md@spicetrip.com', 'md@spicetrip.com', 298, 'Delivery', NULL),
(20200800299, 375486, '2020-08-10 21:17:04', '2020-08-11 21:17:09', '07:00 AM - 10:00 AM', 'Initiated', 36, NULL, 'Pending', '2020-08-10 21:17:32', 'anjan@farmar.in', 'md@spicetrip.com', 299, 'Delivery', NULL),
(20200800300, 262052, '2020-08-10 21:23:11', '2020-08-11 21:23:16', '07:00 AM - 10:00 AM', 'Initiated', 16, NULL, 'Pending', '2020-08-10 21:23:11', 'devaraj@farmar.in', 'devaraj@farmar.in', 300, 'Delivery', NULL),
(20200800301, 972892, '2020-08-10 21:48:23', '2020-08-11 21:48:28', '07:00 AM - 10:00 AM', 'Initiated', 73, NULL, 'Pending', '2020-08-10 21:48:23', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 301, 'Delivery', NULL),
(20200800302, 664127, '2020-08-10 21:52:10', '2020-08-11 21:52:14', '07:00 AM - 10:00 AM', 'Initiated', 143, NULL, 'Pending', '2020-08-10 21:52:10', 'devaraj@farmar.in', 'devaraj@farmar.in', 302, 'Delivery', NULL),
(20200800303, 424631, '2020-08-11 18:18:11', '2020-08-12 18:18:16', '07:00 AM - 10:00 AM', 'Initiated', 15, NULL, 'Pending', '2020-08-11 18:18:11', 'anjan@farmar.in', 'anjan@farmar.in', 303, 'Delivery', NULL),
(20200800304, 486338, '2020-08-11 19:09:11', '2020-08-12 19:09:16', '07:00 AM - 10:00 AM', 'Initiated', 158, NULL, 'Pending', '2020-08-11 19:09:11', 'devaraj@farmar.in', 'devaraj@farmar.in', 304, 'Delivery', NULL),
(20200800305, 432136, '2020-08-11 19:36:25', '2020-08-12 19:36:30', '07:00 AM - 10:00 AM', 'Initiated', 153, NULL, 'Pending', '2020-08-11 19:36:25', 'anjan@farmar.in', 'anjan@farmar.in', 305, 'Delivery', NULL),
(20200800306, 371421, '2020-08-11 19:43:01', '2020-08-12 19:43:06', '07:00 AM - 10:00 AM', 'Initiated', 29, NULL, 'Pending', '2020-08-11 19:43:01', 'anjan@farmar.in', 'anjan@farmar.in', 306, 'Delivery', NULL),
(20200800307, 629874, '2020-08-11 19:46:01', '2020-08-12 19:46:06', '07:00 AM - 10:00 AM', 'Initiated', 103, NULL, 'Pending', '2020-08-11 19:46:01', 'anjan@farmar.in', 'anjan@farmar.in', 307, 'Delivery', NULL),
(20200800308, 161323, '2020-08-11 19:49:24', '2020-08-12 19:49:28', '07:00 AM - 10:00 AM', 'Initiated', 12, NULL, 'Pending', '2020-08-11 19:49:24', 'anjan@farmar.in', 'anjan@farmar.in', 308, 'Delivery', NULL),
(20200800309, 249954, '2020-08-11 20:00:21', '2020-08-12 20:00:26', '07:00 AM - 10:00 AM', 'Initiated', 154, NULL, 'Pending', '2020-08-11 20:47:10', 'devaraj@farmar.in', 'anjan@farmar.in', 309, 'Delivery', NULL),
(20200800310, 325216, '2020-08-11 20:03:11', '2020-08-12 20:03:16', '07:00 AM - 10:00 AM', 'Initiated', 77, NULL, 'Pending', '2020-08-11 20:03:11', 'anjan@farmar.in', 'anjan@farmar.in', 310, 'Delivery', NULL),
(20200800311, 895910, '2020-08-11 20:07:27', '2020-08-12 20:07:32', '07:00 AM - 10:00 AM', 'Initiated', 38, NULL, 'Pending', '2020-08-11 20:07:27', 'anjan@farmar.in', 'anjan@farmar.in', 311, 'Delivery', NULL),
(20200800312, 382200, '2020-08-11 20:24:41', '2020-08-12 20:24:46', '07:00 AM - 10:00 AM', 'Initiated', 150, NULL, 'Pending', '2020-08-11 20:24:41', 'anjan@farmar.in', 'anjan@farmar.in', 312, 'Delivery', NULL),
(20200800313, 158755, '2020-08-11 20:27:03', '2020-08-12 20:27:08', '07:00 AM - 10:00 AM', 'Initiated', 151, NULL, 'Pending', '2020-08-11 20:43:02', 'anjan@farmar.in', 'anjan@farmar.in', 313, 'Delivery', NULL),
(20200800314, 971355, '2020-08-11 20:32:51', '2020-08-12 20:32:56', '07:00 AM - 10:00 AM', 'Initiated', 28, NULL, 'Pending', '2020-08-11 20:32:51', 'anjan@farmar.in', 'anjan@farmar.in', 314, 'Delivery', NULL),
(20200800315, 329308, '2020-08-11 20:35:08', '2020-08-12 20:35:13', '07:00 AM - 10:00 AM', 'Initiated', 87, NULL, 'Pending', '2020-08-11 20:35:08', 'anjan@farmar.in', 'anjan@farmar.in', 315, 'Delivery', NULL),
(20200800316, 537408, '2020-08-11 20:37:13', '2020-08-12 20:37:18', '07:00 AM - 10:00 AM', 'Initiated', 108, NULL, 'Pending', '2020-08-11 20:37:13', 'anjan@farmar.in', 'anjan@farmar.in', 316, 'Delivery', NULL),
(20200800317, 420569, '2020-08-11 20:45:59', '2020-08-12 20:46:04', '07:00 AM - 10:00 AM', 'Initiated', 11, NULL, 'Pending', '2020-08-11 20:45:59', 'anjan@farmar.in', 'anjan@farmar.in', 317, 'Delivery', NULL),
(20200800318, 632126, '2020-08-11 21:00:20', '2020-08-12 21:00:25', '07:00 AM - 10:00 AM', 'Initiated', 16, NULL, 'Pending', '2020-08-11 21:00:20', 'anjan@farmar.in', 'anjan@farmar.in', 318, 'Delivery', NULL),
(20200800319, 673062, '2020-08-11 21:10:14', '2020-08-12 21:10:19', '07:00 AM - 10:00 AM', 'Initiated', 84, NULL, 'Pending', '2020-08-11 21:10:14', 'anjan@farmar.in', 'anjan@farmar.in', 319, 'Delivery', NULL),
(20200800320, 888610, '2020-08-11 21:11:47', '2020-08-12 21:11:52', '07:00 AM - 10:00 AM', 'Initiated', 149, NULL, 'Pending', '2020-08-11 21:11:47', 'anjan@farmar.in', 'anjan@farmar.in', 320, 'Delivery', NULL),
(20200800321, 972350, '2020-08-11 21:15:30', '2020-08-12 21:15:34', '07:00 AM - 10:00 AM', 'Initiated', 30, NULL, 'Pending', '2020-08-11 21:16:08', 'anjan@farmar.in', 'anjan@farmar.in', 321, 'Delivery', NULL),
(20200800322, 618167, '2020-08-11 21:17:50', '2020-08-12 21:17:54', '07:00 AM - 10:00 AM', 'Initiated', 54, NULL, 'Pending', '2020-08-11 21:17:50', 'anjan@farmar.in', 'anjan@farmar.in', 322, 'Delivery', NULL),
(20200800323, 126947, '2020-08-11 21:22:31', '2020-08-12 21:22:36', '07:00 AM - 10:00 AM', 'Initiated', 73, NULL, 'Pending', '2020-08-11 21:22:31', 'anjan@farmar.in', 'anjan@farmar.in', 323, 'Delivery', NULL),
(20200800324, 297471, '2020-08-11 21:30:37', '2020-08-12 21:30:42', '07:00 AM - 10:00 AM', 'Initiated', 48, NULL, 'Pending', '2020-08-11 21:30:37', 'anjan@farmar.in', 'anjan@farmar.in', 324, 'Delivery', NULL),
(20200800325, 591689, '2020-08-11 21:43:41', '2020-08-12 21:43:45', '07:00 AM - 10:00 AM', 'Initiated', 143, NULL, 'Pending', '2020-08-11 21:43:41', 'anjan@farmar.in', 'anjan@farmar.in', 325, 'Delivery', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `OrdersHistory`
--

DROP TABLE IF EXISTS `OrdersHistory`;
CREATE TABLE IF NOT EXISTS `OrdersHistory` (
  `OrderNo` bigint(20) NOT NULL,
  `PassCode` bigint(20) NOT NULL,
  `OrderedDateTime` datetime NOT NULL,
  `DeliveryDate` datetime DEFAULT NULL,
  `DeliveryTime` varchar(30) DEFAULT NULL,
  `Status` varchar(20) NOT NULL,
  `ShopId` int(11) NOT NULL,
  `DeliveryUserId` int(11) DEFAULT NULL,
  `PaymentStatus` varchar(10) NOT NULL,
  `UpdatedDateTime` datetime NOT NULL,
  `CreatedUserId` varchar(50) NOT NULL,
  `UpdatedUserId` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `OrdersHistory`
--

INSERT INTO `OrdersHistory` (`OrderNo`, `PassCode`, `OrderedDateTime`, `DeliveryDate`, `DeliveryTime`, `Status`, `ShopId`, `DeliveryUserId`, `PaymentStatus`, `UpdatedDateTime`, `CreatedUserId`, `UpdatedUserId`) VALUES
(20200800251, 767668, '2020-08-08 22:43:15', '2020-08-09 22:43:20', '07:00 AM - 10:00 AM', 'Initiated', 143, NULL, '', '2020-08-08 22:43:15', 'md@spicetrip.com', 'md@spicetrip.com'),
(20200800263, 562780, '2020-08-09 19:47:52', '2020-08-10 19:47:57', '07:00 AM - 10:00 AM', 'Initiated', 58, NULL, '', '2020-08-09 20:10:03', 'anjan@farmar.in', 'anjan@farmar.in'),
(20200800282, 770720, '2020-08-10 17:47:42', '2020-08-11 17:47:47', '07:00 AM - 10:00 AM', 'Initiated', 157, NULL, '', '2020-08-10 17:47:42', 'md@spicetrip.com', 'md@spicetrip.com');

-- --------------------------------------------------------

--
-- Table structure for table `OrderTime`
--

DROP TABLE IF EXISTS `OrderTime`;
CREATE TABLE IF NOT EXISTS `OrderTime` (
  `FromTime` datetime NOT NULL,
  `ToTime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `OrderTime`
--

INSERT INTO `OrderTime` (`FromTime`, `ToTime`) VALUES
('2020-07-05 21:05:39', '2020-07-05 23:55:39');

-- --------------------------------------------------------

--
-- Table structure for table `ProductCategories`
--

DROP TABLE IF EXISTS `ProductCategories`;
CREATE TABLE IF NOT EXISTS `ProductCategories` (
  `CategoryId` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) NOT NULL,
  `Deactivate` tinyint(4) DEFAULT NULL,
  `CreatedDateTime` datetime NOT NULL,
  `CreatedUserId` varchar(50) NOT NULL,
  PRIMARY KEY (`CategoryId`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ProductCategories`
--

INSERT INTO `ProductCategories` (`CategoryId`, `Name`, `Deactivate`, `CreatedDateTime`, `CreatedUserId`) VALUES
(26, 'Vegetables', 0, '2020-06-25 10:40:16', ''),
(27, 'Fruits', 0, '2020-06-25 10:40:35', '');

-- --------------------------------------------------------

--
-- Table structure for table `ProductHistory`
--

DROP TABLE IF EXISTS `ProductHistory`;
CREATE TABLE IF NOT EXISTS `ProductHistory` (
  `ProductHistId` int(11) NOT NULL AUTO_INCREMENT,
  `ProductId` int(11) NOT NULL,
  `CategoryId` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `RatePerKG` decimal(10,2) NOT NULL,
  `MinPurchaseQuantity` decimal(10,2) NOT NULL,
  `CreatedDateTime` datetime NOT NULL,
  `UpdatedDateTime` datetime NOT NULL,
  `CreatedUserId` varchar(50) NOT NULL,
  `UpdatedUserId` varchar(50) NOT NULL,
  `StatusCode` char(1) NOT NULL,
  `TotalStock` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`ProductHistId`)
) ENGINE=InnoDB AUTO_INCREMENT=1162 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ProductHistory`
--

INSERT INTO `ProductHistory` (`ProductHistId`, `ProductId`, `CategoryId`, `Name`, `RatePerKG`, `MinPurchaseQuantity`, `CreatedDateTime`, `UpdatedDateTime`, `CreatedUserId`, `UpdatedUserId`, `StatusCode`, `TotalStock`) VALUES
(22, 6, 26, 'BEANS (LOCAL)', '35.00', '5.00', '2020-06-29 14:21:30', '2020-06-29 18:21:13', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(23, 6, 26, 'BEANS (LOCAL)', '35.00', '12.00', '2020-06-29 14:21:30', '2020-06-29 18:21:33', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(24, 5, 26, 'ALOO', '25.00', '5.00', '2020-06-29 14:20:48', '2020-06-29 18:21:41', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(25, 6, 26, 'BEANS (LOCAL)', '35.00', '15.00', '2020-06-29 14:21:30', '2020-06-29 05:52:07', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(26, 5, 26, 'ALOO', '25.00', '10.00', '2020-06-29 14:20:48', '2020-06-30 11:21:58', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(27, 5, 26, 'ALOO', '25.00', '10.00', '2020-06-29 14:20:48', '2020-07-02 01:51:26', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(28, 5, 26, 'ALOO', '25.00', '10.00', '2020-06-29 14:20:48', '2020-07-02 02:00:15', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'U', '99.00'),
(29, 5, 26, 'ALOO', '25.00', '10.00', '2020-06-29 14:20:48', '2020-07-02 14:31:36', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'D', NULL),
(30, 6, 26, 'BEANS (LOCAL)', '35.00', '12.00', '2020-06-29 14:21:30', '2020-07-02 02:06:19', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(31, 6, 26, 'ALOO', '25.00', '10.00', '2020-06-29 14:21:30', '2020-07-02 02:38:17', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'U', '50.00'),
(32, 6, 26, 'ALOO', '25.00', '10.00', '2020-06-29 14:21:30', '2020-07-03 07:09:16', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'D', NULL),
(33, 37, 26, 'ALOO', '10.00', '10.00', '2020-07-02 06:11:16', '2020-07-03 07:12:01', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'D', NULL),
(34, 38, 26, 'ALOO', '10.00', '10.00', '2020-07-02 06:13:43', '2020-07-03 07:15:16', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'D', NULL),
(35, 39, 26, 'ALOO', '10.00', '10.00', '2020-07-02 06:17:45', '2020-07-03 07:19:41', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'D', NULL),
(36, 40, 26, 'ALOO', '10.00', '10.00', '2020-07-02 06:21:13', '2020-07-02 06:50:33', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'U', '10.00'),
(37, 40, 26, 'ALOO', '10.00', '10.00', '2020-07-02 06:21:13', '2020-07-03 07:51:07', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'U', '10.00'),
(38, 40, 26, 'ALOO', '10.00', '10.00', '2020-07-02 06:21:13', '2020-07-03 07:32:41', 'abhijitjd003@gmail.com', '', 'U', '10.00'),
(39, 40, 26, 'ALOO', '10.00', '10.00', '2020-07-02 06:21:13', '2020-07-03 07:33:04', 'abhijitjd003@gmail.com', '', 'U', '10.00'),
(40, 40, 26, 'ALOO', '10.00', '10.00', '2020-07-02 06:21:13', '2020-07-03 07:33:08', 'abhijitjd003@gmail.com', '', 'U', '20.00'),
(41, 40, 26, 'ALOO', '10.00', '10.00', '2020-07-02 06:21:13', '2020-07-03 07:33:34', 'abhijitjd003@gmail.com', 'null', 'D', NULL),
(42, 41, 26, 'ALOO', '10.00', '10.00', '2020-07-03 07:35:40', '2020-07-03 08:13:40', '', '', 'U', '10.00'),
(43, 41, 26, 'ALOO', '10.00', '10.00', '2020-07-03 07:35:40', '2020-07-03 08:13:59', '', '', 'U', '10.00'),
(44, 41, 26, 'ALOO', '10.00', '10.00', '2020-07-03 07:35:40', '2020-07-03 08:28:43', '', '', 'U', '10.00'),
(45, 41, 26, 'ALOO', '10.00', '10.00', '2020-07-03 07:35:40', '2020-07-03 08:29:00', '', 'null', 'D', NULL),
(46, 42, 26, 'ALOO', '10.00', '10.00', '2020-07-03 08:31:50', '2020-07-03 12:44:51', '', '', 'U', '10.00'),
(47, 11, 26, 'BRINJAL (ROUND)', '9.00', '7.00', '2020-06-29 14:23:51', '2020-07-03 12:47:56', 'abhijitjd003@gmail.com', '', 'U', '65.00'),
(48, 7, 26, 'BEANS (OOTY)', '60.00', '5.00', '2020-06-29 14:21:54', '2020-07-03 12:48:21', 'abhijitjd003@gmail.com', '', 'U', '60.00'),
(49, 8, 26, 'BEETROOT', '30.00', '3.00', '2020-06-29 14:22:19', '2020-07-03 12:48:32', 'abhijitjd003@gmail.com', '', 'U', '30.00'),
(50, 9, 26, 'BHENDI', '15.00', '10.00', '2020-06-29 14:22:41', '2020-07-03 12:48:48', 'abhijitjd003@gmail.com', '', 'U', '100.00'),
(51, 10, 26, 'BRINJAL (LONG)', '10.00', '8.00', '2020-06-29 14:22:59', '2020-07-03 12:48:57', 'abhijitjd003@gmail.com', '', 'U', '75.00'),
(52, 11, 26, 'BRINJAL (ROUND)', '14.00', '7.00', '2020-06-29 14:23:51', '2020-07-03 12:49:11', 'abhijitjd003@gmail.com', '', 'U', '65.00'),
(53, 12, 26, 'CABBAGE', '11.00', '11.00', '2020-06-29 14:24:18', '2020-07-03 12:49:22', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(54, 13, 26, 'CAPSICUM', '65.00', '100.00', '2020-06-29 14:25:12', '2020-07-03 12:49:38', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(55, 14, 26, 'CARROT', '30.00', '25.00', '2020-06-29 14:25:39', '2020-07-03 12:49:59', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(56, 16, 26, 'CUCUMBER', '8.00', '25.00', '2020-06-29 14:26:10', '2020-07-03 12:50:29', 'abhijitjd003@gmail.com', '', 'U', '65.00'),
(57, 17, 26, 'DRUMSTICK', '54.00', '10.00', '2020-06-29 14:26:27', '2020-07-03 12:50:55', 'abhijitjd003@gmail.com', '', 'U', '20.00'),
(58, 18, 26, 'GARLIC', '80.00', '5.00', '2020-06-29 14:26:45', '2020-07-03 12:51:53', 'abhijitjd003@gmail.com', '', 'U', '25.00'),
(59, 19, 26, 'GINGER', '70.00', '5.00', '2020-06-29 14:27:04', '2020-07-03 12:52:25', 'abhijitjd003@gmail.com', '', 'U', '30.00'),
(60, 20, 26, 'GREEN CHILLIES', '30.00', '5.00', '2020-06-29 14:27:20', '2020-07-03 12:52:48', 'abhijitjd003@gmail.com', '', 'U', '30.00'),
(61, 21, 26, 'HAGALA KAI', '44.00', '10.00', '2020-06-29 14:27:39', '2020-07-03 12:53:12', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(62, 22, 26, 'HALASANDE', '1.00', '1.00', '2020-06-29 14:27:57', '2020-07-03 12:53:41', 'abhijitjd003@gmail.com', '', 'U', '1.00'),
(63, 23, 26, 'HIREKAI', '30.00', '10.00', '2020-06-29 14:28:11', '2020-07-03 12:54:02', 'abhijitjd003@gmail.com', '', 'U', '35.00'),
(64, 24, 26, 'KNOL KHOL', '24.00', '4.00', '2020-06-29 14:28:32', '2020-07-03 12:54:29', 'abhijitjd003@gmail.com', '', 'U', '25.00'),
(65, 25, 26, 'KUMBALA', '80.00', '8.00', '2020-06-29 14:28:47', '2020-07-03 12:54:53', 'abhijitjd003@gmail.com', '', 'U', '80.00'),
(66, 26, 26, 'LEMON', '40.00', '4.00', '2020-06-29 14:29:04', '2020-07-03 12:55:07', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(67, 27, 26, 'MC', '5.00', '5.00', '2020-06-29 14:29:17', '2020-07-03 12:55:40', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(68, 28, 26, 'MULANGI', '15.00', '10.00', '2020-06-29 14:29:29', '2020-07-03 12:56:07', 'abhijitjd003@gmail.com', '', 'U', '25.00'),
(69, 29, 26, 'ONION', '18.00', '15.00', '2020-06-29 14:30:03', '2020-07-03 12:56:39', 'abhijitjd003@gmail.com', '', 'U', '200.00'),
(70, 30, 26, 'PADUVALAKAI', '18.00', '8.00', '2020-06-29 14:30:17', '2020-07-03 12:57:02', 'abhijitjd003@gmail.com', '', 'U', '80.00'),
(71, 31, 26, 'SIMEBADNE KAI', '20.00', '15.00', '2020-06-29 14:30:35', '2020-07-03 12:57:21', 'abhijitjd003@gmail.com', '', 'U', '70.00'),
(72, 32, 26, 'SMALL ONION', '65.00', '6.00', '2020-06-29 14:30:54', '2020-07-03 12:57:44', 'abhijitjd003@gmail.com', '', 'U', '65.00'),
(73, 33, 26, 'SOREKAI', '18.00', '10.00', '2020-06-29 14:31:10', '2020-07-03 12:58:06', 'abhijitjd003@gmail.com', '', 'U', '20.00'),
(74, 36, 26, 'THONDEKAI', '20.00', '10.00', '2020-06-29 14:32:02', '2020-07-03 12:58:38', 'abhijitjd003@gmail.com', '', 'U', '25.00'),
(75, 34, 26, 'TOMATO (HULI)', '15.00', '20.00', '2020-06-29 14:31:27', '2020-07-03 12:58:56', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(76, 35, 26, 'TOMATO (JAMUN)', '18.00', '20.00', '2020-06-29 14:31:43', '2020-07-03 12:59:17', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(77, 58, 26, 'Apple', '200.00', '10.00', '2020-07-05 06:17:51', '2020-07-04 17:49:59', '', 'null', 'D', '50.00'),
(78, 59, 26, 'Apple', '200.00', '10.00', '2020-07-05 06:20:18', '2020-07-04 19:17:00', '', 'null', 'D', '50.00'),
(79, 42, 26, 'ALOO', '10.00', '10.00', '2020-07-03 08:31:50', '2020-07-05 08:08:59', '', '', 'U', '10.00'),
(80, 7, 26, 'BEANS (OOTY)', '26.00', '5.00', '2020-06-29 14:21:54', '2020-07-05 08:10:00', 'abhijitjd003@gmail.com', '', 'U', '60.00'),
(81, 8, 26, 'BEETROOT', '28.00', '3.00', '2020-06-29 14:22:19', '2020-07-05 08:12:04', 'abhijitjd003@gmail.com', '', 'U', '30.00'),
(82, 8, 26, 'BEETROOT', '28.00', '3.00', '2020-06-29 14:22:19', '2020-07-05 08:14:58', 'abhijitjd003@gmail.com', '', 'U', '30.00'),
(83, 7, 26, 'BEANS (OOTY)', '26.00', '5.00', '2020-06-29 14:21:54', '2020-07-05 08:20:03', 'abhijitjd003@gmail.com', '', 'U', '60.00'),
(84, 60, 26, 'Apple', '200.00', '10.00', '2020-07-05 08:21:58', '2020-07-05 08:22:55', '', '', 'U', '10.00'),
(85, 9, 26, 'BHENDI', '12.00', '10.00', '2020-06-29 14:22:41', '2020-07-04 22:59:36', 'abhijitjd003@gmail.com', '', 'U', '100.00'),
(86, 60, 26, 'Apple', '200.00', '10.00', '2020-07-05 08:21:58', '2020-07-04 23:00:11', '', '', 'U', '10.00'),
(87, 10, 26, 'BRINJAL (LONG)', '16.00', '8.00', '2020-06-29 14:22:59', '2020-07-05 01:16:09', 'abhijitjd003@gmail.com', '', 'U', '75.00'),
(88, 10, 26, 'BRINJAL (LONG)', '16.00', '8.00', '2020-06-29 14:22:59', '2020-07-05 01:16:22', 'abhijitjd003@gmail.com', '', 'U', '75.00'),
(89, 10, 26, 'BRINJAL (LONG)', '16.00', '8.00', '2020-06-29 14:22:59', '2020-07-05 01:16:46', 'abhijitjd003@gmail.com', '', 'U', '75.00'),
(90, 7, 26, 'BEANS (OOTY)', '26.00', '5.00', '2020-06-29 14:21:54', '2020-07-05 14:41:25', 'abhijitjd003@gmail.com', '', 'U', '60.00'),
(91, 9, 26, 'BHENDI', '12.00', '10.00', '2020-06-29 14:22:41', '2020-07-05 14:42:41', 'abhijitjd003@gmail.com', '', 'U', '100.00'),
(92, 12, 26, 'CABBAGE', '10.00', '11.00', '2020-06-29 14:24:18', '2020-07-05 14:43:18', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(93, 13, 26, 'CAPSICUM', '65.00', '100.00', '2020-06-29 14:25:12', '2020-07-05 14:43:34', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(94, 14, 26, 'CARROT', '30.00', '25.00', '2020-06-29 14:25:39', '2020-07-05 14:43:50', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(95, 15, 26, 'CAULIFLOWER', '20.00', '20.00', '2020-06-29 14:25:53', '2020-07-05 14:44:13', 'abhijitjd003@gmail.com', '', 'U', '30.00'),
(96, 16, 26, 'CUCUMBER', '9.00', '25.00', '2020-06-29 14:26:10', '2020-07-05 14:44:35', 'abhijitjd003@gmail.com', '', 'U', '65.00'),
(97, 17, 26, 'DRUMSTICK', '40.00', '10.00', '2020-06-29 14:26:27', '2020-07-05 14:44:51', 'abhijitjd003@gmail.com', '', 'U', '20.00'),
(98, 20, 26, 'GREEN CHILLIES', '26.00', '5.00', '2020-06-29 14:27:20', '2020-07-05 14:46:58', 'abhijitjd003@gmail.com', '', 'U', '30.00'),
(99, 20, 26, 'GREEN CHILLIES', '30.00', '5.00', '2020-06-29 14:27:20', '2020-07-05 14:47:20', 'abhijitjd003@gmail.com', '', 'U', '30.00'),
(100, 23, 26, 'HIREKAI', '18.00', '10.00', '2020-06-29 14:28:11', '2020-07-05 14:47:41', 'abhijitjd003@gmail.com', '', 'U', '35.00'),
(101, 25, 26, 'KUMBALA', '10.00', '8.00', '2020-06-29 14:28:47', '2020-07-05 14:48:01', 'abhijitjd003@gmail.com', '', 'U', '80.00'),
(102, 26, 26, 'LEMON', '40.00', '4.00', '2020-06-29 14:29:04', '2020-07-05 14:48:30', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(103, 27, 26, 'MC', '5.00', '5.00', '2020-06-29 14:29:17', '2020-07-05 14:48:41', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(104, 28, 26, 'MULANGI', '14.00', '10.00', '2020-06-29 14:29:29', '2020-07-05 14:48:51', 'abhijitjd003@gmail.com', '', 'U', '25.00'),
(105, 28, 26, 'MULANGI', '14.00', '10.00', '2020-06-29 14:29:29', '2020-07-05 14:49:00', 'abhijitjd003@gmail.com', '', 'U', '25.00'),
(106, 29, 26, 'ONION', '13.00', '15.00', '2020-06-29 14:30:03', '2020-07-05 14:49:32', 'abhijitjd003@gmail.com', '', 'U', '200.00'),
(107, 33, 26, 'SOREKAI', '11.00', '10.00', '2020-06-29 14:31:10', '2020-07-05 14:50:01', 'abhijitjd003@gmail.com', '', 'U', '20.00'),
(108, 34, 26, 'TOMATO (HULI)', '28.00', '20.00', '2020-06-29 14:31:27', '2020-07-05 14:50:21', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(109, 35, 26, 'TOMATO (JAMUN)', '28.00', '20.00', '2020-06-29 14:31:43', '2020-07-05 14:50:37', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(110, 46, 26, 'Pudina', '2.00', '3.00', '2020-07-03 13:08:54', '2020-07-05 14:51:10', '', '', 'U', '10.00'),
(111, 60, 26, 'Apple', '200.00', '10.00', '2020-07-05 08:21:58', '2020-07-05 14:54:32', '', 'null', 'D', '10.00'),
(112, 61, 26, 'Sapsige', '12.00', '10.00', '2020-07-05 14:55:16', '2020-07-05 14:55:33', '', '', 'U', '5.00'),
(113, 61, 26, 'Sapsige', '12.00', '10.00', '2020-07-05 14:55:16', '2020-07-05 14:56:13', '', '', 'U', '5.00'),
(114, 42, 26, 'ALOO', '10.00', '10.00', '2020-07-03 08:31:50', '2020-07-05 15:02:32', '', '', 'U', '10.00'),
(115, 18, 26, 'GARLIC', '80.00', '5.00', '2020-06-29 14:26:45', '2020-07-05 15:05:07', 'abhijitjd003@gmail.com', '', 'U', '25.00'),
(116, 10, 26, 'BRINJAL (LONG)', '16.00', '8.00', '2020-06-29 14:22:59', '2020-07-05 15:10:31', 'abhijitjd003@gmail.com', '', 'U', '75.00'),
(117, 12, 26, 'CABBAGE', '12.00', '11.00', '2020-06-29 14:24:18', '2020-07-05 15:10:54', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(118, 13, 26, 'CAPSICUM', '60.00', '100.00', '2020-06-29 14:25:12', '2020-07-05 15:11:30', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(119, 14, 26, 'CARROT', '32.00', '25.00', '2020-06-29 14:25:39', '2020-07-05 15:11:47', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(120, 16, 26, 'CUCUMBER', '10.00', '25.00', '2020-06-29 14:26:10', '2020-07-05 15:12:29', 'abhijitjd003@gmail.com', '', 'U', '65.00'),
(121, 17, 26, 'DRUMSTICK', '40.00', '10.00', '2020-06-29 14:26:27', '2020-07-05 15:12:44', 'abhijitjd003@gmail.com', '', 'U', '20.00'),
(122, 18, 26, 'GARLIC', '80.00', '5.00', '2020-06-29 14:26:45', '2020-07-05 15:13:00', 'abhijitjd003@gmail.com', '', 'U', '25.00'),
(123, 19, 26, 'GINGER', '60.00', '5.00', '2020-06-29 14:27:04', '2020-07-05 15:13:15', 'abhijitjd003@gmail.com', '', 'U', '30.00'),
(124, 20, 26, 'GREEN CHILLIES', '35.00', '5.00', '2020-06-29 14:27:20', '2020-07-05 15:13:32', 'abhijitjd003@gmail.com', '', 'U', '30.00'),
(125, 21, 26, 'HAGALA KAI', '36.00', '10.00', '2020-06-29 14:27:39', '2020-07-05 15:13:46', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(126, 22, 26, 'HALASANDE', '30.00', '1.00', '2020-06-29 14:27:57', '2020-07-05 15:14:01', 'abhijitjd003@gmail.com', '', 'U', '1.00'),
(127, 17, 26, 'DRUMSTICK', '40.00', '10.00', '2020-06-29 14:26:27', '2020-07-05 15:14:14', 'abhijitjd003@gmail.com', '', 'U', '20.00'),
(128, 23, 26, 'HIREKAI', '25.00', '10.00', '2020-06-29 14:28:11', '2020-07-05 15:14:34', 'abhijitjd003@gmail.com', '', 'U', '35.00'),
(129, 24, 26, 'KNOL KHOL', '18.00', '4.00', '2020-06-29 14:28:32', '2020-07-05 15:15:00', 'abhijitjd003@gmail.com', '', 'U', '25.00'),
(130, 25, 26, 'KUMBALA', '12.00', '8.00', '2020-06-29 14:28:47', '2020-07-05 15:15:14', 'abhijitjd003@gmail.com', '', 'U', '80.00'),
(131, 26, 26, 'LEMON', '45.00', '4.00', '2020-06-29 14:29:04', '2020-07-05 15:15:38', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(132, 27, 26, 'MC', '6.00', '5.00', '2020-06-29 14:29:17', '2020-07-05 15:16:49', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(133, 28, 26, 'MULANGI', '18.00', '10.00', '2020-06-29 14:29:29', '2020-07-05 15:17:45', 'abhijitjd003@gmail.com', '', 'U', '25.00'),
(134, 29, 26, 'ONION', '12.00', '15.00', '2020-06-29 14:30:03', '2020-07-05 15:18:13', 'abhijitjd003@gmail.com', '', 'U', '200.00'),
(135, 30, 26, 'PADUVALAKAI', '12.00', '8.00', '2020-06-29 14:30:17', '2020-07-05 15:18:33', 'abhijitjd003@gmail.com', '', 'U', '80.00'),
(136, 31, 26, 'SIMEBADNE KAI', '20.00', '15.00', '2020-06-29 14:30:35', '2020-07-05 15:18:52', 'abhijitjd003@gmail.com', '', 'U', '70.00'),
(137, 33, 26, 'SOREKAI', '12.00', '10.00', '2020-06-29 14:31:10', '2020-07-05 15:19:30', 'abhijitjd003@gmail.com', '', 'U', '20.00'),
(138, 34, 26, 'TOMATO (HULI)', '25.00', '20.00', '2020-06-29 14:31:27', '2020-07-05 15:20:02', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(139, 35, 26, 'TOMATO (JAMUN)', '26.00', '20.00', '2020-06-29 14:31:43', '2020-07-05 15:20:17', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(140, 36, 26, 'THONDEKAI', '18.00', '10.00', '2020-06-29 14:32:02', '2020-07-05 15:20:35', 'abhijitjd003@gmail.com', '', 'U', '25.00'),
(141, 30, 26, 'PADUVALAKAI', '12.00', '8.00', '2020-06-29 14:30:17', '2020-07-05 15:20:54', 'abhijitjd003@gmail.com', '', 'U', '80.00'),
(142, 42, 26, 'ALOO', '10.00', '10.00', '2020-07-03 08:31:50', '2020-07-05 15:21:31', '', '', 'U', '10.00'),
(143, 43, 26, 'Beans', '18.00', '3.00', '2020-07-03 13:02:15', '2020-07-05 15:21:58', '', '', 'U', '0.00'),
(144, 44, 26, 'Karibevu', '1.50', '3.00', '2020-07-03 13:08:04', '2020-07-05 15:22:22', '', '', 'U', '10.00'),
(145, 45, 26, 'kothmiri', '3.00', '3.00', '2020-07-03 13:08:28', '2020-07-05 15:22:43', '', '', 'U', '10.00'),
(146, 46, 26, 'Pudina', '3.00', '3.00', '2020-07-03 13:08:54', '2020-07-05 15:22:57', '', '', 'U', '10.00'),
(147, 47, 26, 'Palak', '2.00', '3.00', '2020-07-03 13:09:17', '2020-07-05 15:23:26', '', '', 'U', '10.00'),
(148, 11, 26, 'BRINJAL (ROUND)', '14.00', '7.00', '2020-06-29 14:23:51', '2020-07-05 15:23:50', 'abhijitjd003@gmail.com', '', 'U', '65.00'),
(149, 15, 26, 'CAULIFLOWER', '18.00', '20.00', '2020-06-29 14:25:53', '2020-07-05 15:25:13', 'abhijitjd003@gmail.com', '', 'U', '30.00'),
(150, 15, 26, 'CAULIFLOWER', '18.00', '20.00', '2020-06-29 14:25:53', '2020-07-05 15:26:12', 'abhijitjd003@gmail.com', '', 'U', '30.00'),
(151, 61, 26, 'Sapsige', '2.00', '3.00', '2020-07-05 14:55:16', '2020-07-05 15:27:05', '', '', 'U', '10.00'),
(152, 42, 26, 'ALOO', '10.00', '10.00', '2020-07-03 08:31:50', '2020-07-05 15:28:35', '', '', 'U', '10.00'),
(153, 42, 26, 'Brinjal Black', '16.00', '10.00', '2020-07-03 08:31:50', '2020-07-05 15:28:58', '', '', 'U', '10.00'),
(154, 43, 26, 'Beans', '18.00', '3.00', '2020-07-03 13:02:15', '2020-07-05 15:29:52', '', '', 'U', '10.00'),
(155, 42, 26, 'Brinjal Black', '16.00', '10.00', '2020-07-03 08:31:50', '2020-07-05 15:31:29', '', '', 'U', '10.00'),
(156, 43, 26, 'Potato', '18.00', '3.00', '2020-07-03 13:02:15', '2020-07-05 15:32:46', '', '', 'U', '10.00'),
(157, 62, 26, 'Beans', '18.00', '10.00', '2020-07-05 15:30:20', '2020-07-05 15:33:07', '', '', 'U', '10.00'),
(158, 61, 26, 'Sapsige', '2.00', '3.00', '2020-07-05 14:55:16', '2020-07-05 15:33:51', '', '', 'U', '10.00'),
(159, 29, 26, 'ONION', '12.00', '15.00', '2020-06-29 14:30:03', '2020-07-05 15:48:19', 'abhijitjd003@gmail.com', '', 'U', '200.00'),
(160, 8, 26, 'BEETROOT', '28.00', '3.00', '2020-06-29 14:22:19', '2020-07-05 18:46:53', 'abhijitjd003@gmail.com', '', 'U', '30.00'),
(161, 7, 26, 'BEANS (OOTY)', '25.00', '5.00', '2020-06-29 14:21:54', '2020-07-05 18:47:21', 'abhijitjd003@gmail.com', '', 'U', '60.00'),
(162, 12, 26, 'CABBAGE', '12.00', '11.00', '2020-06-29 14:24:18', '2020-07-05 18:49:30', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(163, 43, 26, 'Beans', '18.00', '3.00', '2020-07-03 13:02:15', '2020-07-05 18:50:09', '', '', 'U', '10.00'),
(164, 16, 26, 'CUCUMBER', '10.00', '25.00', '2020-06-29 14:26:10', '2020-07-05 18:51:30', 'abhijitjd003@gmail.com', '', 'U', '65.00'),
(165, 26, 26, 'LEMON', '45.00', '4.00', '2020-06-29 14:29:04', '2020-07-05 18:52:07', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(166, 21, 26, 'HAGALA KAI', '36.00', '10.00', '2020-06-29 14:27:39', '2020-07-05 18:52:47', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(167, 9, 26, 'BHENDI', '13.00', '10.00', '2020-06-29 14:22:41', '2020-07-05 18:53:37', 'abhijitjd003@gmail.com', '', 'U', '100.00'),
(168, 10, 26, 'BRINJAL (LONG)', '16.00', '8.00', '2020-06-29 14:22:59', '2020-07-05 18:55:18', 'abhijitjd003@gmail.com', '', 'U', '75.00'),
(169, 13, 26, 'CAPSICUM', '60.00', '100.00', '2020-06-29 14:25:12', '2020-07-05 18:55:59', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(170, 13, 26, 'BRINJAL(Long)', '16.00', '100.00', '2020-06-29 14:25:12', '2020-07-05 18:56:41', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(171, 17, 26, 'DRUMSTICK', '40.00', '10.00', '2020-06-29 14:26:27', '2020-07-05 19:00:04', 'abhijitjd003@gmail.com', '', 'U', '20.00'),
(172, 22, 26, 'HALASANDE', '30.00', '1.00', '2020-06-29 14:27:57', '2020-07-05 19:01:20', 'abhijitjd003@gmail.com', '', 'U', '1.00'),
(173, 23, 26, 'HIREKAI', '25.00', '10.00', '2020-06-29 14:28:11', '2020-07-05 19:02:16', 'abhijitjd003@gmail.com', '', 'U', '35.00'),
(174, 11, 26, 'BRINJAL (ROUND)', '14.00', '7.00', '2020-06-29 14:23:51', '2020-07-05 19:05:55', 'abhijitjd003@gmail.com', '', 'U', '65.00'),
(175, 12, 26, 'BRINJAL (Black)', '16.00', '11.00', '2020-06-29 14:24:18', '2020-07-05 19:06:31', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(176, 13, 26, 'BRINJAL(Long)', '16.00', '100.00', '2020-06-29 14:25:12', '2020-07-05 19:07:37', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(177, 14, 26, 'CARROT', '32.00', '25.00', '2020-06-29 14:25:39', '2020-07-05 19:08:22', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(178, 13, 26, 'TOMATO(Sour)', '12.00', '100.00', '2020-06-29 14:25:12', '2020-07-05 19:08:37', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(179, 15, 26, 'CAULIFLOWER', '18.00', '20.00', '2020-06-29 14:25:53', '2020-07-05 19:08:59', 'abhijitjd003@gmail.com', '', 'U', '30.00'),
(180, 16, 26, 'CABBAGE', '12.00', '25.00', '2020-06-29 14:26:10', '2020-07-05 19:09:38', 'abhijitjd003@gmail.com', '', 'U', '65.00'),
(181, 17, 26, 'HALSANDE', '30.00', '10.00', '2020-06-29 14:26:27', '2020-07-05 19:09:45', 'abhijitjd003@gmail.com', 'null', 'D', '20.00'),
(182, 15, 26, 'ONION', '12.00', '20.00', '2020-06-29 14:25:53', '2020-07-05 19:10:25', 'abhijitjd003@gmail.com', '', 'U', '30.00'),
(183, 14, 26, 'TOMATO(Jamun)', '32.00', '25.00', '2020-06-29 14:25:39', '2020-07-05 19:10:49', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(184, 22, 26, 'ONION', '12.00', '1.00', '2020-06-29 14:27:57', '2020-07-05 19:11:45', 'abhijitjd003@gmail.com', '', 'U', '1.00'),
(185, 23, 26, 'SMALL ONION', '30.00', '10.00', '2020-06-29 14:28:11', '2020-07-05 19:12:22', 'abhijitjd003@gmail.com', '', 'U', '35.00'),
(186, 24, 26, 'KNOL KHOL', '18.00', '4.00', '2020-06-29 14:28:32', '2020-07-05 19:13:27', 'abhijitjd003@gmail.com', '', 'U', '25.00'),
(187, 25, 26, 'KUMBALA', '12.00', '8.00', '2020-06-29 14:28:47', '2020-07-05 19:13:57', 'abhijitjd003@gmail.com', '', 'U', '80.00'),
(188, 26, 26, 'CUCUMBER', '10.00', '4.00', '2020-06-29 14:29:04', '2020-07-05 19:14:22', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(189, 27, 26, 'MC', '6.00', '5.00', '2020-06-29 14:29:17', '2020-07-05 19:14:55', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(190, 23, 26, 'MC', '6.00', '10.00', '2020-06-29 14:28:11', '2020-07-05 19:15:48', 'abhijitjd003@gmail.com', '', 'U', '35.00'),
(191, 23, 26, 'MC', '6.00', '10.00', '2020-06-29 14:28:11', '2020-07-05 19:16:10', 'abhijitjd003@gmail.com', '', 'U', '35.00'),
(192, 23, 26, 'MC', '6.00', '10.00', '2020-06-29 14:28:11', '2020-07-05 19:16:23', 'abhijitjd003@gmail.com', '', 'U', '35.00'),
(193, 22, 26, 'CUCUMBER', '10.00', '1.00', '2020-06-29 14:27:57', '2020-07-05 19:17:27', 'abhijitjd003@gmail.com', '', 'U', '1.00'),
(194, 23, 26, 'MC', '6.00', '10.00', '2020-06-29 14:28:11', '2020-07-05 19:17:38', 'abhijitjd003@gmail.com', '', 'U', '35.00'),
(195, 28, 26, 'MULANGI', '18.00', '10.00', '2020-06-29 14:29:29', '2020-07-05 19:18:04', 'abhijitjd003@gmail.com', '', 'U', '25.00'),
(196, 29, 26, 'ONION', '13.00', '15.00', '2020-06-29 14:30:03', '2020-07-05 19:18:21', 'abhijitjd003@gmail.com', '', 'U', '200.00'),
(197, 34, 26, 'TOMATO (HULI)', '25.00', '20.00', '2020-06-29 14:31:27', '2020-07-05 19:20:10', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(198, 30, 26, 'PADUVALAKAI', '12.00', '8.00', '2020-06-29 14:30:17', '2020-07-05 19:21:33', 'abhijitjd003@gmail.com', '', 'U', '80.00'),
(199, 31, 26, 'SIMEBADNE KAI', '20.00', '15.00', '2020-06-29 14:30:35', '2020-07-05 19:22:06', 'abhijitjd003@gmail.com', '', 'U', '70.00'),
(200, 35, 26, 'TOMATO (JAMUN)', '26.00', '20.00', '2020-06-29 14:31:43', '2020-07-05 19:23:10', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(201, 33, 26, 'SOREKAI', '12.00', '10.00', '2020-06-29 14:31:10', '2020-07-05 19:23:52', 'abhijitjd003@gmail.com', '', 'U', '20.00'),
(202, 32, 26, 'SMALL ONION', '65.00', '6.00', '2020-06-29 14:30:54', '2020-07-05 19:24:34', 'abhijitjd003@gmail.com', '', 'U', '65.00'),
(203, 32, 26, 'EEE', '65.00', '6.00', '2020-06-29 14:30:54', '2020-07-05 19:25:02', 'abhijitjd003@gmail.com', '', 'U', '65.00'),
(204, 33, 26, 'TONDEKAI', '18.00', '10.00', '2020-06-29 14:31:10', '2020-07-05 19:26:08', 'abhijitjd003@gmail.com', '', 'U', '20.00'),
(205, 42, 26, 'Brinjal Black', '16.00', '10.00', '2020-07-03 08:31:50', '2020-07-05 19:27:08', '', '', 'U', '10.00'),
(206, 44, 26, 'Karibevu', '1.50', '3.00', '2020-07-03 13:08:04', '2020-07-05 19:27:54', '', '', 'U', '10.00'),
(207, 45, 26, 'kothmiri', '3.00', '3.00', '2020-07-03 13:08:28', '2020-07-05 19:30:41', '', '', 'U', '10.00'),
(208, 46, 26, 'Pudina', '3.00', '3.00', '2020-07-03 13:08:54', '2020-07-05 19:31:36', '', '', 'U', '10.00'),
(209, 47, 26, 'Palak', '2.00', '3.00', '2020-07-03 13:09:17', '2020-07-05 19:32:13', '', '', 'U', '10.00'),
(210, 12, 26, 'EEE', '16.00', '11.00', '2020-06-29 14:24:18', '2020-07-05 19:33:24', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(211, 22, 26, 'EEE', '10.00', '1.00', '2020-06-29 14:27:57', '2020-07-05 19:33:35', 'abhijitjd003@gmail.com', '', 'U', '1.00'),
(212, 23, 26, 'EEE', '6.00', '10.00', '2020-06-29 14:28:11', '2020-07-05 19:33:46', 'abhijitjd003@gmail.com', '', 'U', '35.00'),
(213, 32, 26, 'EEE', '65.00', '6.00', '2020-06-29 14:30:54', '2020-07-05 19:34:02', 'abhijitjd003@gmail.com', '', 'U', '65.00'),
(214, 33, 26, 'EEE', '18.00', '10.00', '2020-06-29 14:31:10', '2020-07-05 19:34:19', 'abhijitjd003@gmail.com', '', 'U', '20.00'),
(215, 42, 26, 'EEE', '16.00', '10.00', '2020-07-03 08:31:50', '2020-07-05 19:34:32', '', '', 'U', '10.00'),
(216, 43, 26, 'Beetroot', '28.00', '3.00', '2020-07-03 13:02:15', '2020-07-05 19:36:27', '', '', 'U', '10.00'),
(217, 61, 26, 'Sapsige', '2.00', '3.00', '2020-07-05 14:55:16', '2020-07-05 19:37:07', '', '', 'U', '10.00'),
(218, 62, 26, 'Potato', '18.00', '10.00', '2020-07-05 15:30:20', '2020-07-05 19:38:01', '', '', 'U', '10.00'),
(219, 64, 26, 'HAGALKAYI', '35.00', '3.00', '2020-07-05 19:39:44', '2020-07-05 19:41:26', '', '', 'U', '10.00'),
(220, 42, 26, 'EEE', '16.00', '10.00', '2020-07-03 08:31:50', '2020-07-05 19:42:46', '', '', 'U', '10.00'),
(221, 62, 26, 'SEEMEBADANE', '20.00', '10.00', '2020-07-05 15:30:20', '2020-07-05 19:44:37', '', '', 'U', '10.00'),
(222, 62, 26, 'SEEMEBADANE', '20.00', '10.00', '2020-07-05 15:30:20', '2020-07-05 19:45:04', '', '', 'U', '10.00'),
(223, 27, 26, 'BRINJAL(Round)', '6.00', '5.00', '2020-06-29 14:29:17', '2020-07-05 19:46:38', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(224, 27, 26, 'BRINJAL(Round)', '14.00', '5.00', '2020-06-29 14:29:17', '2020-07-05 19:47:05', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(225, 26, 26, 'BRINJAL (Black)', '10.00', '4.00', '2020-06-29 14:29:04', '2020-07-05 19:47:31', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(226, 26, 26, 'BRINJAL (Black)', '16.00', '4.00', '2020-06-29 14:29:04', '2020-07-05 19:47:53', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(227, 20, 26, 'GREEN CHILLIES', '35.00', '5.00', '2020-06-29 14:27:20', '2020-07-05 19:48:54', 'abhijitjd003@gmail.com', '', 'U', '30.00'),
(228, 29, 26, 'MC', '13.00', '15.00', '2020-06-29 14:30:03', '2020-07-05 19:50:13', 'abhijitjd003@gmail.com', '', 'U', '200.00'),
(229, 13, 26, 'TOMATO(Huli)', '12.00', '100.00', '2020-06-29 14:25:12', '2020-07-05 19:51:32', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(230, 14, 26, 'TOMATO(Jamun)', '32.00', '25.00', '2020-06-29 14:25:39', '2020-07-05 19:51:43', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(231, 12, 26, 'EEE', '16.00', '11.00', '2020-06-29 14:24:18', '2020-07-05 20:36:09', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(232, 22, 26, 'EEE', '10.00', '1.00', '2020-06-29 14:27:57', '2020-07-05 20:36:25', 'abhijitjd003@gmail.com', '', 'U', '1.00'),
(233, 22, 26, 'EEE', '10.00', '1.00', '2020-06-29 14:27:57', '2020-07-05 20:36:36', 'abhijitjd003@gmail.com', '', 'U', '1.00'),
(234, 23, 26, 'EEE', '6.00', '10.00', '2020-06-29 14:28:11', '2020-07-05 20:36:46', 'abhijitjd003@gmail.com', '', 'U', '35.00'),
(235, 32, 26, 'EEE', '65.00', '6.00', '2020-06-29 14:30:54', '2020-07-05 20:37:05', 'abhijitjd003@gmail.com', '', 'U', '65.00'),
(236, 33, 26, 'EEE', '18.00', '10.00', '2020-06-29 14:31:10', '2020-07-05 20:37:16', 'abhijitjd003@gmail.com', '', 'U', '20.00'),
(237, 43, 26, 'EEE', '28.00', '3.00', '2020-07-03 13:02:15', '2020-07-05 20:37:35', '', '', 'U', '10.00'),
(238, 66, 26, 'xyz', '200.00', '10.00', '2020-07-05 21:23:33', '2020-07-05 21:24:34', '', '', 'U', '50.00'),
(239, 13, 26, 'TOMATO(Huli)', '25.00', '100.00', '2020-06-29 14:25:12', '2020-07-06 12:37:42', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(240, 14, 26, 'TOMATO(Jamun)', '26.00', '25.00', '2020-06-29 14:25:39', '2020-07-06 12:38:02', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(241, 36, 26, 'THONDEKAI', '18.00', '10.00', '2020-06-29 14:32:02', '2020-07-06 12:47:05', 'abhijitjd003@gmail.com', '', 'U', '25.00'),
(242, 67, 26, 'kothmiri', '3.00', '3.00', '2020-07-06 12:39:51', '2020-07-06 12:47:34', '', '', 'U', '10.00'),
(243, 36, 26, 'THONDEKAI', '18.00', '10.00', '2020-06-29 14:32:02', '2020-07-06 12:48:00', 'abhijitjd003@gmail.com', '', 'U', '25.00'),
(244, 67, 26, 'kothmiri', '3.00', '3.00', '2020-07-06 12:39:51', '2020-07-06 12:48:30', '', '', 'U', '10.00'),
(245, 12, 26, 'EEE', '16.00', '11.00', '2020-06-29 14:24:18', '2020-07-06 12:49:04', 'abhijitjd003@gmail.com', 'null', 'D', '40.00'),
(246, 22, 26, 'EEE', '10.00', '1.00', '2020-06-29 14:27:57', '2020-07-06 12:49:13', 'abhijitjd003@gmail.com', 'null', 'D', '1.00'),
(247, 23, 26, 'EEE', '6.00', '10.00', '2020-06-29 14:28:11', '2020-07-06 12:49:19', 'abhijitjd003@gmail.com', 'null', 'D', '35.00'),
(248, 25, 26, 'BRINJAL (White)', '12.00', '8.00', '2020-06-29 14:28:47', '2020-07-06 12:53:52', 'abhijitjd003@gmail.com', '', 'U', '80.00'),
(249, 16, 26, 'SMALL ONION', '15.00', '25.00', '2020-06-29 14:26:10', '2020-07-06 12:54:01', 'abhijitjd003@gmail.com', '', 'U', '65.00'),
(250, 69, 26, 'Pudina', '3.00', '3.00', '2020-07-06 12:40:50', '2020-07-06 12:56:50', '', '', 'U', '10.00'),
(251, 67, 26, 'kothmiri', '3.00', '3.00', '2020-07-06 12:39:51', '2020-07-06 12:57:23', '', '', 'U', '10.00'),
(252, 68, 26, 'Karibevu', '1.50', '3.00', '2020-07-06 12:40:25', '2020-07-06 12:57:41', '', '', 'U', '10.00'),
(253, 69, 26, 'Pudina', '3.00', '3.00', '2020-07-06 12:40:50', '2020-07-06 12:58:09', '', '', 'U', '10.00'),
(254, 71, 26, 'sapsige', '2.00', '3.00', '2020-07-06 12:41:52', '2020-07-06 12:58:32', '', '', 'U', '10.00'),
(255, 70, 26, 'Palak', '2.00', '3.00', '2020-07-06 12:41:13', '2020-07-06 12:58:51', '', '', 'U', '10.00'),
(256, 66, 26, 'xyz', '200.00', '10.00', '2020-07-05 21:23:33', '2020-07-06 13:00:43', '', 'null', 'D', '50.00'),
(257, 33, 26, 'EEE', '18.00', '10.00', '2020-06-29 14:31:10', '2020-07-06 13:00:51', 'abhijitjd003@gmail.com', 'null', 'D', '20.00'),
(258, 32, 26, 'EEE', '65.00', '6.00', '2020-06-29 14:30:54', '2020-07-06 13:01:02', 'abhijitjd003@gmail.com', 'null', 'D', '65.00'),
(259, 43, 26, 'EEE', '28.00', '3.00', '2020-07-03 13:02:15', '2020-07-06 13:01:11', '', 'null', 'D', '10.00'),
(260, 18, 26, 'GARLIC', '80.00', '5.00', '2020-06-29 14:26:45', '2020-07-07 01:54:05', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'U', '25.00'),
(261, 19, 26, 'GINGER', '60.00', '5.00', '2020-06-29 14:27:04', '2020-07-07 01:55:31', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'U', '30.00'),
(262, 13, 26, 'TOMATO(Huli)', '28.00', '100.00', '2020-06-29 14:25:12', '2020-07-08 14:53:35', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(263, 47, 26, 'SOREKAI', '12.00', '3.00', '2020-07-03 13:09:17', '2020-07-08 14:54:09', '', 'test@gmail.com', 'U', '10.00'),
(264, 16, 26, 'SMALL ONION', '15.00', '25.00', '2020-06-29 14:26:10', '2020-07-08 14:54:45', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(265, 62, 26, 'SEEMEBADANE', '20.00', '10.00', '2020-07-05 15:30:20', '2020-07-08 14:55:21', '', 'test@gmail.com', 'U', '10.00'),
(266, 46, 26, 'PADUVALKAYI', '12.00', '3.00', '2020-07-03 13:08:54', '2020-07-08 14:55:30', '', 'test@gmail.com', 'U', '10.00'),
(267, 15, 26, 'ONION', '12.00', '20.00', '2020-06-29 14:25:53', '2020-07-08 14:55:43', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(268, 35, 26, 'MULANGI', '18.00', '20.00', '2020-06-29 14:31:43', '2020-07-08 14:57:05', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(269, 29, 26, 'MC', '6.00', '15.00', '2020-06-29 14:30:03', '2020-07-08 14:57:16', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(270, 21, 26, 'LEMON', '45.00', '10.00', '2020-06-29 14:27:39', '2020-07-08 14:57:27', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(271, 63, 26, 'KHOL KHOL', '18.00', '5.00', '2020-07-05 19:38:57', '2020-07-08 14:58:34', '', 'test@gmail.com', 'U', '10.00'),
(272, 45, 26, 'HEEREKAI', '25.00', '3.00', '2020-07-03 13:08:28', '2020-07-08 14:58:52', '', 'test@gmail.com', 'U', '10.00'),
(273, 64, 26, 'HAGALKAYI', '35.00', '3.00', '2020-07-05 19:39:44', '2020-07-08 14:59:21', '', 'test@gmail.com', 'U', '10.00'),
(274, 20, 26, 'GREEN CHILLIES', '30.00', '5.00', '2020-06-29 14:27:20', '2020-07-08 14:59:32', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(275, 19, 26, 'GINGER', '60.00', '6.00', '2020-06-29 14:27:04', '2020-07-08 14:59:44', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(276, 18, 26, 'GARLIC', '80.00', '5.00', '2020-06-29 14:26:45', '2020-07-08 14:59:55', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(277, 28, 26, 'CUCUMBER', '10.00', '10.00', '2020-06-29 14:29:29', '2020-07-08 15:00:08', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(278, 31, 26, 'CAULIFLOWER', '18.00', '15.00', '2020-06-29 14:30:35', '2020-07-08 15:00:17', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '70.00'),
(279, 9, 26, 'CARROT', '32.00', '10.00', '2020-06-29 14:22:41', '2020-07-08 15:00:26', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '100.00'),
(280, 10, 26, 'CAPSICUM', '60.00', '8.00', '2020-06-29 14:22:59', '2020-07-08 15:00:34', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '75.00'),
(281, 30, 26, 'CABBAGE', '12.00', '8.00', '2020-06-29 14:30:17', '2020-07-08 15:00:44', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(282, 26, 26, 'BRINJAL (Black)', '16.00', '4.00', '2020-06-29 14:29:04', '2020-07-08 15:01:29', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(283, 27, 26, 'BRINJAL(Round)', '14.00', '5.00', '2020-06-29 14:29:17', '2020-07-08 15:01:40', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(284, 25, 26, 'BRINJAL (White)', '12.00', '8.00', '2020-06-29 14:28:47', '2020-07-08 15:01:52', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(285, 34, 26, 'BENDI', '13.00', '20.00', '2020-06-29 14:31:27', '2020-07-08 15:02:10', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(286, 61, 26, 'BEETROOT', '28.00', '3.00', '2020-07-05 14:55:16', '2020-07-08 15:02:19', '', 'test@gmail.com', 'U', '10.00'),
(287, 8, 26, 'Beans(OOTY)', '25.00', '3.00', '2020-06-29 14:22:19', '2020-07-08 15:02:31', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(288, 7, 26, 'Beans', '18.00', '5.00', '2020-06-29 14:21:54', '2020-07-08 15:02:42', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(289, 70, 26, 'Palak', '2.00', '3.00', '2020-07-06 12:41:13', '2020-07-08 15:03:11', '', 'test@gmail.com', 'U', '10.00'),
(290, 69, 26, 'Pudina', '3.00', '3.00', '2020-07-06 12:40:50', '2020-07-08 15:03:20', '', 'test@gmail.com', 'U', '10.00'),
(291, 71, 26, 'sapsige', '2.00', '3.00', '2020-07-06 12:41:52', '2020-07-08 15:04:39', '', 'test@gmail.com', 'U', '10.00'),
(292, 68, 26, 'Karibevu', '1.50', '3.00', '2020-07-06 12:40:25', '2020-07-08 15:27:11', '', 'test@gmail.com', 'U', '10.00'),
(293, 36, 26, 'THONDEKAI', '18.00', '10.00', '2020-06-29 14:32:02', '2020-07-08 15:31:21', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(294, 44, 26, 'DRUMSTICK', '40.00', '3.00', '2020-07-03 13:08:04', '2020-07-08 15:31:59', '', 'test@gmail.com', 'U', '10.00'),
(295, 65, 26, 'PUMPKIN', '12.00', '3.00', '2020-07-05 19:44:05', '2020-07-08 15:33:08', '', 'test@gmail.com', 'U', '10.00'),
(296, 68, 26, 'Karibevu', '2.50', '3.00', '2020-07-06 12:40:25', '2020-07-08 15:34:49', '', 'test@gmail.com', 'U', '10.00'),
(297, 67, 26, 'kothmiri', '3.00', '3.00', '2020-07-06 12:39:51', '2020-07-08 15:34:58', '', 'test@gmail.com', 'U', '10.00'),
(298, 71, 26, 'sapsige', '2.50', '3.00', '2020-07-06 12:41:52', '2020-07-08 15:35:11', '', 'test@gmail.com', 'U', '10.00'),
(299, 69, 26, 'Pudina', '3.00', '3.00', '2020-07-06 12:40:50', '2020-07-08 15:35:18', '', 'test@gmail.com', 'U', '10.00'),
(300, 70, 26, 'Palak', '2.50', '3.00', '2020-07-06 12:41:13', '2020-07-08 15:35:25', '', 'test@gmail.com', 'U', '10.00'),
(301, 36, 26, 'THONDEKAI', '15.00', '10.00', '2020-06-29 14:32:02', '2020-07-08 15:35:33', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(302, 14, 26, 'TOMATO(Jamun)', '29.00', '25.00', '2020-06-29 14:25:39', '2020-07-08 15:35:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(303, 13, 26, 'TOMATO(Huli)', '29.00', '100.00', '2020-06-29 14:25:12', '2020-07-08 15:35:48', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(304, 47, 26, 'SOREKAI', '14.00', '3.00', '2020-07-03 13:09:17', '2020-07-08 15:35:54', '', 'test@gmail.com', 'U', '10.00'),
(305, 16, 26, 'SMALL ONION', '45.00', '25.00', '2020-06-29 14:26:10', '2020-07-08 15:36:03', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(306, 62, 26, 'SEEMEBADANE', '22.00', '10.00', '2020-07-05 15:30:20', '2020-07-08 15:36:08', '', 'test@gmail.com', 'U', '10.00'),
(307, 46, 26, 'PADUVALKAYI', '13.00', '3.00', '2020-07-03 13:08:54', '2020-07-08 15:36:16', '', 'test@gmail.com', 'U', '10.00'),
(308, 15, 26, 'ONION', '13.00', '20.00', '2020-06-29 14:25:53', '2020-07-08 15:36:24', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(309, 44, 26, 'DRUMSTICK', '43.00', '3.00', '2020-07-03 13:08:04', '2020-07-08 15:36:34', '', 'test@gmail.com', 'U', '10.00'),
(310, 35, 26, 'MULANGI', '14.00', '20.00', '2020-06-29 14:31:43', '2020-07-08 15:36:40', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(311, 29, 26, 'MC', '8.00', '15.00', '2020-06-29 14:30:03', '2020-07-08 15:37:04', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(312, 21, 26, 'LEMON', '49.00', '10.00', '2020-06-29 14:27:39', '2020-07-08 15:37:12', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(313, 65, 26, 'PUMPKIN', '11.00', '3.00', '2020-07-05 19:44:05', '2020-07-08 15:37:26', '', 'test@gmail.com', 'U', '10.00'),
(314, 63, 26, 'KHOL KHOL', '16.00', '5.00', '2020-07-05 19:38:57', '2020-07-08 15:37:34', '', 'test@gmail.com', 'U', '10.00'),
(315, 45, 26, 'HEEREKAI', '26.00', '3.00', '2020-07-03 13:08:28', '2020-07-08 15:37:49', '', 'test@gmail.com', 'U', '10.00'),
(316, 64, 26, 'HAGALKAYI', '26.00', '3.00', '2020-07-05 19:39:44', '2020-07-08 15:38:18', '', 'test@gmail.com', 'U', '10.00'),
(317, 20, 26, 'GREEN CHILLIES', '35.00', '5.00', '2020-06-29 14:27:20', '2020-07-08 15:38:29', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(318, 19, 26, 'GINGER', '60.00', '6.00', '2020-06-29 14:27:04', '2020-07-08 15:38:37', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(319, 28, 26, 'CUCUMBER', '12.00', '10.00', '2020-06-29 14:29:29', '2020-07-08 15:38:44', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(320, 31, 26, 'CAULIFLOWER', '18.00', '15.00', '2020-06-29 14:30:35', '2020-07-08 15:38:51', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '70.00'),
(321, 9, 26, 'CARROT', '33.00', '10.00', '2020-06-29 14:22:41', '2020-07-08 15:38:56', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '100.00'),
(322, 10, 26, 'CAPSICUM', '60.00', '8.00', '2020-06-29 14:22:59', '2020-07-08 15:39:03', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '75.00'),
(323, 30, 26, 'CABBAGE', '12.00', '8.00', '2020-06-29 14:30:17', '2020-07-08 15:39:09', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(324, 26, 26, 'BRINJAL (Black)', '18.00', '4.00', '2020-06-29 14:29:04', '2020-07-08 15:39:23', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(325, 27, 26, 'BRINJAL(Round)', '14.00', '5.00', '2020-06-29 14:29:17', '2020-07-08 15:39:31', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(326, 25, 26, 'BRINJAL (White)', '16.00', '8.00', '2020-06-29 14:28:47', '2020-07-08 15:39:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(327, 25, 26, 'BRINJAL (White)', '16.00', '8.00', '2020-06-29 14:28:47', '2020-07-08 15:39:56', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(328, 34, 26, 'BENDI', '14.00', '20.00', '2020-06-29 14:31:27', '2020-07-08 15:40:25', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(329, 61, 26, 'BEETROOT', '28.00', '3.00', '2020-07-05 14:55:16', '2020-07-08 15:40:55', '', 'test@gmail.com', 'U', '10.00'),
(330, 8, 26, 'Beans(OOTY)', '25.00', '3.00', '2020-06-29 14:22:19', '2020-07-08 15:41:11', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(331, 7, 26, 'Beans', '20.00', '5.00', '2020-06-29 14:21:54', '2020-07-08 15:41:36', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(332, 11, 26, 'POTATO', '14.00', '7.00', '2020-06-29 14:23:51', '2020-07-08 15:42:06', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(333, 24, 26, 'BRINJAL(Long)', '16.00', '4.00', '2020-06-29 14:28:32', '2020-07-08 15:47:18', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(334, 16, 26, 'SMALL ONION', '45.00', '25.00', '2020-06-29 14:26:10', '2020-07-08 15:50:55', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(335, 25, 26, 'BRINJAL (White)', '16.00', '8.00', '2020-06-29 14:28:47', '2020-07-08 15:52:59', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(336, 24, 26, 'BRINJAL(Long)', '16.00', '4.00', '2020-06-29 14:28:32', '2020-07-08 15:58:43', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(337, 24, 26, 'BRINJAL(Long)', '16.00', '4.00', '2020-06-29 14:28:32', '2020-07-08 15:59:35', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(338, 42, 26, 'HALSANDE', '30.00', '10.00', '2020-07-03 08:31:50', '2020-07-08 15:59:57', '', 'test@gmail.com', 'U', '10.00'),
(339, 25, 26, 'BRINJAL (White)', '16.00', '8.00', '2020-06-29 14:28:47', '2020-07-08 16:00:36', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(340, 68, 26, 'Karibevu', '2.50', '3.00', '2020-07-06 12:40:25', '2020-07-09 04:32:21', '', 'test@gmail.com', 'U', '10.00'),
(341, 67, 26, 'kothmiri', '3.00', '3.00', '2020-07-06 12:39:51', '2020-07-09 04:32:33', '', 'test@gmail.com', 'U', '10.00'),
(342, 71, 26, 'sapsige', '2.50', '3.00', '2020-07-06 12:41:52', '2020-07-09 04:32:38', '', 'test@gmail.com', 'U', '10.00'),
(343, 69, 26, 'Pudina', '3.00', '3.00', '2020-07-06 12:40:50', '2020-07-09 04:32:44', '', 'test@gmail.com', 'U', '10.00'),
(344, 70, 26, 'Palak', '2.50', '3.00', '2020-07-06 12:41:13', '2020-07-09 04:32:53', '', 'test@gmail.com', 'U', '10.00'),
(345, 36, 26, 'THONDEKAI', '15.00', '10.00', '2020-06-29 14:32:02', '2020-07-09 04:33:00', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(346, 14, 26, 'TOMATO(Jamun)', '29.00', '25.00', '2020-06-29 14:25:39', '2020-07-09 04:33:07', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(347, 13, 26, 'TOMATO(Huli)', '29.00', '100.00', '2020-06-29 14:25:12', '2020-07-09 04:33:17', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(348, 47, 26, 'SOREKAI', '14.00', '3.00', '2020-07-03 13:09:17', '2020-07-09 04:33:25', '', 'test@gmail.com', 'U', '10.00'),
(349, 16, 26, 'SMALL ONION', '45.00', '25.00', '2020-06-29 14:26:10', '2020-07-09 04:33:31', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(350, 62, 26, 'SEEMEBADANE', '22.00', '10.00', '2020-07-05 15:30:20', '2020-07-09 04:33:38', '', 'test@gmail.com', 'U', '10.00'),
(351, 46, 26, 'PADUVALKAYI', '13.00', '3.00', '2020-07-03 13:08:54', '2020-07-09 04:33:47', '', 'test@gmail.com', 'U', '10.00'),
(352, 15, 26, 'ONION', '13.00', '20.00', '2020-06-29 14:25:53', '2020-07-09 04:33:53', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(353, 44, 26, 'DRUMSTICK', '43.00', '3.00', '2020-07-03 13:08:04', '2020-07-09 04:33:59', '', 'test@gmail.com', 'U', '10.00'),
(354, 29, 26, 'MC', '8.00', '15.00', '2020-06-29 14:30:03', '2020-07-09 04:34:05', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(355, 21, 26, 'LEMON', '49.00', '10.00', '2020-06-29 14:27:39', '2020-07-09 04:34:14', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(356, 65, 26, 'PUMPKIN', '11.00', '3.00', '2020-07-05 19:44:05', '2020-07-09 04:34:22', '', 'test@gmail.com', 'U', '10.00'),
(357, 63, 26, 'KHOL KHOL', '16.00', '5.00', '2020-07-05 19:38:57', '2020-07-09 04:34:28', '', 'test@gmail.com', 'U', '10.00'),
(358, 45, 26, 'HEEREKAI', '26.00', '3.00', '2020-07-03 13:08:28', '2020-07-09 04:34:35', '', 'test@gmail.com', 'U', '10.00'),
(359, 64, 26, 'HAGALKAYI', '36.00', '3.00', '2020-07-05 19:39:44', '2020-07-09 04:34:54', '', 'test@gmail.com', 'U', '10.00'),
(360, 20, 26, 'GREEN CHILLIES', '35.00', '5.00', '2020-06-29 14:27:20', '2020-07-09 04:34:59', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(361, 19, 26, 'GINGER', '60.00', '6.00', '2020-06-29 14:27:04', '2020-07-09 04:35:08', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(362, 18, 26, 'GARLIC', '80.00', '5.00', '2020-06-29 14:26:45', '2020-07-09 04:35:15', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(363, 28, 26, 'CUCUMBER', '12.00', '10.00', '2020-06-29 14:29:29', '2020-07-09 04:35:22', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(364, 31, 26, 'CAULIFLOWER', '18.00', '15.00', '2020-06-29 14:30:35', '2020-07-09 04:35:29', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '70.00'),
(365, 9, 26, 'CARROT', '33.00', '10.00', '2020-06-29 14:22:41', '2020-07-09 04:35:35', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '100.00'),
(366, 10, 26, 'CAPSICUM', '60.00', '8.00', '2020-06-29 14:22:59', '2020-07-09 04:35:43', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '75.00'),
(367, 30, 26, 'CABBAGE', '12.00', '8.00', '2020-06-29 14:30:17', '2020-07-09 04:35:50', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(368, 26, 26, 'BRINJAL (Black)', '18.00', '4.00', '2020-06-29 14:29:04', '2020-07-09 04:36:03', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(369, 27, 26, 'BRINJAL(Round)', '14.00', '5.00', '2020-06-29 14:29:17', '2020-07-09 04:36:12', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(370, 25, 26, 'BRINJAL (White)', '16.00', '8.00', '2020-06-29 14:28:47', '2020-07-09 04:36:19', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(371, 34, 26, 'BENDI', '14.00', '20.00', '2020-06-29 14:31:27', '2020-07-09 04:36:25', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(372, 61, 26, 'BEETROOT', '28.00', '3.00', '2020-07-05 14:55:16', '2020-07-09 04:36:33', '', 'test@gmail.com', 'U', '10.00'),
(373, 8, 26, 'Beans(OOTY)', '25.00', '3.00', '2020-06-29 14:22:19', '2020-07-09 04:36:40', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(374, 7, 26, 'Beans', '20.00', '5.00', '2020-06-29 14:21:54', '2020-07-09 04:36:48', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(375, 11, 26, 'POTATO', '29.00', '7.00', '2020-06-29 14:23:51', '2020-07-09 04:36:56', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(376, 11, 26, 'POTATO', '29.00', '7.00', '2020-06-29 14:23:51', '2020-07-09 14:11:02', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(377, 7, 26, 'Beans', '20.00', '5.00', '2020-06-29 14:21:54', '2020-07-09 14:11:07', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(378, 8, 26, 'Beans(OOTY)', '25.00', '3.00', '2020-06-29 14:22:19', '2020-07-09 14:11:18', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(379, 61, 26, 'BEETROOT', '28.00', '3.00', '2020-07-05 14:55:16', '2020-07-09 14:11:25', '', 'test@gmail.com', 'U', '10.00'),
(380, 72, 26, 'Balekayi', '10.00', '1.00', '2020-07-09 14:18:36', '2020-07-09 14:19:33', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(381, 42, 26, 'HALSANDE', '30.00', '10.00', '2020-07-03 08:31:50', '2020-07-09 14:24:54', '', 'test@gmail.com', 'U', '10.00'),
(382, 73, 26, 'Methya Soppu', '3.00', '1.00', '2020-07-09 14:25:43', '2020-07-09 14:26:21', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(383, 24, 26, 'BRINJAL(Long)', '16.00', '4.00', '2020-06-29 14:28:32', '2020-07-09 14:33:50', 'abhijitjd003@gmail.com', 'test@gmail.com', 'D', '25.00'),
(384, 72, 26, 'Balekayi', '10.00', '1.00', '2020-07-09 14:18:36', '2020-07-09 14:34:00', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(385, 73, 26, 'Methya Soppu', '3.00', '1.00', '2020-07-09 14:25:43', '2020-07-09 14:34:08', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(386, 71, 26, 'sapsige', '2.50', '3.00', '2020-07-06 12:41:52', '2020-07-09 14:34:31', '', 'test@gmail.com', 'U', '10.00'),
(387, 70, 26, 'Palak', '2.50', '3.00', '2020-07-06 12:41:13', '2020-07-09 14:35:09', '', 'test@gmail.com', 'U', '10.00'),
(388, 67, 26, 'kothmiri', '3.00', '3.00', '2020-07-06 12:39:51', '2020-07-09 14:35:30', '', 'test@gmail.com', 'U', '10.00'),
(389, 69, 26, 'Pudina', '3.00', '3.00', '2020-07-06 12:40:50', '2020-07-09 14:35:40', '', 'test@gmail.com', 'U', '10.00'),
(390, 68, 26, 'Karibevu', '2.50', '3.00', '2020-07-06 12:40:25', '2020-07-09 14:35:53', '', 'test@gmail.com', 'U', '10.00'),
(391, 42, 26, 'HALSANDE', '30.00', '10.00', '2020-07-03 08:31:50', '2020-07-09 14:36:22', '', 'test@gmail.com', 'U', '10.00'),
(392, 36, 26, 'THONDEKAI', '15.00', '10.00', '2020-06-29 14:32:02', '2020-07-09 14:37:04', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(393, 14, 26, 'TOMATO(Jamun)', '32.00', '25.00', '2020-06-29 14:25:39', '2020-07-09 14:37:16', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(394, 13, 26, 'TOMATO(Huli)', '32.00', '100.00', '2020-06-29 14:25:12', '2020-07-09 14:37:35', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(395, 47, 26, 'SOREKAI', '14.00', '3.00', '2020-07-03 13:09:17', '2020-07-09 14:37:57', '', 'test@gmail.com', 'U', '10.00'),
(396, 16, 26, 'SMALL ONION', '45.00', '25.00', '2020-06-29 14:26:10', '2020-07-09 14:38:09', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(397, 62, 26, 'SEEMEBADANE', '22.00', '10.00', '2020-07-05 15:30:20', '2020-07-09 14:38:18', '', 'test@gmail.com', 'U', '10.00'),
(398, 46, 26, 'PADUVALKAYI', '13.00', '3.00', '2020-07-03 13:08:54', '2020-07-09 14:38:26', '', 'test@gmail.com', 'U', '10.00');
INSERT INTO `ProductHistory` (`ProductHistId`, `ProductId`, `CategoryId`, `Name`, `RatePerKG`, `MinPurchaseQuantity`, `CreatedDateTime`, `UpdatedDateTime`, `CreatedUserId`, `UpdatedUserId`, `StatusCode`, `TotalStock`) VALUES
(399, 15, 26, 'ONION', '13.00', '20.00', '2020-06-29 14:25:53', '2020-07-09 14:38:32', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(400, 44, 26, 'DRUMSTICK', '43.00', '3.00', '2020-07-03 13:08:04', '2020-07-09 14:38:43', '', 'test@gmail.com', 'U', '10.00'),
(401, 35, 26, 'MULANGI', '14.00', '20.00', '2020-06-29 14:31:43', '2020-07-09 14:38:56', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(402, 29, 26, 'MC', '9.00', '15.00', '2020-06-29 14:30:03', '2020-07-09 14:39:11', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(403, 21, 26, 'LEMON', '49.00', '10.00', '2020-06-29 14:27:39', '2020-07-09 14:39:19', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(404, 65, 26, 'PUMPKIN', '11.00', '3.00', '2020-07-05 19:44:05', '2020-07-09 14:39:33', '', 'test@gmail.com', 'U', '10.00'),
(405, 63, 26, 'KHOL KHOL', '16.00', '5.00', '2020-07-05 19:38:57', '2020-07-09 14:39:47', '', 'test@gmail.com', 'U', '10.00'),
(406, 45, 26, 'HEEREKAI', '26.00', '3.00', '2020-07-03 13:08:28', '2020-07-09 14:39:53', '', 'test@gmail.com', 'U', '10.00'),
(407, 64, 26, 'HAGALKAYI', '36.00', '3.00', '2020-07-05 19:39:44', '2020-07-09 14:39:59', '', 'test@gmail.com', 'U', '10.00'),
(408, 20, 26, 'GREEN CHILLIES', '35.00', '5.00', '2020-06-29 14:27:20', '2020-07-09 14:40:04', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(409, 19, 26, 'GINGER', '60.00', '6.00', '2020-06-29 14:27:04', '2020-07-09 14:40:10', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(410, 18, 26, 'GARLIC', '80.00', '5.00', '2020-06-29 14:26:45', '2020-07-09 14:40:21', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(411, 28, 26, 'CUCUMBER', '12.00', '10.00', '2020-06-29 14:29:29', '2020-07-09 14:40:30', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(412, 31, 26, 'CAULIFLOWER', '18.00', '15.00', '2020-06-29 14:30:35', '2020-07-09 14:40:36', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '70.00'),
(413, 9, 26, 'CARROT', '33.00', '10.00', '2020-06-29 14:22:41', '2020-07-09 14:40:49', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '100.00'),
(414, 10, 26, 'CAPSICUM', '62.00', '8.00', '2020-06-29 14:22:59', '2020-07-09 14:41:00', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '75.00'),
(415, 30, 26, 'CABBAGE', '12.00', '8.00', '2020-06-29 14:30:17', '2020-07-09 14:41:07', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(416, 26, 26, 'BRINJAL (Black)', '18.00', '4.00', '2020-06-29 14:29:04', '2020-07-09 14:41:20', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(417, 27, 26, 'BRINJAL(Round)', '14.00', '5.00', '2020-06-29 14:29:17', '2020-07-09 14:41:27', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(418, 25, 26, 'BRINJAL (White)', '16.00', '8.00', '2020-06-29 14:28:47', '2020-07-09 14:41:39', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(419, 34, 26, 'BENDI', '14.00', '20.00', '2020-06-29 14:31:27', '2020-07-09 14:41:54', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(420, 61, 26, 'BEETROOT', '28.00', '3.00', '2020-07-05 14:55:16', '2020-07-09 14:42:04', '', 'test@gmail.com', 'U', '10.00'),
(421, 8, 26, 'Beans(OOTY)', '25.00', '3.00', '2020-06-29 14:22:19', '2020-07-09 14:42:11', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(422, 7, 26, 'Beans', '20.00', '5.00', '2020-06-29 14:21:54', '2020-07-09 14:42:16', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(423, 11, 26, 'POTATO', '29.00', '7.00', '2020-06-29 14:23:51', '2020-07-09 14:42:22', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(424, 72, 26, 'Balekayi', '10.00', '1.00', '2020-07-09 14:18:36', '2020-07-10 15:00:27', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(425, 73, 26, 'Methya Soppu', '3.00', '1.00', '2020-07-09 14:25:43', '2020-07-10 15:01:09', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(426, 71, 26, 'Sabsige', '2.50', '3.00', '2020-07-06 12:41:52', '2020-07-10 15:01:33', '', 'test@gmail.com', 'U', '10.00'),
(427, 70, 26, 'Palak', '3.00', '3.00', '2020-07-06 12:41:13', '2020-07-10 15:01:53', '', 'test@gmail.com', 'U', '10.00'),
(428, 67, 26, 'Kothmiri', '3.00', '3.00', '2020-07-06 12:39:51', '2020-07-10 15:02:17', '', 'test@gmail.com', 'U', '10.00'),
(429, 69, 26, 'Pudina / Mint Leaves', '3.00', '3.00', '2020-07-06 12:40:50', '2020-07-10 15:02:31', '', 'test@gmail.com', 'U', '10.00'),
(430, 68, 26, 'Karibevu / Curry Leaves', '4.00', '3.00', '2020-07-06 12:40:25', '2020-07-10 15:02:57', '', 'test@gmail.com', 'U', '10.00'),
(431, 42, 26, 'HALSANDE', '30.00', '10.00', '2020-07-03 08:31:50', '2020-07-10 15:03:15', '', 'test@gmail.com', 'U', '10.00'),
(432, 36, 26, 'THONDEKAI / IVY GOURD', '15.00', '10.00', '2020-06-29 14:32:02', '2020-07-10 15:03:32', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(433, 14, 26, 'TOMATO(Jamun)', '33.00', '25.00', '2020-06-29 14:25:39', '2020-07-10 15:03:53', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(434, 13, 26, 'TOMATO(Huli)', '32.00', '100.00', '2020-06-29 14:25:12', '2020-07-10 15:04:16', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(435, 47, 26, 'SOREKAI / BOTTLE GOURD', '15.00', '3.00', '2020-07-03 13:09:17', '2020-07-10 15:04:35', '', 'test@gmail.com', 'U', '10.00'),
(436, 16, 26, 'SMALL ONION', '45.00', '25.00', '2020-06-29 14:26:10', '2020-07-10 15:04:59', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(437, 62, 26, 'SEEMEBADANE', '18.00', '10.00', '2020-07-05 15:30:20', '2020-07-10 15:05:18', '', 'test@gmail.com', 'U', '10.00'),
(438, 46, 26, 'PADUVALKAYI', '18.00', '3.00', '2020-07-03 13:08:54', '2020-07-10 15:05:39', '', 'test@gmail.com', 'U', '10.00'),
(439, 15, 26, 'ONION', '13.00', '20.00', '2020-06-29 14:25:53', '2020-07-10 15:05:51', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(440, 44, 26, 'DRUMSTICK', '45.00', '3.00', '2020-07-03 13:08:04', '2020-07-10 15:06:09', '', 'test@gmail.com', 'U', '10.00'),
(441, 35, 26, 'MULANGI / Raddish', '16.00', '20.00', '2020-06-29 14:31:43', '2020-07-10 15:06:25', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(442, 29, 26, 'Mangalore CUCUMBER', '9.00', '15.00', '2020-06-29 14:30:03', '2020-07-10 15:06:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(443, 21, 26, 'LEMON', '49.00', '10.00', '2020-06-29 14:27:39', '2020-07-10 15:06:56', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(444, 65, 26, 'PUMPKIN', '11.00', '3.00', '2020-07-05 19:44:05', '2020-07-10 15:07:17', '', 'test@gmail.com', 'U', '10.00'),
(445, 63, 26, 'KHOL KHOL', '18.00', '5.00', '2020-07-05 19:38:57', '2020-07-10 15:07:39', '', 'test@gmail.com', 'U', '10.00'),
(446, 45, 26, 'HEEREKAI', '26.00', '3.00', '2020-07-03 13:08:28', '2020-07-10 15:07:56', '', 'test@gmail.com', 'U', '10.00'),
(447, 64, 26, 'HAGALKAYI', '36.00', '3.00', '2020-07-05 19:39:44', '2020-07-10 15:08:16', '', 'test@gmail.com', 'U', '10.00'),
(448, 20, 26, 'GREEN CHILLIES', '35.00', '5.00', '2020-06-29 14:27:20', '2020-07-10 15:08:35', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(449, 19, 26, 'GINGER', '60.00', '6.00', '2020-06-29 14:27:04', '2020-07-10 15:08:58', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(450, 18, 26, 'GARLIC', '75.00', '5.00', '2020-06-29 14:26:45', '2020-07-10 15:09:08', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(451, 28, 26, 'CUCUMBER', '15.00', '10.00', '2020-06-29 14:29:29', '2020-07-10 15:09:24', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(452, 31, 26, 'CAULIFLOWER', '18.00', '15.00', '2020-06-29 14:30:35', '2020-07-10 15:09:47', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '70.00'),
(453, 9, 26, 'CARROT', '33.00', '10.00', '2020-06-29 14:22:41', '2020-07-10 15:09:59', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '100.00'),
(454, 10, 26, 'CAPSICUM', '65.00', '8.00', '2020-06-29 14:22:59', '2020-07-10 15:10:15', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '75.00'),
(455, 30, 26, 'CABBAGE', '12.00', '8.00', '2020-06-29 14:30:17', '2020-07-10 15:10:28', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(456, 26, 26, 'BRINJAL (Black)', '16.00', '4.00', '2020-06-29 14:29:04', '2020-07-10 15:11:58', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(457, 27, 26, 'BRINJAL(Round)', '16.00', '5.00', '2020-06-29 14:29:17', '2020-07-10 15:12:19', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(458, 25, 26, 'BRINJAL (Long)', '16.00', '8.00', '2020-06-29 14:28:47', '2020-07-10 15:12:38', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(459, 34, 26, 'BENDI / Ladies FINGER', '15.00', '20.00', '2020-06-29 14:31:27', '2020-07-10 15:13:04', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(460, 61, 26, 'BEETROOT', '28.00', '3.00', '2020-07-05 14:55:16', '2020-07-10 15:13:15', '', 'test@gmail.com', 'U', '10.00'),
(461, 8, 26, 'Beans(OOTY)', '25.00', '3.00', '2020-06-29 14:22:19', '2020-07-10 15:13:31', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(462, 7, 26, 'Beans', '20.00', '5.00', '2020-06-29 14:21:54', '2020-07-10 15:13:54', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(463, 11, 26, 'POTATO', '29.00', '7.00', '2020-06-29 14:23:51', '2020-07-10 15:14:12', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(464, 26, 26, 'BRINJAL (Black)', '16.00', '4.00', '2020-06-29 14:29:04', '2020-07-10 15:26:15', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(465, 27, 26, 'BRINJAL(Round)', '14.00', '5.00', '2020-06-29 14:29:17', '2020-07-10 15:26:51', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(466, 25, 26, 'BRINJAL (Long)', '16.00', '8.00', '2020-06-29 14:28:47', '2020-07-10 15:27:29', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(467, 34, 26, 'BENDI / Ladies FINGER', '13.00', '20.00', '2020-06-29 14:31:27', '2020-07-10 15:27:53', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(468, 61, 26, 'BEETROOT', '28.00', '3.00', '2020-07-05 14:55:16', '2020-07-10 15:28:04', '', 'test@gmail.com', 'U', '10.00'),
(469, 8, 26, 'Beans(OOTY)', '25.00', '3.00', '2020-06-29 14:22:19', '2020-07-10 15:28:12', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(470, 7, 26, 'Beans', '20.00', '5.00', '2020-06-29 14:21:54', '2020-07-10 15:28:23', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(471, 11, 26, 'POTATO', '39.00', '7.00', '2020-06-29 14:23:51', '2020-07-10 15:28:31', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(472, 11, 26, 'POTATO', '39.00', '7.00', '2020-06-29 14:23:51', '2020-07-10 15:44:15', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(473, 72, 26, 'Balekayi', '8.00', '1.00', '2020-07-09 14:18:36', '2020-07-11 13:47:52', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(474, 73, 26, 'Methya Soppu', '4.50', '1.00', '2020-07-09 14:25:43', '2020-07-11 13:48:11', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(475, 71, 26, 'Sabsige', '3.00', '3.00', '2020-07-06 12:41:52', '2020-07-11 13:48:25', '', 'test@gmail.com', 'U', '10.00'),
(476, 70, 26, 'Palak', '3.00', '3.00', '2020-07-06 12:41:13', '2020-07-11 13:48:35', '', 'test@gmail.com', 'U', '10.00'),
(477, 67, 26, 'Kothmiri', '4.00', '3.00', '2020-07-06 12:39:51', '2020-07-11 13:48:50', '', 'test@gmail.com', 'U', '10.00'),
(478, 69, 26, 'Pudina / Mint Leaves', '3.00', '3.00', '2020-07-06 12:40:50', '2020-07-11 13:49:22', '', 'test@gmail.com', 'U', '10.00'),
(479, 68, 26, 'Karibevu / Curry Leaves', '2.50', '3.00', '2020-07-06 12:40:25', '2020-07-11 13:49:39', '', 'test@gmail.com', 'U', '10.00'),
(480, 42, 26, 'HALSANDE', '30.00', '10.00', '2020-07-03 08:31:50', '2020-07-11 13:49:57', '', 'test@gmail.com', 'U', '10.00'),
(481, 36, 26, 'THONDEKAI / IVY GOURD', '15.00', '10.00', '2020-06-29 14:32:02', '2020-07-11 13:50:11', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(482, 14, 26, 'TOMATO(Jamun)', '33.00', '25.00', '2020-06-29 14:25:39', '2020-07-11 13:50:31', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(483, 13, 26, 'TOMATO(Huli)', '30.00', '100.00', '2020-06-29 14:25:12', '2020-07-11 13:50:48', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(484, 47, 26, 'SOREKAI / BOTTLE GOURD', '15.00', '3.00', '2020-07-03 13:09:17', '2020-07-11 13:51:09', '', 'test@gmail.com', 'U', '10.00'),
(485, 16, 26, 'SMALL ONION', '40.00', '25.00', '2020-06-29 14:26:10', '2020-07-11 13:51:30', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(486, 62, 26, 'SEEMEBADANE', '22.00', '10.00', '2020-07-05 15:30:20', '2020-07-11 13:51:46', '', 'test@gmail.com', 'U', '10.00'),
(487, 46, 26, 'PADUVALKAYI', '14.00', '3.00', '2020-07-03 13:08:54', '2020-07-11 13:52:00', '', 'test@gmail.com', 'U', '10.00'),
(488, 15, 26, 'ONION', '13.00', '20.00', '2020-06-29 14:25:53', '2020-07-11 13:52:16', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(489, 44, 26, 'DRUMSTICK', '45.00', '3.00', '2020-07-03 13:08:04', '2020-07-11 13:52:46', '', 'test@gmail.com', 'U', '10.00'),
(490, 35, 26, 'MULANGI / Raddish', '16.00', '20.00', '2020-06-29 14:31:43', '2020-07-11 13:53:09', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(491, 29, 26, 'Mangalore CUCUMBER', '9.00', '15.00', '2020-06-29 14:30:03', '2020-07-11 13:53:22', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(492, 21, 26, 'LEMON', '49.00', '10.00', '2020-06-29 14:27:39', '2020-07-11 13:53:40', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(493, 65, 26, 'PUMPKIN', '11.00', '3.00', '2020-07-05 19:44:05', '2020-07-11 13:54:00', '', 'test@gmail.com', 'U', '10.00'),
(494, 63, 26, 'KHOL KHOL', '28.00', '5.00', '2020-07-05 19:38:57', '2020-07-11 13:54:23', '', 'test@gmail.com', 'U', '10.00'),
(495, 45, 26, 'HEEREKAI', '26.00', '3.00', '2020-07-03 13:08:28', '2020-07-11 13:54:51', '', 'test@gmail.com', 'U', '10.00'),
(496, 64, 26, 'HAGALKAYI', '29.00', '3.00', '2020-07-05 19:39:44', '2020-07-11 13:55:09', '', 'test@gmail.com', 'U', '10.00'),
(497, 20, 26, 'GREEN CHILLIES', '30.00', '5.00', '2020-06-29 14:27:20', '2020-07-11 13:55:27', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(498, 19, 26, 'GINGER', '60.00', '6.00', '2020-06-29 14:27:04', '2020-07-11 13:55:39', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(499, 18, 26, 'GARLIC', '75.00', '5.00', '2020-06-29 14:26:45', '2020-07-11 13:55:53', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(500, 28, 26, 'CUCUMBER', '15.00', '10.00', '2020-06-29 14:29:29', '2020-07-11 13:56:04', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(501, 31, 26, 'CAULIFLOWER', '18.00', '15.00', '2020-06-29 14:30:35', '2020-07-11 13:56:23', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '70.00'),
(502, 9, 26, 'CARROT', '33.00', '10.00', '2020-06-29 14:22:41', '2020-07-11 13:56:35', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '100.00'),
(503, 10, 26, 'CAPSICUM', '68.00', '8.00', '2020-06-29 14:22:59', '2020-07-11 13:56:49', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '75.00'),
(504, 30, 26, 'CABBAGE', '12.00', '8.00', '2020-06-29 14:30:17', '2020-07-11 13:57:06', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(505, 26, 26, 'BRINJAL (Black)', '16.00', '4.00', '2020-06-29 14:29:04', '2020-07-11 13:57:32', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(506, 27, 26, 'BRINJAL(Round)', '14.00', '5.00', '2020-06-29 14:29:17', '2020-07-11 13:57:46', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(507, 25, 26, 'BRINJAL (Long)', '16.00', '8.00', '2020-06-29 14:28:47', '2020-07-11 13:58:06', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(508, 34, 26, 'BENDI / Ladies FINGER', '13.00', '20.00', '2020-06-29 14:31:27', '2020-07-11 13:58:24', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(509, 61, 26, 'BEETROOT', '28.00', '3.00', '2020-07-05 14:55:16', '2020-07-11 13:58:37', '', 'test@gmail.com', 'U', '10.00'),
(510, 8, 26, 'Beans(OOTY)', '25.00', '3.00', '2020-06-29 14:22:19', '2020-07-11 13:58:49', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(511, 7, 26, 'Beans', '20.00', '5.00', '2020-06-29 14:21:54', '2020-07-11 13:58:58', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(512, 11, 26, 'POTATO', '29.00', '7.00', '2020-06-29 14:23:51', '2020-07-11 13:59:10', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(513, 30, 26, 'CABBAGE', '12.00', '8.00', '2020-06-29 14:30:17', '2020-07-11 14:12:16', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(514, 26, 26, 'BRINJAL (Black)', '26.00', '4.00', '2020-06-29 14:29:04', '2020-07-11 14:13:02', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(515, 27, 26, 'BRINJAL(Round)', '14.00', '5.00', '2020-06-29 14:29:17', '2020-07-11 14:13:10', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(516, 26, 26, 'BRINJAL (Black)', '16.00', '4.00', '2020-06-29 14:29:04', '2020-07-11 14:13:33', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(517, 25, 26, 'BRINJAL (Long)', '14.00', '8.00', '2020-06-29 14:28:47', '2020-07-11 14:13:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(518, 34, 26, 'BENDI / Ladies FINGER', '16.00', '20.00', '2020-06-29 14:31:27', '2020-07-11 14:14:02', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(519, 61, 26, 'BEETROOT', '28.00', '3.00', '2020-07-05 14:55:16', '2020-07-11 14:14:17', '', 'test@gmail.com', 'U', '10.00'),
(520, 8, 26, 'Beans(OOTY)', '25.00', '3.00', '2020-06-29 14:22:19', '2020-07-11 14:14:29', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(521, 7, 26, 'Beans', '20.00', '5.00', '2020-06-29 14:21:54', '2020-07-11 14:14:53', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(522, 11, 26, 'POTATO', '29.00', '7.00', '2020-06-29 14:23:51', '2020-07-11 14:15:02', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(523, 15, 26, 'ONION', '13.00', '20.00', '2020-06-29 14:25:53', '2020-07-11 14:23:56', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(524, 44, 26, 'DRUMSTICK', '45.00', '3.00', '2020-07-03 13:08:04', '2020-07-11 14:24:12', '', 'test@gmail.com', 'U', '10.00'),
(525, 35, 26, 'MULANGI / Raddish', '16.00', '20.00', '2020-06-29 14:31:43', '2020-07-11 14:24:30', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(526, 29, 26, 'Mangalore CUCUMBER', '9.00', '15.00', '2020-06-29 14:30:03', '2020-07-11 14:24:56', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(527, 21, 26, 'LEMON', '49.00', '10.00', '2020-06-29 14:27:39', '2020-07-11 14:25:22', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(528, 65, 26, 'PUMPKIN', '11.00', '3.00', '2020-07-05 19:44:05', '2020-07-11 14:25:34', '', 'test@gmail.com', 'U', '10.00'),
(529, 63, 26, 'KHOL KHOL', '22.00', '5.00', '2020-07-05 19:38:57', '2020-07-11 14:26:34', '', 'test@gmail.com', 'U', '10.00'),
(530, 45, 26, 'HEEREKAI', '26.00', '3.00', '2020-07-03 13:08:28', '2020-07-11 14:27:08', '', 'test@gmail.com', 'U', '10.00'),
(531, 64, 26, 'HAGALKAYI', '30.00', '3.00', '2020-07-05 19:39:44', '2020-07-11 14:27:41', '', 'test@gmail.com', 'U', '10.00'),
(532, 20, 26, 'GREEN CHILLIES', '30.00', '5.00', '2020-06-29 14:27:20', '2020-07-11 14:28:32', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(533, 19, 26, 'GINGER', '60.00', '6.00', '2020-06-29 14:27:04', '2020-07-11 14:28:38', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(534, 18, 26, 'GARLIC', '75.00', '5.00', '2020-06-29 14:26:45', '2020-07-11 14:28:45', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(535, 28, 26, 'CUCUMBER', '15.00', '10.00', '2020-06-29 14:29:29', '2020-07-11 14:29:27', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(536, 31, 26, 'CAULIFLOWER', '16.00', '15.00', '2020-06-29 14:30:35', '2020-07-11 14:29:34', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '70.00'),
(537, 9, 26, 'CARROT', '33.00', '10.00', '2020-06-29 14:22:41', '2020-07-11 14:29:50', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '100.00'),
(538, 10, 26, 'CAPSICUM', '68.00', '8.00', '2020-06-29 14:22:59', '2020-07-11 14:30:01', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '75.00'),
(539, 30, 26, 'CABBAGE', '13.00', '8.00', '2020-06-29 14:30:17', '2020-07-11 14:30:59', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(540, 26, 26, 'BRINJAL (Black)', '16.00', '4.00', '2020-06-29 14:29:04', '2020-07-11 14:31:25', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(541, 27, 26, 'BRINJAL(Round)', '14.00', '5.00', '2020-06-29 14:29:17', '2020-07-11 14:31:35', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(542, 25, 26, 'BRINJAL (Long)', '14.00', '8.00', '2020-06-29 14:28:47', '2020-07-11 14:31:43', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(543, 34, 26, 'BENDI / Ladies FINGER', '16.00', '20.00', '2020-06-29 14:31:27', '2020-07-11 14:32:05', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(544, 61, 26, 'BEETROOT', '28.00', '3.00', '2020-07-05 14:55:16', '2020-07-11 14:32:12', '', 'test@gmail.com', 'U', '10.00'),
(545, 8, 26, 'Beans(OOTY)', '25.00', '3.00', '2020-06-29 14:22:19', '2020-07-11 14:32:42', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(546, 7, 26, 'Beans', '20.00', '5.00', '2020-06-29 14:21:54', '2020-07-11 14:32:50', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(547, 11, 26, 'POTATO', '29.00', '7.00', '2020-06-29 14:23:51', '2020-07-11 14:33:00', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(548, 74, 27, 'Apple', '200.00', '10.00', '2020-07-12 07:07:28', '2020-07-12 07:07:44', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'U', '50.00'),
(549, 74, 27, 'Apple', '200.00', '10.00', '2020-07-12 07:07:28', '2020-07-12 08:34:53', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'D', '50.00'),
(550, 72, 26, 'Balekayi', '8.00', '1.00', '2020-07-09 14:18:36', '2020-07-12 15:04:04', 'test@gmail.com', 'abhijitjd003@gmail.com', 'U', '10.00'),
(551, 72, 26, 'Balekayi', '8.00', '1.00', '2020-07-09 14:18:36', '2020-07-12 15:04:15', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(552, 72, 26, 'Balekayi', '8.00', '1.00', '2020-07-09 14:18:36', '2020-07-12 15:06:07', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(553, 7, 26, 'Beans', '20.00', '5.00', '2020-06-29 14:21:54', '2020-07-12 15:06:30', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(554, 8, 26, 'Beans(OOTY)', '25.00', '3.00', '2020-06-29 14:22:19', '2020-07-12 15:06:37', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(555, 61, 26, 'BEETROOT', '28.00', '3.00', '2020-07-05 14:55:16', '2020-07-12 15:06:41', '', 'test@gmail.com', 'U', '10.00'),
(556, 34, 26, 'BENDI / Ladies FINGER', '16.00', '20.00', '2020-06-29 14:31:27', '2020-07-12 15:07:17', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(557, 64, 26, 'HAGALKAYI', '30.00', '3.00', '2020-07-05 19:39:44', '2020-07-12 15:07:40', '', 'test@gmail.com', 'U', '10.00'),
(558, 26, 26, 'BRINJAL (Black)', '16.00', '4.00', '2020-06-29 14:29:04', '2020-07-12 15:08:10', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(559, 47, 26, 'SOREKAI / BOTTLE GOURD', '15.00', '3.00', '2020-07-03 13:09:17', '2020-07-12 15:08:43', '', 'test@gmail.com', 'U', '10.00'),
(560, 25, 26, 'BRINJAL (Long)', '14.00', '8.00', '2020-06-29 14:28:47', '2020-07-12 15:08:58', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(561, 28, 26, 'CUCUMBER', '15.00', '10.00', '2020-06-29 14:29:29', '2020-07-12 15:09:31', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(562, 30, 26, 'CABBAGE', '12.00', '8.00', '2020-06-29 14:30:17', '2020-07-12 15:09:43', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(563, 10, 26, 'CAPSICUM', '68.00', '8.00', '2020-06-29 14:22:59', '2020-07-12 15:09:53', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '75.00'),
(564, 9, 26, 'CARROT', '33.00', '10.00', '2020-06-29 14:22:41', '2020-07-12 15:10:02', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '100.00'),
(565, 31, 26, 'CAULIFLOWER', '16.00', '15.00', '2020-06-29 14:30:35', '2020-07-12 15:10:13', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '70.00'),
(566, 62, 26, 'SEEMEBADANE', '22.00', '10.00', '2020-07-05 15:30:20', '2020-07-12 15:10:57', '', 'test@gmail.com', 'U', '10.00'),
(567, 67, 26, 'Kothmiri', '4.00', '3.00', '2020-07-06 12:39:51', '2020-07-12 15:11:40', '', 'test@gmail.com', 'U', '10.00'),
(568, 28, 26, 'British Cucumber/ಬ್ರಿಟಿಷ್ ಸೌತೆಕಾಯಿ', '15.00', '10.00', '2020-06-29 14:29:29', '2020-07-12 15:12:19', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(569, 68, 26, 'Karibevu / Curry Leaves', '2.50', '3.00', '2020-07-06 12:40:25', '2020-07-12 15:12:34', '', 'test@gmail.com', 'U', '10.00'),
(570, 44, 26, 'DRUMSTICK', '45.00', '3.00', '2020-07-03 13:08:04', '2020-07-12 15:13:05', '', 'test@gmail.com', 'U', '10.00'),
(571, 18, 26, 'GARLIC', '75.00', '5.00', '2020-06-29 14:26:45', '2020-07-12 15:13:15', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(572, 19, 26, 'GINGER', '60.00', '6.00', '2020-06-29 14:27:04', '2020-07-12 15:13:33', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(573, 19, 26, 'Ginger/ಶುಂಠಿ', '60.00', '6.00', '2020-06-29 14:27:04', '2020-07-12 15:13:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(574, 20, 26, 'GREEN CHILLIES', '30.00', '5.00', '2020-06-29 14:27:20', '2020-07-12 15:14:02', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(575, 42, 26, 'HALSANDE', '30.00', '10.00', '2020-07-03 08:31:50', '2020-07-12 15:14:20', '', 'test@gmail.com', 'U', '10.00'),
(576, 36, 26, 'THONDEKAI / IVY GOURD', '15.00', '10.00', '2020-06-29 14:32:02', '2020-07-12 15:14:43', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(577, 63, 26, 'KHOL KHOL', '22.00', '5.00', '2020-07-05 19:38:57', '2020-07-12 15:15:17', '', 'test@gmail.com', 'U', '10.00'),
(578, 34, 26, 'Ladies FINGER/ BENDI / ', '15.00', '20.00', '2020-06-29 14:31:27', '2020-07-12 15:15:33', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(579, 21, 26, 'LEMON', '49.00', '10.00', '2020-06-29 14:27:39', '2020-07-12 15:15:44', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(580, 29, 26, 'Mangalore CUCUMBER', '9.00', '15.00', '2020-06-29 14:30:03', '2020-07-12 15:16:00', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(581, 73, 26, 'Methya Soppu', '4.50', '1.00', '2020-07-09 14:25:43', '2020-07-12 15:16:16', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(582, 69, 26, 'Pudina / Mint Leaves', '3.00', '3.00', '2020-07-06 12:40:50', '2020-07-12 15:16:35', '', 'test@gmail.com', 'U', '10.00'),
(583, 15, 26, 'ONION', '14.00', '20.00', '2020-06-29 14:25:53', '2020-07-12 15:16:57', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(584, 8, 26, 'Beans(OOTY)', '28.00', '3.00', '2020-06-29 14:22:19', '2020-07-12 15:17:18', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(585, 70, 26, 'Palak', '3.00', '3.00', '2020-07-06 12:41:13', '2020-07-12 15:17:37', '', 'test@gmail.com', 'U', '10.00'),
(586, 11, 26, 'POTATO', '29.00', '7.00', '2020-06-29 14:23:51', '2020-07-12 15:17:54', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(587, 65, 26, 'PUMPKIN', '11.00', '3.00', '2020-07-05 19:44:05', '2020-07-12 15:18:06', '', 'test@gmail.com', 'U', '10.00'),
(588, 35, 26, 'MULANGI / Raddish', '16.00', '20.00', '2020-06-29 14:31:43', '2020-07-12 15:18:39', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(589, 45, 26, 'HEEREKAI', '26.00', '3.00', '2020-07-03 13:08:28', '2020-07-12 15:18:50', '', 'test@gmail.com', 'U', '10.00'),
(590, 27, 26, 'BRINJAL(Round)', '14.00', '5.00', '2020-06-29 14:29:17', '2020-07-12 15:19:24', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(591, 71, 26, 'Sabsige', '3.00', '3.00', '2020-07-06 12:41:52', '2020-07-12 15:19:41', '', 'test@gmail.com', 'U', '10.00'),
(592, 16, 26, 'SMALL ONION', '40.00', '25.00', '2020-06-29 14:26:10', '2020-07-12 15:19:57', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(593, 46, 26, 'PADUVALKAYI', '14.00', '3.00', '2020-07-03 13:08:54', '2020-07-12 15:20:10', '', 'test@gmail.com', 'U', '10.00'),
(594, 14, 26, 'TOMATO(Jamun)', '34.00', '25.00', '2020-06-29 14:25:39', '2020-07-12 15:20:23', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(595, 13, 26, 'TOMATO(Huli)', '33.00', '100.00', '2020-06-29 14:25:12', '2020-07-12 15:20:34', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(596, 26, 26, 'Black Brinjal/ಬದನೇಕಾಯಿ', '16.00', '4.00', '2020-06-29 14:29:04', '2020-07-12 15:21:52', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(597, 61, 26, 'BEETROOT', '28.00', '3.00', '2020-07-05 14:55:16', '2020-07-12 15:22:22', '', 'test@gmail.com', 'U', '10.00'),
(598, 7, 26, 'Beans', '23.00', '5.00', '2020-06-29 14:21:54', '2020-07-12 15:22:39', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(599, 72, 26, 'Balekayi', '8.00', '1.00', '2020-07-09 14:18:36', '2020-07-12 15:22:55', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(600, 75, 26, 'Avarekai ', '25.00', '5.00', '2020-07-12 15:04:39', '2020-07-12 15:23:07', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(601, 76, 26, 'White Bitter Gourd / ಹಾಗಲಕಾಯಿ  ', '30.00', '3.00', '2020-07-12 15:27:22', '2020-07-12 15:27:40', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(602, 75, 26, 'Avare Kai/ಅವರೆ ಕೈ', '25.00', '5.00', '2020-07-12 15:04:39', '2020-07-12 15:32:40', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(603, 62, 26, 'Chayote gourd/ಸೇಮೆ ಬದನೆ', '22.00', '10.00', '2020-07-05 15:30:20', '2020-07-12 15:33:23', '', 'test@gmail.com', 'U', '10.00'),
(604, 73, 26, 'Menthya soppu/ಮೆಂಥ್ಯಾ ಸೋಪ್ಪು', '3.00', '1.00', '2020-07-09 14:25:43', '2020-07-12 15:34:25', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(605, 71, 26, 'Sabsige Soppu/ ಸಬ್ಸಿಜ್ ಸೊಪ್ಪ', '3.00', '3.00', '2020-07-06 12:41:52', '2020-07-12 15:35:02', '', 'test@gmail.com', 'U', '10.00'),
(606, 76, 26, 'Bitter Gourd- White  / ಹಾಗಲಕಾಯಿ  ', '30.00', '3.00', '2020-07-12 15:27:22', '2020-07-12 15:35:38', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(607, 19, 26, 'Ginger/ಶುಂಠಿ', '65.00', '6.00', '2020-06-29 14:27:04', '2020-07-12 15:36:44', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(608, 71, 26, 'ಸಬ್ಸಿಗೆ ಸೊಪ್ಪು ', '3.00', '3.00', '2020-07-06 12:41:52', '2020-07-12 15:38:59', '', 'test@gmail.com', 'U', '10.00'),
(609, 77, 26, 'Beans Cluster / ಗೋರಿಕಾಯಿ ', '18.00', '5.00', '2020-07-12 15:42:27', '2020-07-12 15:43:17', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(610, 75, 26, 'Avare Kai/ಅವರೆಕಾಯಿ', '25.00', '5.00', '2020-07-12 15:04:39', '2020-07-13 15:19:03', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(611, 11, 26, 'Potato/ಆಲೂ ಗೆಡ್ಡೆ ', '29.00', '7.00', '2020-06-29 14:23:51', '2020-07-13 15:21:28', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(612, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '23.00', '5.00', '2020-06-29 14:21:54', '2020-07-13 15:21:43', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(613, 34, 26, 'Lady\'s finger / Okra/ಬೆಂಡೇಕಾಯಿ  ', '15.00', '20.00', '2020-06-29 14:31:27', '2020-07-13 15:22:42', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(614, 30, 26, 'Cabbage/ಎಲೆ ಕೋಸು', '11.00', '8.00', '2020-06-29 14:30:17', '2020-07-13 15:23:14', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(615, 77, 26, 'Cluster Beans / ಗೋರಿಕಾಯಿ ', '18.00', '5.00', '2020-07-12 15:42:27', '2020-07-13 15:23:51', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(616, 20, 26, 'Green chilli/ಹಸಿರು ಮೆಣಸಿನಕಾಯಿ ', '32.00', '5.00', '2020-06-29 14:27:20', '2020-07-13 15:24:12', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(617, 62, 26, 'Chayote Gourd/ಸೀಮೆ ಬದನೆ ', '22.00', '10.00', '2020-07-05 15:30:20', '2020-07-13 15:24:30', '', 'test@gmail.com', 'U', '10.00'),
(618, 68, 26, 'Curry leaves/ಕರಿಬೇವು   ', '2.00', '3.00', '2020-07-06 12:40:25', '2020-07-13 15:24:52', '', 'test@gmail.com', 'U', '10.00'),
(619, 69, 26, 'Mint leaves/ಪುದಿನ ಸೊಪ್ಪು ', '2.00', '3.00', '2020-07-06 12:40:50', '2020-07-13 15:25:24', '', 'test@gmail.com', 'U', '10.00'),
(620, 67, 26, 'Coriander leaves/ಕೊತ್ತಂಬರಿ ಸೊಪ್ಪು', '3.00', '3.00', '2020-07-06 12:39:51', '2020-07-13 15:25:36', '', 'test@gmail.com', 'U', '10.00'),
(621, 73, 26, 'Menthya Soppu/ಮೆಂತ್ಯ ಸೊಪ್ಪು ', '3.00', '1.00', '2020-07-09 14:25:43', '2020-07-13 15:25:52', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(622, 78, 26, 'Avarekai - Chaparada', '32.00', '5.00', '2020-07-13 15:20:54', '2020-07-13 15:26:47', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(623, 78, 26, 'Avarekai - Chapparada / ಚಪ್ಪರದ ಅವರೆಕಾಯಿ', '32.00', '5.00', '2020-07-13 15:20:54', '2020-07-13 15:29:13', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(624, 67, 26, 'Coriander leaves/ಕೊತ್ತಂಬರಿ ಸೊಪ್ಪು', '4.00', '3.00', '2020-07-06 12:39:51', '2020-07-13 15:46:46', '', 'test@gmail.com', 'U', '10.00'),
(625, 68, 26, 'Curry leaves/ಕರಿಬೇವು   ', '2.50', '3.00', '2020-07-06 12:40:25', '2020-07-13 15:47:13', '', 'test@gmail.com', 'U', '10.00'),
(626, 69, 26, 'Mint leaves/ಪುದಿನ ಸೊಪ್ಪು ', '3.00', '3.00', '2020-07-06 12:40:50', '2020-07-13 15:47:42', '', 'test@gmail.com', 'U', '10.00'),
(627, 73, 26, 'Menthya Soppu/ಮೆಂತ್ಯ ಸೊಪ್ಪು ', '4.50', '1.00', '2020-07-09 14:25:43', '2020-07-13 15:48:38', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(628, 42, 26, 'Halasande/ಹಲಸಂದೆ (ಉದ್ದ ) ', '30.00', '10.00', '2020-07-03 08:31:50', '2020-07-13 16:02:27', '', 'test@gmail.com', 'U', '10.00'),
(629, 10, 26, 'Capsicum/ದಪ್ಪ ಮೆಣಸಿನಕಾಯಿ', '68.00', '8.00', '2020-06-29 14:22:59', '2020-07-14 15:11:36', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '75.00'),
(630, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '34.00', '25.00', '2020-06-29 14:25:39', '2020-07-14 15:12:13', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(631, 13, 26, 'Tomato(Sour)/ಟೊಮ್ಯಾಟೊ ', '33.00', '100.00', '2020-06-29 14:25:12', '2020-07-14 15:12:37', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(632, 34, 26, 'Lady\'s finger / Okra/ಬೆಂಡೇಕಾಯಿ  ', '14.00', '20.00', '2020-06-29 14:31:27', '2020-07-14 15:16:01', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(633, 78, 26, 'Avarekai - Chapparada / ಚಪ್ಪರದ ಅವರೆಕಾಯಿ', '32.00', '5.00', '2020-07-13 15:20:54', '2020-07-14 15:16:22', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(634, 42, 26, 'Halasande/ಹಲಸಂದೆ (ಉದ್ದ ) ', '30.00', '10.00', '2020-07-03 08:31:50', '2020-07-14 15:16:39', '', 'test@gmail.com', 'U', '10.00'),
(635, 18, 26, 'Garlic/ಬೆಳ್ಳುಳ್ಳಿ  ', '75.00', '5.00', '2020-06-29 14:26:45', '2020-07-14 15:39:21', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(636, 9, 26, 'Carrot/ಕ್ಯಾರೆಟ್ ', '33.00', '10.00', '2020-06-29 14:22:41', '2020-07-14 15:39:32', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '100.00'),
(637, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '28.00', '3.00', '2020-06-29 14:22:19', '2020-07-15 13:30:21', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(638, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '23.00', '5.00', '2020-06-29 14:21:54', '2020-07-15 13:30:34', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(639, 76, 26, 'Bitter Gourd- White  / ಬಿಳಿ ಹಾಗಲಕಾಯಿ  ', '30.00', '3.00', '2020-07-12 15:27:22', '2020-07-15 13:31:13', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(640, 76, 26, 'Bitter Gourd- White  / ಬಿಳಿ ಹಾಗಲಕಾಯಿ  ', '30.00', '3.00', '2020-07-12 15:27:22', '2020-07-15 13:32:28', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(641, 47, 26, 'Bottle gourd/ಸೋರೆಕಾಯಿ', '15.00', '3.00', '2020-07-03 13:09:17', '2020-07-15 13:33:07', '', 'test@gmail.com', 'U', '10.00'),
(642, 10, 26, 'Capsicum/ದಪ್ಪ ಮೆಣಸಿನಕಾಯಿ', '69.00', '8.00', '2020-06-29 14:22:59', '2020-07-15 13:34:47', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '75.00'),
(643, 62, 26, 'Chayote Gourd/ಸೀಮೆ ಬದನೆ ', '20.00', '10.00', '2020-07-05 15:30:20', '2020-07-15 13:35:47', '', 'test@gmail.com', 'U', '10.00'),
(644, 62, 26, 'Chayote Gourd/ಸೀಮೆ ಬದನೆ ', '22.00', '10.00', '2020-07-05 15:30:20', '2020-07-15 13:38:40', '', 'test@gmail.com', 'U', '10.00'),
(645, 62, 26, 'Chayote Gourd/ಸೀಮೆ ಬದನೆ ', '20.00', '10.00', '2020-07-05 15:30:20', '2020-07-15 13:40:09', '', 'test@gmail.com', 'U', '10.00'),
(646, 34, 26, 'Lady\'s finger / Okra/ಬೆಂಡೇಕಾಯಿ  ', '15.00', '20.00', '2020-06-29 14:31:27', '2020-07-15 13:40:51', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(647, 29, 26, 'Mangalore Cucumber/ಮಂಗಳೂರು ಸವತೆಕಾಯಿ ', '9.00', '15.00', '2020-06-29 14:30:03', '2020-07-15 13:42:37', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(648, 69, 26, 'Mint leaves/ಪುದಿನ ಸೊಪ್ಪು ', '2.00', '3.00', '2020-07-06 12:40:50', '2020-07-15 13:43:10', '', 'test@gmail.com', 'U', '10.00'),
(649, 13, 26, 'Tomato(Sour)/ಟೊಮ್ಯಾಟೊ ', '32.00', '100.00', '2020-06-29 14:25:12', '2020-07-15 13:44:33', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(650, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '33.00', '25.00', '2020-06-29 14:25:39', '2020-07-15 13:44:52', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(651, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '33.00', '25.00', '2020-06-29 14:25:39', '2020-07-15 13:45:14', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(652, 28, 26, 'Cucumber(Green)/ಸೌತೇಕಾಯಿ ', '15.00', '10.00', '2020-06-29 14:29:29', '2020-07-15 13:47:48', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(653, 61, 26, 'Beetroot/ಬೀಟ್ ರೂಟ್ ', '28.00', '3.00', '2020-07-05 14:55:16', '2020-07-15 14:09:35', '', 'test@gmail.com', 'U', '10.00'),
(654, 35, 26, 'Radish/ಮೂಲಂಗಿ ', '16.00', '20.00', '2020-06-29 14:31:43', '2020-07-15 14:54:52', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(655, 11, 26, 'Potato/ಆಲೂ ಗೆಡ್ಡೆ ', '29.00', '7.00', '2020-06-29 14:23:51', '2020-07-16 12:57:21', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(656, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '28.00', '5.00', '2020-06-29 14:21:54', '2020-07-16 12:57:44', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(657, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '32.00', '3.00', '2020-06-29 14:22:19', '2020-07-16 12:58:03', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(658, 30, 26, 'Cabbage/ಎಲೆ ಕೋಸು', '10.00', '8.00', '2020-06-29 14:30:17', '2020-07-16 12:58:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(659, 10, 26, 'Capsicum/ದಪ್ಪ ಮೆಣಸಿನಕಾಯಿ', '70.00', '8.00', '2020-06-29 14:22:59', '2020-07-16 12:58:55', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '75.00'),
(660, 31, 26, 'Cauliflower/ಹೂ ಕೋಸು', '18.00', '15.00', '2020-06-29 14:30:35', '2020-07-16 12:59:23', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '70.00'),
(661, 77, 26, 'Cluster Beans / ಗೋರಿಕಾಯಿ ', '22.00', '5.00', '2020-07-12 15:42:27', '2020-07-16 13:00:19', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(662, 20, 26, 'Green chilli/ಹಸಿರು ಮೆಣಸಿನಕಾಯಿ ', '30.00', '5.00', '2020-06-29 14:27:20', '2020-07-16 13:00:46', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(663, 65, 26, 'Pumpkin(Green)/ಕುಂಬಳಕಾಯಿ ', '11.00', '3.00', '2020-07-05 19:44:05', '2020-07-16 13:01:17', '', 'test@gmail.com', 'U', '10.00'),
(664, 29, 26, 'Mangalore Cucumber/ಮಂಗಳೂರು ಸವತೆಕಾಯಿ ', '11.00', '15.00', '2020-06-29 14:30:03', '2020-07-16 13:01:49', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(665, 35, 26, 'Raddish/ಮೂಲಂಗಿ ', '16.00', '20.00', '2020-06-29 14:31:43', '2020-07-16 13:02:06', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(666, 44, 26, 'Drum Stick/ನುಗ್ಗೆ ಕಾಯಿ ', '45.00', '3.00', '2020-07-03 13:08:04', '2020-07-16 13:02:25', '', 'test@gmail.com', 'U', '10.00'),
(667, 62, 26, 'Chayote Gourd/ಸೀಮೆ ಬದನೆ ', '22.00', '10.00', '2020-07-05 15:30:20', '2020-07-16 13:02:46', '', 'test@gmail.com', 'U', '10.00'),
(668, 36, 26, 'Ivy gourd/ತೊಂಡೆ ಕಾಯಿ ', '15.00', '10.00', '2020-06-29 14:32:02', '2020-07-16 13:03:07', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(669, 44, 26, 'Drum Stick/ನುಗ್ಗೆ ಕಾಯಿ ', '16.00', '3.00', '2020-07-03 13:08:04', '2020-07-16 13:15:58', '', 'test@gmail.com', 'U', '10.00'),
(670, 44, 26, 'Drum Stick/ನುಗ್ಗೆ ಕಾಯಿ ', '16.00', '3.00', '2020-07-03 13:08:04', '2020-07-16 13:16:39', '', 'test@gmail.com', 'U', '10.00'),
(671, 72, 26, 'Balekayi/ಬಾಲೆಕಾಯಿ', '8.00', '1.00', '2020-07-09 14:18:36', '2020-07-17 01:59:16', 'test@gmail.com', 'abhijitjd003@gmail.com', 'U', '10.00'),
(672, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '35.00', '3.00', '2020-06-29 14:22:19', '2020-07-17 01:59:27', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'U', '30.00'),
(673, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '30.00', '5.00', '2020-06-29 14:21:54', '2020-07-17 01:59:38', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'U', '60.00'),
(674, 11, 26, 'Potato/ಆಲೂ ಗೆಡ್ಡೆ ', '30.00', '7.00', '2020-06-29 14:23:51', '2020-07-16 15:21:28', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(675, 34, 26, 'Lady\'s finger / Okra/ಬೆಂಡೇಕಾಯಿ  ', '18.00', '20.00', '2020-06-29 14:31:27', '2020-07-16 15:22:15', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(676, 31, 26, 'Cauliflower/ಹೂ ಕೋಸು', '20.00', '15.00', '2020-06-29 14:30:35', '2020-07-16 15:22:48', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '70.00'),
(677, 45, 26, 'Ridge Gourd/ಹೀರೆಕಾಯಿ ', '26.00', '3.00', '2020-07-03 13:08:28', '2020-07-16 15:23:21', '', 'test@gmail.com', 'U', '10.00'),
(678, 63, 26, 'Knol Khol /ನವಿಲುಕೋಸು ', '18.00', '5.00', '2020-07-05 19:38:57', '2020-07-16 15:23:41', '', 'test@gmail.com', 'U', '10.00'),
(679, 29, 26, 'Mangalore Cucumber/ಮಂಗಳೂರು ಸವತೆಕಾಯಿ ', '14.00', '15.00', '2020-06-29 14:30:03', '2020-07-16 15:24:08', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(680, 29, 26, 'Mangalore Cucumber/ಮಂಗಳೂರು ಸವತೆಕಾಯಿ ', '14.00', '13.00', '2020-06-29 14:30:03', '2020-07-16 15:24:49', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(681, 36, 26, 'Ivy gourd/ತೊಂಡೆ ಕಾಯಿ ', '18.00', '10.00', '2020-06-29 14:32:02', '2020-07-16 15:25:52', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(682, 75, 26, 'Avare Kai/ಅವರೆಕಾಯಿ', '25.00', '5.00', '2020-07-12 15:04:39', '2020-07-16 21:56:59', 'test@gmail.com', 'abhijitjd003@gmail.com', 'U', '50.00'),
(683, 75, 26, 'Avare Kai/ಅವರೆಕಾಯಿ', '25.00', '5.00', '2020-07-12 15:04:39', '2020-07-17 12:32:03', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(684, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '35.00', '3.00', '2020-06-29 14:22:19', '2020-07-17 12:32:32', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(685, 34, 26, 'Lady\'s finger / Okra/ಬೆಂಡೇಕಾಯಿ  ', '20.00', '20.00', '2020-06-29 14:31:27', '2020-07-17 12:33:01', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(686, 30, 26, 'Cabbage/ಎಲೆ ಕೋಸು', '11.00', '8.00', '2020-06-29 14:30:17', '2020-07-17 12:33:20', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(687, 10, 26, 'Capsicum/ದಪ್ಪ ಮೆಣಸಿನಕಾಯಿ', '68.00', '8.00', '2020-06-29 14:22:59', '2020-07-17 12:34:24', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '75.00'),
(688, 10, 26, 'Capsicum/ದಪ್ಪ ಮೆಣಸಿನಕಾಯಿ', '65.00', '8.00', '2020-06-29 14:22:59', '2020-07-17 12:34:56', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '75.00'),
(689, 28, 26, 'Cucumber(Green)/ಸೌತೇಕಾಯಿ ', '20.00', '10.00', '2020-06-29 14:29:29', '2020-07-17 12:36:16', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(690, 20, 26, 'Green chilli/ಹಸಿರು ಮೆಣಸಿನಕಾಯಿ ', '32.00', '5.00', '2020-06-29 14:27:20', '2020-07-17 12:36:34', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(691, 63, 26, 'Knol Khol /ನವಿಲುಕೋಸು ', '17.00', '5.00', '2020-07-05 19:38:57', '2020-07-17 12:37:00', '', 'test@gmail.com', 'U', '10.00'),
(692, 65, 26, 'Pumpkin(Green)/ಕುಂಬಳಕಾಯಿ ', '10.00', '3.00', '2020-07-05 19:44:05', '2020-07-17 12:37:13', '', 'test@gmail.com', 'U', '10.00'),
(693, 29, 26, 'Mangalore Cucumber/ಮಂಗಳೂರು ಸವತೆಕಾಯಿ ', '13.00', '13.00', '2020-06-29 14:30:03', '2020-07-17 12:37:39', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(694, 46, 26, 'Snake gourd/ಪಡವಲಕಾಯಿ  ', '14.00', '3.00', '2020-07-03 13:08:54', '2020-07-17 12:38:00', '', 'test@gmail.com', 'U', '10.00'),
(695, 16, 26, 'Onion Small /ಸಣ್ಣ ಈರುಳ್ಳಿ  ', '40.00', '25.00', '2020-06-29 14:26:10', '2020-07-17 12:38:24', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(696, 47, 26, 'Bottle gourd/ಸೋರೆಕಾಯಿ', '11.00', '3.00', '2020-07-03 13:09:17', '2020-07-17 12:38:37', '', 'test@gmail.com', 'U', '10.00'),
(697, 13, 26, 'Tomato(Sour)/ಟೊಮ್ಯಾಟೊ ', '33.00', '100.00', '2020-06-29 14:25:12', '2020-07-17 12:38:59', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(698, 36, 26, 'Ivy gourd/ತೊಂಡೆ ಕಾಯಿ ', '17.00', '10.00', '2020-06-29 14:32:02', '2020-07-17 12:39:18', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(699, 68, 26, 'Curry leaves/ಕರಿಬೇವು   ', '2.00', '3.00', '2020-07-06 12:40:25', '2020-07-17 12:39:40', '', 'test@gmail.com', 'U', '10.00'),
(700, 69, 26, 'Mint leaves/ಪುದಿನ ಸೊಪ್ಪು ', '3.00', '3.00', '2020-07-06 12:40:50', '2020-07-17 12:40:03', '', 'test@gmail.com', 'U', '10.00'),
(701, 67, 26, 'Coriander leaves/ಕೊತ್ತಂಬರಿ ಸೊಪ್ಪು', '3.00', '3.00', '2020-07-06 12:39:51', '2020-07-17 12:40:28', '', 'test@gmail.com', 'U', '10.00'),
(702, 70, 26, 'Palak/ಪಾಲಾಕ್ ', '3.00', '3.00', '2020-07-06 12:41:13', '2020-07-17 12:40:47', '', 'test@gmail.com', 'U', '10.00'),
(703, 71, 26, 'Sabsige Soppu / ಸಬ್ಸಿಗೆ ಸೊಪ್ಪು ', '3.00', '3.00', '2020-07-06 12:41:52', '2020-07-17 12:41:05', '', 'test@gmail.com', 'U', '10.00'),
(704, 73, 26, 'Menthya Soppu/ಮೆಂತ್ಯ ಸೊಪ್ಪು ', '3.00', '1.00', '2020-07-09 14:25:43', '2020-07-17 12:41:25', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(705, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '30.00', '5.00', '2020-06-29 14:21:54', '2020-07-17 12:42:28', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(706, 75, 26, 'Avare Kai/ಅವರೆಕಾಯಿ', '30.00', '5.00', '2020-07-12 15:04:39', '2020-07-17 21:52:22', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(707, 72, 26, 'Balekayi/ಬಾಲೆಕಾಯಿ', '8.00', '1.00', '2020-07-09 14:18:36', '2020-07-17 21:52:47', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(708, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '35.00', '3.00', '2020-06-29 14:22:19', '2020-07-17 21:56:19', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(709, 61, 26, 'Beetroot/ಬೀಟ್ ರೂಟ್ ', '24.00', '3.00', '2020-07-05 14:55:16', '2020-07-17 21:56:35', '', 'test@gmail.com', 'U', '10.00'),
(710, 34, 26, 'Lady\'s finger / Okra/ಬೆಂಡೇಕಾಯಿ  ', '19.50', '20.00', '2020-06-29 14:31:27', '2020-07-17 21:57:00', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(711, 25, 26, 'Brinjal/ಬದನೇಕಾಯಿ (ಬಿಳಿ )', '14.00', '8.00', '2020-06-29 14:28:47', '2020-07-17 21:58:01', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(712, 27, 26, 'Brinjal Round /ಬದನೇಕಾಯಿ ', '14.00', '5.00', '2020-06-29 14:29:17', '2020-07-17 21:58:14', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(713, 30, 26, 'Cabbage/ಎಲೆ ಕೋಸು', '12.00', '8.00', '2020-06-29 14:30:17', '2020-07-17 21:58:30', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(714, 10, 26, 'Capsicum/ದಪ್ಪ ಮೆಣಸಿನಕಾಯಿ', '65.00', '8.00', '2020-06-29 14:22:59', '2020-07-17 21:59:08', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '75.00'),
(715, 9, 26, 'Carrot/ಕ್ಯಾರೆಟ್ ', '34.00', '10.00', '2020-06-29 14:22:41', '2020-07-17 21:59:19', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '100.00'),
(716, 31, 26, 'Cauliflower/ಹೂ ಕೋಸು', '19.00', '15.00', '2020-06-29 14:30:35', '2020-07-17 21:59:31', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '70.00'),
(717, 28, 26, 'Cucumber(Green)/ಸೌತೇಕಾಯಿ ', '16.00', '10.00', '2020-06-29 14:29:29', '2020-07-17 21:59:48', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(718, 44, 26, 'Drum Stick/ನುಗ್ಗೆ ಕಾಯಿ ', '45.00', '3.00', '2020-07-03 13:08:04', '2020-07-17 22:00:06', '', 'test@gmail.com', 'U', '10.00'),
(719, 18, 26, 'Garlic/ಬೆಳ್ಳುಳ್ಳಿ  ', '80.00', '5.00', '2020-06-29 14:26:45', '2020-07-17 22:00:24', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(720, 19, 26, 'Ginger/ಶುಂಠಿ', '60.00', '6.00', '2020-06-29 14:27:04', '2020-07-17 22:00:35', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(721, 20, 26, 'Green chilli/ಹಸಿರು ಮೆಣಸಿನಕಾಯಿ ', '32.00', '5.00', '2020-06-29 14:27:20', '2020-07-17 22:00:50', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(722, 76, 26, 'Bitter Gourd- White  / ಬಿಳಿ ಹಾಗಲಕಾಯಿ  ', '30.00', '3.00', '2020-07-12 15:27:22', '2020-07-17 22:01:12', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(723, 42, 26, 'Halasande/ಹಲಸಂದೆ (ಉದ್ದ ) ', '30.00', '10.00', '2020-07-03 08:31:50', '2020-07-17 22:01:35', '', 'test@gmail.com', 'U', '10.00'),
(724, 45, 26, 'Ridge Gourd/ಹೀರೆಕಾಯಿ ', '24.00', '3.00', '2020-07-03 13:08:28', '2020-07-17 22:01:51', '', 'test@gmail.com', 'U', '10.00'),
(725, 63, 26, 'Knol Khol /ನವಿಲುಕೋಸು ', '22.00', '5.00', '2020-07-05 19:38:57', '2020-07-17 22:02:12', '', 'test@gmail.com', 'U', '10.00'),
(726, 65, 26, 'Pumpkin(Green)/ಕುಂಬಳಕಾಯಿ ', '12.00', '3.00', '2020-07-05 19:44:05', '2020-07-17 22:02:33', '', 'test@gmail.com', 'U', '10.00'),
(727, 21, 26, 'Lemon/ನಿಂಬೆ ಹಣ್ಣು ', '49.00', '10.00', '2020-06-29 14:27:39', '2020-07-17 22:03:00', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(728, 29, 26, 'Mangalore Cucumber/ಮಂಗಳೂರು ಸವತೆಕಾಯಿ ', '14.00', '13.00', '2020-06-29 14:30:03', '2020-07-17 22:03:27', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(729, 35, 26, 'Raddish/ಮೂಲಂಗಿ ', '14.00', '20.00', '2020-06-29 14:31:43', '2020-07-17 22:03:47', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(730, 15, 26, 'Onion/ಈರುಳ್ಳಿ ', '14.00', '20.00', '2020-06-29 14:25:53', '2020-07-17 22:04:04', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(731, 46, 26, 'Snake gourd/ಪಡವಲಕಾಯಿ  ', '16.00', '3.00', '2020-07-03 13:08:54', '2020-07-17 22:04:30', '', 'test@gmail.com', 'U', '10.00'),
(732, 62, 26, 'Chayote Gourd/ಸೀಮೆ ಬದನೆ ', '20.00', '10.00', '2020-07-05 15:30:20', '2020-07-17 22:05:42', '', 'test@gmail.com', 'U', '10.00'),
(733, 16, 26, 'Onion Small /ಸಣ್ಣ ಈರುಳ್ಳಿ  ', '42.00', '25.00', '2020-06-29 14:26:10', '2020-07-17 22:06:00', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(734, 47, 26, 'Bottle gourd/ಸೋರೆಕಾಯಿ', '14.00', '3.00', '2020-07-03 13:09:17', '2020-07-17 22:06:18', '', 'test@gmail.com', 'U', '10.00'),
(735, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '34.00', '25.00', '2020-06-29 14:25:39', '2020-07-17 22:06:43', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(736, 13, 26, 'Tomato(Sour)/ಟೊಮ್ಯಾಟೊ ', '30.00', '100.00', '2020-06-29 14:25:12', '2020-07-17 22:06:54', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00');
INSERT INTO `ProductHistory` (`ProductHistId`, `ProductId`, `CategoryId`, `Name`, `RatePerKG`, `MinPurchaseQuantity`, `CreatedDateTime`, `UpdatedDateTime`, `CreatedUserId`, `UpdatedUserId`, `StatusCode`, `TotalStock`) VALUES
(737, 77, 26, 'Cluster Beans / ಗೋರಿಕಾಯಿ ', '22.00', '5.00', '2020-07-12 15:42:27', '2020-07-17 22:07:10', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(738, 68, 26, 'Curry leaves/ಕರಿಬೇವು   ', '3.00', '3.00', '2020-07-06 12:40:25', '2020-07-17 22:07:41', '', 'test@gmail.com', 'U', '10.00'),
(739, 69, 26, 'Mint leaves/ಪುದಿನ ಸೊಪ್ಪು ', '6.50', '3.00', '2020-07-06 12:40:50', '2020-07-17 22:08:18', '', 'test@gmail.com', 'U', '10.00'),
(740, 67, 26, 'Coriander leaves/ಕೊತ್ತಂಬರಿ ಸೊಪ್ಪು', '8.00', '3.00', '2020-07-06 12:39:51', '2020-07-17 22:08:34', '', 'test@gmail.com', 'U', '10.00'),
(741, 77, 26, 'Cluster Beans / ಗೋರಿಕಾಯಿ ', '25.00', '5.00', '2020-07-12 15:42:27', '2020-07-17 22:12:18', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(742, 70, 26, 'Palak/ಪಾಲಾಕ್ ', '3.50', '3.00', '2020-07-06 12:41:13', '2020-07-17 22:16:40', '', 'test@gmail.com', 'U', '10.00'),
(743, 80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '25.00', '3.00', '2020-07-17 22:21:11', '2020-07-17 23:07:43', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(744, 79, 27, 'Banana(Yellaki) / ಬಾಳೆಹಣ್ಣು', '55.00', '3.00', '2020-07-17 22:20:12', '2020-07-17 23:07:58', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(745, 80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '25.00', '3.00', '2020-07-17 22:21:11', '2020-07-17 23:08:39', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(746, 79, 27, 'Banana(Yellaki) / ಬಾಳೆಹಣ್ಣು', '55.00', '3.00', '2020-07-17 22:20:12', '2020-07-17 23:08:54', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(747, 11, 26, 'Potato/ಆಲೂ ಗೆಡ್ಡೆ ', '30.50', '7.00', '2020-06-29 14:23:51', '2020-07-17 23:10:05', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(748, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '45.00', '3.00', '2020-06-29 14:22:19', '2020-07-17 23:10:35', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(749, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '28.00', '5.00', '2020-06-29 14:21:54', '2020-07-17 23:10:46', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(750, 64, 26, 'Bitter gourd/ಹಾಗಲಕಾಯಿ ', '30.00', '3.00', '2020-07-05 19:39:44', '2020-07-17 23:12:38', '', 'test@gmail.com', 'U', '10.00'),
(751, 42, 26, 'Halasande/ಹಲಸಂದೆ (ಉದ್ದ ) ', '50.00', '10.00', '2020-07-03 08:31:50', '2020-07-17 23:13:17', '', 'test@gmail.com', 'U', '10.00'),
(752, 36, 26, 'Ivy gourd/ತೊಂಡೆ ಕಾಯಿ ', '18.00', '10.00', '2020-06-29 14:32:02', '2020-07-17 23:15:16', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(753, 77, 26, 'Cluster Beans / ಗೋರಿಕಾಯಿ ', '30.00', '5.00', '2020-07-12 15:42:27', '2020-07-17 23:16:31', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(754, 71, 26, 'Sabsige Soppu / ಸಬ್ಸಿಗೆ ಸೊಪ್ಪು ', '5.00', '3.00', '2020-07-06 12:41:52', '2020-07-17 23:17:07', '', 'test@gmail.com', 'U', '10.00'),
(755, 80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '25.00', '3.00', '2020-07-17 22:21:11', '2020-07-17 23:17:39', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(756, 80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '25.00', '3.00', '2020-07-17 22:21:11', '2020-07-17 23:18:00', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(757, 80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '25.00', '3.00', '2020-07-17 22:21:11', '2020-07-17 23:19:50', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(758, 80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '25.00', '3.00', '2020-07-17 22:21:11', '2020-07-17 23:20:37', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(759, 80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '25.00', '3.00', '2020-07-17 22:21:11', '2020-07-17 23:26:51', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(760, 80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '25.00', '3.00', '2020-07-17 22:21:11', '2020-07-17 23:27:17', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(761, 80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '25.00', '3.00', '2020-07-17 22:21:11', '2020-07-17 23:27:45', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(762, 80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '25.00', '3.00', '2020-07-17 22:21:11', '2020-07-17 23:28:24', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(763, 79, 27, 'Banana(Yellaki) / ಬಾಳೆಹಣ್ಣು', '55.00', '3.00', '2020-07-17 22:20:12', '2020-07-17 23:28:50', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(764, 80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '25.00', '3.00', '2020-07-17 22:21:11', '2020-07-17 23:30:11', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(765, 80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '25.00', '3.00', '2020-07-17 22:21:11', '2020-07-17 23:30:49', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(766, 79, 27, 'Banana(Yellaki) / ಬಾಳೆಹಣ್ಣು', '55.00', '3.00', '2020-07-17 22:20:12', '2020-07-17 23:30:57', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(767, 80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '25.00', '3.00', '2020-07-17 22:21:11', '2020-07-17 23:55:25', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(768, 80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '25.00', '3.00', '2020-07-17 22:21:11', '2020-07-17 23:55:57', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(769, 81, 27, 'Apple', '200.00', '10.00', '2020-07-18 08:00:15', '2020-07-18 08:03:24', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'U', '10.00'),
(770, 81, 27, 'Apple', '200.00', '10.00', '2020-07-18 08:00:15', '2020-07-18 20:43:41', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'U', '10.00'),
(771, 81, 27, 'Apple', '200.00', '10.00', '2020-07-18 08:00:15', '2020-07-18 20:45:54', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'U', '10.00'),
(772, 81, 27, 'Apple', '200.00', '10.00', '2020-07-18 08:00:15', '2020-07-18 08:36:19', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'U', '10.00'),
(773, 81, 27, 'Apple', '200.00', '10.00', '2020-07-18 08:00:15', '2020-07-18 09:49:30', 'abhijitjd003@gmail.com', 'test@gmail.com', 'D', '10.00'),
(774, 82, 26, 'ATest 1', '50.00', '5.00', '2020-07-18 14:01:54', '2020-07-18 14:02:22', 'md@spicetrip.com', 'md@spicetrip.com', 'D', '50.00'),
(775, 75, 26, 'Avare Kai/ಅವರೆಕಾಯಿ', '40.00', '5.00', '2020-07-12 15:04:39', '2020-07-18 14:04:11', 'test@gmail.com', 'md@spicetrip.com', 'U', '50.00'),
(776, 75, 26, 'Avare Kai/ಅವರೆಕಾಯಿ', '50.00', '5.00', '2020-07-12 15:04:39', '2020-07-18 15:22:29', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(777, 72, 26, 'Balekayi/ಬಾಲೆಕಾಯಿ', '12.00', '1.00', '2020-07-09 14:18:36', '2020-07-18 15:23:07', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(778, 80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '25.00', '3.00', '2020-07-17 22:21:11', '2020-07-18 15:23:38', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(779, 79, 27, 'Banana(Yellaki) / ಬಾಳೆಹಣ್ಣು', '55.00', '3.00', '2020-07-17 22:20:12', '2020-07-18 15:23:44', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(780, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '45.00', '3.00', '2020-06-29 14:22:19', '2020-07-18 15:23:52', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(781, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '40.00', '5.00', '2020-06-29 14:21:54', '2020-07-18 15:24:00', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(782, 61, 26, 'Beetroot/ಬೀಟ್ ರೂಟ್ ', '40.00', '3.00', '2020-07-05 14:55:16', '2020-07-18 15:24:08', '', 'test@gmail.com', 'U', '10.00'),
(783, 64, 26, 'Bitter gourd/ಹಾಗಲಕಾಯಿ ', '50.00', '3.00', '2020-07-05 19:39:44', '2020-07-18 15:24:20', '', 'test@gmail.com', 'U', '10.00'),
(784, 76, 26, 'Bitter Gourd- White  / ಬಿಳಿ ಹಾಗಲಕಾಯಿ  ', '50.00', '3.00', '2020-07-12 15:27:22', '2020-07-18 15:25:01', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(785, 47, 26, 'Bottle gourd/ಸೋರೆಕಾಯಿ', '20.00', '3.00', '2020-07-03 13:09:17', '2020-07-18 15:25:09', '', 'test@gmail.com', 'U', '10.00'),
(786, 26, 26, 'Brinjal Black /ಬದನೇಕಾಯಿ', '16.00', '4.00', '2020-06-29 14:29:04', '2020-07-18 15:25:19', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(787, 27, 26, 'Brinjal Round /ಬದನೇಕಾಯಿ ', '30.00', '5.00', '2020-06-29 14:29:17', '2020-07-18 15:25:29', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(788, 25, 26, 'Brinjal/ಬದನೇಕಾಯಿ (ಬಿಳಿ )', '30.00', '8.00', '2020-06-29 14:28:47', '2020-07-18 15:25:39', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(789, 30, 26, 'Cabbage/ಎಲೆ ಕೋಸು', '20.00', '8.00', '2020-06-29 14:30:17', '2020-07-18 15:25:47', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(790, 10, 26, 'Capsicum/ದಪ್ಪ ಮೆಣಸಿನಕಾಯಿ', '75.00', '8.00', '2020-06-29 14:22:59', '2020-07-18 15:25:55', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '75.00'),
(791, 9, 26, 'Carrot/ಕ್ಯಾರೆಟ್ ', '40.00', '10.00', '2020-06-29 14:22:41', '2020-07-18 15:26:03', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '100.00'),
(792, 31, 26, 'Cauliflower/ಹೂ ಕೋಸು', '25.00', '15.00', '2020-06-29 14:30:35', '2020-07-18 15:26:10', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '70.00'),
(793, 62, 26, 'Chayote Gourd/ಸೀಮೆ ಬದನೆ ', '30.00', '10.00', '2020-07-05 15:30:20', '2020-07-18 15:26:21', '', 'test@gmail.com', 'U', '10.00'),
(794, 77, 26, 'Cluster Beans / ಗೋರಿಕಾಯಿ ', '30.00', '5.00', '2020-07-12 15:42:27', '2020-07-18 15:26:29', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(795, 67, 26, 'Coriander leaves/ಕೊತ್ತಂಬರಿ ಸೊಪ್ಪು', '5.00', '3.00', '2020-07-06 12:39:51', '2020-07-18 15:26:40', '', 'test@gmail.com', 'U', '10.00'),
(796, 28, 26, 'Cucumber(Green)/ಸೌತೇಕಾಯಿ ', '25.00', '10.00', '2020-06-29 14:29:29', '2020-07-18 15:26:49', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(797, 68, 26, 'Curry leaves/ಕರಿಬೇವು   ', '4.00', '3.00', '2020-07-06 12:40:25', '2020-07-18 15:26:59', '', 'test@gmail.com', 'U', '10.00'),
(798, 44, 26, 'Drum Stick/ನುಗ್ಗೆ ಕಾಯಿ ', '55.00', '3.00', '2020-07-03 13:08:04', '2020-07-18 15:27:07', '', 'test@gmail.com', 'U', '10.00'),
(799, 18, 26, 'Garlic/ಬೆಳ್ಳುಳ್ಳಿ  ', '100.00', '5.00', '2020-06-29 14:26:45', '2020-07-18 15:27:20', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(800, 19, 26, 'Ginger/ಶುಂಠಿ', '100.00', '6.00', '2020-06-29 14:27:04', '2020-07-18 15:27:30', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(801, 20, 26, 'Green chilli/ಹಸಿರು ಮೆಣಸಿನಕಾಯಿ ', '45.00', '5.00', '2020-06-29 14:27:20', '2020-07-18 15:27:40', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(802, 36, 26, 'Ivy gourd/ತೊಂಡೆ ಕಾಯಿ ', '25.00', '10.00', '2020-06-29 14:32:02', '2020-07-18 15:27:50', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(803, 63, 26, 'Knol Khol /ನವಿಲುಕೋಸು ', '30.00', '5.00', '2020-07-05 19:38:57', '2020-07-18 15:28:05', '', 'test@gmail.com', 'U', '10.00'),
(804, 34, 26, 'Lady\'s finger / Okra/ಬೆಂಡೇಕಾಯಿ  ', '30.00', '20.00', '2020-06-29 14:31:27', '2020-07-18 15:28:19', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(805, 21, 26, 'Lemon/ನಿಂಬೆ ಹಣ್ಣು ', '10.00', '10.00', '2020-06-29 14:27:39', '2020-07-18 15:28:32', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(806, 29, 26, 'Mangalore Cucumber/ಮಂಗಳೂರು ಸವತೆಕಾಯಿ ', '15.00', '13.00', '2020-06-29 14:30:03', '2020-07-18 15:28:42', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(807, 73, 26, 'Menthya Soppu/ಮೆಂತ್ಯ ಸೊಪ್ಪು ', '3.50', '1.00', '2020-07-09 14:25:43', '2020-07-18 15:28:55', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(808, 69, 26, 'Mint leaves/ಪುದಿನ ಸೊಪ್ಪು ', '4.00', '3.00', '2020-07-06 12:40:50', '2020-07-18 15:29:05', '', 'test@gmail.com', 'U', '10.00'),
(809, 16, 26, 'Onion Small /ಸಣ್ಣ ಈರುಳ್ಳಿ  ', '60.00', '25.00', '2020-06-29 14:26:10', '2020-07-18 15:29:18', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(810, 15, 26, 'Onion/ಈರುಳ್ಳಿ ', '17.00', '20.00', '2020-06-29 14:25:53', '2020-07-18 15:29:28', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(811, 70, 26, 'Palak/ಪಾಲಾಕ್ ', '4.00', '3.00', '2020-07-06 12:41:13', '2020-07-18 15:29:42', '', 'test@gmail.com', 'U', '10.00'),
(812, 11, 26, 'Potato/ಆಲೂ ಗೆಡ್ಡೆ ', '40.00', '7.00', '2020-06-29 14:23:51', '2020-07-18 15:29:55', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(813, 65, 26, 'Pumpkin(Green)/ಕುಂಬಳಕಾಯಿ ', '20.00', '3.00', '2020-07-05 19:44:05', '2020-07-18 15:30:10', '', 'test@gmail.com', 'U', '10.00'),
(814, 35, 26, 'Raddish/ಮೂಲಂಗಿ ', '25.00', '20.00', '2020-06-29 14:31:43', '2020-07-18 15:30:25', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(815, 45, 26, 'Ridge Gourd/ಹೀರೆಕಾಯಿ ', '35.00', '3.00', '2020-07-03 13:08:28', '2020-07-18 15:30:36', '', 'test@gmail.com', 'U', '10.00'),
(816, 71, 26, 'Sabsige Soppu / ಸಬ್ಸಿಗೆ ಸೊಪ್ಪು ', '5.00', '3.00', '2020-07-06 12:41:52', '2020-07-18 15:30:45', '', 'test@gmail.com', 'U', '10.00'),
(817, 46, 26, 'Snake gourd/ಪಡವಲಕಾಯಿ  ', '20.00', '3.00', '2020-07-03 13:08:54', '2020-07-18 15:30:54', '', 'test@gmail.com', 'U', '10.00'),
(818, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '40.00', '25.00', '2020-06-29 14:25:39', '2020-07-18 15:31:03', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(819, 13, 26, 'Tomato(Sour)/ಟೊಮ್ಯಾಟೊ ', '40.00', '100.00', '2020-06-29 14:25:12', '2020-07-18 15:31:15', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(820, 42, 26, 'Halasande/ಹಲಸಂದೆ (ಉದ್ದ ) ', '50.00', '10.00', '2020-07-03 08:31:50', '2020-07-18 15:32:11', '', 'test@gmail.com', 'U', '10.00'),
(821, 42, 26, 'Halasande/ಹಲಸಂದೆ (ಉದ್ದ ) ', '50.00', '10.00', '2020-07-03 08:31:50', '2020-07-18 15:43:01', '', 'test@gmail.com', 'U', '10.00'),
(822, 42, 26, 'Halasande/ಹಲಸಂದೆ (ಉದ್ದ ) ', '38.00', '10.00', '2020-07-03 08:31:50', '2020-07-18 15:43:46', '', 'test@gmail.com', 'U', '10.00'),
(823, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '36.00', '3.00', '2020-06-29 14:22:19', '2020-07-19 14:19:00', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(824, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '28.00', '5.00', '2020-06-29 14:21:54', '2020-07-19 14:19:15', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(825, 31, 26, 'Cauliflower/ಹೂ ಕೋಸು', '20.00', '15.00', '2020-06-29 14:30:35', '2020-07-19 14:19:36', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '70.00'),
(826, 62, 26, 'Chayote Gourd/ಸೀಮೆ ಬದನೆ ', '26.00', '10.00', '2020-07-05 15:30:20', '2020-07-19 14:19:51', '', 'test@gmail.com', 'U', '10.00'),
(827, 28, 26, 'Cucumber(Green)/ಸೌತೇಕಾಯಿ ', '16.00', '10.00', '2020-06-29 14:29:29', '2020-07-19 14:20:13', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(828, 36, 26, 'Ivy gourd/ತೊಂಡೆ ಕಾಯಿ ', '22.00', '10.00', '2020-06-29 14:32:02', '2020-07-19 14:20:32', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(829, 29, 26, 'Mangalore Cucumber/ಮಂಗಳೂರು ಸವತೆಕಾಯಿ ', '14.00', '13.00', '2020-06-29 14:30:03', '2020-07-19 14:21:00', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(830, 16, 26, 'Onion Small /ಸಣ್ಣ ಈರುಳ್ಳಿ  ', '40.00', '25.00', '2020-06-29 14:26:10', '2020-07-19 14:21:22', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(831, 46, 26, 'Snake gourd/ಪಡವಲಕಾಯಿ  ', '18.00', '3.00', '2020-07-03 13:08:54', '2020-07-19 14:21:52', '', 'test@gmail.com', 'U', '10.00'),
(832, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '35.00', '25.00', '2020-06-29 14:25:39', '2020-07-19 14:22:10', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(833, 13, 26, 'Tomato(Sour)/ಟೊಮ್ಯಾಟೊ ', '32.00', '100.00', '2020-06-29 14:25:12', '2020-07-19 14:22:23', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(834, 30, 26, 'Cabbage/ಎಲೆ ಕೋಸು', '12.00', '8.00', '2020-06-29 14:30:17', '2020-07-19 14:33:39', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(835, 15, 26, 'Onion/ಈರುಳ್ಳಿ ', '14.00', '20.00', '2020-06-29 14:25:53', '2020-07-19 14:33:52', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(836, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '32.00', '3.00', '2020-06-29 14:22:19', '2020-07-19 14:34:30', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(837, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '25.00', '5.00', '2020-06-29 14:21:54', '2020-07-19 14:34:51', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(838, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '33.00', '25.00', '2020-06-29 14:25:39', '2020-07-19 15:05:39', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(839, 75, 26, 'Avare Kai/ಅವರೆಕಾಯಿ', '28.00', '5.00', '2020-07-12 15:04:39', '2020-07-20 14:30:33', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(840, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '30.00', '3.00', '2020-06-29 14:22:19', '2020-07-20 14:30:57', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(841, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '22.00', '5.00', '2020-06-29 14:21:54', '2020-07-20 14:31:10', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(842, 84, 26, 'British Cucumber/ ಬ್ರಿಟಿಷ್ ಸೌತೆಕಾಯಿ', '28.00', '3.00', '2020-07-20 14:35:58', '2020-07-20 14:37:19', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(843, 84, 26, 'British Cucumber/ ಬ್ರಿಟಿಷ್ ಸೌತೆಕಾಯಿ', '28.00', '3.00', '2020-07-20 14:35:58', '2020-07-20 14:37:56', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(844, 30, 26, 'Cabbage/ಎಲೆ ಕೋಸು', '11.00', '8.00', '2020-06-29 14:30:17', '2020-07-20 14:38:25', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(845, 10, 26, 'Capsicum/ದಪ್ಪ ಮೆಣಸಿನಕಾಯಿ', '68.00', '8.00', '2020-06-29 14:22:59', '2020-07-20 14:38:34', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '75.00'),
(846, 31, 26, 'Cauliflower/ಹೂ ಕೋಸು', '18.00', '15.00', '2020-06-29 14:30:35', '2020-07-20 14:38:47', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '70.00'),
(847, 42, 26, 'Halasande/ಹಲಸಂದೆ (ಉದ್ದ ) ', '38.00', '10.00', '2020-07-03 08:31:50', '2020-07-20 14:39:53', '', 'test@gmail.com', 'U', '10.00'),
(848, 21, 26, 'Lemon/ನಿಂಬೆ ಹಣ್ಣು ', '49.00', '10.00', '2020-06-29 14:27:39', '2020-07-20 14:40:13', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(849, 11, 26, 'Potato/ಆಲೂ ಗೆಡ್ಡೆ ', '30.50', '7.00', '2020-06-29 14:23:51', '2020-07-20 14:40:44', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(850, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '30.00', '25.00', '2020-06-29 14:25:39', '2020-07-20 14:41:18', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(851, 13, 26, 'Tomato(Sour)/ಟೊಮ್ಯಾಟೊ ', '24.00', '100.00', '2020-06-29 14:25:12', '2020-07-20 14:41:27', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(852, 84, 26, 'British Cucumber/ ಬ್ರಿಟಿಷ್ ಸೌತೆಕಾಯಿ', '28.00', '3.00', '2020-07-20 14:35:58', '2020-07-20 14:41:51', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(853, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '30.00', '3.00', '2020-06-29 14:22:19', '2020-07-21 14:24:17', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(854, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '33.00', '3.00', '2020-06-29 14:22:19', '2020-07-21 14:25:21', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(855, 26, 26, 'Brinjal Black /ಬದನೇಕಾಯಿ', '26.00', '4.00', '2020-06-29 14:29:04', '2020-07-21 14:27:20', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(856, 30, 26, 'Cabbage/ಎಲೆ ಕೋಸು', '10.00', '8.00', '2020-06-29 14:30:17', '2020-07-21 14:30:00', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(857, 28, 26, 'Cucumber(Green)/ಸೌತೇಕಾಯಿ ', '18.00', '10.00', '2020-06-29 14:29:29', '2020-07-21 14:31:12', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(858, 20, 26, 'Green chilli/ಹಸಿರು ಮೆಣಸಿನಕಾಯಿ ', '36.00', '5.00', '2020-06-29 14:27:20', '2020-07-21 14:32:28', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(859, 20, 26, 'Green chilli/ಹಸಿರು ಮೆಣಸಿನಕಾಯಿ ', '30.00', '5.00', '2020-06-29 14:27:20', '2020-07-21 14:33:42', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(860, 29, 26, 'Mangalore Cucumber/ಮಂಗಳೂರು ಸವತೆಕಾಯಿ ', '15.00', '13.00', '2020-06-29 14:30:03', '2020-07-21 14:35:21', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(861, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '28.00', '25.00', '2020-06-29 14:25:39', '2020-07-21 14:37:10', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(862, 13, 26, 'Tomato(Sour)/ಟೊಮ್ಯಾಟೊ ', '22.00', '100.00', '2020-06-29 14:25:12', '2020-07-21 14:38:06', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(863, 85, 26, 'Apple', '100.00', '10.00', '2020-07-21 22:31:16', '2020-07-21 22:31:32', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'U', '0.00'),
(864, 85, 26, 'Apple', '101.00', '20.00', '2020-07-21 22:31:16', '2020-07-21 22:31:53', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'D', '0.00'),
(865, 78, 26, 'Avarekai - Chapparada / ಚಪ್ಪರದ ಅವರೆಕಾಯಿ', '32.00', '5.00', '2020-07-13 15:20:54', '2020-07-22 09:58:02', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(866, 75, 26, 'Avare Kai/ಅವರೆಕಾಯಿ', '27.00', '5.00', '2020-07-12 15:04:39', '2020-07-22 09:58:13', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(867, 80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '25.00', '3.00', '2020-07-17 22:21:11', '2020-07-22 14:02:23', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(868, 79, 27, 'Banana(Yellaki) / ಬಾಳೆಹಣ್ಣು', '55.00', '3.00', '2020-07-17 22:20:12', '2020-07-22 14:02:23', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(869, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '33.00', '3.00', '2020-06-29 14:22:19', '2020-07-22 14:02:23', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(870, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '23.00', '5.00', '2020-06-29 14:21:54', '2020-07-22 14:02:23', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(871, 25, 26, 'Brinjal/ಬದನೇಕಾಯಿ (ಬಿಳಿ )', '14.00', '8.00', '2020-06-29 14:28:47', '2020-07-22 14:02:23', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(872, 31, 26, 'Cauliflower/ಹೂ ಕೋಸು', '20.00', '15.00', '2020-06-29 14:30:35', '2020-07-22 14:02:23', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '70.00'),
(873, 44, 26, 'Drum Stick/ನುಗ್ಗೆ ಕಾಯಿ ', '45.00', '3.00', '2020-07-03 13:08:04', '2020-07-22 14:02:23', '', 'test@gmail.com', 'U', '10.00'),
(874, 36, 26, 'Ivy gourd/ತೊಂಡೆ ಕಾಯಿ ', '20.00', '10.00', '2020-06-29 14:32:02', '2020-07-22 14:02:23', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(875, 63, 26, 'Knol Khol /ನವಿಲುಕೋಸು ', '20.00', '5.00', '2020-07-05 19:38:57', '2020-07-22 14:02:23', '', 'test@gmail.com', 'U', '10.00'),
(876, 69, 26, 'Mint leaves/ಪುದಿನ ಸೊಪ್ಪು ', '2.50', '3.00', '2020-07-06 12:40:50', '2020-07-22 14:02:23', '', 'test@gmail.com', 'U', '10.00'),
(877, 70, 26, 'Palak/ಪಾಲಾಕ್ ', '2.00', '3.00', '2020-07-06 12:41:13', '2020-07-22 14:02:23', '', 'test@gmail.com', 'U', '10.00'),
(878, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '26.00', '25.00', '2020-06-29 14:25:39', '2020-07-22 14:02:23', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(879, 13, 26, 'Tomato(Sour)/ಟೊಮ್ಯಾಟೊ ', '20.00', '100.00', '2020-06-29 14:25:12', '2020-07-22 14:02:23', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(880, 75, 26, 'Avare Kai/ಅವರೆಕಾಯಿ', '28.00', '5.00', '2020-07-12 15:04:39', '2020-07-22 20:34:12', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(881, 36, 26, 'Ivy gourd/ತೊಂಡೆ ಕಾಯಿ ', '22.00', '10.00', '2020-06-29 14:32:02', '2020-07-23 11:58:57', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(882, 34, 26, 'Lady\'s finger / Okra/ಬೆಂಡೇಕಾಯಿ  ', '18.00', '20.00', '2020-06-29 14:31:27', '2020-07-23 11:58:57', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(883, 35, 26, 'Raddish/ಮೂಲಂಗಿ ', '16.00', '20.00', '2020-06-29 14:31:43', '2020-07-23 11:58:57', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(884, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '34.00', '25.00', '2020-06-29 14:25:39', '2020-07-23 11:58:57', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(885, 44, 26, 'Drum Stick/ನುಗ್ಗೆ ಕಾಯಿ ', '55.00', '3.00', '2020-07-03 13:08:04', '2020-07-23 20:01:11', '', 'test@gmail.com', 'U', '10.00'),
(886, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '25.00', '5.00', '2020-06-29 14:21:54', '2020-07-24 15:24:10', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(887, 25, 26, 'Brinjal/ಬದನೇಕಾಯಿ (ಬಿಳಿ )', '18.00', '8.00', '2020-06-29 14:28:47', '2020-07-24 15:24:10', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(888, 31, 26, 'Cauliflower/ಹೂ ಕೋಸು', '21.00', '15.00', '2020-06-29 14:30:35', '2020-07-24 15:24:10', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '70.00'),
(889, 84, 26, 'Cucumber - British/ ಬ್ರಿಟಿಷ್ ಸೌತೆಕಾಯಿ', '28.00', '3.00', '2020-07-20 14:35:58', '2020-07-24 15:24:10', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(890, 28, 26, 'Cucumber(Green)/ಸೌತೇಕಾಯಿ ', '20.00', '10.00', '2020-06-29 14:29:29', '2020-07-24 15:24:10', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(891, 18, 26, 'Garlic/ಬೆಳ್ಳುಳ್ಳಿ  ', '80.00', '5.00', '2020-06-29 14:26:45', '2020-07-24 15:24:10', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(892, 20, 26, 'Green chilli/ಹಸಿರು ಮೆಣಸಿನಕಾಯಿ ', '30.00', '5.00', '2020-06-29 14:27:20', '2020-07-24 15:24:10', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(893, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '33.00', '25.00', '2020-06-29 14:25:39', '2020-07-24 15:24:10', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(894, 20, 26, 'Green chilli/ಹಸಿರು ಮೆಣಸಿನಕಾಯಿ ', '28.00', '5.00', '2020-06-29 14:27:20', '2020-07-24 15:29:13', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(895, 34, 26, 'Lady\'s finger / Okra/ಬೆಂಡೇಕಾಯಿ  ', '20.00', '20.00', '2020-06-29 14:31:27', '2020-07-24 15:29:13', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(896, 75, 26, 'Avare Kai/ಅವರೆಕಾಯಿ', '98.00', '5.00', '2020-07-12 15:04:39', '2020-07-25 21:40:47', 'test@gmail.com', 'abhijitjd003@gmail.com', 'U', '50.00'),
(897, 75, 26, 'Avare Kai/ಅವರೆಕಾಯಿ', '99.00', '5.00', '2020-07-12 15:04:39', '2020-07-25 21:41:02', 'test@gmail.com', 'abhijitjd003@gmail.com', 'U', '50.00'),
(898, 86, 27, 'Apple', '100.00', '10.00', '2020-07-25 21:42:01', '2020-07-25 21:42:15', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'D', '0.00'),
(899, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '35.00', '3.00', '2020-06-29 14:22:19', '2020-07-25 16:02:01', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(900, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '30.00', '5.00', '2020-06-29 14:21:54', '2020-07-25 16:02:01', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '120.00'),
(901, 61, 26, 'Beetroot/ಬೀಟ್ ರೂಟ್ ', '24.00', '3.00', '2020-07-05 14:55:16', '2020-07-25 16:02:01', '', 'test@gmail.com', 'U', '0.00'),
(902, 64, 26, 'Bitter gourd/ಹಾಗಲಕಾಯಿ ', '42.00', '3.00', '2020-07-05 19:39:44', '2020-07-25 16:02:01', '', 'test@gmail.com', 'U', '0.00'),
(903, 27, 26, 'Brinjal Round /ಬದನೇಕಾಯಿ ', '14.00', '5.00', '2020-06-29 14:29:17', '2020-07-25 16:02:01', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(904, 10, 26, 'Capsicum/ದಪ್ಪ ಮೆಣಸಿನಕಾಯಿ', '65.00', '8.00', '2020-06-29 14:22:59', '2020-07-25 16:02:01', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(905, 9, 26, 'Carrot/ಕ್ಯಾರೆಟ್ ', '34.00', '10.00', '2020-06-29 14:22:41', '2020-07-25 16:02:01', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(906, 34, 26, 'Lady\'s finger / Okra/ಬೆಂಡೇಕಾಯಿ  ', '19.00', '20.00', '2020-06-29 14:31:27', '2020-07-25 16:02:01', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(907, 11, 26, 'Potato/ಆಲೂ ಗೆಡ್ಡೆ ', '31.00', '7.00', '2020-06-29 14:23:51', '2020-07-25 16:02:01', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(908, 45, 26, 'Ridge Gourd/ಹೀರೆಕಾಯಿ ', '26.00', '3.00', '2020-07-03 13:08:28', '2020-07-25 16:02:01', '', 'test@gmail.com', 'U', '0.00'),
(909, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '28.00', '25.00', '2020-06-29 14:25:39', '2020-07-25 16:02:01', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(910, 76, 26, 'Bitter Gourd- White  / ಬಿಳಿ ಹಾಗಲಕಾಯಿ  ', '42.00', '3.00', '2020-07-12 15:27:22', '2020-07-26 13:55:28', 'test@gmail.com', 'test@gmail.com', 'U', '0.00'),
(911, 64, 26, 'Bitter gourd/ಹಾಗಲಕಾಯಿ ', '40.00', '3.00', '2020-07-05 19:39:44', '2020-07-26 13:55:28', '', 'test@gmail.com', 'U', '0.00'),
(912, 31, 26, 'Cauliflower/ಹೂ ಕೋಸು', '18.00', '15.00', '2020-06-29 14:30:35', '2020-07-26 13:55:28', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(913, 20, 26, 'Green chilli/ಹಸಿರು ಮೆಣಸಿನಕಾಯಿ ', '29.00', '5.00', '2020-06-29 14:27:20', '2020-07-26 13:55:28', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-30.00'),
(914, 36, 26, 'Ivy gourd/ತೊಂಡೆ ಕಾಯಿ ', '23.00', '10.00', '2020-06-29 14:32:02', '2020-07-26 13:55:28', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(915, 63, 26, 'Knol Khol /ನವಿಲುಕೋಸು ', '23.00', '5.00', '2020-07-05 19:38:57', '2020-07-26 13:55:28', '', 'test@gmail.com', 'U', '0.00'),
(916, 29, 26, 'Mangalore Cucumber/ಮಂಗಳೂರು ಸವತೆಕಾಯಿ ', '16.00', '13.00', '2020-06-29 14:30:03', '2020-07-26 13:55:28', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(917, 45, 26, 'Ridge Gourd/ಹೀರೆಕಾಯಿ ', '28.00', '3.00', '2020-07-03 13:08:28', '2020-07-26 13:55:28', '', 'test@gmail.com', 'U', '0.00'),
(918, 13, 26, 'Tomato(Sour)/ಟೊಮ್ಯಾಟೊ ', '22.00', '100.00', '2020-06-29 14:25:12', '2020-07-26 13:55:28', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-400.00'),
(919, 25, 26, 'Brinjal/ಬದನೇಕಾಯಿ (ಬಿಳಿ )', '16.00', '8.00', '2020-06-29 14:28:47', '2020-07-26 13:56:25', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(920, 25, 26, 'Brinjal/ಬದನೇಕಾಯಿ (ಬಿಳಿ )', '19.00', '8.00', '2020-06-29 14:28:47', '2020-07-26 14:10:06', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(921, 9, 26, 'Carrot/ಕ್ಯಾರೆಟ್ ', '36.00', '10.00', '2020-06-29 14:22:41', '2020-07-26 14:10:06', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-10.00'),
(922, 45, 26, 'Ridge Gourd/ಹೀರೆಕಾಯಿ ', '32.00', '3.00', '2020-07-03 13:08:28', '2020-07-26 14:10:06', '', 'test@gmail.com', 'U', '0.00'),
(923, 44, 26, 'Drum Stick/ನುಗ್ಗೆ ಕಾಯಿ ', '50.00', '3.00', '2020-07-03 13:08:04', '2020-07-26 14:17:18', '', 'test@gmail.com', 'U', '0.00'),
(924, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '31.00', '5.00', '2020-06-29 14:21:54', '2020-07-27 12:38:51', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '95.00'),
(925, 64, 26, 'Bitter gourd/ಹಾಗಲಕಾಯಿ ', '38.00', '3.00', '2020-07-05 19:39:44', '2020-07-27 12:38:51', '', 'test@gmail.com', 'U', '-3.00'),
(926, 27, 26, 'Brinjal Round /ಬದನೇಕಾಯಿ ', '14.50', '5.00', '2020-06-29 14:29:17', '2020-07-27 12:38:51', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'U', '-5.00'),
(927, 62, 26, 'Chayote Gourd/ಸೀಮೆ ಬದನೆ ', '24.00', '10.00', '2020-07-05 15:30:20', '2020-07-27 12:38:51', '', 'abhijitjd003@gmail.com', 'U', '-10.00'),
(928, 63, 26, 'Knol Khol /ನವಿಲುಕೋಸು ', '24.00', '5.00', '2020-07-05 19:38:57', '2020-07-27 12:38:51', '', 'test@gmail.com', 'U', '0.00'),
(929, 11, 26, 'Potato/ಆಲೂ ಗೆಡ್ಡೆ ', '32.00', '7.00', '2020-06-29 14:23:51', '2020-07-27 12:38:51', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(930, 35, 26, 'Raddish/ಮೂಲಂಗಿ ', '15.00', '20.00', '2020-06-29 14:31:43', '2020-07-27 12:38:51', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(931, 45, 26, 'Ridge Gourd/ಹೀರೆಕಾಯಿ ', '30.00', '3.00', '2020-07-03 13:08:28', '2020-07-27 12:38:51', '', 'test@gmail.com', 'U', '0.00'),
(932, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '32.00', '25.00', '2020-06-29 14:25:39', '2020-07-27 12:38:51', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(933, 13, 26, 'Tomato(Sour)/ಟೊಮ್ಯಾಟೊ ', '24.00', '100.00', '2020-06-29 14:25:12', '2020-07-27 12:38:51', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-400.00'),
(934, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '36.00', '5.00', '2020-06-29 14:21:54', '2020-07-27 12:40:47', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '95.00'),
(935, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '36.00', '3.00', '2020-06-29 14:22:19', '2020-07-27 12:40:57', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-75.00'),
(936, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '38.00', '3.00', '2020-06-29 14:22:19', '2020-07-28 14:30:52', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '119.00'),
(937, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '35.00', '3.00', '2020-06-29 14:21:54', '2020-07-28 14:30:52', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '85.00'),
(938, 64, 26, 'Bitter gourd/ಹಾಗಲಕಾಯಿ ', '34.00', '3.00', '2020-07-05 19:39:44', '2020-07-28 14:30:52', '', 'test@gmail.com', 'U', '-3.00'),
(939, 10, 26, 'Capsicum/ದಪ್ಪ ಮೆಣಸಿನಕಾಯಿ', '68.00', '3.00', '2020-06-29 14:22:59', '2020-07-28 14:30:52', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-16.00'),
(940, 9, 26, 'Carrot/ಕ್ಯಾರೆಟ್ ', '35.00', '3.00', '2020-06-29 14:22:41', '2020-07-28 14:30:52', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-10.00'),
(941, 31, 26, 'Cauliflower/ಹೂ ಕೋಸು', '20.00', '3.00', '2020-06-29 14:30:35', '2020-07-28 14:30:52', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(942, 84, 26, 'Cucumber - British/ ಬ್ರಿಟಿಷ್ ಸೌತೆಕಾಯಿ', '18.00', '3.00', '2020-07-20 14:35:58', '2020-07-28 14:30:52', 'test@gmail.com', 'test@gmail.com', 'U', '0.00'),
(943, 36, 26, 'Ivy gourd/ತೊಂಡೆ ಕಾಯಿ ', '24.00', '3.00', '2020-06-29 14:32:02', '2020-07-28 14:30:52', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(944, 63, 26, 'Knol Khol /ನವಿಲುಕೋಸು ', '22.00', '3.00', '2020-07-05 19:38:57', '2020-07-28 14:30:52', '', 'test@gmail.com', 'U', '0.00'),
(945, 11, 26, 'Potato/ಆಲೂ ಗೆಡ್ಡೆ ', '31.50', '3.00', '2020-06-29 14:23:51', '2020-07-28 14:30:52', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(946, 45, 26, 'Ridge Gourd/ಹೀರೆಕಾಯಿ ', '27.00', '3.00', '2020-07-03 13:08:28', '2020-07-28 14:30:52', '', 'test@gmail.com', 'U', '0.00'),
(947, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '30.00', '3.00', '2020-06-29 14:25:39', '2020-07-28 14:30:52', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '135.00'),
(948, 13, 26, 'Tomato(Sour)/ಟೊಮ್ಯಾಟೊ ', '18.00', '5.00', '2020-06-29 14:25:12', '2020-07-28 14:30:52', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-400.00'),
(949, 13, 26, 'Tomato(Sour)/ಟೊಮ್ಯಾಟೊ ', '21.00', '5.00', '2020-06-29 14:25:12', '2020-07-28 14:38:00', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-400.00'),
(950, 61, 26, 'Beetroot/ಬೀಟ್ ರೂಟ್ ', '26.00', '3.00', '2020-07-05 14:55:16', '2020-07-28 14:44:19', '', 'test@gmail.com', 'U', '-18.00'),
(951, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '45.00', '3.00', '2020-06-29 14:22:19', '2020-07-29 14:42:38', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '116.00'),
(952, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '40.00', '3.00', '2020-06-29 14:21:54', '2020-07-29 14:42:38', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '85.00'),
(953, 10, 26, 'Capsicum/ದಪ್ಪ ಮೆಣಸಿನಕಾಯಿ', '69.00', '3.00', '2020-06-29 14:22:59', '2020-07-29 14:42:38', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-16.00'),
(954, 31, 26, 'Cauliflower/ಹೂ ಕೋಸು', '21.00', '3.00', '2020-06-29 14:30:35', '2020-07-29 14:42:38', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(955, 84, 26, 'Cucumber - British/ ಬ್ರಿಟಿಷ್ ಸೌತೆಕಾಯಿ', '20.00', '3.00', '2020-07-20 14:35:58', '2020-07-29 14:42:38', 'test@gmail.com', 'test@gmail.com', 'U', '0.00'),
(956, 36, 26, 'Ivy gourd/ತೊಂಡೆ ಕಾಯಿ ', '26.00', '3.00', '2020-06-29 14:32:02', '2020-07-29 14:42:38', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(957, 73, 26, 'Menthya Soppu/ಮೆಂತ್ಯ ಸೊಪ್ಪು ', '4.00', '1.00', '2020-07-09 14:25:43', '2020-07-29 14:42:38', 'test@gmail.com', 'test@gmail.com', 'U', '0.00'),
(958, 11, 26, 'Potato/ಆಲೂ ಗೆಡ್ಡೆ ', '32.00', '3.00', '2020-06-29 14:23:51', '2020-07-29 14:42:38', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(959, 65, 26, 'Pumpkin(Green)/ಕುಂಬಳಕಾಯಿ ', '11.00', '5.00', '2020-07-05 19:44:05', '2020-07-29 14:42:38', '', 'test@gmail.com', 'U', '0.00'),
(960, 28, 26, 'Cucumber(Green)/ಸೌತೇಕಾಯಿ ', '18.00', '3.00', '2020-06-29 14:29:29', '2020-07-29 14:43:34', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(961, 11, 26, 'Potato/ಆಲೂ ಗೆಡ್ಡೆ ', '33.00', '3.00', '2020-06-29 14:23:51', '2020-07-29 14:51:05', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(962, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '43.00', '3.00', '2020-06-29 14:22:19', '2020-07-30 10:28:40', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '35.00'),
(963, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '0.00', '3.00', '2020-06-29 14:22:19', '2020-07-30 10:57:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '35.00'),
(964, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '38.00', '3.00', '2020-06-29 14:21:54', '2020-07-30 10:57:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '49.00'),
(965, 27, 26, 'Brinjal Round /ಬದನೇಕಾಯಿ ', '14.00', '3.00', '2020-06-29 14:29:17', '2020-07-30 10:57:41', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'U', '-5.00'),
(966, 25, 26, 'Brinjal/ಬದನೇಕಾಯಿ (ಬಿಳಿ )', '18.00', '3.00', '2020-06-29 14:28:47', '2020-07-30 10:57:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-6.00'),
(967, 30, 26, 'Cabbage/ಎಲೆ ಕೋಸು', '11.00', '3.00', '2020-06-29 14:30:17', '2020-07-30 10:57:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '85.00'),
(968, 84, 26, 'Cucumber - British/ ಬ್ರಿಟಿಷ್ ಸೌತೆಕಾಯಿ', '25.00', '3.00', '2020-07-20 14:35:58', '2020-07-30 10:57:41', 'test@gmail.com', 'test@gmail.com', 'U', '0.00'),
(969, 20, 26, 'Green chilli/ಹಸಿರು ಮೆಣಸಿನಕಾಯಿ ', '32.00', '1.00', '2020-06-29 14:27:20', '2020-07-30 10:57:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-30.00'),
(970, 34, 26, 'Lady\'s finger / Okra/ಬೆಂಡೇಕಾಯಿ  ', '20.00', '3.00', '2020-06-29 14:31:27', '2020-07-30 10:57:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(971, 29, 26, 'Mangalore Cucumber/ಮಂಗಳೂರು ಸವತೆಕಾಯಿ ', '19.00', '3.00', '2020-06-29 14:30:03', '2020-07-30 10:57:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(972, 73, 26, 'Menthya Soppu/ಮೆಂತ್ಯ ಸೊಪ್ಪು ', '5.00', '1.00', '2020-07-09 14:25:43', '2020-07-30 10:57:41', 'test@gmail.com', 'test@gmail.com', 'U', '-6.00'),
(973, 65, 26, 'Pumpkin(Green)/ಕುಂಬಳಕಾಯಿ ', '12.00', '5.00', '2020-07-05 19:44:05', '2020-07-30 10:57:41', '', 'test@gmail.com', 'U', '-10.00'),
(974, 35, 26, 'Raddish/ಮೂಲಂಗಿ ', '16.00', '3.00', '2020-06-29 14:31:43', '2020-07-30 10:57:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(975, 45, 26, 'Ridge Gourd/ಹೀರೆಕಾಯಿ ', '28.00', '3.00', '2020-07-03 13:08:28', '2020-07-30 10:57:41', '', 'test@gmail.com', 'U', '0.00'),
(976, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '32.00', '3.00', '2020-06-29 14:25:39', '2020-07-30 10:57:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '129.00'),
(977, 13, 26, 'Tomato(Sour)/ಟೊಮ್ಯಾಟೊ ', '20.00', '5.00', '2020-06-29 14:25:12', '2020-07-30 10:57:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-410.00'),
(978, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '30.00', '3.00', '2020-06-29 14:21:54', '2020-07-30 11:10:30', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '49.00'),
(979, 27, 26, 'Brinjal Round /ಬದನೇಕಾಯಿ ', '16.00', '3.00', '2020-06-29 14:29:17', '2020-07-30 11:10:30', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'U', '-5.00'),
(980, 25, 26, 'Brinjal/ಬದನೇಕಾಯಿ (ಬಿಳಿ )', '20.00', '3.00', '2020-06-29 14:28:47', '2020-07-30 11:10:30', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-6.00'),
(981, 9, 26, 'Carrot/ಕ್ಯಾರೆಟ್ ', '36.00', '3.00', '2020-06-29 14:22:41', '2020-07-30 11:10:30', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-10.00'),
(982, 19, 26, 'Ginger/ಶುಂಠಿ', '60.00', '2.00', '2020-06-29 14:27:04', '2020-07-30 11:10:30', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(983, 45, 26, 'Ridge Gourd/ಹೀರೆಕಾಯಿ ', '25.00', '3.00', '2020-07-03 13:08:28', '2020-07-30 11:10:30', '', 'test@gmail.com', 'U', '0.00'),
(984, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '45.00', '3.00', '2020-06-29 14:22:19', '2020-07-31 12:11:44', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '29.00'),
(985, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '32.00', '3.00', '2020-06-29 14:21:54', '2020-07-31 12:11:44', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '49.00'),
(986, 64, 26, 'Bitter gourd/ಹಾಗಲಕಾಯಿ ', '38.00', '3.00', '2020-07-05 19:39:44', '2020-07-31 12:11:44', '', 'test@gmail.com', 'U', '-18.00'),
(987, 27, 26, 'Brinjal Round /ಬದನೇಕಾಯಿ ', '17.00', '3.00', '2020-06-29 14:29:17', '2020-07-31 12:11:44', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'U', '-5.00'),
(988, 10, 26, 'Capsicum/ದಪ್ಪ ಮೆಣಸಿನಕಾಯಿ', '68.00', '3.00', '2020-06-29 14:22:59', '2020-07-31 12:11:44', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-16.00'),
(989, 31, 26, 'Cauliflower/ಹೂ ಕೋಸು', '22.00', '3.00', '2020-06-29 14:30:35', '2020-07-31 12:11:44', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(990, 84, 26, 'Cucumber - British/ ಬ್ರಿಟಿಷ್ ಸೌತೆಕಾಯಿ', '18.00', '3.00', '2020-07-20 14:35:58', '2020-07-31 12:11:44', 'test@gmail.com', 'test@gmail.com', 'U', '0.00'),
(991, 20, 26, 'Green chilli/ಹಸಿರು ಮೆಣಸಿನಕಾಯಿ ', '28.00', '1.00', '2020-06-29 14:27:20', '2020-07-31 12:11:44', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-30.00'),
(992, 21, 26, 'Lemon/ನಿಂಬೆ ಹಣ್ಣು ', '50.00', '2.00', '2020-06-29 14:27:39', '2020-07-31 12:11:44', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(993, 29, 26, 'Mangalore Cucumber/ಮಂಗಳೂರು ಸವತೆಕಾಯಿ ', '17.00', '3.00', '2020-06-29 14:30:03', '2020-07-31 12:11:44', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(994, 30, 26, 'Cabbage/ಎಲೆ ಕೋಸು', '12.00', '3.00', '2020-06-29 14:30:17', '2020-07-31 12:12:24', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '85.00'),
(995, 20, 26, 'Green chilli/ಹಸಿರು ಮೆಣಸಿನಕಾಯಿ ', '32.00', '1.00', '2020-06-29 14:27:20', '2020-07-31 12:13:12', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-30.00'),
(996, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '48.00', '3.00', '2020-06-29 14:22:19', '2020-08-01 15:06:27', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '29.00'),
(997, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '33.00', '3.00', '2020-06-29 14:21:54', '2020-08-01 15:06:27', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '49.00'),
(998, 10, 26, 'Capsicum/ದಪ್ಪ ಮೆಣಸಿನಕಾಯಿ', '69.00', '3.00', '2020-06-29 14:22:59', '2020-08-01 15:06:27', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-16.00'),
(999, 9, 26, 'Carrot/ಕ್ಯಾರೆಟ್ ', '38.00', '3.00', '2020-06-29 14:22:41', '2020-08-01 15:06:27', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-10.00'),
(1000, 31, 26, 'Cauliflower/ಹೂ ಕೋಸು', '23.00', '3.00', '2020-06-29 14:30:35', '2020-08-01 15:06:27', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(1001, 20, 26, 'Green chilli/ಹಸಿರು ಮೆಣಸಿನಕಾಯಿ ', '30.00', '1.00', '2020-06-29 14:27:20', '2020-08-01 15:06:27', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-30.00'),
(1002, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '30.00', '3.00', '2020-06-29 14:25:39', '2020-08-01 15:06:27', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '129.00'),
(1003, 9, 26, 'Carrot/ಕ್ಯಾರೆಟ್ ', '36.00', '3.00', '2020-06-29 14:22:41', '2020-08-02 11:12:49', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-13.00'),
(1004, 31, 26, 'Cauliflower/ಹೂ ಕೋಸು', '21.00', '3.00', '2020-06-29 14:30:35', '2020-08-02 11:12:49', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(1005, 28, 26, 'Cucumber(Green)/ಸೌತೇಕಾಯಿ ', '25.00', '3.00', '2020-06-29 14:29:29', '2020-08-02 11:12:49', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(1006, 20, 26, 'Green chilli/ಹಸಿರು ಮೆಣಸಿನಕಾಯಿ ', '28.00', '1.00', '2020-06-29 14:27:20', '2020-08-02 11:12:49', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-30.00'),
(1007, 34, 26, 'Lady\'s finger / Okra/ಬೆಂಡೇಕಾಯಿ  ', '18.00', '3.00', '2020-06-29 14:31:27', '2020-08-02 11:12:49', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(1008, 13, 26, 'Tomato(Sour)/ಟೊಮ್ಯಾಟೊ ', '18.00', '5.00', '2020-06-29 14:25:12', '2020-08-02 11:12:49', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-410.00'),
(1009, 25, 26, 'Brinjal/ಬದನೇಕಾಯಿ (ಬಿಳಿ )', '19.00', '3.00', '2020-06-29 14:28:47', '2020-08-02 11:23:21', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-6.00'),
(1010, 75, 26, 'Avare Kai/ಅವರೆಕಾಯಿ', '98.00', '3.00', '2020-07-12 15:04:39', '2020-08-02 15:08:50', 'test@gmail.com', 'abhijitjd003@gmail.com', 'U', '-20.00'),
(1011, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '30.00', '3.00', '2020-06-29 14:21:54', '2020-08-02 15:08:50', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '13.00'),
(1012, 64, 26, 'Bitter gourd/ಹಾಗಲಕಾಯಿ ', '40.00', '3.00', '2020-07-05 19:39:44', '2020-08-02 15:08:50', '', 'test@gmail.com', 'U', '-24.00'),
(1013, 30, 26, 'Cabbage/ಎಲೆ ಕೋಸು', '11.00', '3.00', '2020-06-29 14:30:17', '2020-08-02 15:08:50', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '82.00'),
(1014, 20, 26, 'Green chilli/ಹಸಿರು ಮೆಣಸಿನಕಾಯಿ ', '33.00', '1.00', '2020-06-29 14:27:20', '2020-08-02 15:08:50', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-30.00'),
(1015, 36, 26, 'Ivy gourd/ತೊಂಡೆ ಕಾಯಿ ', '25.00', '3.00', '2020-06-29 14:32:02', '2020-08-02 15:08:50', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(1016, 34, 26, 'Lady\'s finger / Okra/ಬೆಂಡೇಕಾಯಿ  ', '15.00', '3.00', '2020-06-29 14:31:27', '2020-08-02 15:08:50', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(1017, 13, 26, 'Tomato(Sour)/ಟೊಮ್ಯಾಟೊ ', '19.00', '5.00', '2020-06-29 14:25:12', '2020-08-02 15:08:50', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-410.00'),
(1018, 75, 26, 'Avare Kai/ಅವರೆಕಾಯಿ', '36.00', '3.00', '2020-07-12 15:04:39', '2020-08-02 15:27:44', 'test@gmail.com', 'test@gmail.com', 'D', '-20.00'),
(1019, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '45.00', '1.00', '2020-06-29 14:22:19', '2020-08-03 10:43:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(1020, 10, 26, 'Capsicum/ದಪ್ಪ ಮೆಣಸಿನಕಾಯಿ', '68.00', '1.00', '2020-06-29 14:22:59', '2020-08-03 10:43:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(1021, 9, 26, 'Carrot/ಕ್ಯಾರೆಟ್ ', '38.00', '1.00', '2020-06-29 14:22:41', '2020-08-03 10:43:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(1022, 31, 26, 'Cauliflower/ಹೂ ಕೋಸು', '22.00', '1.00', '2020-06-29 14:30:35', '2020-08-03 10:43:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(1023, 67, 26, 'Coriander leaves/ಕೊತ್ತಂಬರಿ ಸೊಪ್ಪು', '4.00', '1.00', '2020-07-06 12:39:51', '2020-08-03 10:43:41', '', 'test@gmail.com', 'U', '0.00'),
(1024, 44, 26, 'Drum Stick/ನುಗ್ಗೆ ಕಾಯಿ ', '46.00', '1.00', '2020-07-03 13:08:04', '2020-08-03 10:43:41', '', 'test@gmail.com', 'U', '0.00'),
(1025, 20, 26, 'Green chilli/ಹಸಿರು ಮೆಣಸಿನಕಾಯಿ ', '32.00', '1.00', '2020-06-29 14:27:20', '2020-08-03 10:43:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(1026, 29, 26, 'Mangalore Cucumber/ಮಂಗಳೂರು ಸವತೆಕಾಯಿ ', '18.00', '1.00', '2020-06-29 14:30:03', '2020-08-03 10:43:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(1027, 16, 26, 'Onion Small /ಸಣ್ಣ ಈರುಳ್ಳಿ  ', '42.00', '1.00', '2020-06-29 14:26:10', '2020-08-03 10:43:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(1028, 35, 26, 'Raddish/ಮೂಲಂಗಿ ', '15.00', '1.00', '2020-06-29 14:31:43', '2020-08-03 10:43:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(1029, 71, 26, 'Sabsige Soppu / ಸಬ್ಸಿಗೆ ಸೊಪ್ಪು ', '2.50', '1.00', '2020-07-06 12:41:52', '2020-08-03 10:43:41', '', 'test@gmail.com', 'U', '0.00'),
(1030, 9, 26, 'Carrot/ಕ್ಯಾರೆಟ್ ', '0.00', '1.00', '2020-06-29 14:22:41', '2020-08-03 10:45:24', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(1031, 9, 26, 'Carrot/ಕ್ಯಾರೆಟ್ ', '42.00', '1.00', '2020-06-29 14:22:41', '2020-08-03 14:14:28', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-20.00'),
(1032, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '33.00', '1.00', '2020-06-29 14:21:54', '2020-08-04 11:24:33', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-46.00'),
(1033, 30, 26, 'Cabbage/ಎಲೆ ಕೋಸು', '12.00', '1.00', '2020-06-29 14:30:17', '2020-08-04 11:24:33', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-18.00'),
(1034, 9, 26, 'Carrot/ಕ್ಯಾರೆಟ್ ', '40.00', '1.00', '2020-06-29 14:22:41', '2020-08-04 11:24:33', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-90.00'),
(1035, 31, 26, 'Cauliflower/ಹೂ ಕೋಸು', '20.00', '1.00', '2020-06-29 14:30:35', '2020-08-04 11:24:33', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-33.00'),
(1036, 67, 26, 'Coriander leaves/ಕೊತ್ತಂಬರಿ ಸೊಪ್ಪು', '4.50', '1.00', '2020-07-06 12:39:51', '2020-08-04 11:24:33', '', 'test@gmail.com', 'U', '-100.00'),
(1037, 34, 26, 'Lady\'s finger / Okra/ಬೆಂಡೇಕಾಯಿ  ', '18.00', '1.00', '2020-06-29 14:31:27', '2020-08-04 11:24:34', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-58.00'),
(1038, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '28.00', '1.00', '2020-06-29 14:25:39', '2020-08-04 11:24:34', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-76.00'),
(1039, 13, 26, 'Tomato(Sour)/ಟೊಮ್ಯಾಟೊ ', '18.00', '1.00', '2020-06-29 14:25:12', '2020-08-04 11:24:34', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-85.00'),
(1040, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '22.00', '1.00', '2020-06-29 14:25:39', '2020-08-04 11:35:26', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-76.00'),
(1041, 13, 26, 'Tomato(Sour)/ಟೊಮ್ಯಾಟೊ ', '16.00', '1.00', '2020-06-29 14:25:12', '2020-08-04 11:35:26', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-85.00'),
(1042, 75, 26, 'Avare Kai/ಅವರೆಕಾಯಿ', '36.00', '1.00', '2020-07-12 15:04:39', '2020-08-05 00:00:07', 'test@gmail.com', 'abhijitjd003@gmail.com', 'U', '0.00'),
(1043, 77, 26, 'Cluster Beans / ಗೋರಿಕಾಯಿ ', '22.00', '1.00', '2020-07-12 15:42:27', '2020-08-05 00:00:07', 'test@gmail.com', 'test@gmail.com', 'U', '2.00'),
(1044, 42, 26, 'Halasande/ಹಲಸಂದೆ (ಉದ್ದ ) ', '27.00', '1.00', '2020-07-03 08:31:50', '2020-08-05 00:00:07', '', 'test@gmail.com', 'U', '0.00'),
(1045, 80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '35.00', '1.00', '2020-07-17 22:21:11', '2020-08-05 13:08:44', 'test@gmail.com', 'md@spicetrip.com', 'D', '0.00'),
(1046, 79, 27, 'Banana(Yellaki) / ಬಾಳೆಹಣ್ಣು', '25.00', '1.00', '2020-07-17 22:20:12', '2020-08-05 13:08:58', 'test@gmail.com', 'md@spicetrip.com', 'D', '0.00'),
(1047, 61, 26, 'Beetroot/ಬೀಟ್ ರೂಟ್ ', '25.00', '1.00', '2020-07-05 14:55:16', '2020-08-05 13:15:50', '', 'test@gmail.com', 'U', '-59.00'),
(1048, 26, 26, 'Brinjal Black /ಬದನೇಕಾಯಿ', '32.00', '1.00', '2020-06-29 14:29:04', '2020-08-05 13:15:50', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-6.00'),
(1049, 30, 26, 'Cabbage/ಎಲೆ ಕೋಸು', '11.00', '1.00', '2020-06-29 14:30:17', '2020-08-05 13:15:50', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-24.00'),
(1050, 10, 26, 'Capsicum/ದಪ್ಪ ಮೆಣಸಿನಕಾಯಿ', '65.00', '1.00', '2020-06-29 14:22:59', '2020-08-05 13:15:50', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '2.00'),
(1051, 62, 26, 'Chayote Gourd/ಸೀಮೆ ಬದನೆ ', '26.00', '1.00', '2020-07-05 15:30:20', '2020-08-05 13:15:50', '', 'abhijitjd003@gmail.com', 'U', '-86.00'),
(1052, 83, 26, 'Chilli Bajji', '50.00', '1.00', '2020-07-19 14:23:45', '2020-08-05 13:15:50', 'test@gmail.com', 'test@gmail.com', 'U', '0.00'),
(1053, 29, 26, 'Mangalore Cucumber/ಮಂಗಳೂರು ಸವತೆಕಾಯಿ ', '15.00', '1.00', '2020-06-29 14:30:03', '2020-08-05 13:15:50', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-39.00'),
(1054, 65, 26, 'Pumpkin(Green)/ಕುಂಬಳಕಾಯಿ ', '11.00', '1.00', '2020-07-05 19:44:05', '2020-08-05 13:15:50', '', 'test@gmail.com', 'U', '-31.00');
INSERT INTO `ProductHistory` (`ProductHistId`, `ProductId`, `CategoryId`, `Name`, `RatePerKG`, `MinPurchaseQuantity`, `CreatedDateTime`, `UpdatedDateTime`, `CreatedUserId`, `UpdatedUserId`, `StatusCode`, `TotalStock`) VALUES
(1055, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '21.00', '1.00', '2020-06-29 14:25:39', '2020-08-05 13:15:50', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-121.00'),
(1056, 13, 26, 'Tomato(Sour)/ಟೊಮ್ಯಾಟೊ ', '15.00', '1.00', '2020-06-29 14:25:12', '2020-08-05 13:15:50', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-138.00'),
(1057, 88, 26, 'Ash Gourd', '30.00', '1.00', '2020-08-04 19:08:20', '2020-08-05 13:17:41', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 'U', '0.00'),
(1058, 75, 26, 'Avare Kai/ಅವರೆಕಾಯಿ', '20.00', '1.00', '2020-07-12 15:04:39', '2020-08-05 13:17:42', 'test@gmail.com', 'abhijitjd003@gmail.com', 'U', '0.00'),
(1059, 87, 26, 'Beans - Solar', '25.00', '1.00', '2020-08-04 18:59:14', '2020-08-05 13:18:38', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 'U', '0.00'),
(1060, 26, 26, 'Brinjal Black /ಬದನೇಕಾಯಿ', '30.00', '1.00', '2020-06-29 14:29:04', '2020-08-05 13:20:02', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-6.00'),
(1061, 25, 26, 'Brinjal/ಬದನೇಕಾಯಿ (ಬಿಳಿ )', '16.00', '1.00', '2020-06-29 14:28:47', '2020-08-05 13:20:02', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-59.00'),
(1062, 25, 26, 'Brinjal/ಬದನೇಕಾಯಿ (ಬಿಳಿ )', '20.00', '1.00', '2020-06-29 14:28:47', '2020-08-05 13:20:23', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-59.00'),
(1063, 76, 26, 'Bitter Gourd- White  / ಬಿಳಿ ಹಾಗಲಕಾಯಿ  ', '0.00', '1.00', '2020-07-12 15:27:22', '2020-08-05 19:04:11', 'test@gmail.com', 'test@gmail.com', 'U', '0.00'),
(1064, 47, 26, 'Bottle gourd/ಸೋರೆಕಾಯಿ', '12.00', '1.00', '2020-07-03 13:09:17', '2020-08-05 19:04:11', '', 'test@gmail.com', 'U', '-6.00'),
(1065, 84, 26, 'Cucumber - British/ ಬ್ರಿಟಿಷ್ ಸೌತೆಕಾಯಿ', '20.00', '1.00', '2020-07-20 14:35:58', '2020-08-05 19:04:11', 'test@gmail.com', 'test@gmail.com', 'U', '0.00'),
(1066, 42, 26, 'Halasande/ಹಲಸಂದೆ (ಉದ್ದ ) ', '36.00', '1.00', '2020-07-03 08:31:50', '2020-08-05 19:04:11', '', 'test@gmail.com', 'U', '0.00'),
(1067, 47, 26, 'Bottle gourd/ಸೋರೆಕಾಯಿ', '16.00', '1.00', '2020-07-03 13:09:17', '2020-08-05 19:56:06', '', 'test@gmail.com', 'U', '-6.00'),
(1068, 46, 26, 'Snake gourd/ಪಡವಲಕಾಯಿ  ', '16.00', '1.00', '2020-07-03 13:08:54', '2020-08-05 19:56:06', '', 'test@gmail.com', 'U', '-6.00'),
(1069, 7, 26, 'Beans / ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '30.00', '1.00', '2020-06-29 14:21:54', '2020-08-06 15:22:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-92.00'),
(1070, 8, 26, 'Beans Ooty / ಬೀನ್ಸ್ (ಊಟಿ)', '40.00', '1.00', '2020-06-29 14:22:19', '2020-08-06 15:22:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-14.00'),
(1071, 61, 26, 'Beetroot / ಬೀಟ್ ರೂಟ್ ', '22.00', '1.00', '2020-07-05 14:55:16', '2020-08-06 15:22:41', '', 'test@gmail.com', 'U', '-71.00'),
(1072, 25, 26, 'Brinjal / ಬದನೇಕಾಯಿ (ಬಿಳಿ )', '16.00', '1.00', '2020-06-29 14:28:47', '2020-08-06 15:22:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-109.00'),
(1073, 31, 26, 'Cauliflower / ಹೂ ಕೋಸು', '22.00', '1.00', '2020-06-29 14:30:35', '2020-08-06 15:22:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-96.00'),
(1074, 67, 26, 'Coriander Leaves / ಕೊತ್ತಂಬರಿ ಸೊಪ್ಪು', '4.00', '1.00', '2020-07-06 12:39:51', '2020-08-06 15:22:41', '', 'test@gmail.com', 'U', '-310.00'),
(1075, 34, 26, 'Lady\'s Finger / Okra / ಬೆಂಡೇಕಾಯಿ  ', '16.00', '1.00', '2020-06-29 14:31:27', '2020-08-06 15:22:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-149.00'),
(1076, 29, 26, 'Mangalore Cucumber / ಮಂಗಳೂರು ಸವತೆಕಾಯಿ ', '16.00', '1.00', '2020-06-29 14:30:03', '2020-08-06 15:22:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-48.00'),
(1077, 73, 26, 'Menthya Soppu / ಮೆಂತ್ಯ ಸೊಪ್ಪು ', '4.50', '1.00', '2020-07-09 14:25:43', '2020-08-06 15:22:41', 'test@gmail.com', 'test@gmail.com', 'U', '-60.00'),
(1078, 35, 26, 'Raddish / ಮೂಲಂಗಿ ', '16.00', '1.00', '2020-06-29 14:31:43', '2020-08-06 15:22:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-78.00'),
(1079, 14, 26, 'Tomato (Jamoon) / ಟೊಮ್ಯಾಟೊ', '22.00', '1.00', '2020-06-29 14:25:39', '2020-08-06 15:22:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-146.00'),
(1080, 13, 26, 'Tomato (Sour) / ಟೊಮ್ಯಾಟೊ ', '18.00', '1.00', '2020-06-29 14:25:12', '2020-08-06 15:22:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-258.00'),
(1081, 75, 26, 'Avare Kai / ಅವರೆಕಾಯಿ', '26.00', '1.00', '2020-07-12 15:04:39', '2020-08-06 20:11:51', 'test@gmail.com', 'test@gmail.com', 'U', '0.00'),
(1082, 77, 26, 'Cluster Beans / ಗೋರಿಕಾಯಿ ', '26.00', '1.00', '2020-07-12 15:42:27', '2020-08-06 20:11:51', 'test@gmail.com', 'test@gmail.com', 'U', '2.00'),
(1083, 42, 26, 'Halasande / ಹಲಸಂದೆ (ಉದ್ದ ) ', '30.00', '1.00', '2020-07-03 08:31:50', '2020-08-06 20:11:51', '', 'test@gmail.com', 'U', '0.00'),
(1084, 78, 26, 'Avare Kai - Chapparada / ಚಪ್ಪರದ ಅವರೆಕಾಯಿ', '33.00', '1.00', '2020-07-13 15:20:54', '2020-08-07 08:44:24', 'test@gmail.com', 'md@spicetrip.com', 'D', '0.00'),
(1085, 87, 26, 'Beans - Solar / ಬೀನ್ಸ್', '30.00', '1.00', '2020-08-04 18:59:14', '2020-08-07 08:44:33', 'kanthraj@dotangle.com', 'md@spicetrip.com', 'D', '-6.00'),
(1086, 7, 26, 'Beans / ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '33.00', '1.00', '2020-06-29 14:21:54', '2020-08-07 11:58:46', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-119.00'),
(1087, 8, 26, 'Beans Ooty / ಬೀನ್ಸ್ (ಊಟಿ)', '45.00', '1.00', '2020-06-29 14:22:19', '2020-08-07 11:58:46', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-36.00'),
(1088, 61, 26, 'Beetroot / ಬೀಟ್ ರೂಟ್ ', '24.00', '1.00', '2020-07-05 14:55:16', '2020-08-07 11:58:46', '', 'test@gmail.com', 'U', '-81.00'),
(1089, 34, 26, 'Bendekayi / Okra / ಬೆಂಡೇಕಾಯಿ  ', '17.00', '1.00', '2020-06-29 14:31:27', '2020-08-07 11:58:46', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'U', '-162.00'),
(1090, 83, 26, 'Chilli Bajji / ಚಿಲ್ಲಿ ಬಜ್ಜಿ', '55.00', '1.00', '2020-07-19 14:23:45', '2020-08-07 11:58:46', 'test@gmail.com', 'test@gmail.com', 'U', '-40.00'),
(1091, 67, 26, 'Coriander Leaves / ಕೊತ್ತಂಬರಿ ಸೊಪ್ಪು', '4.50', '1.00', '2020-07-06 12:39:51', '2020-08-07 11:58:46', '', 'test@gmail.com', 'U', '-403.00'),
(1092, 77, 26, 'Gorikayi / ಗೋರಿಕಾಯಿ ', '28.00', '1.00', '2020-07-12 15:42:27', '2020-08-07 11:58:46', 'test@gmail.com', 'md@spicetrip.com', 'U', '-4.00'),
(1093, 64, 26, 'Hagalakai Green / ಹಾಗಲಕಾಯಿ ', '39.00', '1.00', '2020-07-05 19:39:44', '2020-08-07 11:58:46', '', 'md@spicetrip.com', 'U', '-87.00'),
(1094, 76, 26, 'Hagalakayi - White  / ಬಿಳಿ ಹಾಗಲಕಾಯಿ  ', '39.00', '1.00', '2020-07-12 15:27:22', '2020-08-07 11:58:46', 'test@gmail.com', 'md@spicetrip.com', 'U', '-3.00'),
(1095, 44, 26, 'Nuggekayi / ನುಗ್ಗೆ ಕಾಯಿ ', '50.00', '1.00', '2020-07-03 13:08:04', '2020-08-07 11:58:47', '', 'md@spicetrip.com', 'U', '-65.00'),
(1096, 16, 26, 'Onion Small / ಸಣ್ಣ ಈರುಳ್ಳಿ  ', '48.00', '1.00', '2020-06-29 14:26:10', '2020-08-07 11:58:47', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-35.00'),
(1097, 36, 26, 'Tondekayi / ತೊಂಡೆ ಕಾಯಿ ', '24.00', '1.00', '2020-06-29 14:32:02', '2020-08-07 11:58:47', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'U', '-59.00'),
(1098, 68, 26, 'Curry Leaves / ಕರಿಬೇವು   ', '2.00', '1.00', '2020-07-06 12:40:25', '2020-08-07 12:00:27', '', 'test@gmail.com', 'U', '-130.00'),
(1099, 61, 26, 'Beetroot / ಬೀಟ್ ರೂಟ್ ', '22.00', '1.00', '2020-07-05 14:55:16', '2020-08-07 13:17:39', '', 'test@gmail.com', 'U', '-81.00'),
(1100, 34, 26, 'Bendekayi / Okra / ಬೆಂಡೇಕಾಯಿ  ', '18.00', '1.00', '2020-06-29 14:31:27', '2020-08-07 13:17:39', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'U', '-162.00'),
(1101, 25, 26, 'Brinjal / ಬದನೇಕಾಯಿ (ಬಿಳಿ )', '18.00', '1.00', '2020-06-29 14:28:47', '2020-08-07 13:17:39', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-124.00'),
(1102, 10, 26, 'Capsicum / ದಪ್ಪ ಮೆಣಸಿನಕಾಯಿ', '60.00', '1.00', '2020-06-29 14:22:59', '2020-08-07 13:17:39', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-38.00'),
(1103, 83, 26, 'Chilli Bajji / ಚಿಲ್ಲಿ ಬಜ್ಜಿ', '60.00', '1.00', '2020-07-19 14:23:45', '2020-08-07 13:17:39', 'test@gmail.com', 'test@gmail.com', 'U', '-40.00'),
(1104, 63, 26, 'Knol Khol / ನವಿಲುಕೋಸು ', '24.00', '1.00', '2020-07-05 19:38:57', '2020-08-07 13:17:39', '', 'test@gmail.com', 'U', '-102.00'),
(1105, 46, 26, 'Padavalakai / ಪಡವಲಕಾಯಿ  ', '18.00', '1.00', '2020-07-03 13:08:54', '2020-08-07 13:17:39', '', 'md@spicetrip.com', 'U', '-6.00'),
(1106, 35, 26, 'Raddish / ಮೂಲಂಗಿ ', '17.00', '1.00', '2020-06-29 14:31:43', '2020-08-07 13:17:39', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-96.00'),
(1107, 62, 26, 'Seemebadne / ಸೀಮೆ ಬದನೆ ', '22.00', '1.00', '2020-07-05 15:30:20', '2020-08-07 13:17:39', '', 'md@spicetrip.com', 'U', '-113.00'),
(1108, 47, 26, 'Sorekai / ಸೋರೆಕಾಯಿ', '18.00', '1.00', '2020-07-03 13:09:17', '2020-08-07 13:17:39', '', 'md@spicetrip.com', 'U', '-21.00'),
(1109, 8, 26, 'Beans Ooty / ಬೀನ್ಸ್ (ಊಟಿ)', '48.00', '1.00', '2020-06-29 14:22:19', '2020-08-07 13:20:05', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-36.00'),
(1110, 7, 26, 'Beans / ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '38.00', '1.00', '2020-06-29 14:21:54', '2020-08-07 13:27:21', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-119.00'),
(1111, 8, 26, 'Beans Ooty / ಬೀನ್ಸ್ (ಊಟಿ)', '44.00', '1.00', '2020-06-29 14:22:19', '2020-08-07 13:27:51', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-36.00'),
(1112, 19, 26, 'Ginger / ಶುಂಠಿ', '65.00', '1.00', '2020-06-29 14:27:04', '2020-08-07 13:29:43', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-64.00'),
(1113, 14, 26, 'Tomato (Jamoon) / ಟೊಮ್ಯಾಟೊ', '27.00', '1.00', '2020-06-29 14:25:39', '2020-08-07 13:33:00', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-164.00'),
(1114, 30, 26, 'Cabbage / ಎಲೆ ಕೋಸು', '12.00', '1.00', '2020-06-29 14:30:17', '2020-08-08 12:35:46', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-61.00'),
(1115, 19, 26, 'Ginger / ಶುಂಠಿ', '70.00', '1.00', '2020-06-29 14:27:04', '2020-08-08 12:35:46', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-72.00'),
(1116, 61, 26, 'Beetroot / ಬೀಟ್ ರೂಟ್ ', '20.00', '1.00', '2020-07-05 14:55:16', '2020-08-08 13:20:30', '', 'test@gmail.com', 'U', '-113.00'),
(1117, 16, 26, 'Onion Small / ಸಣ್ಣ ಈರುಳ್ಳಿ  ', '50.00', '1.00', '2020-06-29 14:26:10', '2020-08-08 13:20:30', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-35.00'),
(1118, 11, 26, 'Potato / ಆಲೂ ಗೆಡ್ಡೆ ', '32.00', '1.00', '2020-06-29 14:23:51', '2020-08-08 13:20:30', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-259.00'),
(1119, 36, 26, 'Tondekayi / ತೊಂಡೆ ಕಾಯಿ ', '23.00', '1.00', '2020-06-29 14:32:02', '2020-08-08 13:20:30', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'U', '-122.00'),
(1120, 27, 26, 'Brinjal Round / ಬದನೇಕಾಯಿ ', '16.00', '1.00', '2020-06-29 14:29:17', '2020-08-08 13:39:34', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-94.00'),
(1121, 28, 26, 'Cucumber (Green) / ಸೌತೇಕಾಯಿ ', '20.00', '1.00', '2020-06-29 14:29:29', '2020-08-08 13:39:34', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-294.00'),
(1122, 18, 26, 'Garlic / ಬೆಳ್ಳುಳ್ಳಿ  ', '110.00', '1.00', '2020-06-29 14:26:45', '2020-08-08 13:39:34', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-44.00'),
(1123, 42, 26, 'Halasande / ಹಲಸಂದೆ (ಉದ್ದ ) ', '27.00', '1.00', '2020-07-03 08:31:50', '2020-08-08 13:39:34', '', 'test@gmail.com', 'U', '-12.00'),
(1124, 8, 26, 'Beans Ooty / ಬೀನ್ಸ್ (ಊಟಿ)', '38.00', '1.00', '2020-06-29 14:22:19', '2020-08-08 13:41:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-88.00'),
(1125, 8, 26, 'Beans Ooty / ಬೀನ್ಸ್ (ಊಟಿ)', '40.00', '1.00', '2020-06-29 14:22:19', '2020-08-08 13:44:38', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-88.00'),
(1126, 72, 26, 'Balekayi / ಬಾಲೆಕಾಯಿ', '8.00', '1.00', '2020-07-09 14:18:36', '2020-08-10 12:51:57', 'test@gmail.com', 'test@gmail.com', 'U', '-322.00'),
(1127, 8, 26, 'Beans Ooty / ಬೀನ್ಸ್ (ಊಟಿ)', '45.00', '1.00', '2020-06-29 14:22:19', '2020-08-10 12:51:57', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-142.00'),
(1128, 25, 26, 'Brinjal / ಬದನೇಕಾಯಿ (ಬಿಳಿ )', '19.00', '1.00', '2020-06-29 14:28:47', '2020-08-10 12:51:57', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-188.00'),
(1129, 26, 26, 'Brinjal Black / ಬದನೇಕಾಯಿ', '18.00', '1.00', '2020-06-29 14:29:04', '2020-08-10 12:51:57', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-80.00'),
(1130, 27, 26, 'Brinjal Round / ಬದನೇಕಾಯಿ ', '18.00', '1.00', '2020-06-29 14:29:17', '2020-08-10 12:51:57', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-109.00'),
(1131, 10, 26, 'Capsicum / ದಪ್ಪ ಮೆಣಸಿನಕಾಯಿ', '65.00', '1.00', '2020-06-29 14:22:59', '2020-08-10 12:51:58', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-109.00'),
(1132, 31, 26, 'Cauliflower / ಹೂ ಕೋಸು', '23.00', '1.00', '2020-06-29 14:30:35', '2020-08-10 12:51:58', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-244.00'),
(1133, 83, 26, 'Chilli Bajji / ಚಿಲ್ಲಿ ಬಜ್ಜಿ', '59.00', '1.00', '2020-07-19 14:23:45', '2020-08-10 12:51:58', 'test@gmail.com', 'test@gmail.com', 'U', '-101.00'),
(1134, 67, 26, 'Coriander Leaves / ಕೊತ್ತಂಬರಿ ಸೊಪ್ಪು', '4.00', '1.00', '2020-07-06 12:39:51', '2020-08-10 12:51:58', '', 'test@gmail.com', 'U', '-795.00'),
(1135, 29, 26, 'Mangalore Cucumber / ಮಂಗಳೂರು ಸವತೆಕಾಯಿ ', '18.00', '1.00', '2020-06-29 14:30:03', '2020-08-10 12:51:58', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-110.00'),
(1136, 35, 26, 'Raddish / ಮೂಲಂಗಿ ', '15.00', '1.00', '2020-06-29 14:31:43', '2020-08-10 12:51:58', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-181.00'),
(1137, 62, 26, 'Seemebadne / ಸೀಮೆ ಬದನೆ ', '23.00', '1.00', '2020-07-05 15:30:20', '2020-08-10 12:51:58', '', 'md@spicetrip.com', 'U', '-208.00'),
(1138, 36, 26, 'Tondekayi / ತೊಂಡೆ ಕಾಯಿ ', '22.00', '1.00', '2020-06-29 14:32:02', '2020-08-10 12:51:58', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'U', '-137.00'),
(1139, 26, 26, 'Brinjal Black / ಬದನೇಕಾಯಿ', '19.00', '1.00', '2020-06-29 14:29:04', '2020-08-10 13:11:55', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-80.00'),
(1140, 30, 26, 'Cabbage / ಎಲೆ ಕೋಸು', '11.00', '1.00', '2020-06-29 14:30:17', '2020-08-10 13:11:55', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-186.00'),
(1141, 10, 26, 'Capsicum / ದಪ್ಪ ಮೆಣಸಿನಕಾಯಿ', '52.00', '1.00', '2020-06-29 14:22:59', '2020-08-10 13:11:55', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-109.00'),
(1142, 64, 26, 'Hagalakai Green / ಹಾಗಲಕಾಯಿ ', '38.00', '1.00', '2020-07-05 19:39:44', '2020-08-10 13:11:55', '', 'md@spicetrip.com', 'U', '-134.00'),
(1143, 76, 26, 'Hagalakayi - White  / ಬಿಳಿ ಹಾಗಲಕಾಯಿ  ', '38.00', '1.00', '2020-07-12 15:27:22', '2020-08-10 13:11:55', 'test@gmail.com', 'md@spicetrip.com', 'U', '-3.00'),
(1144, 72, 26, 'Balekayi / ಬಾಲೆಕಾಯಿ', '10.00', '1.00', '2020-07-09 14:18:36', '2020-08-10 13:14:46', 'test@gmail.com', 'test@gmail.com', 'U', '-322.00'),
(1145, 20, 26, 'Green Chilli / ಹಸಿರು ಮೆಣಸಿನಕಾಯಿ ', '34.00', '1.00', '2020-06-29 14:27:20', '2020-08-10 13:14:46', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-299.00'),
(1146, 11, 26, 'Potato / ಆಲೂ ಗೆಡ್ಡೆ ', '32.50', '1.00', '2020-06-29 14:23:51', '2020-08-10 13:15:21', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-365.00'),
(1147, 31, 26, 'Cauliflower / ಹೂ ಕೋಸು', '24.00', '1.00', '2020-06-29 14:30:35', '2020-08-10 13:21:09', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'U', NULL),
(1148, 7, 26, 'Beans / ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '36.00', '1.00', '2020-06-29 14:21:54', '2020-08-11 12:29:17', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'U', '-250.00'),
(1149, 8, 26, 'Beans Ooty / ಬೀನ್ಸ್ (ಊಟಿ)', '55.00', '1.00', '2020-06-29 14:22:19', '2020-08-11 12:29:17', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'U', '-166.00'),
(1150, 10, 26, 'Capsicum / ದಪ್ಪ ಮೆಣಸಿನಕಾಯಿ', '56.00', '1.00', '2020-06-29 14:22:59', '2020-08-11 12:29:17', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'U', '-139.00'),
(1151, 31, 26, 'Cauliflower / ಹೂ ಕೋಸು', '20.00', '1.00', '2020-06-29 14:30:35', '2020-08-11 12:29:17', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'U', '-280.00'),
(1152, 67, 26, 'Coriander Leaves / ಕೊತ್ತಂಬರಿ ಸೊಪ್ಪು', '5.00', '1.00', '2020-07-06 12:39:51', '2020-08-11 12:29:17', '', 'test@gmail.com', 'U', '-960.00'),
(1153, 28, 26, 'Cucumber (Green) / ಸೌತೇಕಾಯಿ ', '21.00', '1.00', '2020-06-29 14:29:29', '2020-08-11 12:29:17', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-374.00'),
(1154, 19, 26, 'Ginger / ಶುಂಠಿ', '78.00', '1.00', '2020-06-29 14:27:04', '2020-08-11 12:29:17', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-91.00'),
(1155, 20, 26, 'Green Chilli / ಹಸಿರು ಮೆಣಸಿನಕಾಯಿ ', '32.00', '1.00', '2020-06-29 14:27:20', '2020-08-11 12:29:17', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-320.00'),
(1156, 63, 26, 'Knol Khol / ನವಿಲುಕೋಸು ', '22.00', '1.00', '2020-07-05 19:38:57', '2020-08-11 12:29:17', '', 'md@spicetrip.com', 'U', '-174.00'),
(1157, 29, 26, 'Mangalore Cucumber / ಮಂಗಳೂರು ಸವತೆಕಾಯಿ ', '15.00', '1.00', '2020-06-29 14:30:03', '2020-08-11 12:29:17', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'U', '-135.00'),
(1158, 14, 26, 'Tomato (Jamoon) / ಟೊಮ್ಯಾಟೊ', '25.00', '1.00', '2020-06-29 14:25:39', '2020-08-11 12:29:17', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'U', '-361.00'),
(1159, 13, 26, 'Tomato (Sour) / ಟೊಮ್ಯಾಟೊ ', '22.00', '1.00', '2020-06-29 14:25:12', '2020-08-11 12:29:17', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'U', '-772.00'),
(1160, 10, 26, 'Capsicum / ದಪ್ಪ ಮೆಣಸಿನಕಾಯಿ', '50.00', '1.00', '2020-06-29 14:22:59', '2020-08-11 12:29:57', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'U', '-139.00'),
(1161, 9, 26, 'Carrot / ಕ್ಯಾರೆಟ್ ', '58.00', '1.00', '2020-06-29 14:22:41', '2020-08-11 12:32:17', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'U', '-402.00');

-- --------------------------------------------------------

--
-- Table structure for table `Products`
--

DROP TABLE IF EXISTS `Products`;
CREATE TABLE IF NOT EXISTS `Products` (
  `ProductId` int(11) NOT NULL AUTO_INCREMENT,
  `CategoryId` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `RatePerKG` decimal(10,2) NOT NULL,
  `MinPurchaseQuantity` decimal(10,2) NOT NULL,
  `CreatedDateTime` datetime NOT NULL,
  `UpdatedDateTime` datetime NOT NULL,
  `CreatedUserId` varchar(50) NOT NULL,
  `UpdatedUserId` varchar(50) NOT NULL,
  `Deactivate` varchar(4) DEFAULT NULL,
  `TotalStock` decimal(10,2) NOT NULL,
  `ProductImagePath` varchar(200) NOT NULL,
  `UnitType` varchar(10) NOT NULL,
  `GradeBStock` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`ProductId`),
  KEY `FK_CategoryId` (`CategoryId`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Products`
--

INSERT INTO `Products` (`ProductId`, `CategoryId`, `Name`, `RatePerKG`, `MinPurchaseQuantity`, `CreatedDateTime`, `UpdatedDateTime`, `CreatedUserId`, `UpdatedUserId`, `Deactivate`, `TotalStock`, `ProductImagePath`, `UnitType`, `GradeBStock`) VALUES
(7, 26, 'Beans / ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '38.00', '1.00', '2020-06-29 14:21:54', '2020-08-11 20:42:46', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'NO', '-283.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 15 copy.JPG', 'KG', '0.00'),
(8, 26, 'Beans Ooty / ಬೀನ್ಸ್ (ಊಟಿ)', '42.00', '1.00', '2020-06-29 14:22:19', '2020-08-11 20:42:46', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'NO', '-196.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 23 copy.JPG', 'KG', '0.00'),
(9, 26, 'Carrot / ಕ್ಯಾರೆಟ್ ', '55.00', '1.00', '2020-06-29 14:22:41', '2020-08-11 20:42:46', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'NO', '-462.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 16 copy.JPG', 'KG', '0.00'),
(10, 26, 'Capsicum / ದಪ್ಪ ಮೆಣಸಿನಕಾಯಿ', '48.00', '1.00', '2020-06-29 14:22:59', '2020-08-11 20:42:46', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'NO', '-185.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 27 copy.JPG', 'KG', '0.00'),
(11, 26, 'Potato / ಆಲೂ ಗೆಡ್ಡೆ ', '33.00', '1.00', '2020-06-29 14:23:51', '2020-08-11 20:42:47', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'NO', '-467.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 21 copy.JPG', 'KG', '0.00'),
(13, 26, 'Tomato (Sour) / ಟೊಮ್ಯಾಟೊ ', '24.00', '1.00', '2020-06-29 14:25:12', '2020-08-11 20:42:47', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'NO', '-837.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 49 copy.JPG', 'KG', '0.00'),
(14, 26, 'Tomato (Jamoon) / ಟೊಮ್ಯಾಟೊ', '26.00', '1.00', '2020-06-29 14:25:39', '2020-08-11 20:42:47', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'NO', '-383.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 50 copy.JPG', 'KG', '0.00'),
(15, 26, 'Onion / ಈರುಳ್ಳಿ ', '15.00', '1.00', '2020-06-29 14:25:53', '2020-08-11 20:42:47', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'NO', '-300.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 44 copy.JPG', 'KG', '0.00'),
(16, 26, 'Onion Small / ಸಣ್ಣ ಈರುಳ್ಳಿ  ', '45.00', '1.00', '2020-06-29 14:26:10', '2020-08-11 20:42:47', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'NO', '-64.00', 'http://demo.farmar.in/UploadedFiles/Products/small-onion-310128419-t1ciq.jpg', 'KG', '0.00'),
(18, 26, 'Garlic / ಬೆಳ್ಳುಳ್ಳಿ  ', '108.00', '1.00', '2020-06-29 14:26:45', '2020-08-11 20:42:46', 'abhijitjd003@gmail.com', 'test@gmail.com', 'NO', '-76.00', 'http://demo.farmar.in/UploadedFiles/Products/garlic.jpg', 'KG', '0.00'),
(19, 26, 'Ginger / ಶುಂಠಿ', '75.00', '1.00', '2020-06-29 14:27:04', '2020-08-11 20:42:46', 'abhijitjd003@gmail.com', 'test@gmail.com', 'NO', '-120.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 32 copy.JPG', 'KG', '0.00'),
(20, 26, 'Green Chilli / ಹಸಿರು ಮೆಣಸಿನಕಾಯಿ ', '30.00', '1.00', '2020-06-29 14:27:20', '2020-08-11 20:42:46', 'abhijitjd003@gmail.com', 'test@gmail.com', 'NO', '-359.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 33 copy.JPG', 'KG', '0.00'),
(21, 26, 'Lemon / ನಿಂಬೆ ಹಣ್ಣು ', '55.00', '1.00', '2020-06-29 14:27:39', '2020-08-11 20:42:47', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'NO', '-35.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 39 copy.JPG', 'KG', '0.00'),
(25, 26, 'Brinjal / ಬದನೇಕಾಯಿ (ಬಿಳಿ )', '20.00', '1.00', '2020-06-29 14:28:47', '2020-08-11 20:42:46', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'NO', '-255.00', 'http://demo.farmar.in/UploadedFiles/Products/brinjal (long).jpg', 'KG', '0.00'),
(26, 26, 'Brinjal Black / ಬದನೇಕಾಯಿ', '24.00', '1.00', '2020-06-29 14:29:04', '2020-08-11 20:42:46', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'NO', '-99.00', 'http://demo.farmar.in/UploadedFiles/Products/51GF3m4aeSL._SL1000_.jpg', 'KG', '0.00'),
(27, 26, 'Brinjal Round / ಬದನೇಕಾಯಿ ', '19.00', '1.00', '2020-06-29 14:29:17', '2020-08-11 20:42:46', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'NO', '-128.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 25 copy.JPG', 'KG', '0.00'),
(28, 26, 'Cucumber (Green) / ಸೌತೇಕಾಯಿ ', '25.00', '1.00', '2020-06-29 14:29:29', '2020-08-11 20:42:46', 'abhijitjd003@gmail.com', 'test@gmail.com', 'NO', '-440.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 29 copy.JPG', 'KG', '0.00'),
(29, 26, 'Mangalore Cucumber / ಮಂಗಳೂರು ಸವತೆಕಾಯಿ ', '16.00', '1.00', '2020-06-29 14:30:03', '2020-08-11 20:42:47', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'NO', '-158.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 40 copy.JPG', 'KG', '0.00'),
(30, 26, 'Cabbage / ಎಲೆ ಕೋಸು', '12.00', '1.00', '2020-06-29 14:30:17', '2020-08-11 20:42:46', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'NO', '-248.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 26 copy.JPG', 'KG', '0.00'),
(31, 26, 'Cauliflower / ಹೂ ಕೋಸು', '22.00', '1.00', '2020-06-29 14:30:35', '2020-08-11 20:42:46', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'NO', '-329.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 281.jpg', 'Piece', '0.00'),
(34, 26, 'Bendekayi / Okra / ಬೆಂಡೇಕಾಯಿ  ', '20.00', '1.00', '2020-06-29 14:31:27', '2020-08-11 20:42:46', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'NO', '-431.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 17 copy.JPG', 'KG', '0.00'),
(35, 26, 'Raddish / ಮೂಲಂಗಿ ', '16.00', '1.00', '2020-06-29 14:31:43', '2020-08-11 20:42:47', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'NO', '-258.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 43 copy.JPG', 'KG', '0.00'),
(36, 26, 'Tondekayi / ತೊಂಡೆ ಕಾಯಿ ', '24.00', '1.00', '2020-06-29 14:32:02', '2020-08-11 20:42:47', 'abhijitjd003@gmail.com', 'md@spicetrip.com', 'YES', '-137.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 51 copy.JPG', 'KG', '0.00'),
(42, 26, 'Halasande / ಹಲಸಂದೆ (ಉದ್ದ ) ', '30.00', '1.00', '2020-07-03 08:31:50', '2020-08-11 20:42:46', '', 'test@gmail.com', 'YES', '-19.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 36 copy.JPG', 'KG', '0.00'),
(44, 26, 'Nuggekayi / ನುಗ್ಗೆ ಕಾಯಿ ', '55.00', '1.00', '2020-07-03 13:08:04', '2020-08-11 20:42:47', '', 'md@spicetrip.com', 'NO', '-140.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 30 copy.JPG', 'KG', '0.00'),
(45, 26, 'Hirekayi / ಹೀರೆಕಾಯಿ ', '28.00', '1.00', '2020-07-03 13:08:28', '2020-08-11 20:42:46', '', 'md@spicetrip.com', 'YES', '-229.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 35 copy.JPG', 'KG', '0.00'),
(46, 26, 'Padavalakai / ಪಡವಲಕಾಯಿ  ', '19.00', '1.00', '2020-07-03 13:08:54', '2020-08-11 20:42:47', '', 'md@spicetrip.com', 'NO', '-54.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 45 copy.JPG', 'KG', '0.00'),
(47, 26, 'Sorekai / ಸೋರೆಕಾಯಿ', '19.00', '1.00', '2020-07-03 13:09:17', '2020-08-11 20:42:47', '', 'md@spicetrip.com', 'YES', '-36.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 48 copy.JPG', 'KG', '0.00'),
(61, 26, 'Beetroot / ಬೀಟ್ ರೂಟ್ ', '17.00', '1.00', '2020-07-05 14:55:16', '2020-08-11 20:42:46', '', 'md@spicetrip.com', 'NO', '-221.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 22 copy.JPG', 'KG', '0.00'),
(62, 26, 'Seemebadne / ಸೀಮೆ ಬದನೆ ', '24.00', '1.00', '2020-07-05 15:30:20', '2020-08-11 20:42:47', '', 'md@spicetrip.com', 'NO', '-275.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 46 copy.JPG', 'KG', '0.00'),
(63, 26, 'Knol Khol / ನವಿಲುಕೋಸು ', '24.00', '1.00', '2020-07-05 19:38:57', '2020-08-11 20:42:47', '', 'md@spicetrip.com', 'NO', '-227.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 37 copy.JPG', 'KG', '0.00'),
(64, 26, 'Hagalakai Green / ಹಾಗಲಕಾಯಿ ', '39.00', '1.00', '2020-07-05 19:39:44', '2020-08-11 20:42:46', '', 'md@spicetrip.com', 'NO', '-190.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 34 copy.JPG', 'KG', '0.00'),
(65, 26, 'Kumbalakayi (Green) / ಕುಂಬಳಕಾಯಿ ', '12.00', '1.00', '2020-07-05 19:44:05', '2020-08-11 20:42:47', '', 'md@spicetrip.com', 'NO', '-72.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 38 copy.JPG', 'KG', '0.00'),
(67, 26, 'Coriander Leaves / ಕೊತ್ತಂಬರಿ ಸೊಪ್ಪು', '4.50', '1.00', '2020-07-06 12:39:51', '2020-08-11 20:42:46', '', 'test@gmail.com', 'NO', '-1035.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 59 copy.JPG', 'Piece', '0.00'),
(68, 26, 'Curry Leaves / ಕರಿಬೇವು   ', '2.50', '1.00', '2020-07-06 12:40:25', '2020-08-11 20:42:46', '', 'test@gmail.com', 'NO', '-363.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 60 copy.JPG', 'Piece', '0.00'),
(69, 26, 'Pudhina Leaves / ಪುದಿನ ಸೊಪ್ಪು ', '3.00', '1.00', '2020-07-06 12:40:50', '2020-08-11 20:42:47', '', 'md@spicetrip.com', 'NO', '-422.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 58 copy.jpg', 'Piece', '0.00'),
(70, 26, 'Palak / ಪಾಲಾಕ್ ', '2.50', '1.00', '2020-07-06 12:41:13', '2020-08-11 20:42:47', '', 'md@spicetrip.com', 'NO', '-170.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 571 copy.JPG', 'Piece', '0.00'),
(71, 26, 'Sabsige Soppu / ಸಬ್ಸಿಗೆ ಸೊಪ್ಪು ', '3.00', '1.00', '2020-07-06 12:41:52', '2020-08-11 20:42:47', '', 'md@spicetrip.com', 'NO', '-158.00', 'http://demo.farmar.in/UploadedFiles/Products/sabsige.png', 'Piece', '0.00'),
(72, 26, 'Balekayi / ಬಾಲೆಕಾಯಿ', '9.00', '1.00', '2020-07-09 14:18:36', '2020-08-11 20:42:46', 'test@gmail.com', 'md@spicetrip.com', 'NO', '-408.00', 'http://demo.farmar.in/UploadedFiles/Products/download (1).jpg', 'Piece', '0.00'),
(73, 26, 'Menthya Soppu / ಮೆಂತ್ಯ ಸೊಪ್ಪು ', '5.00', '1.00', '2020-07-09 14:25:43', '2020-08-11 20:42:47', 'test@gmail.com', 'md@spicetrip.com', 'YES', '-90.00', 'http://demo.farmar.in/UploadedFiles/Products/menthya.jpg', 'Piece', '0.00'),
(75, 26, 'Avare Kai / ಅವರೆಕಾಯಿ', '25.00', '1.00', '2020-07-12 15:04:39', '2020-08-11 20:42:46', 'test@gmail.com', 'md@spicetrip.com', 'NO', '-35.00', 'http://demo.farmar.in/UploadedFiles/Products/37.jpg', 'KG', '0.00'),
(76, 26, 'Hagalakayi - White  / ಬಿಳಿ ಹಾಗಲಕಾಯಿ  ', '39.00', '1.00', '2020-07-12 15:27:22', '2020-08-11 20:42:46', 'test@gmail.com', 'md@spicetrip.com', 'NO', '-17.00', 'http://demo.farmar.in/UploadedFiles/Products/31ejn6doxEL.jpg', 'KG', '0.00'),
(77, 26, 'Gorikayi / ಗೋರಿಕಾಯಿ ', '30.00', '1.00', '2020-07-12 15:42:27', '2020-08-11 20:42:46', 'test@gmail.com', 'md@spicetrip.com', 'NO', '-50.00', 'http://demo.farmar.in/UploadedFiles/Products/Gorikai.jpg', 'KG', '0.00'),
(83, 26, 'Chilli Bajji / ಚಿಲ್ಲಿ ಬಜ್ಜಿ', '60.00', '1.00', '2020-07-19 14:23:45', '2020-08-11 20:42:46', 'test@gmail.com', 'md@spicetrip.com', 'NO', '-128.00', 'http://demo.farmar.in/UploadedFiles/Products/s-l300.jpg', 'KG', '0.00'),
(84, 26, 'Cucumber - British / ಬ್ರಿಟಿಷ್ ಸೌತೆಕಾಯಿ', '30.00', '1.00', '2020-07-20 14:35:58', '2020-08-11 20:42:46', 'test@gmail.com', 'test@gmail.com', 'YES', '0.00', 'http://demo.farmar.in/UploadedFiles/Products/british cucumber.jpg', 'KG', '0.00'),
(87, 26, 'Beans - Solar / ಬೀನ್ಸ್', '30.00', '1.00', '2020-08-04 18:59:14', '2020-08-11 20:42:46', 'kanthraj@dotangle.com', 'md@spicetrip.com', 'YES', '-6.00', 'http://demo.farmar.in/UploadedFiles/Products/solar.jpg', 'KG', '0.00'),
(88, 26, 'Ash Gourd / ಬೂದಿ ಕುಂಬಳಕಾಯಿ', '16.00', '1.00', '2020-08-04 19:08:20', '2020-08-11 20:42:46', 'kanthraj@dotangle.com', 'md@spicetrip.com', 'NO', '-3.00', 'http://demo.farmar.in/UploadedFiles/Products/ash-gourd.jpg', 'KG', '0.00');

-- --------------------------------------------------------

--
-- Table structure for table `RemovedGradeAStock`
--

DROP TABLE IF EXISTS `RemovedGradeAStock`;
CREATE TABLE IF NOT EXISTS `RemovedGradeAStock` (
  `ProductName` varchar(50) NOT NULL,
  `Weight` decimal(10,2) DEFAULT NULL,
  `ReasonType` varchar(20) DEFAULT NULL,
  `RemovedDateTime` datetime NOT NULL,
  `RemovedUserId` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `RemovedGradeBStock`
--

DROP TABLE IF EXISTS `RemovedGradeBStock`;
CREATE TABLE IF NOT EXISTS `RemovedGradeBStock` (
  `ProductName` varchar(50) NOT NULL,
  `Weight` decimal(10,2) DEFAULT NULL,
  `BuyerName` varchar(50) NOT NULL,
  `RemovedDateTime` datetime NOT NULL,
  `RemovedUserId` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `Routes`
--

DROP TABLE IF EXISTS `Routes`;
CREATE TABLE IF NOT EXISTS `Routes` (
  `RouteCategory` varchar(30) NOT NULL,
  `Route` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Routes`
--

INSERT INTO `Routes` (`RouteCategory`, `Route`) VALUES
('Route A', 'Kuvempu Nagar'),
('Route B', 'Vivekanand Nagar'),
('Route C', 'Hebbal');

-- --------------------------------------------------------

--
-- Table structure for table `ShopDetails`
--

DROP TABLE IF EXISTS `ShopDetails`;
CREATE TABLE IF NOT EXISTS `ShopDetails` (
  `ShopId` int(11) NOT NULL AUTO_INCREMENT,
  `ShopName` varchar(50) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `GSTNo` varchar(30) DEFAULT NULL,
  `ReferralCode` varchar(20) DEFAULT NULL,
  `MobileNo` bigint(20) NOT NULL,
  `Status` varchar(30) NOT NULL,
  `RejectedReason` varchar(100) DEFAULT NULL,
  `Location` varchar(400) NOT NULL,
  `CreatedDateTime` datetime NOT NULL,
  `UpdatedDateTime` datetime NOT NULL,
  `UpdatedUserId` varchar(50) NOT NULL,
  `CreatedUserId` varchar(50) NOT NULL,
  `AlternateContactNo` bigint(20) DEFAULT NULL,
  `Email` varchar(30) DEFAULT NULL,
  `ContactPerson` varchar(50) NOT NULL,
  `Route` varchar(30) DEFAULT NULL,
  `PinCode` bigint(20) NOT NULL,
  PRIMARY KEY (`ShopId`)
) ENGINE=InnoDB AUTO_INCREMENT=160 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ShopDetails`
--

INSERT INTO `ShopDetails` (`ShopId`, `ShopName`, `Address`, `GSTNo`, `ReferralCode`, `MobileNo`, `Status`, `RejectedReason`, `Location`, `CreatedDateTime`, `UpdatedDateTime`, `UpdatedUserId`, `CreatedUserId`, `AlternateContactNo`, `Email`, `ContactPerson`, `Route`, `PinCode`) VALUES
(10, 'Chamundeshwari Vegetables 119', '# Tank road, Hootgalli', '', '119', 7204909141, 'Approved', NULL, 'Hootgalli', '2020-07-29 14:15:03', '2020-08-11 19:00:50', 'srinivas@farmar.in', 'test@gmail.com', 0, '', 'Vasanth Kumar', NULL, 570027),
(11, 'Nandi Vegetables MYS086', '\"N\" Block, Near to MRF wheel Alignment', '', 'MYS086', 7760375777, 'Approved', NULL, 'Kuvempunagar', '2020-07-29 14:19:09', '2020-08-10 18:38:38', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'Basavaraju', NULL, 570023),
(12, 'S.L.V. Vegetables MYS087', 'University Layout, Near R.T.Nagar', '', 'MYS087', 7892797291, 'Approved', NULL, 'University Layout', '2020-07-29 14:20:55', '2020-08-10 18:38:38', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'Lakshmi Narayan', NULL, 570006),
(13, 'Hotel Akshaya Veg 148', 'Opposite to Appollo Hospital', '', '148', 9901793009, 'Approved', NULL, 'Kuvempunagar', '2020-07-29 14:22:31', '2020-08-11 19:00:50', 'srinivas@farmar.in', 'test@gmail.com', 0, '', 'M.K.VinayaBabu', NULL, 570023),
(14, 'Dosa Point 147', 'Appollo Road, Kuvempunagar', '', '147', 9916256503, 'Approved', NULL, 'Kuvempunagar', '2020-07-29 14:24:06', '2020-08-11 19:00:50', 'srinivas@farmar.in', 'test@gmail.com', 0, '', 'Mr. Rakshith', NULL, 570023),
(15, 'Vaishnavi Dosa Palace 144', 'Ramaswamy Circle', '', '144', 9686195178, 'Approved', NULL, 'Mysore', '2020-07-29 14:25:25', '2020-08-02 17:46:42', 'test@gmail.com', 'test@gmail.com', 0, '', 'Renuka Raju', NULL, 0),
(16, 'Raithana Thota 137', '#2024, Kanakadasanagar', '', '137', 9986678798, 'Approved', NULL, 'Dattagalli', '2020-07-29 14:28:13', '2020-08-10 21:19:39', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'Uday', NULL, 570022),
(28, 'KAMALA PROVISION STORE  01', ' 4th main, near Safe Wheels', '', '1', 9945100305, 'Approved', NULL, 'Saraswathipuram', '2020-08-02 16:35:39', '2020-08-11 13:19:10', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'Chandru', NULL, 570009),
(29, 'GREENS FRUITS&VEGETABLES 02', 'Vivekananda Circle', '', '2', 9113832898, 'Approved', NULL, 'Kuvempunagar', '2020-08-02 16:36:14', '2020-08-11 13:19:10', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'VIJAYA KP', NULL, 570023),
(30, 'FARMERS FRESH 03', 'Depo Circle', '', '03', 8105452954, 'Approved', NULL, 'Vivekanandanagar', '2020-08-02 16:36:49', '2020-08-10 18:04:05', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'RAGHAVENDRA RAO', NULL, 570023),
(31, 'HAPPY MART 04', '942, 20th cross', '', '4', 9686513811, 'Approved', NULL, 'J.P.Nagar', '2020-08-02 16:37:11', '2020-08-11 13:19:10', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'RAVI.M', NULL, 570008),
(32, 'MAHALAKSHMI STORES 05', 'Opp Kavitha Bakery', '', '5', 8762897831, 'Approved', NULL, 'J.P.Nagar', '2020-08-02 16:37:38', '2020-08-11 13:19:10', 'kanthraj@dotangle.com', 'test@gmail.com', 8217074088, '', 'SURESH', NULL, 570008),
(33, 'R.R PROVISION  STORE 06', '41/H, 2nd stage,  Suburban', '', '6', 9902664304, 'Approved', NULL, 'Vishweshwaranagar', '2020-08-02 16:39:32', '2020-08-11 13:19:10', 'kanthraj@dotangle.com', 'test@gmail.com', 9243123458, '', 'ROHITH', NULL, 570008),
(34, 'SRI NAVADURGA BHANDAR 07', '#41/H1, 2nd stage,St Thamas Road, Bindu bakery Road', '', '7', 9902479909, 'Approved', NULL, 'Vishweshwaranagar', '2020-08-02 16:40:06', '2020-08-10 18:04:05', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'NEMICHAND', NULL, 570008),
(35, 'MANU PROVISSION STORE 08', '#91/A  Industrial Suburb', '', '8', 7259052711, 'Approved', NULL, 'Vishweshwaranagar', '2020-08-02 16:40:33', '2020-08-11 13:05:48', 'kanthraj@dotangle.com', 'test@gmail.com', 9480909391, '', 'VIJIYA', NULL, 570008),
(36, 'MATHAJI STORES 09', 'Next to J.P. Nagar Club ', '', '9', 8050304010, 'Approved', NULL, 'J.P.Nagar', '2020-08-02 16:40:57', '2020-08-11 13:05:48', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'CHOWDARY', NULL, 570008),
(37, 'SRI SHIVANANDA STORE 10', 'Near SiBaba  Temple, 6th cross', '', '10', 9886872465, 'Approved', NULL, 'J.P.Nagar', '2020-08-02 16:41:23', '2020-08-11 13:05:48', 'kanthraj@dotangle.com', 'test@gmail.com', 7483363472, '', 'AKASH', NULL, 570008),
(38, 'AISHWARYA FRUITS & VEGETABLES 11', '2/2 D- Block, J.P.Nagar', '', '11', 9902375497, 'Approved', NULL, 'J.P.Nagar', '2020-08-02 16:42:33', '2020-08-11 13:05:48', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'ANILKUMAR', NULL, 570008),
(39, 'A.M VARALAKSHMI 12', 'Andani Circle', '', '12', 9945682776, 'Approved', NULL, 'Vidyaranyapuram', '2020-08-02 16:42:57', '2020-08-11 13:19:10', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'NAVEEN KUMAR', NULL, 570008),
(40, 'VENKATESH VEGETABLES 13', 'Opp Vishal Selection, Vijaya Bhandar', '', '13', 7899908511, 'Approved', NULL, 'Vidyaranyapuram', '2020-08-02 16:43:23', '2020-08-11 13:05:48', 'kanthraj@dotangle.com', 'test@gmail.com', 8310502584, '', 'VENKATESH', NULL, 570008),
(41, 'SIDDESWARA STORE 14', '2nd cross, Near to SaiBaba  Temple', '', '14', 9880782161, 'Approved', NULL, 'J.P.Nagar', '2020-08-02 16:54:57', '2020-08-11 13:05:48', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'KIRAN KUMAR', NULL, 570008),
(42, 'JANATHA BHANDAR 15', '100, LIC Colony', '', '15', 9620306999, 'Approved', NULL, 'Srirampura', '2020-08-02 16:55:20', '2020-08-11 13:05:48', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'VENKATESH', NULL, 570034),
(43, 'SRI BADAMI BANASHANKARI 16', 'Surya Layout Near Naiduagar, Bogadi 2nd stage', '', '16', 9945215899, 'Approved', NULL, 'Bogadi 2nd stage', '2020-08-02 16:55:47', '2020-08-11 13:05:48', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'SANTOSH KUMAR', NULL, 570026),
(44, 'TULASI ENTERPRISES 17', '#5, 20 Block, SBM Layout, 2nd stage', '', '17', 9740400034, 'Approved', NULL, 'Srirampura', '2020-08-02 16:56:18', '2020-08-11 13:19:10', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'BORA RAM', NULL, 570008),
(45, 'AISHWARYA PROVISION STORE 18', '10th cross, 2nd stage, Near to Bramaramba chowltry', '', '18', 9980850586, 'Approved', NULL, 'Srirampura', '2020-08-02 16:57:14', '2020-08-11 13:05:48', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'NAGARAJU', NULL, 570008),
(46, 'SRI VINAYAKA FRUITS & VEGETABLES  19', '#25, Preethi Layout, Srirampura 2nd stage', '', '19', 9482075384, 'Approved', NULL, 'Srirampura', '2020-08-02 16:57:51', '2020-08-11 13:19:10', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'MOHAN', NULL, 570023),
(47, 'HSR VEG 141', 'Vijaynagar 4th stage, 2nd phase', '', '141', 6362422124, 'Approved', NULL, 'Vijaynagar 4th stage', '2020-08-02 16:59:24', '2020-08-10 20:13:33', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'DEEPAK', NULL, 570030),
(48, 'KAMADENU SUPER MARKET 136', '#650, T.K Layout Main Road', '', '136', 9845407218, 'Approved', NULL, 'T.K.Layout', '2020-08-02 17:00:22', '2020-08-10 21:32:24', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'RAJU', NULL, 570022),
(49, 'NKS TRADERS FRUITS&VEGETABLES 20', 'Opp HP Petrol Bunk, Srirampura Main Road', '', '20', 6361626374, 'Approved', NULL, 'Srirampura', '2020-08-02 17:00:34', '2020-08-11 13:05:48', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'SANJAY', NULL, 570008),
(50, 'SRI CHAMUNDESWARI VEGETABLES 21', '\"M\" Block', '', '21', 9980936975, 'Approved', NULL, 'Kuvempunagar', '2020-08-02 17:00:58', '2020-08-10 19:10:29', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'MANJU', NULL, 570023),
(51, 'DHANALAKSHMI BHANDAR 135', '#2236, 3rd stage, D Block, Kanakadasanagar', '', '135', 7338157882, 'Approved', NULL, 'Dattagalli', '2020-08-02 17:01:08', '2020-08-10 20:27:35', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'SURESH CHOWDRI', NULL, 570022),
(52, 'K.S.T BALEMANDI 22', '72, Nrupathunga Road, 2nd Stage, M Block', '', '22', 9480927005, 'Approved', NULL, 'Kuvempunagar', '2020-08-02 17:01:20', '2020-08-10 18:54:07', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'SIDDALINGASWAMY', NULL, 570023),
(53, 'FARMER FRESH 23', 'Behind Mega Medicals', '', '23', 9945653404, 'Approved', NULL, 'Kuvempunagar', '2020-08-02 17:01:46', '2020-08-10 19:23:51', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'DINESH', NULL, 570023),
(54, 'SELTAR SUPER MARKET 134', 'H/8C, Kanthrajurs Road', '', '134', 8217772854, 'Approved', NULL, 'Shardhadevinagar', '2020-08-02 17:02:02', '2020-08-10 20:01:55', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'MANOHAR', NULL, 570022),
(55, 'FARM FRESH 24', '4th cross, Anikethana Road, Cauvery School Road', '', '24', 9611146837, 'Approved', NULL, 'Kuvempunagar', '2020-08-02 17:02:09', '2020-08-10 19:23:51', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'CHANDRU', NULL, 570023),
(56, 'SHIJITH P.P 25', 'Near to Ashokapuram police station, Adichunchangiri road', '', '25', 9886950777, 'Approved', NULL, 'Kuvempunagar', '2020-08-02 17:02:31', '2020-08-10 19:10:29', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'RAJA', NULL, 570023),
(57, 'RAJA RAJESHWARI BHANDAR 133', '#563, Raja RajeshwariNagar, BEML Layout, Near Narayana Bakery', '', '133', 9972840430, 'Approved', NULL, 'Mysore', '2020-08-02 17:02:39', '2020-08-10 20:44:30', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'GOVIND RAM', NULL, 570026),
(58, 'JANATHA SUPER MARKET 26', 'New Court Road, Near to Jaynagar Railway Gate', '', '26', 9886100816, 'Approved', NULL, 'Jaynagar', '2020-08-02 17:03:04', '2020-08-10 19:10:29', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'DHARMARAJU', NULL, 570014),
(59, 'ASHOKA VEGETABLES 27', 'Ashoka Circle, Ballal Circle', '', '27', 8762004749, 'Approved', NULL, 'Krishnamurthypuram', '2020-08-02 17:03:32', '2020-08-10 19:10:29', 'kanthraj@dotangle.com', 'test@gmail.com', 8310711386, '', 'VENKATESH', NULL, 570004),
(60, 'GSV SON 132', '#2233, 80 Ft road,3rd stage, Kanakadasanagar', '', '132', 9483569913, 'Approved', NULL, 'Datagalli', '2020-08-02 17:03:41', '2020-08-10 21:25:38', 'kanthraj@dotangle.com', 'test@gmail.com', 9731717545, '', 'RAGHU', NULL, 570022),
(61, 'S.B.FRESH JUICE FRUITS & VEGETABLES  28', '2368/1, Kanthrajurs road, Near to Railway Bridge', '', '28', 9916986987, 'Approved', NULL, 'K.G.Koppal', '2020-08-02 17:04:01', '2020-08-10 19:10:29', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'BALU', NULL, 570009),
(62, 'KAMADENU GENERAL STORES 131', '#2, Christ Public School Road, 2nd stage, BEML Layout', '', '131', 8861310135, 'Approved', NULL, 'Bogadi', '2020-08-02 17:04:25', '2020-08-10 21:02:25', 'kanthraj@dotangle.com', 'test@gmail.com', 8904101210, '', 'ANAND', NULL, 570026),
(63, 'DHANALAKSHMI FRUITS & VEGETABLES 29', '2nd stage, Near BEML Main Road', '', '29', 8861898759, 'Approved', NULL, 'Srirampura', '2020-08-02 17:04:26', '2020-08-10 19:23:51', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'KOOSAPPA', NULL, 570008),
(64, 'SRI MAHADESWARA PROVISION STORE 30', '20th main', '', '30', 9620476699, 'Approved', NULL, 'J.P.Nagar', '2020-08-02 17:04:59', '2020-08-10 19:10:29', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'UMESH', NULL, 570008),
(65, 'KRISHNA SUPER MARKET 130', '#14, 80Ft Road, Aishwarya Layout, 2nd stage', '', '130', 8123678984, 'Approved', NULL, 'Bogadi', '2020-08-02 17:05:10', '2020-08-10 21:02:25', 'kanthraj@dotangle.com', 'test@gmail.com', 9036278862, '', 'BUDARAM', NULL, 570026),
(66, 'LALITHA PROVISION STORE 31', '\"D\" Block Main Road, Opp Fish Stall, Janatha Layout', '', '31', 8269369851, 'Approved', NULL, 'J.P.Nagar', '2020-08-02 17:05:31', '2020-08-10 19:23:51', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'MALLESH', NULL, 570008),
(67, 'DURGHA BHANDAR 129', '#271, Near Water Tank, Behind Christ Public School', '', '129', 8431519802, 'Approved', NULL, 'Dattagalli', '2020-08-02 17:05:46', '2020-08-11 19:00:50', 'srinivas@farmar.in', 'test@gmail.com', 0, '', 'OM PRAKASH', NULL, 570022),
(68, 'COORG VEGETABLES 32', 'Opp Javaregowda Park', '', '32', 8606616049, 'Approved', NULL, 'Saraswathipuram', '2020-08-02 17:05:55', '2020-08-10 19:23:51', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'MUSAFIR', NULL, 570009),
(69, 'SMM PROVISION STORES 128', 'S.B.M Layout Main Road, Near Roopanagar', '', '128', 9900978379, 'Approved', NULL, 'Bogadi', '2020-08-02 17:06:20', '2020-08-10 20:44:30', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'PUNITH', NULL, 570026),
(70, 'JANATHA FRUITS&VEGETABLES 33', '7th main, 5th cross, Opp Shakthi Medicals', '', '33', 9620433873, 'Approved', NULL, 'Saraswathipuram', '2020-08-02 17:06:30', '2020-08-10 19:10:29', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'JANIF', NULL, 570009),
(71, 'JANATHA FRUITS & VEGETABLES 34', 'Next to Ruby Bakery', '', '34', 8088193938, 'Approved', NULL, 'Ramakrishna nagar', '2020-08-02 17:07:03', '2020-08-10 19:23:51', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'BAIJU', NULL, 570022),
(72, 'TRIVENI 127', '80 Ft Road, Kanakadasanagar', '', '127', 9480313079, 'Approved', NULL, 'Dattagalli', '2020-08-02 17:07:23', '2020-08-10 20:13:33', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'KABEER', NULL, 570022),
(73, 'R.K BHANDAR 126', '#4055, 5th cross, H Block, 3rd Stage', '', '126', 9620611595, 'Approved', NULL, 'Dattagalli', '2020-08-02 17:07:55', '2020-08-10 21:02:25', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'RATHANLAL', NULL, 570022),
(74, 'KANNAN STORES N VEG 123', 'Swimming Pool Road ', '', '123', 9945403119, 'Approved', NULL, 'Saraswathipuram', '2020-08-02 17:08:35', '2020-08-10 20:13:33', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'RAJESH KANNAN', NULL, 570009),
(75, 'BHAVANI FRUITS & VEGETABLES 35', '\"G\" Block, 8th cross, Opp Punith Covention Hall, ', '', '35', 9743678421, 'Approved', NULL, 'Ramakrishnanagar', '2020-08-02 17:08:46', '2020-08-10 19:23:51', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'MAHESH', NULL, 570022),
(76, 'MANCHEGOWDA VEGETABLES 36', '154M, \"E & F\" Block, Near SaiBaba Circle', '', '36', 9741842975, 'Approved', NULL, 'Ramakrishnanagar', '2020-08-02 17:09:15', '2020-08-10 19:47:19', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'MANCHEGOWDA', NULL, 570022),
(77, 'MAHADESHWARA FRUITS N VEG 122', 'Near New Meena Studio', '', '122', 9964392131, 'Approved', NULL, 'Kuvempunagar', '2020-08-02 17:09:17', '2020-08-11 19:00:50', 'srinivas@farmar.in', 'test@gmail.com', 0, '', 'MADHU KUMAR', NULL, 570023),
(78, 'GREEN HOUSE 37', '\"I\" Block, Orchid School Stop', '', '37', 8971669020, 'Approved', NULL, 'Ramakrishnanagar', '2020-08-02 17:09:36', '2020-08-10 19:10:29', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'SUMA', NULL, 570022),
(79, 'AISHWARYA FRUITS N VEG 121', '263/A, 1 stage, V.V.Mohalla', '', '121', 8848512996, 'Approved', NULL, 'Gokulam', '2020-08-02 17:09:52', '2020-08-10 20:14:55', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'MUJEEB', NULL, 570002),
(80, 'ANKANATHESHWARA VEGETABLES 38', '2nd cross, Janathanagar', '', '38', 9739546166, 'Approved', NULL, 'J.P.Nagar', '2020-08-02 17:10:03', '2020-08-10 19:47:19', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'MANJUNATH', NULL, 570008),
(81, 'VINAYAKA ENTERPRISES 120', '#114, 9th main, 11th cross, 3rd stage', '', '120', 9844478999, 'Approved', NULL, 'Gokulam', '2020-08-02 17:10:28', '2020-08-10 20:13:33', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'MANJUNATH', NULL, 570002),
(82, 'SHREEDEVI PROVISION STORES 118', '#12, K.H.B.Colony', '', '118', 8884115007, 'Approved', NULL, 'Hootagalli', '2020-08-02 17:11:04', '2020-08-10 20:01:55', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'PRAVEEN', NULL, 570027),
(83, 'JANATHA FRUITS N VEG 117', '#27, S.B.I. Main Road, Sury Bakery', '', '117', 9036982346, 'Approved', NULL, 'Hebbal', '2020-08-02 17:11:44', '2020-08-10 20:01:55', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'CHANDAN', NULL, 570016),
(84, 'R MART 39', '2nd stage, Devaianahundi Main Road', '', '39', 9343066668, 'Approved', NULL, 'Srirampura', '2020-08-02 17:11:49', '2020-08-10 19:47:19', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'RAGHU', NULL, 570008),
(85, 'BASAVESWARA VEGETABLES 40', 'Next to Suyog Hospital', '', '40', 9148994764, 'Approved', NULL, 'Ramakrishnanagar', '2020-08-02 17:12:12', '2020-08-10 19:47:19', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'MADHU SUDAN', NULL, 570022),
(86, 'VIRABHARGAVESHWARA VEG 116', 'Near Kamakshi hospital', '', '116', 9731502088, 'Approved', NULL, 'Saraswathipuram', '2020-08-02 17:12:20', '2020-08-11 19:00:50', 'srinivas@farmar.in', 'test@gmail.com', 0, '', 'KANTHARAJU', NULL, 570009),
(87, 'NANDAN 112', 'Mysore', NULL, '112', 7975465535, 'Approved', NULL, 'Mysore', '2020-08-02 17:12:55', '2020-08-02 17:13:42', 'test@gmail.com', 'test@gmail.com', 0, NULL, 'NANDAN', NULL, 0),
(88, 'SUKRUTHA FRUITS TEA SHOP 41', 'Opp Mahadevapura, Railway gate', '', '41', 8183075878, 'Approved', NULL, 'J.P.Nagar', '2020-08-02 17:13:34', '2020-08-10 19:10:29', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'SUNIL KUMAR', NULL, 570008),
(89, 'A K VEG 111', '#5, Telephone Exchange Road, 10th cross(Near Ashokapuram station)', '', '111', 8197574564, 'Approved', NULL, 'Ashokapuram', '2020-08-02 17:13:55', '2020-08-10 20:27:35', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'PRADEEP', NULL, 570008),
(90, 'KRISHNA VEGETABLES & FRUITS 42', 'Opp Mahadevpura Railway Gate, J.P.Nagar Railway Gate', '', '42', 7892495065, 'Approved', NULL, 'J.P.Nagar', '2020-08-02 17:14:08', '2020-08-10 19:23:51', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'SAMETH', NULL, 570008),
(91, 'KRISHNA STORE 43', 'Navodaya Badavane, Opp Mahadevapura', '', '43', 7676701851, 'Approved', NULL, 'Mahadevapura', '2020-08-02 17:14:39', '2020-08-11 19:00:50', 'srinivas@farmar.in', 'test@gmail.com', 0, '', 'BALAKRISHNA', NULL, 570008),
(92, 'VIKAS PROVISION STORES 110', 'K.G.Koppal', '', '110', 9945779776, 'Approved', NULL, 'K.G.Koppal', '2020-08-02 17:14:48', '2020-08-10 20:01:55', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'ANAND RAM', NULL, 570009),
(93, 'ABHIRAM STORE 44', '#723, 5th cross, \"B\" Block, Mahadevpura', '', '44', 9916617068, 'Approved', NULL, 'Mahadevapura', '2020-08-02 17:15:03', '2020-08-10 19:23:51', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'ABHIRAM', NULL, 570019),
(94, 'BINCY STORE 45', '6th cross, \"B\" Block', '', '45', 9916020368, 'Approved', NULL, 'Mahadevapura', '2020-08-02 17:15:29', '2020-08-10 18:04:05', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'RAJU', NULL, 570008),
(95, 'CHAMUNDESWARI GREEN HOUSE 46', 'Marinikethana, Opp Halli Bogadi', '', '46', 9611358029, 'Approved', NULL, 'Halli Bogadi', '2020-08-02 17:15:51', '2020-08-10 18:04:05', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'NIJAGUNA', NULL, 570026),
(96, 'CHILLIES FRUITS & VEG 109', 'Vijayanagar 2nd stage', '', '109', 9986806991, 'Approved', NULL, 'Vijayanagar 2nd stage', '2020-08-02 17:16:43', '2020-08-10 20:01:55', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'DILEEP PV', NULL, 570017),
(97, 'MYSORE MART 47', '#10053, 2nd phase,4th stage', '', ' 47', 7349177600, 'Approved', NULL, 'Vijaynagar', '2020-08-02 17:16:51', '2020-08-10 18:04:05', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'VASANTH KUMARI', NULL, 570017),
(98, 'SANGEETHA FRUITS & VEG 108', '2nd stage', '', '108', 9481318450, 'Approved', NULL, 'Siddarthalayout ', '2020-08-02 17:17:26', '2020-08-10 20:13:33', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'SALIM', NULL, 570011),
(99, 'ROOPA BHANDAR 48', '#267, 3rd cross, Roopa Layout', '', '48', 9880940206, 'Approved', NULL, 'Roopanagar', '2020-08-02 17:17:27', '2020-08-10 18:04:05', 'kanthraj@dotangle.com', 'test@gmail.com', 9845395697, '', 'ROOPA BHANDAR ', NULL, 570026),
(100, 'ROAD SIDE VENDOR 49', 'Vijaynagar 3rd stage', '', '49', 7022110690, 'Approved', NULL, 'Vijayshreepura', '2020-08-02 17:18:07', '2020-08-10 18:38:38', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'RAVI', NULL, 570001),
(101, 'JANATHA FRUITS N VEG 107', '#825, Vinaya Marga Main Road', '', '107', 7676101980, 'Approved', NULL, 'Siddarthalayout ', '2020-08-02 17:18:16', '2020-08-10 20:01:55', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'SAJEEAN', NULL, 570011),
(102, 'ANNADATHA FARM 50', 'Vijaynagar, 3rd stage, Vijaya shree pura', '', '50', 7899007800, 'Approved', NULL, 'Vijaynagar 3rd stage', '2020-08-02 17:18:46', '2020-08-11 19:00:50', 'srinivas@farmar.in', 'test@gmail.com', 7760144369, '', 'VEERABHADRA', NULL, 570030),
(103, 'TEJAS ORGANIC 106', '#39, 7th main', '', '106', 6362018656, 'Approved', NULL, 'Saraswathipuram', '2020-08-02 17:19:03', '2020-08-10 20:01:55', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'TEJAS', NULL, 570009),
(104, 'HARI VEGETABLES 51', 'Gaddige Main Road', '', '51', 8073910583, 'Approved', NULL, 'Bogadi', '2020-08-02 17:19:07', '2020-08-10 18:54:07', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'HARISHA', NULL, 570026),
(105, 'ANJANEYA PROVISION STORE 52', 'Roopanagar', '', '52', 9611075592, 'Approved', NULL, 'Roopanagar', '2020-08-02 17:19:38', '2020-08-10 18:04:05', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'GOVINDA SHETTY', NULL, 570026),
(106, 'ANEKA SUPER MARKET 105', '#437/A, Contour Road, 3rd Stage', '', '105', 7411851216, 'Approved', NULL, 'Gokulam', '2020-08-02 17:19:44', '2020-08-10 19:47:19', 'kanthraj@dotangle.com', 'test@gmail.com', 8147216320, '', 'LAVI KUMAR', NULL, 570002),
(107, 'SRI MANJUNATHA FRUITS & VEG 104', 'Teju Corner', '', '104', 9945534655, 'Approved', NULL, 'Mysore', '2020-08-02 17:20:20', '2020-08-10 20:01:55', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'NINGE GOWDA', NULL, 570001),
(108, 'JANATHA FRUITS N VEG 103', '#2H, Opp ICICI Bank, K.D. Road', '', '103', 9036826664, 'Approved', NULL, 'Jayalakshmipuram', '2020-08-02 17:20:59', '2020-08-10 20:01:55', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'VIMAL', NULL, 570012),
(109, 'BALAJI STORES 53', 'Bogadi, Near Harsha Bar', '', '53', 9481044877, 'Approved', NULL, 'Bogadi', '2020-08-02 17:21:13', '2020-08-10 18:04:05', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'SATISH', NULL, 570026),
(110, 'BHARGAVESHWARA FRUITS 102', 'Surya Bakery', '', '102', 8971659330, 'Approved', NULL, 'Hebbal', '2020-08-02 17:21:33', '2020-08-10 19:47:19', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'KISHORE GOWDA', NULL, 570016),
(111, 'NEW KAMADENU 054', '#709/1 Sriranga Comple, Sahukarchinaya road, Near Vijaya Bank', '', '54', 9880785499, 'Approved', NULL, 'Bogadi 2nd stage', '2020-08-02 17:21:38', '2020-08-10 18:54:07', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'MAHADEV', NULL, 570026),
(112, 'JANATHA FRUITS N VEG 101', '#4582, High Tension Road, Vijaynagar 2nd stage', '', '101', 9036605181, 'Approved', NULL, 'Vijaynagar 2nd stage', '2020-08-02 17:22:11', '2020-08-10 20:01:55', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'VIJU', NULL, 570017),
(113, 'SRI CHAMUNDESWARI 100', '#2332, 12th main', '', '100', 9448074920, 'Approved', NULL, 'Vijaynagar 2nd stage', '2020-08-02 17:22:46', '2020-08-10 18:54:07', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'CHANDRASHEKAR', NULL, 570017),
(114, 'MPM FV 56', '#201/1, 2nd stage,Near Vijaya Bank Circle', '', '56', 7019782774, 'Approved', NULL, 'Bogadi', '2020-08-02 17:23:13', '2020-08-10 18:04:05', 'kanthraj@dotangle.com', 'test@gmail.com', 9844566274, '', 'MANU', NULL, 570026),
(115, 'SRI PARVATHI GREEN HOUSE 99', '#1H, No - 2, 16th main road, Vinayakanagar', '', '99', 9986433752, 'Approved', NULL, 'Paduvaralli', '2020-08-02 17:23:33', '2020-08-10 18:04:05', 'kanthraj@dotangle.com', 'test@gmail.com', 9844286844, '', 'SANJAY', NULL, 570002),
(116, 'BHAVANI BHANDAR 57', 'Rajarajeshwarinagar, Near Narayana Bakery', '', '57', 8073935508, 'Approved', NULL, 'Rajarajeshwarinagar', '2020-08-02 17:23:58', '2020-08-10 18:04:05', 'kanthraj@dotangle.com', 'test@gmail.com', 9900423866, '', 'SUKHLAL', NULL, 570026),
(117, 'MAHADESWARA VEGETABLES 98', '#116, 6th main, 5th cross', '', '98', 9945333953, 'Approved', NULL, 'Vinayakanagara', '2020-08-02 17:24:09', '2020-08-11 19:00:50', 'srinivas@farmar.in', 'test@gmail.com', 0, '', 'BASAVARAJU', NULL, 570012),
(118, 'NATURE FRESH 58', '#239, BEML Layout', '', '58', 7026368359, 'Approved', NULL, 'RajaRajeswarinagar', '2020-08-02 17:24:18', '2020-08-10 18:04:05', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'NAGARAJU', NULL, 570026),
(119, 'SIRI MART 59', '546, 80 Ft Road, BEML Layout, R.R.Nagar', '', '59', 6366010389, 'Approved', NULL, 'Mysore', '2020-08-02 17:24:41', '2020-08-10 18:04:05', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'LOKESH', NULL, 570026),
(120, 'GOKULAM FRUITS&VEGETABLES 97', '9th cross, 3rd stage, Dr.Corner', '', '97', 9986440661, 'Approved', NULL, 'Gokulam', '2020-08-02 17:24:42', '2020-08-10 18:38:38', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'SURESH BABU', NULL, 570002),
(121, 'REAL FRESH 96', '#226, 1st main, 2nd stage', '', '96', 9972024560, 'Approved', NULL, 'Gokulam', '2020-08-02 17:25:13', '2020-08-10 18:54:07', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'MOHAMMAD FAZAL', NULL, 570002),
(122, 'PRAJWALA JUICE CORNER 60', 'Nandi circle, 3rd stage', '', '60', 9900284005, 'Approved', NULL, 'R.R. Nagar', '2020-08-02 17:25:54', '2020-08-10 18:04:05', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'GANESH', NULL, 570026),
(123, 'FORM FRESH (R.KNAGAR) 95', 'Near Ruby Bakery, \"H\" Block', '', '95', 9632075317, 'Approved', NULL, 'Ramakrishnanagar', '2020-08-02 17:25:54', '2020-08-10 18:54:07', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'RAMAKRISHNA', NULL, 570022),
(124, 'SRINIVAS STORE 61', '3rd stage, Near Union Bank, Basavaraj circle', '', '61', 7259375796, 'Approved', NULL, 'Vijaynagar 3rd stage', '2020-08-02 17:26:21', '2020-08-10 18:38:38', 'kanthraj@dotangle.com', 'test@gmail.com', 7899075520, '', 'SHYLENDRA', NULL, 570030),
(125, 'TULASI PROVISSION STORE 84', 'Saraswathi Talkies Road, Opp Shyam Studio, Koppulu', '', '84', 9448600240, 'Approved', NULL, 'Saraswathipuram', '2020-08-02 17:26:40', '2020-08-10 18:54:07', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'RAMESH', NULL, 570009),
(126, 'SIDDESWARA STORE 62', 'Vijaynagar 3rd stage, B block, 22 cross, Near Cauvery Bank', '', '62', 9739687788, 'Approved', NULL, 'Vijaynagar ', '2020-08-02 17:26:50', '2020-08-10 18:04:05', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'BABU', NULL, 570030),
(127, 'SAGAR FAST FOOD 83', 'Opp Karnataka Bank, Gobblimara', '', '83', 9535853988, 'Approved', NULL, 'J.P.Nagar', '2020-08-02 17:27:19', '2020-08-10 18:38:38', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'SAGAR', NULL, 570008),
(128, 'CHAMUNDESHWARI FRUITS 63', 'Kanthrajurs road, Ananda nagar', '', '63', 9945434151, 'Approved', NULL, 'Ananda nagar', '2020-08-02 17:27:21', '2020-08-11 19:00:50', 'srinivas@farmar.in', 'test@gmail.com', 0, '', 'CHAMUNDESHWARI FRUITS', NULL, 570022),
(129, 'SHREE SHAKTHI BALE MANDI 64', '3rd main, 9th cross, T.K. Layout, Near BSNL, RTTC', '', '64', 8884662116, 'Approved', NULL, 'T.K.Layout', '2020-08-02 17:28:03', '2020-08-10 18:04:05', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'ARUN KUMAR', NULL, 570022),
(130, 'K.M.D 82', '#44, 4th cross, Muneshwaranagar, Near Ooty Road', '', '82', 8453357637, 'Approved', NULL, 'Mysore', '2020-08-02 17:28:23', '2020-08-11 19:00:50', 'srinivas@farmar.in', 'test@gmail.com', 0, '', 'K.M MAHADEVAGOWDA', NULL, 570001),
(131, 'VARSHINI FARM 65', '3rd cross, 9th main, Near BSNL, RTTC', '', '65', 9845835118, 'Approved', NULL, ' T.K.Layout', '2020-08-02 17:28:33', '2020-08-10 18:38:38', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'CHANNABASAMMA', NULL, 570022),
(132, 'ASHWATHII STORE 81', '#1, 4th main, 17th cross, XL Plant Road', '', '81', 9916253927, 'Approved', NULL, 'Vidyaranyapuram', '2020-08-02 17:28:57', '2020-08-10 18:38:38', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'ANEESH', NULL, 570008),
(133, 'MATHAJI BHANDAR 66', 'Railway Colony, Near Harividyalaya,Near Bogadi', '', '66', 9738301315, 'Approved', NULL, 'Shardhadevinagar', '2020-08-02 17:29:04', '2020-08-10 18:38:38', 'kanthraj@dotangle.com', 'test@gmail.com', 7338158180, '', 'RAMESH', NULL, 570022),
(134, 'SRI MARUTHI PROVISION STORE 80', '4th main, 26th cross, XL Plant Road', '', '80', 9880997116, 'Approved', NULL, 'Vidyaranyapuram', '2020-08-02 17:29:35', '2020-08-10 18:54:07', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'LOKESH', NULL, 570008),
(135, 'PARADISE SUPER BAZAR 79', 'Opp St.Thomas School', '', '79', 8078899388, 'Approved', NULL, 'Vidyaranyapuram', '2020-08-02 17:30:11', '2020-08-10 18:38:38', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'NISAR', NULL, 570008),
(136, 'AMRUTH F AND V STALL 67', 'HIG 11, New Kanthrajurs road', '', '67', 9739737783, 'Approved', NULL, 'Shardhadevi Nagar', '2020-08-02 17:30:15', '2020-08-10 18:04:05', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'KUMAR', NULL, 570022),
(137, 'NARAYAN DEPARTMENTAL STORE 68', '80 Ft Road', '', '68', 9449144294, 'Approved', NULL, 'R.R.Nagar', '2020-08-02 17:30:36', '2020-08-10 18:38:38', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'SRIJITH', NULL, 570026),
(138, 'JAVANAMMA PROVISION STORE 78', 'Janatha Layout, 6th cross, \"D\" Block, Main Road', '', '78', 7892210796, 'Approved', NULL, 'J.P.Nagar', '2020-08-02 17:30:44', '2020-08-10 18:38:38', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'MAHESH', NULL, 570008),
(139, 'LAKSHMIDEVI KRUPE 69', '#354, 3rd stage', '', '69', 8970594025, 'Approved', NULL, 'Dattagalli', '2020-08-02 17:31:06', '2020-08-10 18:54:07', 'kanthraj@dotangle.com', 'test@gmail.com', 8970105192, '', 'RAJU', NULL, 570022),
(140, 'SRI MAHADESHWARA FRUITS&VEG 77', '2nd stage, Naidu Store Stop', '', '77', 7259758182, 'Approved', NULL, 'Srirampura', '2020-08-02 17:31:37', '2020-08-10 18:04:06', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'MAHADEVU', NULL, 570008),
(141, 'ROAD SIDE VENDOR 70', '3rd stage, E Block, Near Park', '', '70', 9972020995, 'Approved', NULL, 'Vijaynagar 3rd stage', '2020-08-02 17:31:37', '2020-08-10 18:38:38', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'MANIKANTA', NULL, 570030),
(142, 'AMBADI DEPARTMENTAL STORE 71', '\"I\" Block, Next to Mysore one', '', '71', 9448101334, 'Approved', NULL, 'Ramakrishnanagar', '2020-08-02 17:31:59', '2020-08-10 18:38:38', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'PURUSHOTHAM', NULL, 570022),
(143, 'MAHADESWARA STORE 72', '2nd stage, Vinayaka Circle', '', '72', 8105187686, 'Approved', NULL, 'Bogadi', '2020-08-02 17:32:25', '2020-08-10 18:38:38', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'DAYANAND', NULL, 570026),
(144, 'BASAVESWARA STORES 76', 'Opp Syndicate bank A.T.M, KavithaBAkery Circle', '', '76', 9448750541, 'Approved', NULL, 'J.P.Nagar', '2020-08-02 17:32:50', '2020-08-10 18:38:38', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'BASAVARAJU', NULL, 570008),
(145, 'JANATA FRUITS & VEGETABLES 73', '5th cross, 14th main', '', '73', 9535319098, 'Approved', NULL, 'Saraswathipuram', '2020-08-02 17:32:50', '2020-08-10 18:38:38', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'KABEER / ABDULLA', NULL, 570009),
(146, 'ANWITHA FRUITS&VEGETABLES 74', '47, 17th main', '', '74', 9591911309, 'Approved', NULL, 'Saraswathipuram', '2020-08-02 17:33:21', '2020-08-10 18:04:06', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'KIRAN KUMAR/ JEEVAN', NULL, 570009),
(147, 'S.K FRUITS&VEGETABLES  75', '663, Rexa Complex, 17th main, Vishwamanava double road', '', '75', 9880693313, 'Approved', NULL, 'Kuvempunagar', '2020-08-02 17:33:27', '2020-08-10 18:38:38', 'kanthraj@dotangle.com', 'test@gmail.com', 0, '', 'SHYLENDRA KUMAR', NULL, 570023),
(148, 'Hotel Shringar 149', 'Shivarampet Road', '', '149', 8762843840, 'Approved', NULL, 'Shivarampet ', '2020-08-02 18:11:12', '2020-08-11 19:00:50', 'srinivas@farmar.in', 'test@gmail.com', 0, '', 'Narayan Hegde', NULL, 570001),
(149, 'R Mart Fresh 55', '#02,Mahamane Circle', '', '55', 9343066669, 'Approved', NULL, 'Dattagalli', '2020-08-02 23:06:42', '2020-08-11 19:00:50', 'srinivas@farmar.in', 'kanthraj@dotangle.com', 0, '', 'RAGHU', NULL, 570023),
(150, 'Bangalore Party 163', 'Mysore', '', '163', 7676303007, 'Approved', NULL, 'Mysore', '2020-08-03 12:19:36', '2020-08-03 18:31:00', 'test@gmail.com', 'test@gmail.com', 0, '', 'Ambarish Gowda', NULL, 0),
(151, 'Kalabairaveshwara Stores 138', 'Engineers colony, Bogadi, 2nd stage, Prashanth Nagar', '', '138', 8105463830, 'Approved', NULL, 'Bogadi 2nd stage', '2020-08-03 18:30:55', '2020-08-11 19:00:50', 'srinivas@farmar.in', 'test@gmail.com', 0, '', 'Ravi', NULL, 570026),
(152, 'Sudha Shankar 85', '5th cross, 4th main', '', '85', 8431558431, 'Approved', NULL, 'Saraswathipuram', '2020-08-04 20:33:33', '2020-08-10 18:54:07', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 0, '', 'Sudha Shankar Ashwath', NULL, 570009),
(153, 'Cafe Roots 151', 'Gokulam', '', '151', 9035364538, 'Approved', NULL, 'Gokulam', '2020-08-06 21:27:51', '2020-08-11 19:00:50', 'srinivas@farmar.in', 'kanthraj@dotangle.com', 0, '', 'Mathew', NULL, 570002),
(154, 'Farm to Kitchen 139', '#229/4, SBM Road,Hebbal, Vijaynagar, 1st stage', '', '139', 8147207578, 'Approved', NULL, 'Vijaynagar 1st stage', '2020-08-07 16:43:27', '2020-08-11 19:00:50', 'srinivas@farmar.in', 'kanthraj@dotangle.com', 6360578910, '', 'Yuvaraj', NULL, 570017),
(155, 'Vinod T C 124', 'Mysore', '', '124', 9886768789, 'Approved', NULL, 'Mysore', '2020-08-07 21:03:06', '2020-08-07 21:03:44', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 0, '', 'Vinod', NULL, 0),
(156, 'Test Mart 1234', '#839, A Block, 3rd Stage Kanakadasa Nagar', '', '1234', 9886168703, 'Approved', NULL, 'Dattagalli.', '2020-08-08 22:50:36', '2020-08-11 13:22:04', 'kanthraj@dotangle.com', '9886168703', 0, '', 'Kanthraj', NULL, 570023),
(157, 'Siddaganga Mess 150', 'Mysore', '', '150', 9972532614, 'Approved', NULL, 'Bogadi', '2020-08-09 19:36:00', '2020-08-11 19:00:50', 'srinivas@farmar.in', 'kanthraj@dotangle.com', 0, '', 'Shivakumar', NULL, 570026),
(158, 'SMS Fruits & Vegetables 164', 'Mysore', '', '164', 9353972521, 'Approved', NULL, 'Vijayanagar', '2020-08-09 19:52:18', '2020-08-11 13:19:10', 'kanthraj@dotangle.com', 'kanthraj@dotangle.com', 0, '', 'Raju', NULL, 570017),
(159, 'MADHU CART ', 'FARMAR GODOWN', '', '', 9880647313, 'Approved', NULL, 'PICK UP AT GODOWN', '2020-08-10 21:02:46', '2020-08-11 13:22:04', 'kanthraj@dotangle.com', 'md@spicetrip.com', 0, '', 'MADHU', NULL, 570000);

-- --------------------------------------------------------

--
-- Table structure for table `ShopImages`
--

DROP TABLE IF EXISTS `ShopImages`;
CREATE TABLE IF NOT EXISTS `ShopImages` (
  `ShopId` int(11) NOT NULL,
  `Image1` varchar(200) NOT NULL,
  `Image2` varchar(200) NOT NULL,
  `Image3` varchar(200) NOT NULL,
  KEY `ShopId` (`ShopId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ShopImages`
--

INSERT INTO `ShopImages` (`ShopId`, `Image1`, `Image2`, `Image3`) VALUES
(4, 'http://demo.farmar.in/UploadedFiles/Vendors/shop_id/1.png', 'http://demo.farmar.in/UploadedFiles/Vendors/shop_id/2.png', 'http://demo.farmar.in/UploadedFiles/Vendors/shop_id/3.png'),
(8, '', '', ''),
(9, '', '', ''),
(10, '', '', ''),
(11, '', '', ''),
(12, '', '', ''),
(13, '', '', ''),
(14, '', '', ''),
(15, '', '', ''),
(16, '', '', ''),
(21, 'http://demo.farmar.in/UploadedFiles/Vendors/21/Cust_59948.jpg', '', ''),
(22, 'http://demo.farmar.in/UploadedFiles/Vendors/22/Cust_42068.jpg', '', ''),
(23, 'http://demo.farmar.in/UploadedFiles/Vendors/23/Cust_28255.jpg', '', ''),
(24, '', '', ''),
(25, '', '', ''),
(26, '', '', ''),
(27, 'http://demo.farmar.in/UploadedFiles/Vendors/27/Cust_56151.jpg', 'http://demo.farmar.in/UploadedFiles/Vendors/27/Cust_98125.jpg', ''),
(28, '', '', ''),
(29, '', '', ''),
(30, '', '', ''),
(31, '', '', ''),
(32, '', '', ''),
(33, '', '', ''),
(34, '', '', ''),
(35, '', '', ''),
(36, '', '', ''),
(37, '', '', ''),
(38, '', '', ''),
(39, '', '', ''),
(40, '', '', ''),
(41, '', '', ''),
(42, '', '', ''),
(43, '', '', ''),
(44, '', '', ''),
(45, '', '', ''),
(46, '', '', ''),
(47, '', '', ''),
(48, '', '', ''),
(49, '', '', ''),
(50, '', '', ''),
(51, '', '', ''),
(52, '', '', ''),
(53, '', '', ''),
(54, '', '', ''),
(55, '', '', ''),
(56, '', '', ''),
(57, '', '', ''),
(58, '', '', ''),
(59, '', '', ''),
(60, '', '', ''),
(61, '', '', ''),
(62, '', '', ''),
(63, '', '', ''),
(64, '', '', ''),
(65, '', '', ''),
(66, '', '', ''),
(67, '', '', ''),
(68, '', '', ''),
(69, '', '', ''),
(70, '', '', ''),
(71, '', '', ''),
(72, '', '', ''),
(73, '', '', ''),
(74, '', '', ''),
(75, '', '', ''),
(76, '', '', ''),
(77, '', '', ''),
(78, '', '', ''),
(79, '', '', ''),
(80, '', '', ''),
(81, '', '', ''),
(82, '', '', ''),
(83, '', '', ''),
(84, '', '', ''),
(85, '', '', ''),
(86, '', '', ''),
(87, '', '', ''),
(88, '', '', ''),
(89, '', '', ''),
(90, '', '', ''),
(91, '', '', ''),
(92, '', '', ''),
(93, '', '', ''),
(94, '', '', ''),
(95, '', '', ''),
(96, '', '', ''),
(97, '', '', ''),
(98, '', '', ''),
(99, '', '', ''),
(100, '', '', ''),
(101, '', '', ''),
(102, '', '', ''),
(103, '', '', ''),
(104, '', '', ''),
(105, '', '', ''),
(106, '', '', ''),
(107, '', '', ''),
(108, '', '', ''),
(109, '', '', ''),
(110, '', '', ''),
(111, '', '', ''),
(112, '', '', ''),
(113, '', '', ''),
(114, '', '', ''),
(115, '', '', ''),
(116, '', '', ''),
(117, '', '', ''),
(118, '', '', ''),
(119, '', '', ''),
(120, '', '', ''),
(121, '', '', ''),
(122, '', '', ''),
(123, '', '', ''),
(124, '', '', ''),
(125, '', '', ''),
(126, '', '', ''),
(127, '', '', ''),
(128, '', '', ''),
(129, '', '', ''),
(130, '', '', ''),
(131, '', '', ''),
(132, '', '', ''),
(133, '', '', ''),
(134, '', '', ''),
(135, '', '', ''),
(136, '', '', ''),
(137, '', '', ''),
(138, '', '', ''),
(139, '', '', ''),
(140, '', '', ''),
(141, '', '', ''),
(142, '', '', ''),
(143, '', '', ''),
(144, '', '', ''),
(145, '', '', ''),
(146, '', '', ''),
(147, '', '', ''),
(148, '', '', ''),
(149, '', '', ''),
(150, '', '', ''),
(151, '', '', ''),
(152, '', '', ''),
(153, '', '', ''),
(154, '', '', ''),
(155, '', '', ''),
(156, 'http://demo.farmar.in/UploadedFiles/Vendors/156/Cust_35715.jpg', '', ''),
(157, '', '', ''),
(158, '', '', ''),
(159, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `Stocks`
--

DROP TABLE IF EXISTS `Stocks`;
CREATE TABLE IF NOT EXISTS `Stocks` (
  `StockId` int(11) NOT NULL AUTO_INCREMENT,
  `VendorId` int(11) NOT NULL,
  `ProductId` int(11) NOT NULL,
  `TotalWeight` decimal(10,2) NOT NULL,
  `GradeAWeight` decimal(10,2) NOT NULL,
  `GradeBWeight` decimal(10,2) DEFAULT NULL,
  `DumpWeight` decimal(10,2) DEFAULT NULL,
  `CreatedDateTime` datetime NOT NULL,
  `CreatedUserId` varchar(50) NOT NULL,
  PRIMARY KEY (`StockId`),
  KEY `FK_S_VendorId` (`VendorId`),
  KEY `FK_S_ProductId` (`ProductId`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Stocks`
--

INSERT INTO `Stocks` (`StockId`, `VendorId`, `ProductId`, `TotalWeight`, `GradeAWeight`, `GradeBWeight`, `DumpWeight`, `CreatedDateTime`, `CreatedUserId`) VALUES
(30, 4, 10, '30.00', '28.00', '0.00', '2.00', '2020-08-03 12:40:25', 'test@gmail.com'),
(31, 4, 8, '114.20', '108.00', '0.00', '6.20', '2020-08-03 13:09:37', 'kanthraj@dotangle.com');

-- --------------------------------------------------------

--
-- Table structure for table `Users`
--

DROP TABLE IF EXISTS `Users`;
CREATE TABLE IF NOT EXISTS `Users` (
  `UserId` int(11) NOT NULL AUTO_INCREMENT,
  `FullName` varchar(30) NOT NULL,
  `MobileNo` bigint(20) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Role` varchar(20) NOT NULL,
  PRIMARY KEY (`UserId`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Users`
--

INSERT INTO `Users` (`UserId`, `FullName`, `MobileNo`, `Email`, `Password`, `Role`) VALUES
(1, 'Abhijit Dharangutte', 8123506123, 'abhijitjd003@gmail.com', '123', 'Admin'),
(2, 'Shamnoon', 9876543210, 'shamnoon@gmail.com', '321', 'Staff'),
(5, 'Test', 1234567890, 'test@gmail.com', '123', 'Admin'),
(6, 'Prashanth B S', 9845404609, 'md@spicetrip.com', 'Delivery456$', 'Admin'),
(7, 'Revanna', 9945273815, 'revanna@farmar.in', 'safe456', 'Staff'),
(8, 'Jagadish', 9845404650, 'jagadish@farmar.in', 'safe456', 'Staff'),
(9, 'Devaraj', 9900852365, 'devaraj@farmar.in', 'safe456', 'Staff'),
(10, 'Kanthraj', 9886168703, 'kanthraj@dotangle.com', 'Mysore456', 'Admin'),
(11, 'Anjan Kumar', 7760693888, 'anjan@farmar.in', 'safe456', 'Staff'),
(12, 'Rakshith', 9901695810, 'rakshitharadhya007@gmail.com', 'Mysore777', 'Admin'),
(13, 'Srinivas', 7406556664, 'srinivas@farmar.in', 'Safe123$', 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `Vendors`
--

DROP TABLE IF EXISTS `Vendors`;
CREATE TABLE IF NOT EXISTS `Vendors` (
  `VendorId` int(11) NOT NULL AUTO_INCREMENT,
  `TypeId` int(11) NOT NULL,
  `ContactName` varchar(50) NOT NULL,
  `MobileNo` bigint(20) NOT NULL,
  `Address` varchar(200) NOT NULL,
  `Disable` tinyint(4) DEFAULT NULL,
  `CreatedDateTime` datetime NOT NULL,
  `CreatedUserId` varchar(50) NOT NULL,
  PRIMARY KEY (`VendorId`),
  KEY `FK_TypeId` (`TypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Vendors`
--

INSERT INTO `Vendors` (`VendorId`, `TypeId`, `ContactName`, `MobileNo`, `Address`, `Disable`, `CreatedDateTime`, `CreatedUserId`) VALUES
(4, 4, 'APMC - Default', 9999999999, 'Mysore', 0, '2020-08-02 23:56:04', 'kanthraj@dotangle.com'),
(5, 6, 'Market - Default', 999999999, 'Mysore', 0, '2020-08-02 23:56:26', 'kanthraj@dotangle.com'),
(6, 5, 'CC- Default', 9999999999, 'Mysore', 0, '2020-08-02 23:56:46', 'kanthraj@dotangle.com');

-- --------------------------------------------------------

--
-- Table structure for table `VendorTypes`
--

DROP TABLE IF EXISTS `VendorTypes`;
CREATE TABLE IF NOT EXISTS `VendorTypes` (
  `TypeId` int(11) NOT NULL AUTO_INCREMENT,
  `TypeName` varchar(50) NOT NULL,
  `Description` varchar(1024) DEFAULT NULL,
  `Disable` tinyint(4) DEFAULT NULL,
  `CreatedDateTime` datetime NOT NULL,
  `CreatedUserId` varchar(50) NOT NULL,
  PRIMARY KEY (`TypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `VendorTypes`
--

INSERT INTO `VendorTypes` (`TypeId`, `TypeName`, `Description`, `Disable`, `CreatedDateTime`, `CreatedUserId`) VALUES
(4, 'APMC', NULL, 0, '2020-08-02 23:54:35', 'kanthraj@dotangle.com'),
(5, 'Collection Centre', NULL, 0, '2020-08-02 23:55:29', 'kanthraj@dotangle.com'),
(6, 'Market', NULL, 0, '2020-08-02 23:55:35', 'kanthraj@dotangle.com');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `OrderProducts`
--
ALTER TABLE `OrderProducts`
  ADD CONSTRAINT `FK_OrderNo` FOREIGN KEY (`OrderNo`) REFERENCES `Orders` (`OrderNo`),
  ADD CONSTRAINT `FK_ProductId` FOREIGN KEY (`ProductId`) REFERENCES `Products` (`ProductId`);

--
-- Constraints for table `Orders`
--
ALTER TABLE `Orders`
  ADD CONSTRAINT `FK_ShopId` FOREIGN KEY (`ShopId`) REFERENCES `ShopDetails` (`ShopId`);

--
-- Constraints for table `Products`
--
ALTER TABLE `Products`
  ADD CONSTRAINT `FK_CategoryId` FOREIGN KEY (`CategoryId`) REFERENCES `ProductCategories` (`CategoryId`);

--
-- Constraints for table `Stocks`
--
ALTER TABLE `Stocks`
  ADD CONSTRAINT `FK_S_VendorId` FOREIGN KEY (`VendorId`) REFERENCES `Vendors` (`VendorId`),
  ADD CONSTRAINT `FK_S_ProductId` FOREIGN KEY (`ProductId`) REFERENCES `Products` (`ProductId`);

--
-- Constraints for table `Vendors`
--
ALTER TABLE `Vendors`
  ADD CONSTRAINT `FK_TypeId` FOREIGN KEY (`TypeId`) REFERENCES `VendorTypes` (`TypeId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
