import React, { Component } from 'react';
import { Route } from 'react-router';
import Layout from './components/Layout';
import Topics from './components/Topics';
import QuestionDetails from './components/QuestionDetails';
import PollDetails from './components/PollDetails';
import SocialLogin from './components/navmenu/SocialLogin';
import { setHyvorTalkSignon, setLoginInfo, setUserAliasName } from './components/utils/SetLocalStorage';
import MyProfile from './components/MyProfile';
import AddQuestion from './components/AddQuestion';
import { DialogContent, IconButton, Grid, Dialog, TextField, DialogActions, Button } from '@material-ui/core';
import CloseIcon from '@material-ui/icons/Close';
import axios from 'axios';
import Notifications from './components/Notifications';
import TestRoute from './components/TestRoute';

export default class App extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            open: false,
            email: '',
            showAlias: false,
            showProfile: false,
            alias_name: '',
            alias_name_err: '',
            prev_page: '',
            isPopular: 0,
            searchValue: '',
            anchorEl: null,
            notification: false,
            readLoginUrl: false,
            hashCode: '',
            userData: '',
        };
    }

    userLogin = () => {
        this.setState({ open: true, anchorEl: null });
        let name = localStorage.getItem('user_name');
        let email = localStorage.getItem('user_email');
        let alias_name = localStorage.getItem('user_alias_name');

        if(name && email && !alias_name) {
            this.setState({ showAlias: true });
        } else if(name && email && alias_name) {
            const { history } = this.props;
            if (history) history.push({ pathname: '/myprofile' });
        }
    }

    embedHyvorTalk = (isLoggedIn, userId, name, email) => {
        fetch('http://localhost:4001/hyvorTalkSignon/'+isLoggedIn+'/'+userId+'/'+name+'/'+email)
        .then(res => res.json())
        .then(result => {
            this.setState({ hashCode: result.hash, userData: result.userData });            
            setHyvorTalkSignon(result.hash, result.userData);
        })
        .catch(function (error) {
            console.log(error);
        })
        .then(function () {
        });
    }

    handleClose = () => {
        this.setState({ open: false });
    };

    handleAliasClose = () => {
        this.setState({ showAlias: false });
    }

    handleChange = (event) => {
        this.setState({ 
            alias_name: event.target.value,
            alias_name_err: event.target.value.length <= 0 ? 'Please enter alias name' : ''
        });
    }

    saveChanges = () => {
        if(this.validateAllInputs() && !this.state.alias_name_err) {
            setUserAliasName(this.state.alias_name);
            this.setState({ showAlias: false });
            this.embedHyvorTalk(true, localStorage.getItem('user_id'), 
                localStorage.getItem('user_alias_name'), 
                localStorage.getItem('user_email'))
        } else {
            if (!this.state.alias_name) {
                this.setState({ alias_name_err: 'Please enter alias name' });
            }
        }
    }

    validateAllInputs = () => {
        if(!this.state.alias_name) {
            return false; 
        }
        else{ return true; }
    }

    onGoogleLoginSuccess = (res) => {
        if(res.profileObj) {
            console.log('[Login Success] currentUser: ', res);
            setLoginInfo(res.profileObj.name, res.profileObj.email, res.profileObj.googleId);
            this.setState({ email: res.profileObj.email, open: false, showAlias: true });
        }
    };

    onGoogleLoginFailure = (res) => {
        console.log('[Login Failed] res: ', res);
        localStorage.clear();
    }

    responseFacebook = (response) => {        
        if(response.name && response.email && response.userId) {
            console.log('[Facebook Login] ', response);
            setLoginInfo(response.name, response.email, response.userId);
            this.setState({ email: response.email, open: false, showAlias: true });
        }
    }

    componentDidMount() {
        let isLoggedIn = localStorage.getItem('user_email') && localStorage.getItem('user_alias_name') ? true : false;
        this.embedHyvorTalk(isLoggedIn, localStorage.getItem('user_id'),
            localStorage.getItem('user_alias_name'), 
            localStorage.getItem('user_email'));

        this.setState({ 
            email: localStorage.getItem('user_email'),
            alias_name: localStorage.getItem('user_alias_name')
        });
    }

    addQuestion = () => {
        this.setState({ anchorEl: null });       
        let name = localStorage.getItem('user_name');
        let email = localStorage.getItem('user_email');
        let alias_name = localStorage.getItem('user_alias_name');

        if(!name && !email && !alias_name) {
            this.setState({ open: true });
        } else if(name && email && !alias_name) {
            this.setState({ showAlias: true });
        } else if(name && email && alias_name) {
            const { history } = this.props;
            //sessionStorage.setItem('redirect_screen_nm', this.props.location.pathname);
            this.setState({ prev_page: this.props.location.pathname });
            if (history) history.push({
                pathname: '/topics/askEDWhat'
            });
        }
    }

    sortByPopular = () => {
        this.setState({isPopular: 1});        
    }

    sortByNew = () => {
        this.setState({isPopular: 0});        
    }

    searchTopics = (event) => {
        this.setState({searchValue: event.target.value});
    }

    handleMobileMenuOpen = (event) => {
        this.setState({ anchorEl: event.currentTarget });
    };
    
    handleMobileMenuClose = () => {
        this.setState({ anchorEl: null });
    };

    webNotifications = () => {
        this.setState({ notification: true });
    }

    handleCloseNotification = () => {
        this.setState({ notification: false });
    }

    componentDidUpdate = (prevProps, prevState) => {
        let array = this.props.location.pathname.split('/');
        let is_login_url = array[array.length-1];

        if(is_login_url === 'is_login_url=true' && !this.state.readLoginUrl) {
            let name = localStorage.getItem('user_name');
            let email = localStorage.getItem('user_email');
            let alias_name = localStorage.getItem('user_alias_name');

            if(!name && !email && !alias_name) {
                this.setState({ open: true, readLoginUrl: true });
            } else if(name && email && !alias_name) {
                this.setState({ showAlias: true, readLoginUrl: true });
            }
        }
    }

    render() {
        const name = localStorage.getItem('user_name');
        const email = localStorage.getItem('user_email');
        const alias_name = localStorage.getItem('user_alias_name');
        
        return (
            <Layout userLogin={this.userLogin} 
                userEmail={email} 
                userName={name}
                userAliasName={alias_name} 
                sortByPopular={this.sortByPopular}
                sortByNew={this.sortByNew}
                prev_page={this.state.prev_page}
                addQuestion={this.addQuestion}
                isPopular={this.state.isPopular}
                searchTopics={this.searchTopics}
                handleMobileMenuOpen={this.handleMobileMenuOpen}
                handleMobileMenuClose={this.handleMobileMenuClose}
                anchorEl={this.state.anchorEl}
                webNotifications={this.webNotifications}
            >
                
                {/* Social Login (Google/Facebook) */}
                { this.state.open && !name && !email &&
                    <SocialLogin open={this.state.open}
                        handleClose={this.handleClose}
                        onGoogleLoginSuccess={this.onGoogleLoginSuccess}
                        onGoogleLoginFailure={this.onGoogleLoginFailure}
                        responseFacebook={this.responseFacebook}
                    />
                }

                {/* Web Notifications */}
                { this.state.notification &&
                    <Notifications open={this.state.notification}
                        handleCloseNotification={this.handleCloseNotification}
                    />
                }

                {/* If Login Success, Set User Alias Name */}
                { this.state.showAlias && name && email && !alias_name &&
                    <React.Fragment>
                        <Dialog fullWidth open={this.state.showAlias}
                            onClose={this.handleAliasClose} disableBackdropClick
                            aria-labelledby="alert-dialog-title"
                            aria-describedby="alert-dialog-description"
                        >
                            <DialogContent style={{ backgroundColor: '#f6f7f2' }}>
                                <Grid container spacing={0}>
                                    <Grid item xs={11}></Grid>
                                    <Grid item xs={1}>
                                        <IconButton style={{ marginLeft: '22px', marginTop: '-20px' }} onClick={this.handleAliasClose} 
                                            aria-label="settings">
                                            <CloseIcon />
                                        </IconButton>
                                    </Grid>
                                </Grid>
                                <TextField fullWidth name="alias_name" label="Enter alias name" required onChange={this.handleChange} 
                                    noValidate onKeyUp={this.handleKeyPress}
                                    value={alias_name} variant="outlined" style={{ backgroundColor: 'white' }}
                                />
                                { this.state.alias_name_err.length > 0 && 
                                    <span className='error'>{this.state.alias_name_err}</span> }
                            </DialogContent>
                            <DialogActions style={{ backgroundColor: '#f6f7f2' }}>
                                <Button onClick={this.saveChanges} color="primary">
                                    Save
                                </Button>
                            </DialogActions>
                        </Dialog>
                    </React.Fragment>
                }

                <Route exact path='/' render={(props) => 
                    <Topics {...props} 
                        userEmail={email} 
                        userAliasName={alias_name} 
                        isPopular={this.state.isPopular}
                        searchValue={this.state.searchValue} 
                    />} />
                
                <Route exact path='/topics' render={(props) => 
                    <Topics {...props} 
                        userEmail={email} 
                        userAliasName={alias_name} 
                        isPopular={this.state.isPopular} 
                        searchValue={this.state.searchValue}
                    />} />
                
                <Route exact path='/topics/question/comments/:topicId/:title' key='abc' render={(props) => 
                    <QuestionDetails {...props} 
                        userEmail={email} 
                        userAliasName={alias_name} 
                        hashCode={this.state.hashCode}
                        userData={this.state.userData}
                    />} />
                
                <Route exact path='/topics/question/comments/:topicId/:title/:is_login_url' key='xyz' render={(props) => 
                    <QuestionDetails {...props} 
                        userEmail={email} 
                        userAliasName={alias_name} 
                        hashCode={this.state.hashCode}
                        userData={this.state.userData}
                    />} />
                
                <Route exact path='/topics/poll/comments/:topicId/:title' render={(props) => 
                    <PollDetails {...props} 
                        userEmail={email} 
                        userAliasName={alias_name} 
                    />} />
                
                <Route exact path='/myprofile' render={(props) => 
                    <MyProfile {...props} 
                        userEmail={email} 
                        userAliasName={alias_name} 
                        searchValue={this.state.searchValue} 
                    />} />
                
                <Route exact path='/topics/askEDWhat' render={(props) => 
                    <AddQuestion {...props} 
                        userEmail={email}
                        userAliasName={alias_name} 
                    />} />

                <Route exact path='/testroute/:topicId/:title' render={(props) => 
                    <TestRoute {...props} 
                        userEmail={email}
                        userAliasName={alias_name}
                    />} />
            </Layout>
        );
    }
}
