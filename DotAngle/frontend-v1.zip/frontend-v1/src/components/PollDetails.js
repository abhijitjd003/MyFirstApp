import React, { Component, Fragment } from 'react';
import { 
    Grid, withStyles, Card, CardContent, Typography, CardHeader, IconButton, TextField, FormControl, FormControlLabel, Radio, 
    RadioGroup, Button, Backdrop, CircularProgress, useMediaQuery
} from '@material-ui/core';
import { withRouter } from 'react-router-dom';
import { useStyles } from './common/useStyles';
import './common/Common.css'
import classNames from 'classnames';
import VisibilityIcon from '@material-ui/icons/Visibility';
import Add1 from './images/add1.jpg';
import Add2 from './images/add2.jpg';
import ShareIcon from '@material-ui/icons/Share';
import MessageIcon from './images/mesage.png';
import VoteIcon from './images/votes_icon.png';
import api from './common/APIValues';
import FlagIcon from '@material-ui/icons/Flag';
import CommonFunc from './common/CommonFunc';
import axios from 'axios';
import LikeIcon from './images/like.png';
import ProgressBar from "@ramonak/react-progress-bar";
import HyvorTalk from 'hyvor-talk-react';
import LikeIconColor from './images/like_h.png';
import VoteIconColor from './images/votes_h.png';
import Report from './Report';

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);    
    return <Component mediaQuery={mediaQuery} {...props} />;
};

class PollDetails extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            userTopic: {}, comment_text: '', userTopicOptions: [], voteOption: '', loader: false, message: '',
            disableVoteNow: false, err_msg: '', success_msg: '', openVote: false, viewInd: true,
            totalVotes: 0, voteInd: false, likeInd: false, openReport: false, rptInd: false,
            errors: {
                voteOption: '',
            },
        }
    }

    componentDidMount() {
        window.scrollTo(0, 0);
        let topicId = this.props.match.params.topicId;
        this.setState({
            disableVoteNow: this.props.userEmail && this.props.userAliasName ? false : true 
        });
        this.loadUserTopicComments(topicId);
    }

    componentDidUpdate = (prevProps, prevState) => {
        if (this.props.userEmail !== prevProps.userEmail || this.props.userAliasName !== prevProps.userAliasName) {
            this.setState({ 
                disableVoteNow: this.props.userEmail && this.props.userAliasName ? false : true 
            });
        }
    }

    loadUserTopicComments(topicId) {
        this.setState({ loader: true });
        fetch(api.partialURL + 'UserPollTopic/GetUserPollTopic?TOPIC_ID=' + topicId + '&USER_ID=' + this.props.userEmail + '&USER_NM=' + this.props.userAliasName)
            .then(res => res.json())
            .then(result => { 
                this.setState({ 
                    userTopic: result, userTopicOptions: result.TOPIC_VOTE_OPTNS, loader: false, 
                    disableVoteNow: this.props.userEmail && this.props.userAliasName && result.TOPIC_VOTE_IND === 0 ? false : true,
                    viewInd: result.TOPIC_VIEW_IND === 1 ? false : true,
                    voteInd: result.TOPIC_VOTE_IND === 1 ? true : false,
                    likeInd: result.TOPIC_LIKE_IND === 1 ? true : false,
                    rptInd: result.TOPIC_RPT_IND === 1 ? true : false,
                });
                let totalVotes = 0;
                this.state.userTopicOptions.map((option, row) => (
                    totalVotes += option.TOPIC_OPTN_VOTE
                ));
                this.setState({totalVotes: totalVotes})
            })
            .catch(err => console.log(err));
    }

    voteNow = () => {
        this.setState({ success_msg: '', err_msg: '' });
        if (CommonFunc.validateForm(this.state.errors) && this.validateAllInputs()) {
            this.setState({ loader: true });
            let rowData = {
                TOPIC_ID: this.state.userTopic.TOPIC_ID,
                TOPIC_VOTE_OPTN: this.state.voteOption,
                TOPIC_VOTE_USER_ID: this.props.userEmail,
                TOPIC_VOTE_USER_NM: this.props.userAliasName
            }

            axios({
                method: 'post',
                url: api.partialURL + 'UserPollTopic/SaveUserPollVote',
                data: JSON.stringify(rowData),
                headers: { 'Content-Type': 'application/json' },
                mode: 'cors',
            })
            .then(res => {
                if(res) {
                    if (res.data === 'success') {
                        this.loadUserTopicComments(this.state.userTopic.TOPIC_ID);
                    } else if (res.data === 'error') {
                        this.setState({ err_msg: 'Allowed only once to vote' });
                    } else {
                        this.setState({ err_msg: 'Failed to vote for poll' });
                    }
                    this.setState({ loader: false, voteOption: '' });
                }
            })
            .catch(function (response) {
                this.setState({ err_msg: response, loader: false });
            });
        } else {
            let errors = this.state.errors;
            if (!this.state.voteOption) {
                errors.voteOption = 'Please select vote option';
            }
            this.setState({ errors });
        }
    }

    validateAllInputs(){
        if(!this.state.voteOption) {
            return false; 
        }
        else{ return true; }
    }

    handleChange = (event) => {
        event.preventDefault();
        const { name, value } = event.target;
        let errors = this.state.errors;

        switch (name) {
            case 'voteOption':
                this.state.voteOption = value;
                errors.voteOption = value.length <= 0 ? 'Please select vote option' : '';
                break;
        }
        this.setState({ errors, [name]: value });
        this.setState({ success_msg: '', err_msg: '' });
    }

    handleClose = () => {
        this.setState({openVote: false});
    };

    viewVotes = () => {
        this.setState({openVote: true});
    };

    saveUserPollLike = () => {
        if(!this.state.likeInd && this.props.userEmail && this.props.userAliasName) {
            this.setState({ loader: true });
            let rowData = {
                TOPIC_ID: this.state.userTopic.TOPIC_ID,
                TOPIC_VOTE_USER_ID: this.props.userEmail,
                TOPIC_VOTE_USER_NM: this.props.userAliasName
            }

            axios({
                method: 'post',
                url: api.partialURL + 'UserPollTopic/SaveUserPollLike',
                data: JSON.stringify(rowData),
                headers: { 'Content-Type': 'application/json' },
                mode: 'cors',
            })
            .then(res => {
                if(res) {                
                    if (res.data === 'success') {
                        this.loadUserTopicComments(this.state.userTopic.TOPIC_ID);
                    }
                }
            })
            .catch(function (response) {
                this.setState({ err_msg: response, loader: false });
            });
        }
    }

    submitReport = () => {
        if(!this.state.rptInd && this.props.userEmail && this.props.userAliasName) {
            this.setState({ openReport: true });
        }
    }

    handleReportClose = () => {
        this.setState({ openReport: false });
    };

    handleStateUpdate = () => {
        this.setState({ openReport: false });
        this.loadUserTopicComments(this.state.userTopic.TOPIC_ID);
    };

    render() {
        const { classes, mediaQuery } = this.props;
        const subHeader = classNames(classes.posTop, classes.subHeader);
        const wrapIcon = classNames(classes.wrapIcon, classes.subHeader);
        const col9 = mediaQuery ? 9 : 12;
        const col3 = mediaQuery ? 3 : 12;
        const topicId = this.props.match.params.topicId;
        const ssoData = {
            hash: sessionStorage.getItem('hash_hyvor_talk'),
            userData: sessionStorage.getItem('user_data_hyvor_talk'),
            loginURL: "https://example.com/login"
        }
        
        return (
            <Fragment>
                <Backdrop className={classes.backdrop} open={this.state.loader}>
                    <CircularProgress color="inherit" />
                </Backdrop>

                {/* Report Section */}
                { this.state.openReport &&
                    <Report open={this.state.openReport}
                        handleReportClose={this.handleReportClose}
                        topicId={topicId}
                        postType='poll'
                        handleStateUpdate={this.handleStateUpdate}
                        userEmail={this.props.userEmail}
                        userAliasName={this.props.userAliasName}
                    />
                }

                <Grid container spacing={1} style={{ marginTop: mediaQuery ? '45px' : '90px' }}>
                    <Grid item xs={col9}>
                        <Grid container spacing={1}>
                                <Grid item xs={12} key={this.state.userTopic.TOPIC_ID}>
                                    <Card>
                                        <CardHeader classes={{ title: classes.title, subheader: classes.subTitle }}
                                            title={this.state.userTopic.TOPIC_TITLE}                                            
                                            subheader={ 'posted by ' + this.state.userTopic.TOPIC_UPDT_USER_NM + ' ' + 
                                                this.state.userTopic.TOPIC_UPDT_DTM + ' ago' }
                                        />
                                        <CardContent>
                                            <Typography className={subHeader} gutterBottom color="textSecondary">
                                                <div dangerouslySetInnerHTML={{ __html: this.state.userTopic.TOPIC_DESC }} />
                                            </Typography>
                                            <Typography>
                                                <Grid container spacing={1}>
                                                    { !this.state.voteInd &&
                                                    <Grid item xs={12}>
                                                        <FormControl component="fieldset">
                                                            <RadioGroup name="voteOption" value={this.state.voteOption} onChange={this.handleChange}>
                                                                { this.state.userTopicOptions && 
                                                                    this.state.userTopicOptions.map((option, row) => (
                                                                    <FormControlLabel value={option.TOPIC_VOTE_OPTN_NM} control={<Radio color="primary" />} 
                                                                        label={<span style={{ fontSize: 13 }}>{option.TOPIC_VOTE_OPTN_NM}</span>} />
                                                                ))}
                                                            </RadioGroup>
                                                            { this.state.errors.voteOption.length > 0 && 
                                                                <span className='error'>{this.state.errors.voteOption}</span> }                                                    
                                                        </FormControl>
                                                    </Grid>
                                                    }
                                                    { this.state.totalVotes > 0 && this.state.voteInd &&
                                                    <Grid item xs={12}>
                                                        <Card style={{ backgroundColor: '#3179c1', color: 'white' }}>
                                                            <CardContent style={{padding: 2, marginLeft: 10}}>        
                                                                <Typography>
                                                                    Poll Voting Result (%)
                                                                </Typography>
                                                            </CardContent>
                                                        </Card>
                                                        { this.state.userTopicOptions && 
                                                            this.state.userTopicOptions.map((option, row) => (
                                                            <div style={{ marginTop: '10px' }}>
                                                                <span style={{
                                                                    color: option.TOPIC_VOTE_OPTN_NM === this.state.userTopic.TOPIC_VOTE_OPTN ? '#3179c1' : null,
                                                                    fontWeight: option.TOPIC_VOTE_OPTN_NM === this.state.userTopic.TOPIC_VOTE_OPTN ? 'bold' : null,
                                                                }}>
                                                                    {option.TOPIC_VOTE_OPTN_NM + ' '}
                                                                </span>
                                                                <span style={{color: '#E0E0DE'}}>
                                                                    ({option.TOPIC_OPTN_VOTE + ' Votes'})
                                                                </span>                                                                
                                                                <ProgressBar completed={((option.TOPIC_OPTN_VOTE/this.state.totalVotes).toFixed(2))*100}
                                                                    bgColor={ row === 0 ? '#6a1b9a' : row === 1 ? '#198754' : row === 2 ? '#0DCAF0' :
                                                                    row === 3 ? '#FFC107' : row === 4 ? '#DC3545' : '0D6EFD' } />
                                                            </div>
                                                        ))}
                                                    </Grid>
                                                    }
                                                </Grid>
                                            </Typography>
                                            { !this.state.voteInd &&
                                                <Typography style={{ marginTop: '10px' }}>
                                                    <Button variant="contained" color="primary" className={classes.customButtonPrimary}
                                                        onClick={this.voteNow} disabled={this.state.disableVoteNow}>Vote Now
                                                    </Button>
                                                    { this.state.err_msg.length > 0 && 
                                                        <span style={{ marginLeft: 10 }} className='error'>{this.state.err_msg}</span> }
                                                    { this.state.success_msg.length > 0 && 
                                                        <span style={{ marginLeft: 10 }} className='success'>{this.state.success_msg}</span> }
                                                </Typography>
                                            }
                                            {/* <Typography style={{ marginTop: '20px' }}>
                                                <TextField fullWidth name="comment_text" label="Write your comment" required
                                                    onChange={this.handleChange} noValidate value={this.state.comment_text}
                                                    variant="outlined" style={{ backgroundColor: '#f6f7f2' }} />
                                            </Typography> */}
                                            <Typography style={{ marginTop: '20px' }} className={wrapIcon} color="textSecondary">
                                                {/* <img src={MessageIcon} height={17} style={{ marginRight: '5px' }} alt="message" />
                                                    <HyvorTalk.CommentCount 
                                                        websiteId={4842}
                                                        id={'poll'+topicId}
                                                    /> */}
                                                <img src={!this.state.voteInd ? VoteIcon : VoteIconColor} height={17} style={{marginRight:'5px',marginLeft:'10px'}} alt="likes" /> 
                                                    {this.state.userTopic.TOPIC_VOTE} Votes

                                                <IconButton onClick={this.saveUserPollLike} style={{ padding: 0, fontSize: '0.8rem', marginLeft:'10px' }} 
                                                    aria-label="share" >
                                                    <img src={!this.state.likeInd ? LikeIcon : LikeIconColor} height={17} style={{marginRight:'5px'}} alt="likes" />
                                                        {this.state.userTopic.TOPIC_LIKE} Likes
                                                </IconButton>
                                                
                                                <VisibilityIcon className={classes.iconSize} style={{marginRight:'5px',marginLeft:'10px'}} /> 
                                                    {this.state.userTopic.TOPIC_VIEW}
                                                
                                                <IconButton style={{ padding: 0, fontSize: '0.8rem', marginLeft:'10px' }} aria-label="share" >
                                                    <ShareIcon className={classes.iconSize} style={{marginRight:'5px'}} /> 
                                                        Share
                                                </IconButton>
                                                
                                                <IconButton onClick={this.submitReport} style={{ padding: 0, fontSize: '0.8rem', marginLeft:'10px' }} aria-label="report" >
                                                    <FlagIcon className={classes.iconSize} style={{marginRight:'5px'}} />
                                                        Report
                                                </IconButton>
                                            </Typography>
                                        </CardContent>
                                    </Card>
                                </Grid>
                                <Grid item xs={12} style={{ marginTop: -15 }}>
                                    <HyvorTalk.Embed
                                        websiteId={4842}
                                        id={'poll'+topicId}
                                        sso={ssoData}
                                    />
                                </Grid>
                        </Grid>
                    </Grid>
                    <Grid item xs={col3}>
                        <Grid container spacing={1}>
                            <Grid item xs={12}>
                                <Card>
                                    <CardContent>
                                        <Typography>
                                            <img src={Add1} alt="Logo" style={{ 
                                                width: '100%', marginBottom: '-8px' }} />
                                        </Typography>
                                    </CardContent>
                                </Card>
                            </Grid>
                            <Grid item xs={12}>
                                <Card square>
                                    <CardContent>
                                        <Typography>
                                            <img src={Add2} alt="Logo" style={{ 
                                                width: '100%', marginBottom: '-8px' }} />
                                        </Typography>
                                    </CardContent>
                                </Card>
                            </Grid>
                        </Grid>
                    </Grid>                    
                </Grid>
            </Fragment>
        );
    }
}

export default withRouter(withStyles(useStyles)(withMediaQuery('(min-width:600px)')(PollDetails)))