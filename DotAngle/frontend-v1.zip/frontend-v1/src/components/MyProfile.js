import React, { Component, Fragment } from 'react';
import { 
    Grid, withStyles, Button, Card, CardContent, Typography, CardHeader, IconButton, Divider, useMediaQuery,
    Backdrop, CircularProgress, Avatar
} from '@material-ui/core';
import { useStyles } from './common/useStyles';
import './common/Common.css'
import classNames from 'classnames';
import VisibilityIcon from '@material-ui/icons/Visibility';
import QuestionIcon from './images/Question.png';
import MessageIcon from './images/mesage.png';
import LikeIcon from './images/like.png';
import PollIcon from './images/poll.png';
import api from './common/APIValues';
import HelpIcon from '@material-ui/icons/Help';
import ThumbUpIcon from '@material-ui/icons/ThumbUp';
import AccountCircleIcon from '@material-ui/icons/AccountCircle';
import DateRangeIcon from '@material-ui/icons/DateRange';
import VoteIcon from './images/votes_icon.png';
import VoteBigIcon from './images/votes_big-size.png';
import { withRouter } from 'react-router-dom';

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);    
    return <Component mediaQuery={mediaQuery} {...props} />;
};

class MyProfile extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            userTopics: [], loader: false, myProfileCount: {},
        }
    }

    componentDidMount() { 
        window.scrollTo(0, 0);       
        this.loadMyProfile(this.props.userEmail);
    }

    componentDidUpdate = (prevProps, prevState) => {
        if (this.props.userEmail !== prevProps.userEmail || this.props.userAliasName !== prevProps.userAliasName || 
            this.props.searchValue !== prevProps.searchValue) {
            this.loadMyProfile(this.props.userEmail);
        }
    }

    loadMyProfile(userId) {
        this.setState({ loader: true });
        let searchValue = this.props.searchValue ? this.props.searchValue : '%%';
        
        fetch(api.partialURL + 'MyProfile/GetMyProfileDetails?USER_ID=' + userId + '&SRCH_VAL=%' + searchValue + '%')
            .then(res => res.json())
            .then(result => {
                this.setState({ userTopics: [] });
                this.setState({ userTopics: result.userTopics, myProfileCount: result.myProfile, loader: false });
            })
            .catch(err => console.log(err));
    }

    viewTopicDetails = (topicId, topicPostType, topicTitle) => {
        const { history } = this.props;        
        if (history) history.push({
            pathname: topicPostType === 'QUESTION' ? '/topics/question/comments/' + topicId + '/' + topicTitle.toLowerCare().replace(/ /g, '-')
                : '/topics/poll/comments/' + topicId + '/' + topicTitle.toLowerCare().replace(/ /g, '-')
        });
    }

    render() {
        const { classes, mediaQuery } = this.props;
        const wrapIcon = classNames(classes.wrapIcon, classes.subHeader);
        const col4 = mediaQuery ? 4 : 2;
        const col3 = mediaQuery ? 3 : 12;

        return (
            <Fragment>
                <Backdrop className={classes.backdrop} open={this.state.loader}>
                    <CircularProgress color="inherit" />
                </Backdrop>

                <Grid container spacing={3} style={{ marginTop: mediaQuery ? '45px' : '90px' }}>
                    <Grid item>
                        <Avatar style={{ backgroundColor: '#a19b9b' }} onClick={this.props.userLogin}
                            src="/static/images/avatar/1.jpg" />
                    </Grid>
                    <Grid item>
                        <Typography variant="h6" color="textSecondary">
                            { this.props.userAliasName }
                        </Typography>
                    </Grid>
                    <Grid item>
                        <Button variant="contained" color="primary" className={classes.customButtonPrimary}
                            onClick={this.editProfile}>Edit Profile
                        </Button>
                    </Grid>
                </Grid>

                <Grid container spacing={col4} style={{ marginTop: '10px' }}>
                    <Grid item xs={col3}>
                        <Card>
                            <CardContent>
                                <Grid container spacing={0}>                            
                                    <Grid item xs={3}>
                                        <HelpIcon className={classes.iconLargeSize} />
                                    </Grid>
                                    <Grid item xs={9} style={{ marginTop: '1%' }}>
                                        <Typography color="textSecondary">
                                            Total Questions
                                        </Typography>
                                        <Typography color="textSecondary">
                                            {this.state.myProfileCount.TOTAL_QUE}
                                        </Typography>
                                    </Grid>
                                </Grid>
                            </CardContent>
                        </Card>
                    </Grid>
                    <Grid item xs={col3}>
                        <Card>
                            <CardContent>
                                <Grid container spacing={0}>                            
                                    <Grid item xs={3}>
                                        <ThumbUpIcon className={classes.iconLargeSize} />
                                    </Grid>
                                    <Grid item xs={9} style={{ marginTop: '1%' }}>
                                        <Typography color="textSecondary">
                                            Total Likes
                                        </Typography>
                                        <Typography color="textSecondary">
                                            {this.state.myProfileCount.TOTAL_LIKE}
                                        </Typography>
                                    </Grid>
                                </Grid>
                            </CardContent>
                        </Card>
                    </Grid>
                    <Grid item xs={col3}>
                        <Card>
                            <CardContent>
                                <Grid container spacing={0}>                            
                                    <Grid item xs={3}>
                                        <img src={VoteBigIcon} width='55%' />
                                    </Grid>
                                    <Grid item xs={9} style={{ marginTop: '1%' }}>
                                        <Typography color="textSecondary">
                                            Total Votes
                                        </Typography>
                                        <Typography color="textSecondary">
                                            {this.state.myProfileCount.TOTAL_VOTE}
                                        </Typography>
                                    </Grid>
                                </Grid>
                            </CardContent>
                        </Card>
                    </Grid>
                    <Grid item xs={col3}>
                        <Card>
                            <CardContent>
                                <Grid container spacing={0}>                            
                                    <Grid item xs={3}>
                                        <VisibilityIcon className={classes.iconLargeSize} />
                                    </Grid>
                                    <Grid item xs={9} style={{ marginTop: '1%' }}>
                                        <Typography color="textSecondary">
                                            Total Views
                                        </Typography>
                                        <Typography color="textSecondary">
                                            {this.state.myProfileCount.TOTAL_VIEW}
                                        </Typography>
                                    </Grid>
                                </Grid>
                            </CardContent>
                        </Card>
                    </Grid>                  
                </Grid>

                <h3 className={classes.headerFont}>My Threads</h3>
                
                <Grid container spacing={2}>
                    { this.state.userTopics.map((topic, row) => (
                        <Grid item xs={12} key={topic.TOPIC_ID}>
                            <Card>
                                <Grid container spacing={0}>
                                    <Grid item xs={ topic.TOPIC_POST_TYPE === 'QUESTION' && topic.TOPIC_IMG_URL ? 10 : 12}>
                                        <CardHeader style={{ cursor: 'pointer', padding: '16px 16px 0px 16px' }}
                                            classes={{ title: classes.title, subheader: classes.subTitle }}
                                            onClick={() => this.viewTopicDetails(topic.TOPIC_ID, topic.TOPIC_POST_TYPE, topic.TOPIC_TITLE)}
                                            title={topic.TOPIC_TITLE}
                                            action={
                                                <IconButton aria-label="questions">                                                
                                                    { topic.TOPIC_POST_TYPE === 'QUESTION' ?
                                                        <img src={QuestionIcon} height={20} alt="QuestionIcon" /> :
                                                        <img src={PollIcon} height={20} alt="PollIcon" />
                                                    }
                                                </IconButton>
                                            }
                                        />
                                        <CardContent>
                                            <Typography className={wrapIcon} color="textSecondary">
                                                <AccountCircleIcon className={classes.iconSize} style={{ marginRight: '5px' }} /> 
                                                    {topic.TOPIC_UPDT_USER_NM}
                                                <Divider orientation="vertical" flexItem className={classes.marginLeftRight} />

                                                <DateRangeIcon className={classes.iconSize} style={{ marginRight: '5px' }} /> 
                                                    {topic.TOPIC_UPDT_DTM}
                                                <Divider orientation="vertical" flexItem className={classes.marginLeftRight} />

                                                <img src={ topic.TOPIC_POST_TYPE === 'QUESTION' ? LikeIcon : VoteIcon } height={17} style={{ marginRight: '5px' }} />
                                                    {topic.TOPIC_LIKE_VOTE} {topic.TOPIC_POST_TYPE === 'QUESTION' ? !mediaQuery ? '' : 'Likes' : !mediaQuery ? '' : 'Votes'}                                                
                                                <Divider orientation="vertical" flexItem className={classes.marginLeftRight} />

                                                <img src={MessageIcon} height={17} style={{ marginRight: '5px' }} alt="MessageIcon" /> 
                                                    500 {!mediaQuery ? '' : 'Comments'}
                                                <Divider orientation="vertical" flexItem className={classes.marginLeftRight} />

                                                <VisibilityIcon className={classes.iconSize} style={{ marginRight: '5px' }} /> {topic.TOPIC_VIEW}
                                            </Typography>
                                        </CardContent>
                                    </Grid>
                                    { topic.TOPIC_POST_TYPE === 'QUESTION' && topic.TOPIC_IMG_URL &&
                                        <Grid item xs={2} key={topic.TOPIC_ID}>
                                            <Typography>
                                                <img src={topic.TOPIC_IMG_URL}
                                                    style={{width: '100%', padding: '10px 10px 10px 0px'}} />
                                            </Typography>
                                        </Grid>
                                    }
                                </Grid>
                            </Card>
                        </Grid>
                    ))}
                </Grid>
            </Fragment>
        );
    }
}

export default withRouter(withStyles(useStyles)(withMediaQuery('(min-width:600px)')(MyProfile)))