export const setLoginInfo = (name, email, googleId) => {
    localStorage.setItem('user_name', name);
    localStorage.setItem('user_email', email);
    localStorage.setItem('user_id', googleId);
}

export const setUserAliasName = (aliasName) => {
    localStorage.setItem('user_alias_name', aliasName);
}

export const setHyvorTalkSignon = (hash, userData) => {
    localStorage.setItem('hash_hyvor_talk', hash);
    localStorage.setItem('user_data_hyvor_talk', userData);
}