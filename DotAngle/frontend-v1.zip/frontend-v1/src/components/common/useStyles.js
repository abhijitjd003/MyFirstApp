const useStyles = theme => ({
    leftIcon: {
        marginRight: theme.spacing.unit,
    },
    topMargin: {
        marginTop: 16,
    },
    topMarginTab: {
        marginTop: 10,
    },
    topMarginSm: {
        marginTop: 5,
    },
    topMarginMd: {
        marginTop: 35,
    },
    root: {
        display: 'flex',
    },
    rootEdit: {
        fontSize: 12, height: '2.1rem', marginTop: 35,
        backgroundColor: "#2b494b",
        "&:hover": {
            backgroundColor: "#2b494b"
        },
        "&:disabled": {
            backgroundColor: "rgba(0, 0, 0, 0.12)"
        },
    },
    rootCreate: {
        fontSize: 12, height: '2.1rem', marginTop: 30,
        backgroundColor: "#2b494b",
        "&:hover": {
            backgroundColor: "#2b494b"
        },
        "&:disabled": {
            backgroundColor: "rgba(0, 0, 0, 0.12)"
        },
    },
    rootModal: {
        fontSize: 12, height: '2.1rem',
        backgroundColor: "#2b494b",
        "&:hover": {
            backgroundColor: "#2b494b"
        },
        "&:disabled": {
            backgroundColor: "rgba(0, 0, 0, 0.12)"
        },
    },
    table: {
        minWidth: 300,
    },
    tabBar: {
        backgroundColor: "white", color: 'orangered'
    },
    tabLinks: {
        fontSize: 12, "&:hover": {
            textDecoration: 'none',
        },
    },
    tabLinksActive: {
        fontSize: 12, backgroundColor: "#347f58", color: 'white',
        "&:hover": {
            textDecoration: 'none',
        },
    },
    rootCard: {
        minWidth: 275, marginTop: 20,
      },
    bullet: {
        display: 'inline-block',
        margin: '0 2px',
        transform: 'scale(0.8)',
      },
    title: {
        fontSize: 16,
        marginBottom: 5,
        fontWeight: 'bold'
    },
    optionSize: {
        fontSize: 15
    },
    subTitle: {
        fontSize: 12,
    },
    subHeader: {
        fontSize: 13,        
    },
    posTop: {
        marginTop: -30
    },
    pos: {
        marginBottom: 20
    },
    posGraph: {
        marginBottom: 0, marginRight: 10, marginLeft: 10, marginTop: 0
    },
    posBottom: {
        marginBottom: 20
    },    
    paper: {
        padding: theme.spacing(2),
        margin: 'auto',
        maxWidth: '100%',
        height: 600,
    },
    image: {
        width: 128,
        height: 128,
    },
    img: {
        margin: 'auto',
        display: 'block',
        maxWidth: '100%',
        maxHeight: '100%',
    },
    customButtonError: {
        borderRadius: '8px',
        color: '#c2272d',
        backgroundColor: "#f9f9f9",
        "&:hover": {
            backgroundColor: "#f9f9f9"
        },
        "&:disabled": {
            backgroundColor: "rgba(0, 0, 0, 0.12)"
        },
    },
    customButtonInfo: {
        borderRadius: '8px',
        color: '#0000008A',
        backgroundColor: "#f9f9f9",
        "&:hover": {
            backgroundColor: "#f9f9f9"
        },
        "&:disabled": {
            backgroundColor: "rgba(0, 0, 0, 0.12)"
        },
    },
    customButtonPrimary: {        
        backgroundColor: "#3179c1",
        "&:hover": {
            backgroundColor: "#3179c1"
        },
        "&:disabled": {
            backgroundColor: "rgba(0, 0, 0, 0.12)"
        },
    },
    radioColor: {
        color: "#3179c1",
    },
    iconColor: {
        color: '#333233',
        fontSize: '2.4rem',        
    },
    iconRedColor: {
        color: '#c2272d',
    },
    activeColor: {
        color: '#333233',
    },
    inactiveColor: {
        color: '#a19b9b',
    },
    appBar: {
        zIndex: theme.zIndex.drawer + 1,
        transition: theme.transitions.create(['width', 'margin'], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen,
        }),
        backgroundColor: 'white',
    },
    alignment: {
        flexGrow: 1,
    },
    badge: {
        right: -3,
        top: 13,
        border: `2px solid ${theme.palette.background.paper}`,
        padding: '0 4px',
    },
    badgeColor: {
        backgroundColor: '#c2272d'
    },
    wrapIcon: {
        verticalAlign: 'middle',
        display: 'inline-flex'
    },
    iconSize: {        
        fontSize: '1.3rem',
        color: '#a19b9b',       
    },
    marginLeftRight: {
        margin: '0px 10px 0px 10px'
    },
    buttonSpacing: {
        margin: theme.spacing(1),
    },
    backdrop: {
        zIndex: theme.zIndex.drawer + 1,
        color: '#fff',
    },
    iconLargeSize: {        
        fontSize: '3rem',
        color: '#a19b9b',
    },
    iconMedSize: {        
        fontSize: '2rem',
        color: '#a19b9b',
    },
    iconMedSize1: {        
        fontSize: '2rem',
        color: '#333233',
    },
    headerFont: {
        color: '#333233',
        textAlign: 'center',
        margin: '30px 0px 10px 0px'
    }
});

export {useStyles}