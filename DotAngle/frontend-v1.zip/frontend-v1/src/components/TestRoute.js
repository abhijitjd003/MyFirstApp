import React, { Component } from 'react';

export default class TestRoute extends Component {
    constructor(props) {
        super(props);
        this.state = { }
    }

    componentDidMount() {
        const { history } = this.props;
        let topicId = this.props.match.params.topicId;
        let title = this.props.match.params.title;
        if (history) history.push({
            pathname: '/topics/question/comments/' + topicId + '/' + title
        });
    }

    render() {
        return (
            <div></div>
        );
    }
}