﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace farmar_market_api.Models
{
    public class VendorType
    {
        public int TypeId { get; set; }
        public string TypeName { get; set; }
        public string Description { get; set; }
        public bool Disable { get; set; }
        public string IsDisable { get; set; }
        public string CreatedDateTime { get; set; }
        public string CreatedUserId { get; set; }
    }
}