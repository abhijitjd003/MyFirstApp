﻿namespace farmar_market_api.Models
{
    public class VoteOption
    {
        public string TOPIC_VOTE_OPTN_NM { get; set; }
        public long TOPIC_OPTN_VOTE { get; set; }
    }
}