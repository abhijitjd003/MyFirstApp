﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace farmar_market_api.Models
{
    public class Customer
    {
        public int ShopId { get; set; }
        public long PinCode { get; set; }
        public string ShopName { get; set; }
        public string ContactPerson { get; set; }
        public string Address { get; set; }
        public string GSTNo { get; set; }
        public string ReferralCode { get; set; }
        public long MobileNo { get; set; }
        public string Email { get; set; }
        public string Location { get; set; }
        public string SalesOfficer { get; set; }
        public long AlternateContactNo { get; set; }
        public string UserId { get; set; }
        public string UpdatedDate { get; set; }
        public decimal Outstanding { get; set; }
        public string LastOrderedDate { get; set; }
        public string Status { get; set; }
        public string RejectedReason { get; set; }
        public string RouteCategory { get; set; }
        public List<CustomerImages> ShopImages { get; set; }
        public string Image1 { get; set; }
        public string Image2 { get; set; }
        public string Image3 { get; set; }
        public string DeviceId { get; set; }
    }
}