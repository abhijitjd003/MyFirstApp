﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace farmar_market_api.Models
{
    public class Configuration
    {
        public long ContactNo1 { get; set; }
        public string PickupAddress { get; set; }
        public long ContactNo2 { get; set; }
        public decimal DeliveryCharges { get; set; }
        public decimal MinOrderWeight { get; set; }
        public DateTime OrderFromTime { get; set; }
        public DateTime OrderToTime { get; set; }
        public DateTime CancelFromTime { get; set; }
        public DateTime CancelToTime { get; set; }
        public string ServerDateTime { get; set; }
        public string CurrentVersion { get; set; }
        public int Interval { get; set; }
        public string OrderMode { get; set; }
        public string OrderTime { get; set; }
        public string CancelTime { get; set; }
        public string CustomMessage { get; set; }
        public bool IsOrderTime { get; set; }
        public bool IsCancelTime { get; set; }
    }
}