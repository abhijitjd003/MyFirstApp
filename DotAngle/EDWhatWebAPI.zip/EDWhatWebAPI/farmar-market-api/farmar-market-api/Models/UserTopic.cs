﻿namespace EDWhatCoreAPI.Models
{
    public class UserTopic
    {
        public long TOPIC_ID { get; set; }
        public string TOPIC_POST_TYPE { get; set; }
        public string TOPIC_IMG_URL { get; set; }
        public string TOPIC_TITLE { get; set; }
        public string TOPIC_DESC { get; set; }
        public string TOPIC_UPDT_DTM { get; set; }
        public string TOPIC_UPDT_USER_NM { get; set; }
        public long TOPIC_LIKE_VOTE { get; set; }
        public long TOPIC_VIEW { get; set; }
        public long TOPIC_POLL_LIKE { get; set; }
        public int LIKE_IND { get; set; }
        public int VOTE_IND { get; set; }
    }
}
