﻿namespace EDWhatCoreAPI.Models
{
    public class UserQuestion
    {
        public string TOPIC_FILE_TYPE { get; set; }
        public string TOPIC_FILE_NM { get; set; }
        public string TOPIC_FILE_BASE_64_STRNG { get; set; }
        public string TOPIC_TITLE { get; set; }
        public string TOPIC_DESC { get; set; }
        public string TOPIC_CREATE_USER_ID { get; set; }
        public string TOPIC_CREATE_USER_NM { get; set; }
    }
}
