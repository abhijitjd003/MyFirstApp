﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace farmar_market_api.Models
{
    public class Vendor
    {
        public int VendorId { get; set; }
        public int TypeId { get; set; }
        public string TypeName { get; set; }
        public string ContactName { get; set; }
        public string Address { get; set; }
        public long MobileNo { get; set; }
        public bool Disable { get; set; }
        public string IsDisable { get; set; }
        public string CreatedDateTime { get; set; }
        public string CreatedUserId { get; set; }
    }
}