﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace farmar_market_api.Models
{
    public class CustomerApproval
    {
        public List<int> ShopIds { get; set; }
        public string Status { get; set; }
        public string UserId { get; set; }
        public string RejectReason { get; set; }
    }
}