﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace farmar_market_api.Models
{
    public class OrderTime
    {
        public DateTime FromTime { get; set; }
        public DateTime ToTime { get; set; }
    }
}