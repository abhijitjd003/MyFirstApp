﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace farmar_market_api.Models
{
    public class Product
    {
        public int ProductId { get; set; }
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public string ProductName { get; set; }
        public string ProductNameKannada { get; set; }
        public string UnitType { get; set; }
        public decimal RatePerKg { get; set; }
        public decimal MinPurchaseQuantity { get; set; }
        public decimal Quantity { get; set; }
        public decimal TotalStock { get; set; }
        public string UpdatedDate { get; set; }
        public string UserId { get; set; }
        public string Deactivate { get; set; }
        public string IsDeactivate { get; set; }
        public string FileType { get; set; }
        public string FileName { get; set; }
        public string FileBase64String { get; set; }
        public decimal TotalPrice { get; set; }
        public decimal TotalWeight { get; set; }
    }
}