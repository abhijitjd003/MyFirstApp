﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace farmar_market_api.Models
{
    public class Payment
    {
        public long OrderNo { get; set; }
        public string ShopName { get; set; }
        public string PaymentStatus { get; set; }
        public decimal Price { get; set; }
        public decimal Received { get; set; }
        public decimal Outstanding { get; set; }
        public decimal DeliveryCharges { get; set; }
    }
}