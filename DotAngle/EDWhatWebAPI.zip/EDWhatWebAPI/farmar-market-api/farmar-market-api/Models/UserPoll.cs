﻿using System.Collections.Generic;

namespace EDWhatCoreAPI.Models
{
    public class UserPoll
    {
        public List<string> TOPIC_VOTE_OPTNS { get; set; }
        public string TOPIC_TITLE { get; set; }
        public string TOPIC_DESC { get; set; }
        public string TOPIC_CREATE_USER_ID { get; set; }
        public string TOPIC_CREATE_USER_NM { get; set; }
    }
}
