﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace farmar_market_api.Models
{
    public class OrderCrates
    {
        public decimal Weight { get; set; }
        public int OrderCount { get; set; }
        public int ProductId { get; set; }
    }
}