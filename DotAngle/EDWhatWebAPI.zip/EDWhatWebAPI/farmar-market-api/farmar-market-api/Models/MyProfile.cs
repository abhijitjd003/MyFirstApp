﻿namespace EDWhatCoreAPI.Models
{
    public class MyProfile
    {
        public long TOTAL_QUE { get; set; }
        public long TOTAL_LIKE { get; set; }
        public long TOTAL_VOTE { get; set; }
        public long TOTAL_VIEW { get; set; }
    }
}
