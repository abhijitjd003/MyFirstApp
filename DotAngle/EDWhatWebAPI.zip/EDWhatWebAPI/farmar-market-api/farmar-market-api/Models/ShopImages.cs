﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace farmar_market_api.Models
{
    public class ShopImages
    {
        public string url { get; set; }
    }
}