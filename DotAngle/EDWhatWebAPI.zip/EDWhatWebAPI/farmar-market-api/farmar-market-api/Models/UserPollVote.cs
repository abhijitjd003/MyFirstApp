﻿namespace EDWhatCoreAPI.Models
{
    public class UserPollVote
    {
        public long TOPIC_ID { get; set; }
        public string TOPIC_VOTE_OPTN { get; set; }
        public string TOPIC_VOTE_USER_ID { get; set; }
        public string TOPIC_VOTE_USER_NM { get; set; }
    }
}
