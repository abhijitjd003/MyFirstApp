﻿using System.Collections.Generic;

namespace farmar_market_api.Models
{
    public class Rates
    {
        public bool Show { get; set; }        
        public List<Product> Products { get; set; }
        public string CurrentDate { get; set; }
        public string CurrentDay { get; set; }
    }
}