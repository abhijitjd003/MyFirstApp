﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace farmar_market_api.Models
{
    public class User
    {
        public int UserId { get; set; }
        public string DeviceId { get; set; }
        public string FullName { get; set; }
        public long MobileNo { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }
        public int OTP { get; set; }
        public string RequestedDateTime { get; set; }
        public List<int> ShopIds { get; set; }
    }
}