﻿namespace EDWhatCoreAPI.Models
{
    public class MyProfileDetail
    {
        public long TOPIC_ID { get; set; }
        public string TOPIC_POST_TYPE { get; set; }
        public string TOPIC_IMG_URL { get; set; }
        public string TOPIC_TITLE { get; set; }
        public string TOPIC_UPDT_DTM { get; set; }
        public string TOPIC_UPDT_USER_NM { get; set; }
        public long TOPIC_LIKE_VOTE { get; set; }
        public long TOPIC_VIEW { get; set; }
    }
}
