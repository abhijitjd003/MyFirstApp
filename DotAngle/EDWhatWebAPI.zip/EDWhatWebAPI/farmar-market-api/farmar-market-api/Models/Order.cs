﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace farmar_market_api.Models
{
    public class Order
    {
        public long OrderNo { get; set; }
        public string ShopName { get; set; }
        public string ContactName { get; set; }
        public string ReferralCode { get; set; }
        public long MobileNo { get; set; }
        public string ProductName { get; set; }
        public int ProductId { get; set; }
        public decimal RatePerKg { get; set; }
        public decimal TotalPrice { get; set; }
        public decimal TotalWeight { get; set; }
        public decimal TotalPiece { get; set; }
        public int PassCode { get; set; }
        public string Status { get; set; }
        public string OrderedDateTime { get; set; }
        public string DeliveryDate { get; set; }
        public string DeliveryTime { get; set; }
        public int DeliveryUserId { get; set; }
        public string DeliveryUser { get; set; }
        public DateTime DeliveredDate { get; set; }
        public decimal DeliveryCharges { get; set; }
        public List<Product> Products { get; set; }
        public int ShopId { get; set; }
        public decimal OverallTotalPrice { get; set; }
        public decimal OverallTotalWeight { get; set; }
        public string PaymentStatus { get; set; }
        public string UserId { get; set; }
        public string ProductImagePath { get; set; }
        public string UnitType { get; set; }
        public string OrderMode { get; set; }
        public long PinCode { get; set; }
        public string Location { get; set; }
        public string Route { get; set; }
        public bool QuantityOne { get; set; }

        public string FileName { get; set; }
        public decimal MinPurchaseQuantity { get; set; }
        public decimal Quantity { get; set; }
        public decimal Cost { get; set; }
        public decimal TotalStock { get; set; }
        public int CategoryId { get; set; }
    }
}