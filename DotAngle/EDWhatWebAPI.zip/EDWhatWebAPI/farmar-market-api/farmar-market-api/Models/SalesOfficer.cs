﻿using System;

namespace farmar_market_api.Models
{
    public class SalesOfficer
    {
        public int RegisteredCustomers { get; set; }
        public string SalesOfficerName { get; set; }
        public int ActiveCustomers { get; set; }
        public int InActiveCustomers { get; set; }
        public int TotalOrders { get; set; }
        public decimal TotalSales { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public DateTime MonthDate { get; set; }
        public string FromDateFormat { get; set; }
        public string ToDateFormat { get; set; }
        public string ToDateYearFormat { get; set; }
        public string MonthDateFormat { get; set; }
    }
}