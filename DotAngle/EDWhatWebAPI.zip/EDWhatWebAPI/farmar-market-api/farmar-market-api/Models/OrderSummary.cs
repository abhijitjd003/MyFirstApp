﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace farmar_market_api.Models
{
    public class OrderSummary
    {
        public int ProductId { get; set; }
        public string OrderedDate { get; set; }
        public string ProductName { get; set; }
        public string ProductImagePath { get; set; }
        public DateTime OrderDate { get; set; }
        public int TotalVendorsOrdered { get; set; }
        public int TotalOrders { get; set; }
        public int TotalVegetables { get; set; }
        public decimal TotalPrice { get; set; }
        public decimal TotalWeight { get; set; }        
        public decimal OverallWeight { get; set; }
        public decimal DeliveryCharges { get; set; }
        public int TotalPieces { get; set; }
        public decimal TotalStock { get; set; }
        public decimal Indent { get; set; }
        public int Crates20 { get; set; }
        public int Crates10 { get; set; }
        public int Crates5 { get; set; }
        public string UnitType { get; set; }
    }
}