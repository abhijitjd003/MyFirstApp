﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace farmar_market_api.Models
{
    public class PollReport
    {
        public long TOPIC_ID { get; set; }
        public string TOPIC_RPT_OPTN { get; set; }
        public string TOPIC_RPT_OTHR_OPTN { get; set; }
        public string TOPIC_RPT_USER_ID { get; set; }
        public string TOPIC_RPT_USER_NM { get; set; }
    }
}