﻿using farmar_market_api.Models;
using System.Collections.Generic;

namespace EDWhatCoreAPI.Models
{
    public class UserPollTopic
    {
        public long TOPIC_ID { get; set; }        
        public string TOPIC_TITLE { get; set; }
        public string TOPIC_DESC { get; set; }
        public string TOPIC_UPDT_DTM { get; set; }
        public string TOPIC_UPDT_USER_NM { get; set; }
        public long TOPIC_VOTE { get; set; }
        public long TOPIC_VIEW { get; set; }
        public long TOPIC_LIKE { get; set; }
        public List<VoteOption> TOPIC_VOTE_OPTNS { get; set; }
        public int TOPIC_VOTE_IND { get; set; }
        public int TOPIC_VIEW_IND { get; set; }
        public int TOPIC_LIKE_IND { get; set; }
        public int TOPIC_RPT_IND { get; set; }
        public string TOPIC_VOTE_OPTN { get; set; }
    }
}
