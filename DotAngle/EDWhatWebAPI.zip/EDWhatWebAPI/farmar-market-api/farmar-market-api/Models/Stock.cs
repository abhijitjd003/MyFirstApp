﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace farmar_market_api.Models
{
    public class Stock
    {
        public int StockId { get; set; }
        public int VendorId { get; set; }
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string VendorName { get; set; }
        public decimal TotalWeight { get; set; }
        public decimal GradeAWeight { get; set; }
        public decimal GradeBWeight { get; set; }
        public decimal DumpWeight { get; set; }
        public string CreatedDateTime { get; set; }
        public string CreatedUserId { get; set; }
        public string ReasonType { get; set; }
        public string BuyerName { get; set; }
    }
}