﻿using System;

namespace EDWhatCoreAPI.Constants
{
    public class SPName
    {
        //USER TOPIC
        public const string GET_USER_TOPICS = "USP_GET_USER_TOPICS";
        
        //USER QUE TOPIC
        public const string GET_USER_QUE_TOPIC = "USP_GET_USER_QUE_TOPIC";
        public const string SAVE_USER_QUE_TOPIC_LIKE = "USP_SAVE_USER_QUE_TOPIC_LIKE";
        public const string SAVE_USER_QUE_TOPIC_VIEW = "USP_SAVE_USER_QUE_TOPIC_VIEW";
        public const string SAVE_USER_QUE_TOPIC = "USP_SAVE_USER_QUE_TOPIC";

        //USER POLL TOPIC
        public const string GET_USER_POLL_TOPIC = "USP_GET_USER_POLL_TOPIC";
        public const string SAVE_USER_POLL_TOPIC_VOTE = "USP_SAVE_USER_POLL_TOPIC_VOTE";        
        public const string SAVE_USER_POLL_TOPIC_LIKE = "USP_SAVE_USER_POLL_TOPIC_LIKE";        
        public const string SAVE_USER_POLL_TOPIC_VIEW = "USP_SAVE_USER_POLL_TOPIC_VIEW";
        public const string SAVE_USER_POLL_TOPIC = "USP_SAVE_USER_POLL_TOPIC";

        //MY PROFILE
        public const string GET_USER_PROFILE_DTL = "USP_GET_USER_PROFILE_DTL";

        //TOPIC REPORT
        public const string GET_USER_TOPIC_RPT_OPTNS = "USP_GET_USER_TOPIC_RPT_OPTNS";
        public const string SAVE_USER_QUE_TOPIC_RPTS = "USP_SAVE_USER_QUE_TOPIC_RPTS";
        public const string SAVE_USER_POLL_TOPIC_RPTS = "USP_SAVE_USER_POLL_TOPIC_RPTS";
    }

    public static class SystemTimeZone
    {
        public static string GetCurrentTimeZone()
        {
            const string timeFormat = "yyyy-MM-dd HH:mm:ss";
            
            TimeZone curTimeZone = TimeZone.CurrentTimeZone;
            DateTime curUTC = curTimeZone.ToUniversalTime(DateTime.Now);
            return curUTC.AddMinutes(330).ToString(timeFormat);
        }
    }
}
