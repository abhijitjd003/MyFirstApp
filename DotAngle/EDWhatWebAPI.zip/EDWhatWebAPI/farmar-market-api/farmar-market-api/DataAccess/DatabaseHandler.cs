﻿using System;
using System.Collections.Generic;
using System.Configuration;
using MySql.Data.MySqlClient;
using System.Linq;
using System.Web;
using System.Data;

namespace farmar_market_api.DataAccess
{
    public static class DatabaseHandler
    {
        public static string ConnectionString()
        {
            return ConfigurationManager.ConnectionStrings["SQLConnection"].ConnectionString;
        }

        public static DataSet GetDataSet(string commandText, CommandType commandType, IDataParameter[] parameters = null)
        {
            using (var connection = CreateConnection())
            {
                connection.Open();
                using (var command = CreateCommand(commandText, commandType, connection))
                {
                    if (parameters != null)
                    {
                        foreach (var parameter in parameters)
                        {
                            command.Parameters.Add(parameter);
                        }
                    }

                    var dataset = new DataSet();
                    var adapter = CreateAdapter(command);
                    adapter.Fill(dataset);
                    return dataset;
                }
            }
        }

        public static DataTable GetDataTable(string commandText, CommandType commandType, IDataParameter[] parameters = null)
        {
            using (var connection = CreateConnection())
            {
                connection.Open();
                using (var command = CreateCommand(commandText, commandType, connection))
                {
                    if (parameters != null)
                    {
                        foreach (var parameter in parameters)
                        {
                            command.Parameters.Add(parameter);
                        }
                    }

                    var dataset = new DataSet();
                    var adapter = CreateAdapter(command);
                    adapter.Fill(dataset);
                    return dataset.Tables[0];
                }
            }
        }

        public static void Save(string commandText, CommandType commandType, IDataParameter[] parameters = null)
        {
            using (var connection = CreateConnection())
            {
                connection.Open();
                using (var command = CreateCommand(commandText, commandType, connection))
                {
                    if (parameters != null)
                    {
                        foreach (var parameter in parameters)
                        {
                            command.Parameters.Add(parameter);
                        }
                    }

                    command.ExecuteNonQuery();
                }
            }
        }

        public static void Delete(string commandText, CommandType commandType, IDataParameter[] parameters = null)
        {
            using (var connection = CreateConnection())
            {
                connection.Open();
                using (var command = CreateCommand(commandText, commandType, connection))
                {
                    if (parameters != null)
                    {
                        foreach (var parameter in parameters)
                        {
                            command.Parameters.Add(parameter);
                        }
                    }

                    command.ExecuteNonQuery();
                }
            }
        }

        public static T Save<T>(string commandText, CommandType commandType, out T last_id, T value, IDataParameter[] parameters = null)
        {
            using (var connection = CreateConnection())
            {
                connection.Open();
                using (var command = CreateCommand(commandText, commandType, connection))
                {
                    if (parameters != null)
                    {
                        foreach (var parameter in parameters)
                        {
                            command.Parameters.Add(parameter);
                        }
                    }

                    last_id = (T)Convert.ChangeType(command.ExecuteScalar() == null ? value : command.ExecuteScalar(), typeof(T));
                }
            }
            return last_id;
        }

        public static T GetScalarValue<T>(string commandText, CommandType commandType, T value, IDataParameter[] parameters = null)
        {
            using (var connection = CreateConnection())
            {
                connection.Open();
                using (var command = CreateCommand(commandText, commandType, connection))
                {
                    if (parameters != null)
                    {
                        foreach (var parameter in parameters)
                        {
                            command.Parameters.Add(parameter);
                        }
                    }

                    return (T)Convert.ChangeType(command.ExecuteScalar() == null ? value : command.ExecuteScalar(), typeof(T));
                }
            }
        }

        public static T GetScalarValue<T>(string commandText, CommandType commandType, T value, bool IsServerChange, IDataParameter[] parameters = null)
        {
            using (var connection = CreateConnection())
            {
                connection.Open();
                using (var command = CreateCommand(commandText, commandType, connection))
                {
                    if (parameters != null)
                    {
                        foreach (var parameter in parameters)
                        {
                            command.Parameters.Add(parameter);
                        }
                    }

                    return (T)Convert.ChangeType(command.ExecuteScalar() == null ? value : command.ExecuteScalar(), typeof(T));
                }
            }
        }

        public static IDbConnection CreateConnection()
        {
            return new MySqlConnection(ConnectionString());
        }

        public static IDbCommand CreateCommand(string commandText, CommandType commandType, IDbConnection connection)
        {
            return new MySqlCommand
            {
                CommandText = commandText,
                CommandType = commandType,
                Connection = (MySqlConnection)connection
            };
        }

        public static IDataAdapter CreateAdapter(IDbCommand command)
        {
            return new MySqlDataAdapter((MySqlCommand)command);
        }

        public static IDbDataParameter CreateParameter(string name, object value)
        {
            return new MySqlParameter
            {
                ParameterName = name,
                Value = value
            };
        }
    }
}