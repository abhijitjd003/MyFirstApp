﻿using farmar_market_api.Common;
using farmar_market_api.DataAccess;
using farmar_market_api.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Web.Mvc;

namespace farmar_market_api.Controllers
{
    public class RatesController : Controller
    {
        // GET: Rates
        public ActionResult Index(bool isShow = false)
        {
            Rates rates = new Rates();            
            List<Product> products = new List<Product>();
            DataTable result = DatabaseHandler.GetDataTable(Constants.GET_PRODUCTS,
                CommandType.StoredProcedure);

            if (result.Rows.Count > 0)
            {
                DataRow[] rowsFiltered = result.Select("Deactivate='NO'");

                foreach (DataRow row in rowsFiltered)
                {
                    Product product = new Product();
                    product.ProductName = Convert.ToString(row["ProductName"]);
                    product.RatePerKg = Convert.ToDecimal(row["RatePerKg"]);
                    product.FileName = Convert.ToString(row["ProductImagePath"]);
                    product.TotalStock = Convert.ToDecimal(row["TotalStock"]);
                    products.Add(product);
                }
            }

            rates.Products = products;
            rates.Show = isShow;
            rates.CurrentDate = DateTime.Now.AddMinutes(750).ToString("dd.MM.yyyy");
            rates.CurrentDay = DateTime.Now.AddMinutes(750).ToString("dddd");
            //if (isShow)
            //{                
            //    rates.Action = "Hide Stocks";
            //}
            //else
            //{
            //    rates.Action = "Show Stocks";
            //}
            return View(rates);
        }

        //public ActionResult ShowHideStocks(bool Show)
        //{
        //    return RedirectToAction("Index", new { isShow = Show });
        //}
    }
}