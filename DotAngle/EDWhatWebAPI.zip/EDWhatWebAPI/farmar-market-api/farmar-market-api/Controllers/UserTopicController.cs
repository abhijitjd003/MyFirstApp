﻿using EDWhatCoreAPI.Constants;
using farmar_market_api.DataAccess;
using EDWhatCoreAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Web.Http;

namespace farmar_market_api.Controllers
{
    [RoutePrefix("api/UserTopic")]
    public class UserTopicController : ApiController
    {
        [HttpGet]
        [Route("GetUserTopics")]        
        public IHttpActionResult GetUserTopics(int SORT_IND, int PAGE_NUM, string USER_ID, string SRCH_VAL)
        {
            long pages = 0;
            List<UserTopic> userTopics = new List<UserTopic>();
            var parameters = new List<IDbDataParameter>();
            parameters.Add(DatabaseHandler.CreateParameter("@P_USER_ID", USER_ID));
            parameters.Add(DatabaseHandler.CreateParameter("@SORT_IND", SORT_IND));
            parameters.Add(DatabaseHandler.CreateParameter("@PAGE_NUM", PAGE_NUM * 10));
            parameters.Add(DatabaseHandler.CreateParameter("@SRCH_VAL", SRCH_VAL));

            DataSet table = DatabaseHandler.GetDataSet(SPName.GET_USER_TOPICS,
                CommandType.StoredProcedure, parameters.ToArray());

            if (table.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow dr in table.Tables[0].Rows)
                {
                    UserTopic topic = new UserTopic();
                    topic.TOPIC_ID = Convert.ToInt64(dr["TOPIC_ID"]);
                    topic.TOPIC_TITLE = Convert.ToString(dr["TOPIC_TITLE"]);
                    topic.TOPIC_DESC = Convert.ToString(dr["TOPIC_DESC"]);
                    topic.TOPIC_UPDT_DTM = Convert.ToString(dr["TOPIC_UPDT_DTM"]);
                    topic.TOPIC_UPDT_USER_NM = Convert.ToString(dr["TOPIC_UPDT_USER_NM"]);
                    topic.TOPIC_POST_TYPE = Convert.ToString(dr["TOPIC_POST_TYPE"]);
                    topic.TOPIC_LIKE_VOTE = Convert.ToInt64(dr["TOPIC_LIKE_VOTE"]);
                    topic.TOPIC_POLL_LIKE = Convert.ToInt64(dr["TOPIC_POLL_LIKE"]);
                    topic.TOPIC_VIEW = Convert.ToInt64(dr["TOPIC_VIEW"]);
                    topic.TOPIC_IMG_URL = Convert.ToString(dr["TOPIC_IMG_URL"]);
                    topic.LIKE_IND = Convert.ToInt32(dr["LIKE_IND"]);
                    topic.VOTE_IND = Convert.ToInt32(dr["VOTE_IND"]);
                    userTopics.Add(topic);
                }
            }

            if (table.Tables[1].Rows.Count > 0)
            {
                pages = Convert.ToInt64(table.Tables[1].Rows[0]["Pages"]);
            }

            var result = new { userTopics, pages };
            return Ok(result);
        }
    }
}