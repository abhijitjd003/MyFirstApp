﻿using EDWhatCoreAPI.Constants;
using farmar_market_api.DataAccess;
using EDWhatCoreAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Web.Http;

namespace farmar_market_api.Controllers
{
    [RoutePrefix("api/UserQueTopic")]
    public class UserQueTopicController : ApiController
    {
        [HttpGet]
        [Route("GetUserQueTopic")]
        public IHttpActionResult GetUserQueTopic(long TOPIC_ID, string USER_ID, string USER_NM)
        {
            UserQueTopic topic = new UserQueTopic();
            var parameters = new List<IDbDataParameter>();

            parameters.Add(DatabaseHandler.CreateParameter("@P_TOPIC_ID", TOPIC_ID));
            parameters.Add(DatabaseHandler.CreateParameter("@P_USER_ID", USER_ID));
            parameters.Add(DatabaseHandler.CreateParameter("@P_USER_NM", USER_NM));
            DataSet table = DatabaseHandler.GetDataSet(SPName.GET_USER_QUE_TOPIC, 
                CommandType.StoredProcedure, parameters.ToArray());

            if (table.Tables[3].Rows.Count > 0)
            {
                topic.TOPIC_ID = Convert.ToInt64(table.Tables[3].Rows[0]["TOPIC_ID"]);
                topic.TOPIC_TITLE = Convert.ToString(table.Tables[3].Rows[0]["TOPIC_TITLE"]);
                topic.TOPIC_DESC = Convert.ToString(table.Tables[3].Rows[0]["TOPIC_DESC"]);
                topic.TOPIC_UPDT_DTM = Convert.ToString(table.Tables[3].Rows[0]["TOPIC_UPDT_DTM"]);
                topic.TOPIC_UPDT_USER_NM = Convert.ToString(table.Tables[3].Rows[0]["TOPIC_UPDT_USER_NM"]);
                topic.TOPIC_LIKE = Convert.ToInt64(table.Tables[3].Rows[0]["TOPIC_LIKE"]);
                topic.TOPIC_VIEW = Convert.ToInt64(table.Tables[3].Rows[0]["TOPIC_VIEW"]);
                topic.TOPIC_IMG_URL = Convert.ToString(table.Tables[3].Rows[0]["TOPIC_IMG_URL"]);
            }

            if (table.Tables[4].Rows.Count > 0)
            {
                topic.TOPIC_LIKE_IND = Convert.ToInt32(table.Tables[4].Rows[0]["LIKE_IND"]);
            }

            if (table.Tables[5].Rows.Count > 0)
            {
                topic.TOPIC_RPT_IND = Convert.ToInt32(table.Tables[5].Rows[0]["RPT_IND"]);
            }
            return Ok(topic);
        }

        [HttpPost]
        [Route("SaveUserQueLike")]
        public string SaveUserQueLike(UserQueTopic queTopic)
        {
            string result = "";
            var parameters = new List<IDbDataParameter>();
            parameters.Add(DatabaseHandler.CreateParameter("@P_TOPIC_ID", queTopic.TOPIC_ID));
            parameters.Add(DatabaseHandler.CreateParameter("@P_TOPIC_UPDT_USER_ID", queTopic.TOPIC_UPDT_USER_ID));
            parameters.Add(DatabaseHandler.CreateParameter("@P_TOPIC_UPDT_USER_NM", queTopic.TOPIC_UPDT_USER_NM));
            parameters.Add(DatabaseHandler.CreateParameter("@P_TOPIC_CREATE_DTM", SystemTimeZone.GetCurrentTimeZone()));

            DataSet dataSet = DatabaseHandler.GetDataSet(SPName.SAVE_USER_QUE_TOPIC_LIKE,
                CommandType.StoredProcedure, parameters.ToArray());

            if (dataSet.Tables[0].Rows.Count > 0)
            {
                result = Convert.ToString(dataSet.Tables[0].Rows[0]["Msg"]);
            }
            return result;
        }
    }
}