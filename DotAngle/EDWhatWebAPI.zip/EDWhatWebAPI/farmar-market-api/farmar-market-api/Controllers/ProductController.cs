﻿using farmar_market_api.Common;
using farmar_market_api.DataAccess;
using farmar_market_api.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Net;
using System.Web;
using System.Web.Http;

namespace farmar_market_api.Controllers
{
    [RoutePrefix("api/Product")]
    public class ProductController : ApiController
    {
        [Route("GetProductCategories")]
        [HttpGet]
        public IHttpActionResult GetProductCategories()
        {
            try
            {
                List<ProductCategory> categories = new List<ProductCategory>();
                DataTable result = DatabaseHandler.GetDataTable(Constants.GET_PRODUCT_CATEGORIES,
                    CommandType.StoredProcedure);

                if (result.Rows.Count > 0)
                {
                    foreach (DataRow row in result.Rows)
                    {
                        ProductCategory category = new ProductCategory();
                        category.CategoryId = Convert.ToInt32(row["CategoryId"]);
                        category.CategoryName = Convert.ToString(row["Name"]);
                        categories.Add(category);
                    }
                }
                return Content(HttpStatusCode.OK, categories);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("CreateProduct")]
        [HttpPost]
        public bool CreateProduct([FromBody]Product product)
        {
            bool res = false; string productImagePath = "";
            try
            {
                if (!string.IsNullOrEmpty(product.FileName))
                {
                    string Server = FTPServer.Server;
                    productImagePath = string.Format("{0}/{1}/{2}/{3}", Server.Replace("ftp://", "https://"), "UploadedFiles", "Products", product.FileName);
                }

                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_ProductId", product.ProductId));
                parameters.Add(DatabaseHandler.CreateParameter("@p_CategoryId", product.CategoryId));
                parameters.Add(DatabaseHandler.CreateParameter("@p_ProductName", product.ProductName));
                parameters.Add(DatabaseHandler.CreateParameter("@p_ProductNameKannada", product.ProductNameKannada));
                parameters.Add(DatabaseHandler.CreateParameter("@p_UnitType", product.UnitType));
                parameters.Add(DatabaseHandler.CreateParameter("@p_RatePerKg", product.RatePerKg));
                parameters.Add(DatabaseHandler.CreateParameter("@p_MinPurchaseQuantity", product.MinPurchaseQuantity));
                //parameters.Add(DatabaseHandler.CreateParameter("@p_TotalStock", product.TotalStock));
                parameters.Add(DatabaseHandler.CreateParameter("@p_CreatedDateTime", DateTime.Now.AddMinutes(750)));
                parameters.Add(DatabaseHandler.CreateParameter("@p_UpdatedDateTime", DateTime.Now.AddMinutes(750)));
                parameters.Add(DatabaseHandler.CreateParameter("@p_UserId", product.UserId));
                //parameters.Add(DatabaseHandler.CreateParameter("@p_Deactivate", product.Deactivate));
                parameters.Add(DatabaseHandler.CreateParameter("@p_ProductImagePath", productImagePath));

                DataSet result = DatabaseHandler.GetDataSet(Constants.CREATE_PRODUCT, CommandType.StoredProcedure, parameters.ToArray());

                if (!string.IsNullOrEmpty(product.FileName))
                {
                    byte[] bytes = Convert.FromBase64String(product.FileBase64String);
                    string createdDirectory = string.Empty;

                    if (product.ProductId > 0)
                    {
                        string url = result.Tables[1].Rows[0]["ProductImagePath"].ToString();
                        FTPServer.DeleteFileFromFTPServer(url.Replace("https://", "ftp://"));
                    }

                    string[] directories = new string[] { "UploadedFiles", "Products" };
                    if (FTPServer.CreateFTPDirectory(directories, out createdDirectory))
                    {
                        FTPServer.UploadFTPFile(product.FileName, bytes, createdDirectory);
                    }
                }

                int tableIndex = product.ProductId == 0 ? 2 : 1;

                if (result.Tables[tableIndex].Rows.Count > 0)
                {
                    if (result.Tables[tableIndex].Rows[0]["Message"].ToString() == "success")
                    {
                        res = true;
                    }
                    else
                    {
                        res = false;
                    }
                }

                return res;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        [Route("UpdateProducts")]
        [HttpPost]
        public bool UpdateProducts([FromBody]List<Product> products)
        {
            try
            {
                foreach (Product product in products)
                {
                    var parameters = new List<IDbDataParameter>();
                    parameters.Add(DatabaseHandler.CreateParameter("@p_ProductId", product.ProductId));                    
                    parameters.Add(DatabaseHandler.CreateParameter("@p_RatePerKg", product.RatePerKg));                    
                    parameters.Add(DatabaseHandler.CreateParameter("@p_UpdatedDateTime", DateTime.Now.AddMinutes(750)));
                    parameters.Add(DatabaseHandler.CreateParameter("@p_UserId", product.UserId));
                    parameters.Add(DatabaseHandler.CreateParameter("@p_Deactivate", product.IsDeactivate));

                    DataSet result = DatabaseHandler.GetDataSet(Constants.UPDATE_PRODUCTS, CommandType.StoredProcedure, parameters.ToArray());
                }

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        [Route("RemoveProduct")]
        [HttpPost]
        public bool RemoveProduct(int ProductId, string UserId)
        {
            try
            {
                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_ProductId", ProductId));
                parameters.Add(DatabaseHandler.CreateParameter("@p_UpdatedDateTime", DateTime.Now.AddMinutes(750)));
                parameters.Add(DatabaseHandler.CreateParameter("@p_UserId", UserId));
                DatabaseHandler.Delete(Constants.DELETE_PRODUCT, CommandType.StoredProcedure,
                    parameters.ToArray());
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        [Route("GetProducts")]
        [HttpGet]
        public IHttpActionResult GetProducts()
        {
            try
            {
                List<Product> products = new List<Product>();
                DataTable result = DatabaseHandler.GetDataTable(Constants.GET_PRODUCTS,
                    CommandType.StoredProcedure);

                if (result.Rows.Count > 0)
                {
                    foreach (DataRow row in result.Rows)
                    {
                        Product product = new Product();
                        product.ProductId = Convert.ToInt32(row["ProductId"]);
                        product.CategoryId = Convert.ToInt32(row["CategoryId"]);
                        product.CategoryName = Convert.ToString(row["CategoryName"]);
                        product.ProductName = Convert.ToString(row["ProductName"]);
                        product.ProductNameKannada = Convert.ToString(row["ProductNameKannada"]);
                        product.UnitType = Convert.ToString(row["UnitType"]);
                        product.RatePerKg = Convert.ToDecimal(row["RatePerKg"]);
                        product.MinPurchaseQuantity = Convert.ToDecimal(row["MinPurchaseQuantity"]);
                        product.TotalStock = Convert.ToDecimal(row["TotalStock"]);
                        product.UpdatedDate = Convert.ToString(row["UpdatedDateTime"]);
                        product.UserId = Convert.ToString(row["UpdatedUserId"]);
                        product.IsDeactivate = Convert.ToString(row["Deactivate"]);
                        products.Add(product);
                    }
                }
                return Content(HttpStatusCode.OK, products);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("GetProductsInOrder")]
        [HttpGet]
        public IHttpActionResult GetProductsInOrder()
        {
            try
            {
                List<Product> products = new List<Product>();
                DataTable result = DatabaseHandler.GetDataTable(Constants.GET_PRODUCTS,
                    CommandType.StoredProcedure);

                if (result.Rows.Count > 0)
                {
                    DataRow[] rowsFiltered = result.Select("Deactivate='NO'");
                    foreach (DataRow row in rowsFiltered)
                    {
                        Product product = new Product();
                        product.ProductId = Convert.ToInt32(row["ProductId"]);
                        product.ProductName = Convert.ToString(row["ProductName"]);
                        product.RatePerKg = Convert.ToDecimal(row["RatePerKg"]);
                        product.MinPurchaseQuantity = Convert.ToDecimal(row["MinPurchaseQuantity"]);
                        product.Quantity = 0;
                        product.TotalStock = Convert.ToDecimal(row["TotalStock"]);
                        product.FileName = Convert.ToString(row["ProductImagePath"]);
                        product.UnitType = Convert.ToString(row["UnitType"]) == "Piece" ? "Pc" : "Kg";
                        products.Add(product);
                    }
                }
                return Content(HttpStatusCode.OK, products);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("GetProductsHistory")]
        [HttpGet]
        public IHttpActionResult GetProductsHistory(string FromDate, string ToDate)
        {
            try
            {
                List<Product> products = new List<Product>();
                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_FromDate", FromDate));
                parameters.Add(DatabaseHandler.CreateParameter("@p_ToDate", ToDate));
                DataTable result = DatabaseHandler.GetDataTable(Constants.GET_PRODUCTS_HISTORY, CommandType.StoredProcedure, parameters.ToArray());

                if (result.Rows.Count > 0)
                {
                    foreach (DataRow row in result.Rows)
                    {
                        Product product = new Product();                        
                        product.ProductName = Convert.ToString(row["ProductName"]);
                        product.RatePerKg = Convert.ToDecimal(row["RatePerKg"]);
                        product.UpdatedDate = Convert.ToString(row["UpdatedDate"]);       products.Add(product);
                    }
                }
                return Content(HttpStatusCode.OK, products);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("GetValidProducts")]
        [HttpGet]
        public IHttpActionResult GetValidProducts()
        {
            try
            {
                List<Product> products = new List<Product>();
                DataTable result = DatabaseHandler.GetDataTable(Constants.GET_PRODUCTS,
                    CommandType.StoredProcedure);

                if (result.Rows.Count > 0)
                {
                    DataRow[] rowsFiltered = result.Select("Deactivate='NO'");
                    foreach (DataRow row in rowsFiltered)
                    {
                        Product product = new Product();
                        product.ProductId = Convert.ToInt32(row["ProductId"]);
                        product.ProductName = Convert.ToString(row["ProductName"]);
                        products.Add(product);
                    }
                }
                return Content(HttpStatusCode.OK, products);
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
