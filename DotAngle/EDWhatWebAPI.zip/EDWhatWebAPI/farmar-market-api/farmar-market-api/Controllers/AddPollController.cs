﻿using EDWhatCoreAPI.Constants;
using farmar_market_api.DataAccess;
using EDWhatCoreAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Web.Http;

namespace farmar_market_api.Controllers
{
    [RoutePrefix("api/AddPoll")]
    public class AddPollController : ApiController
    {
        [HttpPost]
        [Route("CreateUserPoll")]
        public string CreateUserPoll([FromBody] UserPoll userPoll)
        {
            string result = "";
            var parameters = new List<IDbDataParameter>();
            parameters.Add(DatabaseHandler.CreateParameter("@P_TOPIC_TITLE", userPoll.TOPIC_TITLE));
            parameters.Add(DatabaseHandler.CreateParameter("@P_TOPIC_DESC", userPoll.TOPIC_DESC));            
            parameters.Add(DatabaseHandler.CreateParameter("@P_TOPIC_CREATE_USER_ID", userPoll.TOPIC_CREATE_USER_ID));
            parameters.Add(DatabaseHandler.CreateParameter("@P_TOPIC_CREATE_USER_NM", userPoll.TOPIC_CREATE_USER_NM));
            parameters.Add(DatabaseHandler.CreateParameter("@P_TOPIC_CREATE_DTM", SystemTimeZone.GetCurrentTimeZone()));

            DataTable table = DatabaseHandler.GetDataTable(SPName.SAVE_USER_POLL_TOPIC,
                CommandType.StoredProcedure, parameters.ToArray());
            long topicId = Convert.ToInt64(table.Rows[0]["TOPIC_ID"]);

            List<string> options = new List<string>();
            StringBuilder commandText = new StringBuilder
            (
                "INSERT INTO USER_POLL_TOPIC_OPTNS (TOPIC_ID, TOPIC_VOTE_OPTN) VALUES "
            );

            foreach(string option in userPoll.TOPIC_VOTE_OPTNS)
            {
                if (!string.IsNullOrEmpty(option)) 
                {
                    options.Add(string.Format("({0},'{1}')", topicId, option));
                }
            }

            commandText.Append(string.Join(",", options));
            commandText.Append(";");
            DatabaseHandler.Save(commandText.ToString(), CommandType.Text);

            if (table.Rows.Count > 0)
            {
                result = Convert.ToString(table.Rows[0]["Msg"]);
            }
            return result;
        }
    }
}