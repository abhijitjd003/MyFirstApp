﻿using farmar_market_api.Common;
using farmar_market_api.DataAccess;
using farmar_market_api.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Net;
using System.Web.Http;

namespace farmar_market_api.Controllers
{
    [RoutePrefix("api/Home")]
    public class HomeController : ApiController
    {
        [Route("ValidateUser")]
        [HttpPost]
        public string ValidateUser([FromBody]User user)
        {
            string role = "";
            try
            {
                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_Email", user.Email));
                parameters.Add(DatabaseHandler.CreateParameter("@p_Password", user.Password));
                DataSet result = DatabaseHandler.GetDataSet(Constants.VALIDATE_LOGIN_USER, 
                    CommandType.StoredProcedure, parameters.ToArray());

                if (result.Tables[0].Rows.Count > 0)
                {
                    role = Convert.ToString(result.Tables[0].Rows[0]["Role"]);
                }
                return role;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("CreateUser")]
        [HttpPost]
        public bool CreateUser([FromBody]User user)
        {
            bool res = false;
            try
            {
                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_UserId", user.UserId));
                parameters.Add(DatabaseHandler.CreateParameter("@p_FullName", user.FullName));
                parameters.Add(DatabaseHandler.CreateParameter("@p_Email", user.Email));
                parameters.Add(DatabaseHandler.CreateParameter("@p_MobileNo", user.MobileNo));
                parameters.Add(DatabaseHandler.CreateParameter("@p_Role", user.Role));
                parameters.Add(DatabaseHandler.CreateParameter("@p_Password", user.Password));

                DataSet result = DatabaseHandler.GetDataSet(Constants.CREATE_USER, CommandType.StoredProcedure,
                    parameters.ToArray());
                int tableIndex = user.UserId == 0 ? 1 : 0;

                if (result.Tables[tableIndex].Rows.Count > 0)
                {
                    if (result.Tables[tableIndex].Rows[0]["Message"].ToString() == "success")
                    {
                        res = true;
                    }
                    else
                    {
                        res = false;
                    }
                }

                return res;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        [Route("RemoveUser")]
        [HttpPost]
        public bool RemoveUser(int UserId)
        {
            try
            {
                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_UserId", UserId));
                DatabaseHandler.Delete(Constants.DELETE_USER, CommandType.StoredProcedure,
                    parameters.ToArray());
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        [Route("GetUsers")]
        [HttpGet]
        public IHttpActionResult GetUsers()
        {
            try
            {
                List<User> users = new List<User>();
                DataTable result = DatabaseHandler.GetDataTable(Constants.GET_USERS,
                    CommandType.StoredProcedure);

                if (result.Rows.Count > 0)
                {
                    foreach (DataRow row in result.Rows)
                    {
                        User user = new User();
                        user.UserId = Convert.ToInt32(row["UserId"]);
                        user.FullName = Convert.ToString(row["FullName"]);
                        user.Email = Convert.ToString(row["Email"]);
                        user.MobileNo = Convert.ToInt64(row["MobileNo"]);
                        user.Role = Convert.ToString(row["Role"]);
                        user.Password = Convert.ToString(row["Password"]);
                        users.Add(user);
                    }
                }
                return Content(HttpStatusCode.OK, users);
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
