﻿using farmar_market_api.Common;
using farmar_market_api.DataAccess;
using farmar_market_api.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Net;
using System.Text;
using System.Web.Http;
using System.Web.Script.Serialization;

namespace farmar_market_api.Controllers
{
    [RoutePrefix("api/Notification")]
    public class NotificationController : ApiController
    {
        [Route("PushNotification")]
        [HttpPost]
        public bool PushNotification([FromBody]Notification notification)
        {
            bool res = false;
            try
            {
                string sResponseFromServer = "";
                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_Message", notification.Message));
                parameters.Add(DatabaseHandler.CreateParameter("@p_Title", notification.Title));

                DataSet result = DatabaseHandler.GetDataSet(Constants.PUSH_NOTIFICATION, CommandType.StoredProcedure, parameters.ToArray());

                if (result.Tables[1].Rows.Count > 0)
                {
                    if (result.Tables[1].Rows[0]["Message"].ToString() == "success")
                    {
                        res = true;
                    }
                    else
                    {
                        res = false;
                    }
                }

                if (res && result.Tables[2].Rows.Count > 0)
                {
                    foreach (DataRow row in result.Tables[2].Rows)
                    {
                        string shopIds = "";
                        int shopId = Convert.ToInt32(row["ShopId"]);
                        string deviceId = row["DeviceId"].ToString();

                        if (notification.ShopIds != null && notification.ShopIds.Count > 0)
                        {
                            foreach (int ShopId in notification.ShopIds)
                            {
                                shopIds += ShopId.ToString() + ",";
                            }
                        }

                        if (!string.IsNullOrEmpty(shopIds) && !shopIds.Contains(shopId.ToString() + ","))
                        {
                            deviceId = "";
                        }

                        if (!string.IsNullOrEmpty(deviceId))
                        {
                            var data = new
                            {
                                to = deviceId,
                                priority = "high",
                                content_available = true,
                                notification = new
                                {
                                    body = notification.Message,
                                    title = notification.Title.Replace(":", ""),
                                    icon = "ic_silhouette",
                                    sound = "sound.caf",
                                    badge = 1
                                },
                            };

                            var serializer = new JavaScriptSerializer();
                            var jsonData = serializer.Serialize(data);
                            Byte[] byteArray = Encoding.UTF8.GetBytes(jsonData);

                            string serverKey = NotificationKeys.SERVER_KEY;
                            string senderId = NotificationKeys.SENDER_ID;

                            WebRequest tRequest = WebRequest.Create("https://fcm.googleapis.com/fcm/send");
                            tRequest.Method = "post";
                            tRequest.ContentType = "application/json";
                            tRequest.Headers.Add("Authorization: key=" + serverKey);
                            tRequest.Headers.Add("Sender: id=" + senderId);

                            tRequest.ContentLength = byteArray.Length;
                            using (Stream dataStream = tRequest.GetRequestStream())
                            {
                                dataStream.Write(byteArray, 0, byteArray.Length);
                                using (WebResponse tResponse = tRequest.GetResponse())
                                {
                                    using (Stream dataStreamResponse = tResponse.GetResponseStream())
                                    {
                                        if (dataStreamResponse != null) using (StreamReader tReader = new StreamReader(dataStreamResponse))
                                            {
                                                sResponseFromServer = tReader.ReadToEnd();
                                            }
                                    }
                                }
                            }
                        }
                    }
                }

                return res;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        [Route("RemoveNotification")]
        [HttpPost]
        public bool RemoveNotification(int NotificationId)
        {
            try
            {
                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_NotificationId", NotificationId));
                DatabaseHandler.Delete(Constants.DELETE_NOTIFICATION, CommandType.StoredProcedure,
                    parameters.ToArray());
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        [Route("GetNotifications")]
        [HttpGet]
        public IHttpActionResult GetNotifications()
        {
            try
            {
                List<Notification> notifications = new List<Notification>();
                DataTable result = DatabaseHandler.GetDataTable(Constants.GET_NOTIFICATIONS,
                    CommandType.StoredProcedure);

                if (result.Rows.Count > 0)
                {
                    foreach (DataRow row in result.Rows)
                    {
                        Notification notification = new Notification();
                        notification.NotificationId = Convert.ToInt32(row["NotificationId"]);
                        notification.Message = Convert.ToString(row["Message"]);
                        notification.Title = Convert.ToString(row["Title"]);
                        notification.CreatedDateTime = Convert.ToString(row["CreatedDateTime"]);
                        notifications.Add(notification);
                    }
                }
                return Content(HttpStatusCode.OK, notifications);
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
