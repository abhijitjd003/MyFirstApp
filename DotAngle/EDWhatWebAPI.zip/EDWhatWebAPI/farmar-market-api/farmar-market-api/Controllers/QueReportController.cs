﻿using EDWhatCoreAPI.Constants;
using farmar_market_api.DataAccess;
using EDWhatCoreAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Web.Http;
using farmar_market_api.Models;

namespace farmar_market_api.Controllers
{
    [RoutePrefix("api/QueReport")]
    public class QueReportController : ApiController
    {
        [HttpPost]
        [Route("SaveQueReport")]
        public string SaveQueReport([FromBody] QueReport report)
        {
            string result = "";
            var parameters = new List<IDbDataParameter>();
            parameters.Add(DatabaseHandler.CreateParameter("@P_TOPIC_ID", report.TOPIC_ID));
            parameters.Add(DatabaseHandler.CreateParameter("@P_TOPIC_RPT_OPTN", report.TOPIC_RPT_OPTN));
            parameters.Add(DatabaseHandler.CreateParameter("@P_TOPIC_RPT_OTHR_OPTN", report.TOPIC_RPT_OTHR_OPTN));
            parameters.Add(DatabaseHandler.CreateParameter("@P_TOPIC_RPT_USER_ID", report.TOPIC_RPT_USER_ID));
            parameters.Add(DatabaseHandler.CreateParameter("@P_TOPIC_RPT_USER_NM", report.TOPIC_RPT_USER_NM));
            parameters.Add(DatabaseHandler.CreateParameter("@P_TOPIC_RPT_DTM", SystemTimeZone.GetCurrentTimeZone()));

            DataTable table = DatabaseHandler.GetDataTable(SPName.SAVE_USER_QUE_TOPIC_RPTS,
                CommandType.StoredProcedure, parameters.ToArray());
            
            if (table.Rows.Count > 0)
            {
                result = Convert.ToString(table.Rows[0]["Msg"]);
            }
            return result;
        }
    }
}
