﻿using EDWhatCoreAPI.Constants;
using farmar_market_api.DataAccess;
using EDWhatCoreAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Web.Http;
using farmar_market_api.Common;

namespace farmar_market_api.Controllers
{
    [RoutePrefix("api/AddQuestion")]
    public class AddQuestionController : ApiController
    {
        [HttpPost]
        [Route("CreateUserQuestion")]
        public string CreateUserQuestion(UserQuestion userQue)
        {
            string imageUrl = "";
            string result = "";
            long topicId = 0;

            if (!string.IsNullOrEmpty(userQue.TOPIC_FILE_NM))
            {
                string Server = FTPServer.Server;
                imageUrl = string.Format("{0}/{1}/{2}/{3}/{4}",
                    Server.Replace("ftp://", "http://"), "UploadedFiles", "Topics", "topic_id", userQue.TOPIC_FILE_NM);
            }

            var parameters = new List<IDbDataParameter>();
            parameters.Add(DatabaseHandler.CreateParameter("@P_TOPIC_TITLE", userQue.TOPIC_TITLE));
            parameters.Add(DatabaseHandler.CreateParameter("@P_TOPIC_DESC", userQue.TOPIC_DESC));
            parameters.Add(DatabaseHandler.CreateParameter("@P_TOPIC_IMG_URL", imageUrl));
            parameters.Add(DatabaseHandler.CreateParameter("@P_TOPIC_CREATE_USER_ID", userQue.TOPIC_CREATE_USER_ID));
            parameters.Add(DatabaseHandler.CreateParameter("@P_TOPIC_CREATE_USER_NM", userQue.TOPIC_CREATE_USER_NM));
            parameters.Add(DatabaseHandler.CreateParameter("@P_TOPIC_CREATE_DTM", SystemTimeZone.GetCurrentTimeZone()));

            DataSet dataSet = DatabaseHandler.GetDataSet(SPName.SAVE_USER_QUE_TOPIC,
                CommandType.StoredProcedure, parameters.ToArray());

            if (dataSet.Tables[0].Rows.Count > 0)
            {
                result = Convert.ToString(dataSet.Tables[0].Rows[0]["Msg"]);
                topicId = Convert.ToInt64(dataSet.Tables[0].Rows[0]["TOPIC_ID"]);
            }

            if (!string.IsNullOrEmpty(userQue.TOPIC_FILE_NM))
            {
                byte[] bytes = Convert.FromBase64String(userQue.TOPIC_FILE_BASE_64_STRNG);
                string createdDirectory = string.Empty;

                string[] directories = new string[] { "UploadedFiles", "Topics", topicId.ToString() };
                if (FTPServer.CreateFTPDirectory(directories, out createdDirectory))
                {
                    FTPServer.UploadFTPFile(userQue.TOPIC_FILE_NM, bytes, createdDirectory);
                }
            }

            return result;
        }
    }
}