﻿using EDWhatCoreAPI.Constants;
using farmar_market_api.DataAccess;
using EDWhatCoreAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Web.Http;

namespace farmar_market_api.Controllers
{
    [RoutePrefix("api/MyProfile")]
    public class MyProfileController : ApiController
    {
        [HttpGet]
        [Route("GetMyProfileDetails")]
        public IHttpActionResult GetMyProfileDetails(string USER_ID, string SRCH_VAL)
        {
            List<MyProfileDetail> userTopics = new List<MyProfileDetail>();
            MyProfile myProfile = new MyProfile();
            var parameters = new List<IDbDataParameter>();
            parameters.Add(DatabaseHandler.CreateParameter("@P_USER_ID", USER_ID));
            parameters.Add(DatabaseHandler.CreateParameter("@P_SRCH_VAL", SRCH_VAL));

            DataSet tables = DatabaseHandler.GetDataSet(SPName.GET_USER_PROFILE_DTL,
                CommandType.StoredProcedure, parameters.ToArray());

            if (tables.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow dr in tables.Tables[0].Rows)
                {
                    MyProfileDetail topic = new MyProfileDetail();
                    topic.TOPIC_ID = Convert.ToInt64(dr["TOPIC_ID"]);
                    topic.TOPIC_TITLE = Convert.ToString(dr["TOPIC_TITLE"]);
                    topic.TOPIC_UPDT_DTM = Convert.ToString(dr["TOPIC_UPDT_DTM"]);
                    topic.TOPIC_UPDT_USER_NM = Convert.ToString(dr["TOPIC_UPDT_USER_NM"]);
                    topic.TOPIC_POST_TYPE = Convert.ToString(dr["TOPIC_POST_TYPE"]);
                    topic.TOPIC_LIKE_VOTE = Convert.ToInt64(dr["TOPIC_LIKE_VOTE"]);
                    topic.TOPIC_VIEW = Convert.ToInt64(dr["TOPIC_VIEW"]);
                    topic.TOPIC_IMG_URL = Convert.ToString(dr["TOPIC_IMG_URL"]);
                    userTopics.Add(topic);
                }
            }

            if (tables.Tables[1].Rows.Count > 0)
            {
                myProfile.TOTAL_QUE = Convert.ToInt64(tables.Tables[1].Rows[0]["TOTAL_QUE"]);
                myProfile.TOTAL_LIKE = Convert.ToInt64(tables.Tables[1].Rows[0]["TOTAL_LIKE"]);
                myProfile.TOTAL_VOTE = Convert.ToInt64(tables.Tables[1].Rows[0]["TOTAL_VOTE"]);
                myProfile.TOTAL_VIEW = Convert.ToInt64(tables.Tables[1].Rows[0]["TOTAL_VIEW"]);
            }

            var result = new { userTopics, myProfile };
            return Ok(result);
        }
    }
}