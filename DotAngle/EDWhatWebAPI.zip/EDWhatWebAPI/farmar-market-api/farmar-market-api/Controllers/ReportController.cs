﻿using farmar_market_api.Common;
using farmar_market_api.DataAccess;
using farmar_market_api.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Net;
using System.Web.Http;

namespace farmar_market_api.Controllers
{
    [RoutePrefix("api/Report")]
    public class ReportController : ApiController
    {
        [Route("GetProductSales")]
        [HttpGet]
        public IHttpActionResult GetProductSales(string FromDate, string ToDate, int ProductId)
        {
            try
            {
                List<Order> orders = new List<Order>();
                List<Order> productPriceHistory = new List<Order>();
                decimal TotalQuantity = 0; decimal TotalCost = 0; decimal TotalRate = 0;
                decimal AvgQuantity = 0; decimal AvgCost = 0; decimal AvgRatePerKg = 0;
                var parameters = new List<IDbDataParameter>();

                parameters.Add(DatabaseHandler.CreateParameter("@p_FromDate", FromDate));
                parameters.Add(DatabaseHandler.CreateParameter("@p_ToDate", ToDate));
                parameters.Add(DatabaseHandler.CreateParameter("@p_ProductId", ProductId));
                DataSet result = DatabaseHandler.GetDataSet(Constants.GET_PRODUCT_SALES, CommandType.StoredProcedure, parameters.ToArray());

                if (result.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow row in result.Tables[0].Rows)
                    {
                        Order order = new Order();
                        order.Quantity = Convert.ToDecimal(row["Quantity"]);
                        order.Cost = Convert.ToDecimal(row["Price"]);
                        order.OrderedDateTime = Convert.ToString(row["OrderDate"]);
                        TotalQuantity += order.Quantity;
                        TotalCost += order.Cost;
                        orders.Add(order);
                    }

                    AvgQuantity = TotalQuantity / result.Tables[0].Rows.Count;
                    AvgCost = TotalCost / result.Tables[0].Rows.Count;
                }

                if (result.Tables[1].Rows.Count > 0)
                {
                    foreach (DataRow row in result.Tables[1].Rows)
                    {
                        Order order = new Order();
                        order.RatePerKg = Convert.ToDecimal(row["RatePerKg"]);
                        order.OrderedDateTime = Convert.ToString(row["CreatedDate"]);
                        TotalRate += order.RatePerKg;
                        productPriceHistory.Add(order);
                    }

                    AvgRatePerKg = TotalRate / result.Tables[1].Rows.Count;
                }

                return Content(HttpStatusCode.OK,
                    new { orders, productPriceHistory, AvgQuantity, AvgCost, AvgRatePerKg });
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("GetCustomerOrders")]
        [HttpGet]
        public IHttpActionResult GetCustomerOrders(string FromDate, string ToDate, int ShopId)
        {
            try
            {
                List<Order> orders = new List<Order>();
                Order productData = new Order();
                decimal TotalCost = 0;
                decimal AvgCost = 0;
                var parameters = new List<IDbDataParameter>();

                parameters.Add(DatabaseHandler.CreateParameter("@p_FromDate", FromDate));
                parameters.Add(DatabaseHandler.CreateParameter("@p_ToDate", ToDate));
                parameters.Add(DatabaseHandler.CreateParameter("@p_ShopId", ShopId));
                DataSet result = DatabaseHandler.GetDataSet(Constants.GET_CUSTOMER_ORDERS, CommandType.StoredProcedure, parameters.ToArray());

                if (result.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow row in result.Tables[0].Rows)
                    {
                        Order order = new Order();
                        order.Cost = Convert.ToDecimal(row["TotalPrice"]);
                        order.OrderedDateTime = Convert.ToString(row["OrderDate"]);
                        TotalCost += order.Cost;
                        orders.Add(order);
                    }

                    AvgCost = TotalCost / result.Tables[0].Rows.Count;
                }
                if (result.Tables[1].Rows.Count > 0)
                {
                    productData.ProductName = Convert.ToString(result.Tables[1].Rows[0]["ProductName"]).ToUpper();
                    productData.TotalWeight = Convert.ToDecimal(result.Tables[1].Rows[0]["Weight"]);
                    productData.UnitType = Convert.ToString(result.Tables[1].Rows[0]["UnitType"]);
                }

                return Content(HttpStatusCode.OK, new { orders, AvgCost, productData });
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("GetOrdersReport")]
        [HttpGet]
        public IHttpActionResult GetOrdersReport(string FromDate, string ToDate)
        {
            try
            {
                List<OrderSummary> orders = new List<OrderSummary>();
                int OverallTotalOrders = 0; int AvgOrders = 0;
                decimal OverallTotalPrice = 0; decimal AvgPrice = 0;
                decimal OverallTotalWeight = 0; decimal AvgWeight = 0;
                var parameters = new List<IDbDataParameter>();

                parameters.Add(DatabaseHandler.CreateParameter("@p_FromDate", FromDate));
                parameters.Add(DatabaseHandler.CreateParameter("@p_ToDate", ToDate));
                DataSet result = DatabaseHandler.GetDataSet(Constants.GET_ORDERS_REPORT, CommandType.StoredProcedure, parameters.ToArray());

                if (result.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow row in result.Tables[0].Rows)
                    {
                        OrderSummary order = new OrderSummary();
                        order.TotalOrders = Convert.ToInt32(row["TotalOrders"]);
                        order.TotalWeight = Convert.ToDecimal(row["TotalWeight"]);
                        order.TotalPrice = Convert.ToDecimal(row["TotalPrice"]);
                        order.OrderedDate = Convert.ToString(row["OrderDate"]);
                        OverallTotalOrders += order.TotalOrders;
                        OverallTotalWeight += order.TotalWeight;
                        OverallTotalPrice += order.TotalPrice;
                        orders.Add(order);
                    }

                    AvgOrders = OverallTotalOrders / result.Tables[0].Rows.Count;
                    AvgWeight = OverallTotalWeight / result.Tables[0].Rows.Count;
                    AvgPrice = OverallTotalPrice / result.Tables[0].Rows.Count;
                }

                return Content(HttpStatusCode.OK, new { orders, AvgOrders, AvgPrice, AvgWeight });
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("GetDashboardData")]
        [HttpGet]
        public IHttpActionResult GetDashboardData()
        {
            try
            {
                int TotalOrders = 0;
                List<string> Customers = new List<string>();
                List<string> SalesOfficers = new List<string>();
                int ActiveCustomers = 0;
                int InActiveCustomers = 0;
                List<OrderSummary> Vegetables = new List<OrderSummary>();
                List<OrderSummary> DailyOrders = new List<OrderSummary>();

                DataSet result = DatabaseHandler.GetDataSet(Constants.GET_DASHBOARD_DATA, CommandType.StoredProcedure);

                if (result.Tables[0].Rows.Count > 0)
                {
                    TotalOrders = Convert.ToInt32(result.Tables[0].Rows[0]["TotalOrders"]);
                }

                if (result.Tables[1].Rows.Count > 0)
                {
                    foreach (DataRow row in result.Tables[1].Rows)
                    {
                        Customers.Add(row["ShopName"].ToString());
                    }
                }

                if (result.Tables[2].Rows.Count > 0)
                {
                    foreach (DataRow row in result.Tables[2].Rows)
                    {
                        OrderSummary order = new OrderSummary();
                        order.ProductName = Convert.ToString(row["ProductName"]);
                        order.TotalWeight = Convert.ToDecimal(row["TotalWeight"]);
                        Vegetables.Add(order);
                    }
                }

                if (result.Tables[3].Rows.Count > 0)
                {
                    foreach (DataRow row in result.Tables[3].Rows)
                    {
                        SalesOfficers.Add(row["SalesOfficer"].ToString());
                    }
                }

                if (result.Tables[4].Rows.Count > 0)
                {
                    ActiveCustomers = Convert.ToInt32(result.Tables[4].Rows[0]["ActiveCustomers"]);
                }

                if (result.Tables[5].Rows.Count > 0)
                {
                    InActiveCustomers = Convert.ToInt32(result.Tables[5].Rows[0]["InActiveCustomers"]);
                }

                if (result.Tables[6].Rows.Count > 0)
                {
                    foreach (DataRow row in result.Tables[6].Rows)
                    {
                        OrderSummary order = new OrderSummary();
                        order.TotalOrders = Convert.ToInt32(row["TotalOrders"]);
                        order.OrderedDate = Convert.ToString(row["OrderDate"]);
                        DailyOrders.Add(order);
                    }
                }

                return Content(HttpStatusCode.OK, new
                {
                    TotalOrders,
                    Customers,
                    Vegetables,
                    SalesOfficers,
                    ActiveCustomers,
                    InActiveCustomers,
                    DailyOrders
                });
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
