﻿using farmar_market_api.Common;
using farmar_market_api.DataAccess;
using farmar_market_api.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Net;
using System.Web.Http;

namespace farmar_market_api.Controllers
{
    [RoutePrefix("api/SalesOfficer")]
    public class SalesOfficerController : ApiController
    {
        [Route("GetSalesOfficersData")]
        [HttpGet]
        public IHttpActionResult GetSalesOfficersData(string FromDate, string ToDate)
        {
            try
            {
                List<SalesOfficer> salesOfficers = new List<SalesOfficer>();
                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_FromDate", FromDate));
                parameters.Add(DatabaseHandler.CreateParameter("@p_ToDate", ToDate));
                DataTable result = DatabaseHandler.GetDataTable(Constants.GET_SALES_OFFICERS_DATA, CommandType.StoredProcedure, parameters.ToArray());

                if (result.Rows.Count > 0)
                {
                    foreach (DataRow row in result.Rows)
                    {
                        SalesOfficer salesOfficer = new SalesOfficer();
                        salesOfficer.SalesOfficerName = Convert.ToString(row["SalesOfficerName"]);
                        salesOfficer.TotalOrders = Convert.ToInt32(row["TotalOrders"]);
                        salesOfficer.TotalSales = Convert.ToDecimal(row["TotalSales"]);
                        salesOfficer.RegisteredCustomers = Convert.ToInt32(row["RegisteredCustomers"]);
                        salesOfficer.ActiveCustomers = Convert.ToInt32(row["ActiveCustomers"]);
                        salesOfficer.InActiveCustomers = Convert.ToInt32(row["InActiveCustomers"]);
                        salesOfficers.Add(salesOfficer);
                    }
                }
                return Content(HttpStatusCode.OK, salesOfficers);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("GetOrderStartEndDates")]
        [HttpGet]
        public IHttpActionResult GetOrderStartEndDates()
        {
            try
            {
                SalesOfficer salesOfficer = new SalesOfficer();
                DataTable result = DatabaseHandler.GetDataTable(Constants.GET_ORDER_START_END_DATES, CommandType.StoredProcedure);

                if (result.Rows.Count > 0)
                {   
                    salesOfficer.FromDate = Convert.ToDateTime(result.Rows[0]["FromDate"]);
                    salesOfficer.ToDate = Convert.ToDateTime(result.Rows[0]["ToDate"]);
                    salesOfficer.MonthDate = Convert.ToDateTime(result.Rows[0]["MonthDate"]);
                    salesOfficer.FromDateFormat = Convert.ToString(result.Rows[0]["FromDateFormat"]);
                    salesOfficer.ToDateFormat = Convert.ToString(result.Rows[0]["ToDateFormat"]);
                    salesOfficer.ToDateYearFormat = Convert.ToString(result.Rows[0]["ToDateYearFormat"]);
                    salesOfficer.MonthDateFormat = Convert.ToString(result.Rows[0]["MonthDateFormat"]);
                }
                return Content(HttpStatusCode.OK, salesOfficer);
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
