﻿using farmar_market_api.Common;
using farmar_market_api.DataAccess;
using farmar_market_api.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Net;
using System.Web.Http;

namespace farmar_market_api.Controllers
{
    [RoutePrefix("api/Setting")]
    public class SettingController : ApiController
    {
        [Route("GetConfigData")]
        [HttpGet]
        public IHttpActionResult GetConfigData()
        {
            try
            {
                Configuration configuration = new Configuration();
                DataSet result = DatabaseHandler.GetDataSet(Constants.GET_CONFIG_DATA, CommandType.StoredProcedure);

                if (result.Tables[0].Rows.Count > 0)
                {
                    configuration.PickupAddress = Convert.ToString(result.Tables[0].Rows[0]["PickupAddress"]);
                    configuration.ContactNo1 = Convert.ToInt64(result.Tables[0].Rows[0]["ContactNo1"]);
                    configuration.ContactNo2 = Convert.ToInt64(result.Tables[0].Rows[0]["ContactNo2"]);
                    configuration.DeliveryCharges = Convert.ToDecimal(result.Tables[0].Rows[0]["DeliveryCharges"]);
                    configuration.MinOrderWeight = Convert.ToDecimal(result.Tables[0].Rows[0]["MinOrderWeight"]);
                    configuration.OrderFromTime = Convert.ToDateTime(result.Tables[0].Rows[0]["OrderFromTime"]);
                    configuration.OrderToTime = Convert.ToDateTime(result.Tables[0].Rows[0]["OrderToTime"]);
                    configuration.CancelFromTime = Convert.ToDateTime(result.Tables[0].Rows[0]["CancelFromTime"]);
                    configuration.CancelToTime = Convert.ToDateTime(result.Tables[0].Rows[0]["CancelToTime"]);
                    configuration.Interval = Convert.ToInt32(result.Tables[0].Rows[0]["DisplayInterval"]);
                    configuration.OrderMode = Convert.ToString(result.Tables[0].Rows[0]["OrderMode"]);
                    configuration.CustomMessage = Convert.ToString(result.Tables[0].Rows[0]["CustomMessage"]);
                    configuration.CurrentVersion = Convert.ToString(result.Tables[0].Rows[0]["CurrentVersion"]);
                    configuration.ServerDateTime = DateTime.Now.AddMinutes(750).ToString("yyyy-MM-ddTHH:mm:ss");
                    configuration.OrderTime = Convert.ToString(result.Tables[0].Rows[0]["OrderFromTime1"]) + " - " + Convert.ToString(result.Tables[0].Rows[0]["OrderToTime1"]);
                    configuration.CancelTime = Convert.ToString(result.Tables[0].Rows[0]["CancelFromTime1"]) + " - " + Convert.ToString(result.Tables[0].Rows[0]["CancelToTime1"]);

                    if (result.Tables[1].Rows.Count > 0)
                    {
                        string orderTime = Convert.ToString(result.Tables[1].Rows[0]["OrderFromTime"]);
                        configuration.IsOrderTime = !string.IsNullOrEmpty(orderTime) ? true : false;
                    }

                    if (result.Tables[2].Rows.Count > 0)
                    {
                        string cancelTime = Convert.ToString(result.Tables[2].Rows[0]["CancelFromTime"]);
                        configuration.IsCancelTime = !string.IsNullOrEmpty(cancelTime) ? true : false;
                    }
                }
                return Content(HttpStatusCode.OK, configuration);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("UpdateConfigData")]
        [HttpPost]
        public bool UpdateConfigData(Configuration config)
        {
            try
            {
                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_PickupAddress", config.PickupAddress));
                parameters.Add(DatabaseHandler.CreateParameter("@p_ContactNo1", config.ContactNo1));
                parameters.Add(DatabaseHandler.CreateParameter("@p_ContactNo2", config.ContactNo2));
                parameters.Add(DatabaseHandler.CreateParameter("@p_DeliveryCharges", config.DeliveryCharges));
                parameters.Add(DatabaseHandler.CreateParameter("@p_MinOrderWeight", config.MinOrderWeight));
                parameters.Add(DatabaseHandler.CreateParameter("@p_OrderFromTime", config.OrderFromTime));
                parameters.Add(DatabaseHandler.CreateParameter("@p_OrderToTime", config.OrderToTime));
                parameters.Add(DatabaseHandler.CreateParameter("@p_CancelFromTime", config.CancelFromTime));
                parameters.Add(DatabaseHandler.CreateParameter("@p_CancelToTime", config.CancelToTime));
                parameters.Add(DatabaseHandler.CreateParameter("@p_OrderMode", config.OrderMode));
                parameters.Add(DatabaseHandler.CreateParameter("@p_Interval", config.Interval));
                parameters.Add(DatabaseHandler.CreateParameter("@p_CustomMessage", config.CustomMessage));

                DatabaseHandler.Save(Constants.UPDATE_CONFIG_DATA, CommandType.StoredProcedure, parameters.ToArray());
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
