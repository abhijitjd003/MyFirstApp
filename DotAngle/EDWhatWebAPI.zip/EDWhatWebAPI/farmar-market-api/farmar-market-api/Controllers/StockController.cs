﻿using farmar_market_api.Common;
using farmar_market_api.DataAccess;
using farmar_market_api.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Net;
using System.Web.Http;

namespace farmar_market_api.Controllers
{
    [RoutePrefix("api/Stock")]
    public class StockController : ApiController
    {
        [Route("CreateStock")]
        [HttpPost]
        public bool CreateStock([FromBody]Stock stock)
        {
            bool res = false;
            try
            {
                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_StockId", stock.StockId));
                parameters.Add(DatabaseHandler.CreateParameter("@p_VendorId", stock.VendorId));
                parameters.Add(DatabaseHandler.CreateParameter("@p_ProductId", stock.ProductId));
                parameters.Add(DatabaseHandler.CreateParameter("@p_TotalWeight", stock.TotalWeight));
                parameters.Add(DatabaseHandler.CreateParameter("@p_GradeAWeight", stock.GradeAWeight));
                parameters.Add(DatabaseHandler.CreateParameter("@p_GradeBWeight", stock.GradeBWeight));
                parameters.Add(DatabaseHandler.CreateParameter("@p_DumpWeight", stock.DumpWeight));
                parameters.Add(DatabaseHandler.CreateParameter("@p_CreatedUserId", stock.CreatedUserId));
                parameters.Add(DatabaseHandler.CreateParameter("@p_CreatedDateTime", DateTime.Now.AddMinutes(750)));

                DataSet result = DatabaseHandler.GetDataSet(Constants.CREATE_STOCK, CommandType.StoredProcedure, parameters.ToArray());
                int tableIndex = stock.StockId == 0 ? 1 : 1;

                if (result.Tables[tableIndex].Rows.Count > 0)
                {
                    if (result.Tables[tableIndex].Rows[0]["Message"].ToString() == "success")
                    {
                        res = true;
                    }
                    else
                    {
                        res = false;
                    }
                }

                return res;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        [Route("RemoveStock")]
        [HttpPost]
        public bool RemoveStock(int StockId)
        {
            try
            {
                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_StockId", StockId));
                DatabaseHandler.Delete(Constants.DELETE_STOCK, CommandType.StoredProcedure,
                    parameters.ToArray());
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        [Route("GetStocks")]
        [HttpGet]
        public IHttpActionResult GetStocks()
        {
            try
            {
                List<Stock> stocks = new List<Stock>();
                DataTable result = DatabaseHandler.GetDataTable(Constants.GET_STOCKS,
                    CommandType.StoredProcedure);

                if (result.Rows.Count > 0)
                {
                    foreach (DataRow row in result.Rows)
                    {
                        Stock stock = new Stock();
                        stock.StockId = Convert.ToInt32(row["StockId"]);
                        stock.VendorId = Convert.ToInt32(row["VendorId"]);
                        stock.ProductId = Convert.ToInt32(row["ProductId"]);
                        stock.VendorName = Convert.ToString(row["VendorName"]);
                        stock.ProductName = Convert.ToString(row["ProductName"]);
                        stock.TotalWeight = Convert.ToDecimal(row["TotalWeight"]);
                        stock.GradeBWeight = Convert.ToDecimal(row["GradeBWeight"]);
                        stock.GradeAWeight = Convert.ToDecimal(row["GradeAWeight"]);
                        stock.CreatedDateTime = Convert.ToString(row["CreatedDateTime"]);
                        stock.CreatedUserId = Convert.ToString(row["CreatedUserId"]);
                        stock.DumpWeight = Convert.ToDecimal(row["DumpWeight"]);
                        stocks.Add(stock);
                    }
                }
                return Content(HttpStatusCode.OK, stocks);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("RemoveGradeAStock")]
        [HttpPost]
        public bool RemoveGradeAStock([FromBody]Stock stock)
        {
            bool res = false;
            try
            {
                var parameters = new List<IDbDataParameter>();                
                parameters.Add(DatabaseHandler.CreateParameter("@p_ProductId", stock.ProductId));
                parameters.Add(DatabaseHandler.CreateParameter("@p_TotalWeight", stock.TotalWeight));
                parameters.Add(DatabaseHandler.CreateParameter("@p_ReasonType", stock.ReasonType));
                parameters.Add(DatabaseHandler.CreateParameter("@p_CreatedUserId", stock.CreatedUserId));
                parameters.Add(DatabaseHandler.CreateParameter("@p_CreatedDateTime", DateTime.Now.AddMinutes(750)));

                DataSet result = DatabaseHandler.GetDataSet(Constants.REMOVE_GRADE_A_STOCK, CommandType.StoredProcedure, parameters.ToArray());
                int tableIndex = stock.StockId == 0 ? 1 : 0;

                if (result.Tables[tableIndex].Rows.Count > 0)
                {
                    if (result.Tables[tableIndex].Rows[0]["Message"].ToString() == "success")
                    {
                        res = true;
                    }
                    else
                    {
                        res = false;
                    }
                }

                return res;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        [Route("GetRemovedGradeAStocks")]
        [HttpGet]
        public IHttpActionResult GetRemovedGradeAStocks()
        {
            try
            {
                List<Stock> stocks = new List<Stock>();
                DataTable result = DatabaseHandler.GetDataTable(Constants.GET_REMOVED_GRADE_A_STOCKS,
                    CommandType.StoredProcedure);

                if (result.Rows.Count > 0)
                {
                    foreach (DataRow row in result.Rows)
                    {
                        Stock stock = new Stock();                       
                        stock.ProductName = Convert.ToString(row["ProductName"]);
                        stock.TotalWeight = Convert.ToDecimal(row["Weight"]);
                        stock.ReasonType = Convert.ToString(row["ReasonType"]);
                        stock.CreatedDateTime = Convert.ToString(row["RemovedDateTime"]);
                        stock.CreatedUserId = Convert.ToString(row["RemovedUserId"]);
                        stocks.Add(stock);
                    }
                }
                return Content(HttpStatusCode.OK, stocks);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("RemoveGradeBStock")]
        [HttpPost]
        public bool RemoveGradeBStock([FromBody]Stock stock)
        {
            bool res = false;
            try
            {
                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_ProductId", stock.ProductId));
                parameters.Add(DatabaseHandler.CreateParameter("@p_TotalWeight", stock.TotalWeight));
                parameters.Add(DatabaseHandler.CreateParameter("@p_BuyerName", stock.BuyerName));
                parameters.Add(DatabaseHandler.CreateParameter("@p_CreatedUserId", stock.CreatedUserId));
                parameters.Add(DatabaseHandler.CreateParameter("@p_CreatedDateTime", DateTime.Now.AddMinutes(750)));

                DataSet result = DatabaseHandler.GetDataSet(Constants.REMOVE_GRADE_B_STOCK, CommandType.StoredProcedure, parameters.ToArray());
                int tableIndex = stock.StockId == 0 ? 0 : 0;

                if (result.Tables[tableIndex].Rows.Count > 0)
                {
                    if (result.Tables[tableIndex].Rows[0]["Message"].ToString() == "success")
                    {
                        res = true;
                    }
                    else
                    {
                        res = false;
                    }
                }

                return res;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        [Route("GetRemovedGradeBStocks")]
        [HttpGet]
        public IHttpActionResult GetRemovedGradeBStocks()
        {
            try
            {
                List<Stock> stocks = new List<Stock>();
                DataTable result = DatabaseHandler.GetDataTable(Constants.GET_REMOVED_GRADE_B_STOCKS,
                    CommandType.StoredProcedure);

                if (result.Rows.Count > 0)
                {
                    foreach (DataRow row in result.Rows)
                    {
                        Stock stock = new Stock();
                        stock.ProductName = Convert.ToString(row["ProductName"]);
                        stock.TotalWeight = Convert.ToDecimal(row["Weight"]);
                        stock.BuyerName = Convert.ToString(row["BuyerName"]);
                        stock.CreatedDateTime = Convert.ToString(row["RemovedDateTime"]);
                        stock.CreatedUserId = Convert.ToString(row["RemovedUserId"]);
                        stocks.Add(stock);
                    }
                }
                return Content(HttpStatusCode.OK, stocks);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("GetGradeBStocks")]
        [HttpGet]
        public IHttpActionResult GetGradeBStocks()
        {
            try
            {
                List<Stock> stocks = new List<Stock>();
                DataTable result = DatabaseHandler.GetDataTable(Constants.GET_GRADE_B_STOCKS, CommandType.StoredProcedure);

                if (result.Rows.Count > 0)
                {
                    foreach (DataRow row in result.Rows)
                    {
                        Stock stock = new Stock();
                        stock.ProductName = Convert.ToString(row["ProductName"]);
                        stock.GradeBWeight = Convert.ToDecimal(row["GradeBStock"]);
                        stock.GradeAWeight = Convert.ToDecimal(row["TotalStock"]);
                        stock.ReasonType = Convert.ToString(row["Deactivate"]);
                        stocks.Add(stock);
                    }
                }
                return Content(HttpStatusCode.OK, stocks);
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
