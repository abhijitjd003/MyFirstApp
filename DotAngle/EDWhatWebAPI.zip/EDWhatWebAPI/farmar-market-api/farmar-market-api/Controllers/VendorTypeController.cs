﻿using farmar_market_api.Common;
using farmar_market_api.DataAccess;
using farmar_market_api.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Net;
using System.Web.Http;

namespace farmar_market_api.Controllers
{
    [RoutePrefix("api/VendorType")]
    public class VendorTypeController : ApiController
    {
        [Route("CreateVendorType")]
        [HttpPost]
        public bool CreateVendorType([FromBody]VendorType type)
        {
            bool res = false;
            try
            {
                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_TypeId", type.TypeId));
                parameters.Add(DatabaseHandler.CreateParameter("@p_TypeName", type.TypeName));
                parameters.Add(DatabaseHandler.CreateParameter("@p_Description", type.Description));
                parameters.Add(DatabaseHandler.CreateParameter("@p_Disable", type.Disable));
                parameters.Add(DatabaseHandler.CreateParameter("@p_CreatedUserId", type.CreatedUserId));
                parameters.Add(DatabaseHandler.CreateParameter("@p_CreatedDateTime", DateTime.Now.AddMinutes(750)));

                DataSet result = DatabaseHandler.GetDataSet(Constants.CREATE_VENDOR_TYPE, CommandType.StoredProcedure, parameters.ToArray());
                int tableIndex = type.TypeId == 0 ? 1 : 0;

                if (result.Tables[tableIndex].Rows.Count > 0)
                {
                    if (result.Tables[tableIndex].Rows[0]["Message"].ToString() == "success")
                    {
                        res = true;
                    }
                    else
                    {
                        res = false;
                    }
                }

                return res;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        [Route("RemoveVendorType")]
        [HttpPost]
        public bool RemoveVendorType(int TypeId)
        {
            try
            {
                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_TypeId", TypeId));
                DatabaseHandler.Delete(Constants.DELETE_VENDOR_TYPE, CommandType.StoredProcedure,
                    parameters.ToArray());
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        [Route("GetVendorTypes")]
        [HttpGet]
        public IHttpActionResult GetVendorTypes()
        {
            try
            {
                List<VendorType> types = new List<VendorType>();
                DataTable result = DatabaseHandler.GetDataTable(Constants.GET_VENDOR_TYPES,
                    CommandType.StoredProcedure);

                if (result.Rows.Count > 0)
                {
                    foreach (DataRow row in result.Rows)
                    {
                        VendorType type = new VendorType();
                        type.TypeId = Convert.ToInt32(row["TypeId"]);
                        type.TypeName = Convert.ToString(row["TypeName"]);
                        type.Description = Convert.ToString(row["Description"]);
                        type.CreatedDateTime = Convert.ToString(row["CreatedDateTime"]);
                        type.CreatedUserId = Convert.ToString(row["CreatedUserId"]);
                        type.IsDisable = Convert.ToBoolean(row["Disable"]) == true ? "YES" : "NO";
                        types.Add(type);
                    }
                }
                return Content(HttpStatusCode.OK, types);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("GetValidVendorTypes")]
        [HttpGet]
        public IHttpActionResult GetValidVendorTypes()
        {
            try
            {
                List<VendorType> types = new List<VendorType>();
                DataTable result = DatabaseHandler.GetDataTable(Constants.GET_VENDOR_TYPES,
                    CommandType.StoredProcedure);

                if (result.Rows.Count > 0)
                {   
                    DataRow[] rowsFiltered = result.Select("Disable=0");
                    foreach (DataRow row in rowsFiltered)
                    {
                        VendorType type = new VendorType();
                        type.TypeId = Convert.ToInt32(row["TypeId"]);
                        type.TypeName = Convert.ToString(row["TypeName"]);
                        types.Add(type);
                    }
                }
                return Content(HttpStatusCode.OK, types);
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
