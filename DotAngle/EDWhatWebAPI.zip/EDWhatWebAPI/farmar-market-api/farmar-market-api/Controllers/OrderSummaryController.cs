﻿using farmar_market_api.Common;
using farmar_market_api.DataAccess;
using farmar_market_api.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Net;
using System.Web.Http;

namespace farmar_market_api.Controllers
{
    [RoutePrefix("api/OrderSummary")]
    public class OrderSummaryController : ApiController
    {
        [Route("GetOrderSummary")]
        [HttpGet]
        public IHttpActionResult GetOrderSummary(string OrderedDate)
        {
            try
            {
                List<OrderSummary> orderSummary = new List<OrderSummary>();
                DataTable result = DatabaseHandler.GetDataTable(Constants.GET_ORDER_SUMMARY, CommandType.StoredProcedure);

                if (result.Rows.Count > 0)
                {
                    DataRow[] rowsFiltered = null;
                    if (!string.IsNullOrEmpty(OrderedDate))
                        rowsFiltered = result.Select("OrderedDate='" + OrderedDate + "'");
                    else
                        rowsFiltered = result.Select();
                    foreach (DataRow row in rowsFiltered)
                    {
                        OrderSummary order = new OrderSummary();
                        order.TotalVendorsOrdered = Convert.ToInt32(row["TotalVendorsOrdered"]);
                        order.TotalOrders = Convert.ToInt32(row["TotalOrders"]);
                        order.TotalPrice = Convert.ToDecimal(row["TotalPrice"]);
                        order.TotalWeight = Convert.ToDecimal(row["TotalWeight"]);
                        order.TotalPieces = Convert.ToInt32(row["TotalPieces"]);
                        order.TotalVegetables = Convert.ToInt32(row["TotalVegetables"]);
                        order.DeliveryCharges = Convert.ToDecimal(row["DeliveryCharges"]);
                        order.OrderedDate = Convert.ToString(row["OrderedDate"]);
                        orderSummary.Add(order);
                    }
                }
                return Content(HttpStatusCode.OK, orderSummary);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("GetTotalWeightPerProduct")]
        [HttpGet]
        public IHttpActionResult GetTotalWeightPerProduct(string OrderedDate, string Route)
        {
            try
            {
                List<OrderSummary> orderSummary = new List<OrderSummary>();
                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_OrderedDate", OrderedDate));
                parameters.Add(DatabaseHandler.CreateParameter("@p_Route", Route));
                DataTable result = DatabaseHandler.GetDataTable(Constants.GET_TOTAL_WEIGHT_PRODUCT, CommandType.StoredProcedure, parameters.ToArray());

                if (result.Rows.Count > 0)
                {
                    foreach (DataRow row in result.Rows)
                    {
                        OrderSummary order = new OrderSummary();
                        order.TotalWeight = Convert.ToDecimal(row["TotalWeight"]);
                        order.ProductName = Convert.ToString(row["ProductName"]);
                        order.TotalStock = Convert.ToDecimal(row["TotalStock"]);
                        order.Indent = Convert.ToDecimal(row["Indent"]);
                        order.ProductId = Convert.ToInt32(row["ProductId"]);
                        orderSummary.Add(order);
                    }
                }

                return Content(HttpStatusCode.OK, orderSummary);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("GetDisplayInterval")]
        [HttpGet]
        public IHttpActionResult GetDisplayInterval()
        {
            try
            {
                int Interval = 0;
                DataTable result = DatabaseHandler.GetDataTable(Constants.GET_INTERVAL, CommandType.StoredProcedure);

                if (result.Rows.Count > 0)
                {
                    Interval = Convert.ToInt32(result.Rows[0]["DisplayInterval"]);
                }

                return Content(HttpStatusCode.OK, Interval );
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("GetCratesDetails")]
        [HttpGet]
        public IHttpActionResult GetCratesDetails(string OrderedDate, int ProductId)
        {
            try
            {
                Decimal OverallWeight = 0;
                OrderSummary orderSummary = new OrderSummary();
                List<OrderCrates> orderCrates = new List<OrderCrates>();
                List<OrderCrates> orderBreakups = new List<OrderCrates>();
                List<OrderSummary> orderSummaries = new List<OrderSummary>();
                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_OrderedDate", OrderedDate));
                parameters.Add(DatabaseHandler.CreateParameter("@p_ProductId", ProductId));
                DataSet result = DatabaseHandler.GetDataSet(Constants.GET_CRATES_DETAILS, CommandType.StoredProcedure, parameters.ToArray());

                if (result.Tables[0].Rows.Count > 0)
                {
                    orderSummary.TotalWeight = Convert.ToDecimal(result.Tables[0].Rows[0]["TotalWeight"]);
                    orderSummary.ProductName = Convert.ToString(result.Tables[0].Rows[0]["ProductName"]);
                    orderSummary.ProductImagePath = Convert.ToString(result.Tables[0].Rows[0]["ProductImagePath"]);
                    orderSummary.Crates20 = Convert.ToInt32(result.Tables[0].Rows[0]["Crates20"]);
                    orderSummary.Crates10 = Convert.ToInt32(result.Tables[0].Rows[0]["Crates10"]);
                    orderSummary.Crates5 = Convert.ToInt32(result.Tables[0].Rows[0]["Crates5"]);
                    orderSummary.UnitType = Convert.ToString(result.Tables[0].Rows[0]["UnitType"]) == "Piece" ? "Pc" : "Kg";
                }
                if (result.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow row in result.Tables[0].Rows)
                    {
                        OrderSummary orderSum = new OrderSummary();
                        orderSum.TotalWeight = Convert.ToDecimal(row["TotalWeight"]);
                        orderSum.ProductName = Convert.ToString(row["ProductName"]);
                        orderSum.ProductId = Convert.ToInt32(row["ProductId"]);
                        orderSum.ProductImagePath = Convert.ToString(row["ProductImagePath"]);
                        orderSum.UnitType = Convert.ToString(row["UnitType"]) == "Piece" ? "Pc" : "Kg";
                        orderSummaries.Add(orderSum);
                    }
                }
                if (result.Tables[1].Rows.Count > 0)
                {
                    orderSummary.OverallWeight = Convert.ToDecimal(result.Tables[1].Rows[0]["OverallWeight"]);
                    OverallWeight = orderSummary.OverallWeight;
                }
                if (result.Tables[2].Rows.Count > 0)
                {
                    foreach (DataRow row in result.Tables[2].Rows)
                    {
                        OrderCrates orderCrate = new OrderCrates();
                        orderCrate.Weight = Convert.ToDecimal(row["Weight"]);
                        orderCrate.OrderCount = Convert.ToInt32(row["OrderCount"]);
                        orderCrates.Add(orderCrate);
                    }
                }
                if (result.Tables[3].Rows.Count > 0)
                {
                    foreach (DataRow row in result.Tables[3].Rows)
                    {
                        OrderCrates orderBreakup = new OrderCrates();
                        orderBreakup.Weight = Convert.ToDecimal(row["Weight"]);
                        orderBreakup.OrderCount = Convert.ToInt32(row["OrderCount"]);
                        orderBreakup.ProductId = Convert.ToInt32(row["ProductId"]);
                        orderBreakups.Add(orderBreakup);
                    }
                }
                return Content(HttpStatusCode.OK, new { orderSummary, orderCrates, orderSummaries, OverallWeight, orderBreakups });
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("GetProductSummary")]
        [HttpGet]
        public IHttpActionResult GetProductSummary(string OrderedDate, int ProductId)
        {
            try
            {
                List<Order> orders = new List<Order>();

                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_OrderedDate", OrderedDate));
                parameters.Add(DatabaseHandler.CreateParameter("@p_ProductId", ProductId));
                DataTable result = DatabaseHandler.GetDataTable(Constants.GET_PRODUCT_SUMMARY, CommandType.StoredProcedure, parameters.ToArray());

                if (result.Rows.Count > 0)
                {
                    foreach (DataRow row in result.Rows)
                    {
                        Order order = new Order();
                        order.ShopName = Convert.ToString(row["ShopName"]);
                        order.TotalWeight = Convert.ToDecimal(row["Weight"]);
                        orders.Add(order);
                    }
                }

                return Content(HttpStatusCode.OK, orders);
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
