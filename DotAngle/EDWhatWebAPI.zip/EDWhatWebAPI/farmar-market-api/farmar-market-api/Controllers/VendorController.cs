﻿using farmar_market_api.Common;
using farmar_market_api.DataAccess;
using farmar_market_api.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Net;
using System.Web.Http;

namespace farmar_market_api.Controllers
{
    [RoutePrefix("api/Vendor")]
    public class VendorController : ApiController
    {
        [Route("CreateVendor")]
        [HttpPost]
        public bool CreateVendor([FromBody]Vendor vendor)
        {
            bool res = false;
            try
            {
                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_VendorId", vendor.VendorId));
                parameters.Add(DatabaseHandler.CreateParameter("@p_TypeId", vendor.TypeId));
                parameters.Add(DatabaseHandler.CreateParameter("@p_ContactName", vendor.ContactName));
                parameters.Add(DatabaseHandler.CreateParameter("@p_MobileNo", vendor.MobileNo));
                parameters.Add(DatabaseHandler.CreateParameter("@p_Address", vendor.Address));
                parameters.Add(DatabaseHandler.CreateParameter("@p_Disable", vendor.Disable));
                parameters.Add(DatabaseHandler.CreateParameter("@p_CreatedUserId", vendor.CreatedUserId));
                parameters.Add(DatabaseHandler.CreateParameter("@p_CreatedDateTime", DateTime.Now.AddMinutes(750)));

                DataSet result = DatabaseHandler.GetDataSet(Constants.CREATE_VENDOR, CommandType.StoredProcedure, parameters.ToArray());
                int tableIndex = vendor.VendorId == 0 ? 1 : 0;

                if (result.Tables[tableIndex].Rows.Count > 0)
                {
                    if (result.Tables[tableIndex].Rows[0]["Message"].ToString() == "success")
                    {
                        res = true;
                    }
                    else
                    {
                        res = false;
                    }
                }

                return res;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        [Route("RemoveVendor")]
        [HttpPost]
        public bool RemoveVendor(int VendorId)
        {
            try
            {
                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_VendorId", VendorId));
                DatabaseHandler.Delete(Constants.DELETE_VENDOR, CommandType.StoredProcedure,
                    parameters.ToArray());
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        [Route("GetVendors")]
        [HttpGet]
        public IHttpActionResult GetVendors()
        {
            try
            {
                List<Vendor> vendors = new List<Vendor>();
                DataTable result = DatabaseHandler.GetDataTable(Constants.GET_VENDORS,
                    CommandType.StoredProcedure);

                if (result.Rows.Count > 0)
                {
                    foreach (DataRow row in result.Rows)
                    {
                        Vendor vendor = new Vendor();
                        vendor.VendorId = Convert.ToInt32(row["VendorId"]);
                        vendor.TypeId = Convert.ToInt32(row["TypeId"]);
                        vendor.TypeName = Convert.ToString(row["TypeName"]);
                        vendor.ContactName = Convert.ToString(row["ContactName"]);
                        vendor.MobileNo = Convert.ToInt64(row["MobileNo"]);
                        vendor.Address = Convert.ToString(row["Address"]);
                        vendor.CreatedDateTime = Convert.ToString(row["CreatedDateTime"]);
                        vendor.CreatedUserId = Convert.ToString(row["CreatedUserId"]);
                        vendor.IsDisable = Convert.ToBoolean(row["Disable"]) == true ? "YES" : "NO";
                        vendors.Add(vendor);
                    }
                }
                return Content(HttpStatusCode.OK, vendors);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("GetValidVendors")]
        [HttpGet]
        public IHttpActionResult GetValidVendors()
        {
            try
            {
                List<Vendor> vendors = new List<Vendor>();
                DataTable result = DatabaseHandler.GetDataTable(Constants.GET_VENDORS,
                    CommandType.StoredProcedure);

                if (result.Rows.Count > 0)
                {
                    DataRow[] rowsFiltered = result.Select("Disable=0");
                    foreach (DataRow row in rowsFiltered)
                    {
                        Vendor vendor = new Vendor();
                        vendor.VendorId = Convert.ToInt32(row["VendorId"]);                        
                        vendor.ContactName = Convert.ToString(row["ContactName"]);
                        vendors.Add(vendor);
                    }
                }
                return Content(HttpStatusCode.OK, vendors);
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
