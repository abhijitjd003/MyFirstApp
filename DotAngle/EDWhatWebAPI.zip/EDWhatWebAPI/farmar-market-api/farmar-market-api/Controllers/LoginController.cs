﻿using farmar_market_api.Common;
using farmar_market_api.DataAccess;
using farmar_market_api.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Net;
using System.Web.Http;

namespace farmar_market_api.Controllers
{
    [RoutePrefix("api/Login")]
    public class LoginController : ApiController
    {
        [Route("ValidateLoginCustomer")]
        [HttpPost]
        public IHttpActionResult ValidateLoginCustomer([FromBody]User user)
        {
            try
            {
                Customer customer = new Customer();
                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_MobileNo", user.MobileNo));
                DataSet result = DatabaseHandler.GetDataSet(Constants.VALIDATE_LOGIN_CUSTOMER,
                    CommandType.StoredProcedure, parameters.ToArray());

                if (result.Tables[0].Rows.Count > 0)
                {
                    customer.ShopId = Convert.ToInt32(result.Tables[0].Rows[0]["ShopId"]);
                    customer.ShopName = Convert.ToString(result.Tables[0].Rows[0]["ShopName"]);
                    customer.PinCode = Convert.ToInt64(result.Tables[0].Rows[0]["PinCode"]);
                    customer.Address = Convert.ToString(result.Tables[0].Rows[0]["Address"]);
                    customer.GSTNo = Convert.ToString(result.Tables[0].Rows[0]["GSTNo"]);
                    customer.ReferralCode = Convert.ToString(result.Tables[0].Rows[0]["ReferralCode"]);
                    customer.MobileNo = Convert.ToInt64(result.Tables[0].Rows[0]["MobileNo"]);
                    customer.Location = Convert.ToString(result.Tables[0].Rows[0]["Location"]);
                    customer.ContactPerson = Convert.ToString(result.Tables[0].Rows[0]["ContactPerson"]);

                    if (result.Tables[1].Rows.Count > 0)
                    {
                        List<CustomerImages> images = new List<CustomerImages>();
                        foreach (DataRow dr in result.Tables[1].Rows)
                        {
                            CustomerImages image = new CustomerImages();
                            image.FileBase64String = Convert.ToString(dr["Image1"]);
                            string[] image1 = image.FileBase64String.Split('/');
                            image.FileID = Convert.ToString(image1[6].Replace("Cust_", "").Replace(".jpg", ""));
                            images.Add(image);
                        }
                        customer.ShopImages = images;
                    }
                    customer.Status = Convert.ToString(result.Tables[0].Rows[0]["Status"]);
                    customer.RejectedReason = Convert.ToString(result.Tables[0].Rows[0]["RejectedReason"]);
                }
                return Content(HttpStatusCode.OK, customer);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("SendOTP")]
        [HttpPost]
        public bool SendOTP([FromBody]User user)
        {
            try
            {
                string message = SMSMessage.OTP_MSG.Replace("(otp_number)", user.OTP.ToString());
                SMSService.SendSMS(user.MobileNo.ToString(), message);

                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_MobileNo", user.MobileNo));
                parameters.Add(DatabaseHandler.CreateParameter("@p_OTP", user.OTP));
                DatabaseHandler.Save(Constants.ADD_CUSTOMER_OTP, CommandType.StoredProcedure, parameters.ToArray());

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        [Route("GetCustomersOTP")]
        [HttpGet]
        public IHttpActionResult GetCustomersOTP()
        {
            try
            {
                List<User> users = new List<User>();
                DataTable result = DatabaseHandler.GetDataTable(Constants.GET_CUSTOMERS_OTP,
                    CommandType.StoredProcedure);

                if (result.Rows.Count > 0)
                {
                    foreach (DataRow row in result.Rows)
                    {
                        User user = new User();
                        user.OTP = Convert.ToInt32(row["OTP"]);
                        user.MobileNo = Convert.ToInt64(row["MobileNo"]);
                        user.RequestedDateTime = Convert.ToString(row["RequestedDateTime"]);
                        users.Add(user);
                    }
                }
                return Content(HttpStatusCode.OK, users);
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
