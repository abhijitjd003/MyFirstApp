﻿using farmar_market_api.Common;
using farmar_market_api.DataAccess;
using farmar_market_api.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Net;
using System.Web.Http;

namespace farmar_market_api.Controllers
{
    [RoutePrefix("api/Category")]
    public class CategoryController : ApiController
    {
        [Route("CreateCategory")]
        [HttpPost]
        public bool CreateCategory([FromBody]ProductCategory category)
        {
            bool res = false;
            try
            {
                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_CategoryId", category.CategoryId));
                parameters.Add(DatabaseHandler.CreateParameter("@p_CategoryName", category.CategoryName));
                parameters.Add(DatabaseHandler.CreateParameter("@p_Deactivate", category.Deactivate));
                parameters.Add(DatabaseHandler.CreateParameter("@p_UserId", category.UserId));
                parameters.Add(DatabaseHandler.CreateParameter("@p_CreatedDateTime", DateTime.Now.AddMinutes(750)));

                DataSet result = DatabaseHandler.GetDataSet(Constants.CREATE_PRODUCT_CATEGORY, CommandType.StoredProcedure,
                    parameters.ToArray());
                int tableIndex = category.CategoryId == 0 ? 1 : 0;

                if (result.Tables[tableIndex].Rows.Count > 0)
                {
                    if (result.Tables[tableIndex].Rows[0]["Message"].ToString() == "success")
                    {
                        res = true;
                    }
                    else
                    {
                        res = false;
                    }
                }

                return res;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        [Route("RemoveCategory")]
        [HttpPost]
        public bool RemoveCategory(int CategoryId)
        {
            try
            {
                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_CategoryId", CategoryId));
                DatabaseHandler.Delete(Constants.DELETE_PRODUCT_CATEGORY, CommandType.StoredProcedure,
                    parameters.ToArray());
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        [Route("GetCategories")]
        [HttpGet]
        public IHttpActionResult GetCategories()
        {
            try
            {
                List<ProductCategory> categories = new List<ProductCategory>();
                DataTable result = DatabaseHandler.GetDataTable(Constants.GET_CATEGORIES,
                    CommandType.StoredProcedure);

                if (result.Rows.Count > 0)
                {
                    foreach (DataRow row in result.Rows)
                    {
                        ProductCategory category = new ProductCategory();                        
                        category.CategoryId = Convert.ToInt32(row["CategoryId"]);
                        category.CategoryName = Convert.ToString(row["Name"]);                        
                        category.CreatedDate = Convert.ToString(row["CreatedDateTime"]);
                        category.UserId = Convert.ToString(row["CreatedUserId"]);
                        category.IsDeactivate = Convert.ToBoolean(row["Deactivate"]) == true ? "YES" : "NO";
                        categories.Add(category);
                    }
                }
                return Content(HttpStatusCode.OK, categories);
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
