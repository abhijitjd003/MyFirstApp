﻿using EDWhatCoreAPI.Constants;
using farmar_market_api.DataAccess;
using EDWhatCoreAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Web.Http;

namespace farmar_market_api.Controllers
{
    [RoutePrefix("api/TopicReport")]
    public class TopicReportController : ApiController
    {
        [HttpGet]
        [Route("GetTopicReportOptions")]
        public IHttpActionResult GetTopicReportOptions()
        {
            List<string> rptOptions = new List<string>();
            DataTable table = DatabaseHandler.GetDataTable(SPName.GET_USER_TOPIC_RPT_OPTNS,
                CommandType.StoredProcedure);

            if (table.Rows.Count > 0)
            {
                foreach (DataRow dr in table.Rows)
                {
                    rptOptions.Add(dr["TOPIC_RPT_OPTN_NM"].ToString());
                }
            }

            return Ok(rptOptions);
        }
    }
}
