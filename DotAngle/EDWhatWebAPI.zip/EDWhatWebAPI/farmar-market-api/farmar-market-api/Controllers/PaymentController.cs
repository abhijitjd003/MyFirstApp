﻿using farmar_market_api.Common;
using farmar_market_api.DataAccess;
using farmar_market_api.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Net;
using System.Web.Http;

namespace farmar_market_api.Controllers
{
    [RoutePrefix("api/Payment")]
    public class PaymentController : ApiController
    {
        [Route("GetPayments")]
        [HttpGet]
        public IHttpActionResult GetPayments(int ShopId, string OrderedDate, string Status)
        {
            try
            {
                List<Payment> payments = new List<Payment>();
                decimal TotalPrice = 0, TotalOutstanding = 0;
                var parameters = new List<IDbDataParameter>();

                parameters.Add(DatabaseHandler.CreateParameter("@p_ShopId", ShopId));
                parameters.Add(DatabaseHandler.CreateParameter("@p_OrderedDate", OrderedDate));
                parameters.Add(DatabaseHandler.CreateParameter("@p_Status", Status));
                DataSet result = DatabaseHandler.GetDataSet(Constants.GET_PAYMENTS, CommandType.StoredProcedure, parameters.ToArray());

                if (result.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow row in result.Tables[0].Rows)
                    {
                        Payment payment = new Payment();
                        payment.OrderNo = Convert.ToInt64(row["OrderNo"]);
                        payment.ShopName = Convert.ToString(row["ShopName"]);
                        payment.PaymentStatus = Convert.ToString(row["PaymentStatus"]);
                        payment.Price = Convert.ToDecimal(row["Price"]);
                        payment.Received = Convert.ToDecimal(row["Received"]);
                        payment.Outstanding = Convert.ToDecimal(row["Outstanding"]); 
                        payment.DeliveryCharges = Convert.ToDecimal(row["DeliveryCharges"]);
                        payments.Add(payment);
                    }
                }
                if (result.Tables[1].Rows.Count > 0)
                {
                    TotalPrice = Convert.ToDecimal(result.Tables[1].Rows[0]["TotalPrice"]);
                }
                if (result.Tables[2].Rows.Count > 0)
                {
                    TotalOutstanding = Convert.ToDecimal(result.Tables[2].Rows[0]["TotalOutstanding"]);
                }

                return Content(HttpStatusCode.OK, new { payments, TotalPrice, TotalOutstanding });
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("UpdatePayment")]
        [HttpPost]
        public bool UpdatePayment(Payment payment)
        {
            try
            {
                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_PaymentStatus", payment.PaymentStatus));
                parameters.Add(DatabaseHandler.CreateParameter("@p_OrderNo", payment.OrderNo));
                parameters.Add(DatabaseHandler.CreateParameter("@p_Received", payment.Received));
                DatabaseHandler.Save(Constants.UPDATE_PAYMENT, CommandType.StoredProcedure,
                    parameters.ToArray());
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
