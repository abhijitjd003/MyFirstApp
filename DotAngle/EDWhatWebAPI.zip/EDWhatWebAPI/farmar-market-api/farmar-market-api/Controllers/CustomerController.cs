﻿using farmar_market_api.Common;
using farmar_market_api.DataAccess;
using farmar_market_api.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Net;
using System.Web.Http;

namespace farmar_market_api.Controllers
{
    [RoutePrefix("api/Customer")]
    public class CustomerController : ApiController
    {
        [Route("AddCustomer")]
        [HttpPost]
        public IHttpActionResult AddCustomer([FromBody]Customer customer)
        {
            bool res = false; int row = 0; int deleteRow = 0;
            string shopImage1 = "", shopImage2 = "", shopImage3 = "";
            string fileId1 = "", fileId2 = "", fileId3 = "";
            string Server = FTPServer.Server;

            try
            {
                foreach (CustomerImages shop in customer.ShopImages)
                {
                    if (shop != null)
                    {
                        if (!string.IsNullOrEmpty(shop.FileName) && shop.FileBase64String.ToLower() != "deleted")
                        {
                            string shopImage = string.Format("{0}/{1}/{2}/{3}/{4}", Server.Replace("ftp://", "https://"), "UploadedFiles", "Vendors", "shop_id", shop.FileName);

                            switch (row)
                            {
                                case 0:
                                    shopImage1 = shopImage;
                                    break;
                                case 1:
                                    shopImage2 = shopImage;
                                    break;
                                case 2:
                                    shopImage3 = shopImage;
                                    break;
                            }
                        }
                    }
                    row++;
                }

                foreach (CustomerImages shop in customer.ShopImages)
                {
                    if (shop != null)
                    {
                        if (shop.FileBase64String.ToLower() == "deleted" && customer.ShopId > 0)
                        {
                            string basePath = string.Format("{0}/{1}/{2}/{3}/{4}", Server.Replace("ftp://", "https://"), "UploadedFiles", "Vendors", customer.ShopId, "Cust_" + shop.FileID + ".jpg");

                            switch (deleteRow)
                            {
                                case 0:
                                    fileId1 = basePath;
                                    break;
                                case 1:
                                    fileId2 = basePath;
                                    break;
                                case 2:
                                    fileId3 = basePath;
                                    break;
                            }
                        }
                    }
                    deleteRow++;
                }

                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_ShopId", customer.ShopId));
                parameters.Add(DatabaseHandler.CreateParameter("@p_ShopName", customer.ShopName));
                parameters.Add(DatabaseHandler.CreateParameter("@p_PinCode", customer.PinCode));
                parameters.Add(DatabaseHandler.CreateParameter("@p_ContactPerson", customer.ContactPerson));
                parameters.Add(DatabaseHandler.CreateParameter("@p_MobileNo", customer.MobileNo));
                parameters.Add(DatabaseHandler.CreateParameter("@p_Email", customer.Email));
                parameters.Add(DatabaseHandler.CreateParameter("@p_Address", customer.Address));
                parameters.Add(DatabaseHandler.CreateParameter("@p_Location", customer.Location));
                parameters.Add(DatabaseHandler.CreateParameter("@p_GSTNo", customer.GSTNo));
                parameters.Add(DatabaseHandler.CreateParameter("@p_ReferralCode", customer.ReferralCode));
                parameters.Add(DatabaseHandler.CreateParameter("@p_AlternateContactNo", customer.AlternateContactNo));
                parameters.Add(DatabaseHandler.CreateParameter("@p_CreatedDateTime", DateTime.Now.AddMinutes(750)));
                parameters.Add(DatabaseHandler.CreateParameter("@p_UpdatedDateTime", DateTime.Now.AddMinutes(750)));
                parameters.Add(DatabaseHandler.CreateParameter("@p_UserId", customer.UserId));
                parameters.Add(DatabaseHandler.CreateParameter("@p_ShopImage1", shopImage1));
                parameters.Add(DatabaseHandler.CreateParameter("@p_ShopImage2", shopImage2));
                parameters.Add(DatabaseHandler.CreateParameter("@p_ShopImage3", shopImage3));
                parameters.Add(DatabaseHandler.CreateParameter("@p_FileId1", fileId1));
                parameters.Add(DatabaseHandler.CreateParameter("@p_FileId2", fileId2));
                parameters.Add(DatabaseHandler.CreateParameter("@p_FileId3", fileId3));
                parameters.Add(DatabaseHandler.CreateParameter("@p_DeviceId", customer.DeviceId));

                DataSet result = DatabaseHandler.GetDataSet(Constants.ADD_CUSTOMER, CommandType.StoredProcedure, parameters.ToArray());

                if (customer.ShopId > 0 && customer.ShopImages.Count > 0)
                {
                    foreach (CustomerImages image in customer.ShopImages)
                    {
                        if (image != null)
                        {
                            if (image.FileBase64String.ToLower() == "deleted")
                            {
                                foreach (DataRow iRow in result.Tables[0].Rows)
                                {
                                    if (!string.IsNullOrEmpty(iRow["Image1"].ToString()) && iRow["Image1"].ToString().Contains(image.FileID.ToString()))
                                    {
                                        FTPServer.DeleteFileFromFTPServer(iRow["Image1"].ToString().Replace("https://", "ftp://"));
                                    }
                                }
                            }
                        }
                    }
                }

                int tableIndex = customer.ShopId == 0 ? 1 : 1;
                string shopId = "";
                if (customer.ShopId > 0)
                    shopId = customer.ShopId.ToString();
                else
                    shopId = result.Tables[tableIndex].Rows[0]["ShopId"].ToString();

                foreach (CustomerImages shop in customer.ShopImages)
                {
                    if (shop != null)
                    {
                        if (!string.IsNullOrEmpty(shop.FileBase64String) && shop.FileBase64String.ToLower() != "deleted")
                        {
                            byte[] bytes = Convert.FromBase64String(shop.FileBase64String.Replace("data:image/jpeg;base64,", ""));
                            string createdDirectory = string.Empty;

                            string[] directories = new string[] { "UploadedFiles", "Vendors", shopId };
                            if (FTPServer.CreateFTPDirectory(directories, out createdDirectory))
                            {
                                FTPServer.UploadFTPFile(shop.FileName, bytes, createdDirectory);
                            }
                        }
                    }
                }

                if (result.Tables[tableIndex].Rows.Count > 0)
                {
                    if (result.Tables[tableIndex].Rows[0]["Message"].ToString() == "success")
                    {
                        res = true;
                    }
                    else
                    {
                        res = false;
                    }
                }

                return Content(HttpStatusCode.OK, res);
            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.OK, ex.Message);
            }
        }

        [Route("ApproveRejectDisableCustomer")]
        [HttpPost]
        public bool ApproveRejectDisableCustomer(CustomerApproval customerApproval)
        {
            try
            {
                foreach (int ShopId in customerApproval.ShopIds)
                {
                    var parameters = new List<IDbDataParameter>();
                    parameters.Add(DatabaseHandler.CreateParameter("@p_Status", customerApproval.Status));
                    parameters.Add(DatabaseHandler.CreateParameter("@p_UpdatedDateTime", DateTime.Now.AddMinutes(750)));
                    parameters.Add(DatabaseHandler.CreateParameter("@p_UserId", customerApproval.UserId));
                    parameters.Add(DatabaseHandler.CreateParameter("@p_ShopId", ShopId));
                    parameters.Add(DatabaseHandler.CreateParameter("@p_RejectReason", customerApproval.RejectReason));
                    DatabaseHandler.Save(Constants.APPROVE_REJECT_DISABLE_CUSTOMER, CommandType.StoredProcedure,
                        parameters.ToArray());
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        [Route("AssignRoute")]
        [HttpPost]
        public bool AssignRoute(Route route)
        {
            try
            {
                foreach (long OrderNo in route.OrderNos)
                {
                    var parameters = new List<IDbDataParameter>();
                    parameters.Add(DatabaseHandler.CreateParameter("@p_RouteCategory", route.RouteCategory));
                    parameters.Add(DatabaseHandler.CreateParameter("@p_OrderNo", OrderNo));
                    DatabaseHandler.Save(Constants.ASSIGN_ROUTE_ORDER, CommandType.StoredProcedure, parameters.ToArray());
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        [Route("GetAssignedRoutes")]
        [HttpGet]
        public IHttpActionResult GetAssignedRoutes(string OrderedDate, string RouteCategory, int CondOper)
        {
            try
            {
                List<Order> orders = new List<Order>();
                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_OrderedDate", OrderedDate));
                parameters.Add(DatabaseHandler.CreateParameter("@p_RouteCategory", RouteCategory));
                parameters.Add(DatabaseHandler.CreateParameter("@p_CondOper", CondOper));
                DataTable result = DatabaseHandler.GetDataTable(Constants.GET_ASSIGNED_ROUTES,
                    CommandType.StoredProcedure, parameters.ToArray());

                if (result.Rows.Count > 0)
                {
                    foreach (DataRow row in result.Rows)
                    {
                        Order order = new Order();
                        order.OrderNo = Convert.ToInt64(row["OrderNo"]);
                        order.PinCode = Convert.ToInt64(row["PinCode"]);
                        order.ShopName = Convert.ToString(row["ShopName"]);
                        order.Location = Convert.ToString(row["Location"]);
                        order.Route = Convert.ToString(row["Route"]);
                        order.TotalWeight = Convert.ToDecimal(row["TotalWeight"]);
                        orders.Add(order);
                    }
                }
                return Content(HttpStatusCode.OK, orders);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("GetCustomers")]
        [HttpGet]
        public IHttpActionResult GetCustomers(string Status)
        {
            try
            {
                List<Customer> customers = new List<Customer>();
                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_Status", Status));
                DataTable result = DatabaseHandler.GetDataTable(Constants.GET_CUSTOMERS,
                    CommandType.StoredProcedure, parameters.ToArray());

                if (result.Rows.Count > 0)
                {
                    foreach (DataRow row in result.Rows)
                    {
                        Customer customer = new Customer();
                        customer.ShopId = Convert.ToInt32(row["ShopId"]);
                        customer.PinCode = Convert.ToInt64(row["PinCode"]);
                        customer.ShopName = Convert.ToString(row["ShopName"]);
                        customer.Address = Convert.ToString(row["Address"]);
                        customer.GSTNo = Convert.ToString(row["GSTNo"]);
                        customer.ReferralCode = Convert.ToString(row["ReferralCode"]);
                        customer.MobileNo = Convert.ToInt64(row["MobileNo"]);
                        customer.Status = Convert.ToString(row["Status"]);
                        customer.RejectedReason = Convert.ToString(row["RejectedReason"]);
                        customer.Location = Convert.ToString(row["Location"]);
                        customer.Email = Convert.ToString(row["Email"]);
                        customer.ContactPerson = Convert.ToString(row["ContactPerson"]);
                        customer.AlternateContactNo = Convert.ToInt64(row["AlternateContactNo"]);
                        customer.UserId = Convert.ToString(row["UpdatedUserId"]);
                        customer.SalesOfficer = Convert.ToString(row["SalesOfficer"]);
                        customer.UpdatedDate = Convert.ToString(row["UpdatedDateTime"]);
                        customer.RouteCategory = Convert.ToString(row["Route"]);
                        customers.Add(customer);
                    }
                }
                return Content(HttpStatusCode.OK, customers);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("GetCustomer")]
        [HttpGet]
        public IHttpActionResult GetCustomer(int ShopId)
        {
            try
            {
                Customer customer = new Customer();
                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_ShopId", ShopId));
                DataSet result = DatabaseHandler.GetDataSet(Constants.GET_CUSTOMER,
                    CommandType.StoredProcedure, parameters.ToArray());

                if (result.Tables[2].Rows.Count > 0)
                {
                    customer.ShopId = Convert.ToInt32(result.Tables[2].Rows[0]["ShopId"]);
                    customer.ShopName = Convert.ToString(result.Tables[2].Rows[0]["ShopName"]);
                    customer.PinCode = Convert.ToInt64(result.Tables[2].Rows[0]["PinCode"]);
                    customer.Address = Convert.ToString(result.Tables[2].Rows[0]["Address"]);
                    customer.GSTNo = Convert.ToString(result.Tables[2].Rows[0]["GSTNo"]);
                    customer.ReferralCode = Convert.ToString(result.Tables[2].Rows[0]["ReferralCode"]);
                    customer.MobileNo = Convert.ToInt64(result.Tables[2].Rows[0]["MobileNo"]);
                    customer.Location = Convert.ToString(result.Tables[2].Rows[0]["Location"]);
                    customer.Email = Convert.ToString(result.Tables[2].Rows[0]["Email"]);
                    customer.ContactPerson = Convert.ToString(result.Tables[2].Rows[0]["ContactPerson"]);
                    customer.AlternateContactNo = Convert.ToInt64(result.Tables[2].Rows[0]["AlternateContactNo"]);
                    customer.LastOrderedDate = Convert.ToString(result.Tables[2].Rows[0]["LastOrderedDate"]);
                    customer.Outstanding = Convert.ToDecimal(result.Tables[2].Rows[0]["Outstanding"]);
                }
                return Content(HttpStatusCode.OK, customer);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("GetRoutes")]
        [HttpGet]
        public IHttpActionResult GetRoutes()
        {
            try
            {
                List<Route> routes = new List<Route>();
                DataTable result = DatabaseHandler.GetDataTable(Constants.GET_ROUTES,
                    CommandType.StoredProcedure);

                if (result.Rows.Count > 0)
                {
                    foreach (DataRow row in result.Rows)
                    {
                        Route route = new Route();
                        route.RouteCategory = Convert.ToString(row["RouteCategory"]);
                        route.RouteName = Convert.ToString(row["Route"]);
                        routes.Add(route);
                    }
                }
                return Content(HttpStatusCode.OK, routes);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("GetSalesOfficers")]
        [HttpGet]
        public IHttpActionResult GetSalesOfficers()
        {
            try
            {
                List<User> users = new List<User>();
                DataTable result = DatabaseHandler.GetDataTable(Constants.GET_SALES_OFFICERS,
                    CommandType.StoredProcedure);

                if (result.Rows.Count > 0)
                {
                    foreach (DataRow row in result.Rows)
                    {
                        User user = new User();
                        user.FullName = Convert.ToString(row["FullName"]);
                        users.Add(user);
                    }
                }
                return Content(HttpStatusCode.OK, users);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("GetShopImages")]
        [HttpGet]
        public IHttpActionResult GetShopImages(int ShopId)
        {
            try
            {
                List<ShopImages> shopImages = new List<ShopImages>();
                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_ShopId", ShopId));
                DataTable result = DatabaseHandler.GetDataTable(Constants.GET_SHOP_IMAGES,
                    CommandType.StoredProcedure, parameters.ToArray());

                if (result.Rows.Count > 0)
                {
                    foreach (DataRow row in result.Rows)
                    {
                        ShopImages image = new ShopImages();
                        image.url = Convert.ToString(row["Image1"]);
                        shopImages.Add(image);
                    }
                }
                return Content(HttpStatusCode.OK, shopImages);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("AssignSalesOfficer")]
        [HttpPost]
        public bool AssignSalesOfficer(User user)
        {
            try
            {
                foreach (long ShopId in user.ShopIds)
                {
                    var parameters = new List<IDbDataParameter>();
                    parameters.Add(DatabaseHandler.CreateParameter("@p_SalesOfficer", user.FullName));
                    parameters.Add(DatabaseHandler.CreateParameter("@p_ShopId", ShopId));
                    DatabaseHandler.Save(Constants.ASSIGN_SALES_OFFICER, CommandType.StoredProcedure, parameters.ToArray());
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        [Route("StoreDevice")]
        [HttpPost]
        public void StoreDevice([FromBody]User user)
        {
            try
            {
                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_MobileNo", user.MobileNo));
                parameters.Add(DatabaseHandler.CreateParameter("@p_DeviceId", user.DeviceId));
                DataSet result = DatabaseHandler.GetDataSet(Constants.STORE_DEVICE,
                    CommandType.StoredProcedure, parameters.ToArray());
            }
            catch (Exception ex)
            {

            }
        }
    }
}
