﻿using farmar_market_api.Common;
using farmar_market_api.DataAccess;
using farmar_market_api.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Net;
using System.Text;
using System.Web.Http;

namespace farmar_market_api.Controllers
{
    [RoutePrefix("api/Order")]
    public class OrderController : ApiController
    {
        [Route("GetOrders")]
        [HttpGet]
        public IHttpActionResult GetOrders(int ShopId, string OrderedDate)
        {
            try
            {
                List<Order> orders = new List<Order>();
                decimal TotalPrice = 0, TotalOutstanding = 0;
                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_ShopId", ShopId));
                DataSet result = DatabaseHandler.GetDataSet(Constants.GET_ORDERS, CommandType.StoredProcedure, parameters.ToArray());

                if (result.Tables[0].Rows.Count > 0)
                {
                    DataRow[] rowsFiltered = null;
                    if (!string.IsNullOrEmpty(OrderedDate))
                        rowsFiltered = result.Tables[0].Select("OrderedDate='" + OrderedDate + "'");
                    else
                        rowsFiltered = result.Tables[0].Select();

                    foreach (DataRow row in rowsFiltered)
                    {
                        Order order = new Order();
                        order.OrderNo = Convert.ToInt64(row["OrderNo"]);
                        order.ShopName = Convert.ToString(row["ShopName"]);
                        order.ReferralCode = Convert.ToString(row["ReferralCode"]);
                        order.ShopId = Convert.ToInt32(row["ShopId"]);
                        order.TotalPrice = Convert.ToDecimal(row["TotalPrice"]);
                        order.TotalWeight = Convert.ToDecimal(row["TotalWeight"]);
                        order.TotalPiece = Convert.ToDecimal(row["TotalPieces"]);
                        order.OrderMode = Convert.ToString(row["OrderMode"]);
                        order.PassCode = Convert.ToInt32(row["PassCode"]);
                        order.Status = Convert.ToString(row["Status"]);
                        order.OrderedDateTime = Convert.ToString(row["OrderedDateTime"]);
                        order.DeliveryDate = Convert.ToString(row["DeliveryDate"]);
                        order.DeliveryTime = Convert.ToString(row["DeliveryTime"]);
                        order.DeliveryUser = Convert.ToString(row["DeliveryUser"]);
                        order.PaymentStatus = Convert.ToString(row["PaymentStatus"]);
                        order.UserId = Convert.ToString(row["UpdatedUserId"]);
                        order.PinCode = Convert.ToInt64(row["PinCode"]);
                        order.Location = Convert.ToString(row["Location"]);
                        order.Route = Convert.ToString(row["Route"]);
                        orders.Add(order);
                    }
                }

                if (result.Tables[1].Rows.Count > 0)
                {
                    TotalPrice = Convert.ToDecimal(result.Tables[1].Rows[0]["TotalPrice"]);
                }
                if (result.Tables[2].Rows.Count > 0)
                {
                    TotalOutstanding = Convert.ToDecimal(result.Tables[2].Rows[0]["TotalOutstanding"]);
                }
                return Content(HttpStatusCode.OK, new { orders, TotalPrice, TotalOutstanding });
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("UpdateOrder")]
        [HttpPost]
        public bool UpdateOrder(Order order)
        {
            try
            {
                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_Status", order.Status));
                parameters.Add(DatabaseHandler.CreateParameter("@p_OrderNo", order.OrderNo));
                parameters.Add(DatabaseHandler.CreateParameter("@p_DeliveryUserId", order.DeliveryUserId));
                parameters.Add(DatabaseHandler.CreateParameter("@p_DeliveredDate", order.DeliveredDate));
                parameters.Add(DatabaseHandler.CreateParameter("@p_DeliveryTime", order.DeliveryTime));
                parameters.Add(DatabaseHandler.CreateParameter("@p_OrderMode", order.OrderMode));
                DatabaseHandler.Save(Constants.UPDATE_ORDER, CommandType.StoredProcedure,
                    parameters.ToArray());
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        [Route("CreateOrders")]
        [HttpPost]
        public IHttpActionResult CreateOrders(Order order)
        {
            try
            {
                Random random = new Random();
                order.OrderNo = random.Next(100000000, 999999999);
                order.PassCode = random.Next(100000, 999999);

                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_OrderNo", order.OrderNo));
                parameters.Add(DatabaseHandler.CreateParameter("@p_PassCode", order.PassCode));
                parameters.Add(DatabaseHandler.CreateParameter("@p_OrderedDateTime", DateTime.Now.AddMinutes(750)));
                parameters.Add(DatabaseHandler.CreateParameter("@p_ShopId", order.ShopId));
                parameters.Add(DatabaseHandler.CreateParameter("@p_UserId", order.UserId));
                parameters.Add(DatabaseHandler.CreateParameter("@p_OrderMode", order.OrderMode));

                DataTable result = DatabaseHandler.GetDataTable(Constants.CREATE_ORDERS, CommandType.StoredProcedure, parameters.ToArray());
                order.OrderNo = Convert.ToInt64(result.Rows[0]["OrderNo"]);
                AddProducts(order);

                var parameters1 = new List<IDbDataParameter>();
                parameters1.Add(DatabaseHandler.CreateParameter("@p_OrderNo", order.OrderNo));
                parameters1.Add(DatabaseHandler.CreateParameter("@p_CondOper", 2));
                DatabaseHandler.Save(Constants.UPDATE_PRODUCTS_STOCK, CommandType.StoredProcedure, parameters1.ToArray());

                DateTime DeliveryDate = Convert.ToDateTime(result.Rows[0]["DeliveryDate"]);
                long mobileNo = Convert.ToInt64(result.Rows[0]["MobileNo"]);

                if (!string.IsNullOrEmpty(mobileNo.ToString()))
                {
                    string message = SMSMessage.ORDER_CREATE_MSG.Replace("(order_no)", order.OrderNo.ToString());
                    SMSService.SendSMS(mobileNo.ToString(), message);
                }

                return Content(HttpStatusCode.OK, new { order.OrderNo, DeliveryDate });
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("UpdateCreatedOrders")]
        [HttpPost]
        public IHttpActionResult UpdateCreatedOrders(Order order)
        {
            try
            {
                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_OrderNo", order.OrderNo));
                parameters.Add(DatabaseHandler.CreateParameter("@p_OrderMode", order.OrderMode));
                parameters.Add(DatabaseHandler.CreateParameter("@p_UserId", order.UserId));
                parameters.Add(DatabaseHandler.CreateParameter("@p_UpdatedDateTime", DateTime.Now.AddMinutes(750)));
                DataTable result = DatabaseHandler.GetDataTable(Constants.UPDATE_CREATED_ORDERS, CommandType.StoredProcedure, parameters.ToArray());
                AddProducts(order);

                var parameters1 = new List<IDbDataParameter>();
                parameters1.Add(DatabaseHandler.CreateParameter("@p_OrderNo", order.OrderNo));
                parameters1.Add(DatabaseHandler.CreateParameter("@p_CondOper", 1));
                DatabaseHandler.Save(Constants.UPDATE_PRODUCTS_STOCK, CommandType.StoredProcedure, parameters1.ToArray());

                DateTime DeliveryDate = Convert.ToDateTime(result.Rows[0]["DeliveryDate"]);
                long mobileNo = Convert.ToInt64(result.Rows[0]["MobileNo"]);

                if (!string.IsNullOrEmpty(mobileNo.ToString()))
                {
                    string message = SMSMessage.ORDER_UPDATE_MSG.Replace("(order_no)", order.OrderNo.ToString());
                    SMSService.SendSMS(mobileNo.ToString(), message);
                }

                return Content(HttpStatusCode.OK, new { order.OrderNo, DeliveryDate });
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        private void AddProducts(Order order)
        {
            List<string> orderProducts = new List<string>();
            StringBuilder commandOrderProducts = new StringBuilder
            (
                "Insert Into OrderProducts (OrderNo, PricePerKg, Weight, ProductId) Values "
            );

            foreach (Product product in order.Products)
            {
                if (product.Quantity > 0)
                {
                    int ProductId = Convert.ToInt32(product.ProductId);
                    decimal PricePerKg = Convert.ToDecimal(product.RatePerKg);
                    decimal Weight = order.QuantityOne ? Convert.ToDecimal(product.Quantity) :
                        Convert.ToDecimal(product.Quantity * product.MinPurchaseQuantity);

                    orderProducts.Add(string.Format("({0},{1},{2},{3})",
                        order.OrderNo, PricePerKg, Weight, ProductId));
                }
            }

            commandOrderProducts.Append(string.Join(",", orderProducts));
            commandOrderProducts.Append(";");
            DatabaseHandler.Save(commandOrderProducts.ToString(), CommandType.Text);
        }

        [Route("GetOrderProducts")]
        [HttpGet]
        public IHttpActionResult GetOrderProducts(long OrderNo)
        {
            try
            {
                List<Order> orders = new List<Order>();
                Order orderProduct = new Order();
                Configuration orderPickup = new Configuration();
                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_OrderNo", OrderNo));
                DataSet result = DatabaseHandler.GetDataSet(Constants.GET_ORDER_PRODUCTS,
                    CommandType.StoredProcedure, parameters.ToArray());

                if (result.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow row in result.Tables[0].Rows)
                    {
                        Order order = new Order();
                        order.ProductId = Convert.ToInt32(row["ProductId"]);
                        order.ProductName = Convert.ToString(row["ProductName"]);
                        order.TotalPrice = Convert.ToDecimal(row["TotalPrice"]);
                        order.TotalWeight = Convert.ToDecimal(row["TotalWeight"]);
                        order.RatePerKg = Convert.ToDecimal(row["PricePerKg"]);
                        order.ProductImagePath = Convert.ToString(row["ProductImagePath"]);
                        order.FileName = Convert.ToString(row["ProductImagePath"]);
                        order.MinPurchaseQuantity = Convert.ToDecimal(row["MinPurchaseQuantity"]);
                        order.TotalStock = Convert.ToDecimal(row["TotalStock"]);
                        order.UnitType = Convert.ToString(row["UnitType"]) == "Piece" ? "Pc" : "Kg";
                        order.Quantity = order.TotalWeight / order.MinPurchaseQuantity;
                        order.CategoryId = Convert.ToInt32(order.Quantity);
                        orders.Add(order);
                    }
                }

                if (result.Tables[1].Rows.Count > 0)
                {
                    orderProduct.OrderNo = Convert.ToInt64(result.Tables[1].Rows[0]["OrderNo"]);
                    orderProduct.Status = Convert.ToString(result.Tables[1].Rows[0]["Status"]);
                    orderProduct.ShopName = Convert.ToString(result.Tables[1].Rows[0]["ShopName"]);
                    orderProduct.OrderMode = Convert.ToString(result.Tables[1].Rows[0]["OrderMode"]);
                    orderProduct.ContactName = Convert.ToString(result.Tables[1].Rows[0]["ContactPerson"]);
                    orderProduct.MobileNo = Convert.ToInt64(result.Tables[1].Rows[0]["MobileNo"]);
                    orderProduct.DeliveryDate = Convert.ToString(result.Tables[1].Rows[0]["DeliveryDate"]);
                    orderProduct.OrderedDateTime = Convert.ToString(result.Tables[1].Rows[0]["OrderedDateTime"]);
                    orderProduct.DeliveryTime = Convert.ToString(result.Tables[1].Rows[0]["DeliveryTime"]);
                    orderProduct.OverallTotalPrice = Convert.ToDecimal(result.Tables[1].Rows[0]["OverallTotalPrice"]);
                    orderProduct.TotalPrice = Convert.ToDecimal(result.Tables[1].Rows[0]["TotalPiecePrice"]);
                    orderProduct.OverallTotalWeight = Convert.ToDecimal(result.Tables[1].Rows[0]["OverallTotalWeight"]);
                    orderProduct.TotalPiece = Convert.ToDecimal(result.Tables[1].Rows[0]["TotalPiece"]);
                    orderProduct.DeliveryCharges = Convert.ToDecimal(result.Tables[1].Rows[0]["DeliveryCharges"]);
                    orderProduct.PaymentStatus = Convert.ToString(result.Tables[1].Rows[0]["PaymentStatus"]);
                }

                if (result.Tables[2].Rows.Count > 0)
                {
                    orderPickup.ContactNo1 = Convert.ToInt64(result.Tables[2].Rows[0]["ContactNo1"]);
                    orderPickup.ContactNo2 = Convert.ToInt64(result.Tables[2].Rows[0]["ContactNo2"]);
                    orderPickup.PickupAddress = Convert.ToString(result.Tables[2].Rows[0]["PickupAddress"]);
                    orderPickup.DeliveryCharges = Convert.ToDecimal(result.Tables[2].Rows[0]["DeliveryCharges"]);
                }

                return Content(HttpStatusCode.OK, new { orders, orderProduct, orderPickup });
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("GetDeliveryUsers")]
        [HttpGet]
        public IHttpActionResult GetDeliveryUsers()
        {
            try
            {
                List<User> users = new List<User>();
                DataTable result = DatabaseHandler.GetDataTable(Constants.GET_DELIVERY_USERS, CommandType.StoredProcedure);

                if (result.Rows.Count > 0)
                {
                    foreach (DataRow row in result.Rows)
                    {
                        User user = new User();
                        user.UserId = Convert.ToInt32(row["UserId"]);
                        user.FullName = Convert.ToString(row["FullName"]);
                        users.Add(user);
                    }
                }
                return Content(HttpStatusCode.OK, users);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("RemoveCreatedOrder")]
        [HttpPost]
        public bool RemoveCreatedOrder(long OrderNo)
        {
            bool res = false;
            try
            {
                var parameters = new List<IDbDataParameter>();
                parameters.Add(DatabaseHandler.CreateParameter("@p_OrderNo", OrderNo));
                DataSet result = DatabaseHandler.GetDataSet(Constants.REMOVE_CREATED_ORDER, CommandType.StoredProcedure, parameters.ToArray());

                if (result.Tables[1].Rows.Count > 0)
                {
                    if (result.Tables[1].Rows[0]["Message"].ToString() == "success")
                    {
                        res = true;
                    }
                    else
                    {
                        res = false;
                    }
                }
                return res;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
