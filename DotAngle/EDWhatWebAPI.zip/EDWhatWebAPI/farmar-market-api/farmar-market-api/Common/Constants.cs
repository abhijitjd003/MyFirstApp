﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace farmar_market_api.Common
{
    public static class Constants
    {
        //Login
        public const string VALIDATE_LOGIN_CUSTOMER = "UspValidateLoginCustomer";
        public const string ADD_CUSTOMER_OTP = "UspAddCustomerOTP";
        public const string GET_CUSTOMERS_OTP = "UspGetCustomersOTP";

        //Home
        public const string VALIDATE_LOGIN_USER = "UspValidateLoginUser";

        //Product
        public const string GET_PRODUCT_CATEGORIES = "UspGetProductCategories";
        public const string CREATE_PRODUCT = "UspCreateProduct";
        public const string UPDATE_PRODUCTS = "UspUpdateProducts";
        public const string GET_PRODUCTS = "UspGetProducts";
        public const string DELETE_PRODUCT = "UspDeleteProduct";                
        public const string GET_PRODUCTS_HISTORY = "UspGetProductsHistory";

        //Product Category
        public const string CREATE_PRODUCT_CATEGORY = "UspCreateProductCategory";
        public const string DELETE_PRODUCT_CATEGORY = "UspDeleteProductCategory";
        public const string GET_CATEGORIES = "UspGetCategories";

        //Customer        
        public const string ADD_CUSTOMER = "UspAddCustomer";
        public const string GET_CUSTOMERS = "UspGetCustomers";
        public const string GET_CUSTOMER = "UspGetCustomer";
        public const string GET_ROUTES = "UspGetRoutes";
        public const string APPROVE_REJECT_DISABLE_CUSTOMER = "UspApproveRejectDisableCustomer";
        public const string ASSIGN_ROUTE_ORDER = "UspAssignRouteToOrder";
        public const string GET_ASSIGNED_ROUTES = "UspGetAssignedRoutes";
        public const string GET_SALES_OFFICERS = "UspGetSalesOfficers";
        public const string ASSIGN_SALES_OFFICER = "UspAssignSalesOfficer";
        public const string STORE_DEVICE = "UspStoreDevice";
        public const string GET_SHOP_IMAGES = "UspGetShopImages";

        //Orders        
        public const string GET_ORDERS = "UspGetOrders";
        public const string GET_ORDER_PRODUCTS = "UspGetOrderProducts";
        public const string UPDATE_ORDER = "UspUpdateOrder";
        public const string UPDATE_CREATED_ORDERS = "UspUpdateCreatedOrders";
        public const string CREATE_ORDERS = "UspCreateOrders";
        public const string GET_DELIVERY_USERS = "UspGetDeliveryUsers";
        public const string UPDATE_PRODUCTS_STOCK = "UspUpdateProductsStock";
        public const string GET_CONFIG_DATA = "UspGetConfigData";
        public const string UPDATE_CONFIG_DATA = "UspUpdateConfigData";
        public const string REMOVE_CREATED_ORDER = "UspRemoveCreatedOrder";

        //OrderSummary
        public const string GET_ORDER_SUMMARY = "UspGetOrderSummary";
        public const string GET_TOTAL_WEIGHT_PRODUCT = "UspGetTotalWeightPerProduct";
        public const string GET_CRATES_DETAILS = "UspGetCratesDetails";
        public const string GET_INTERVAL = "UspGetDisplayInterval";
        public const string GET_PRODUCT_SUMMARY = "UspGetProductSummary";

        //User
        public const string CREATE_USER = "UspCreateUser";
        public const string DELETE_USER = "UspDeleteUser";
        public const string GET_USERS = "UspGetUsers";

        //Vendor Type
        public const string CREATE_VENDOR_TYPE = "UspCreateVendorType";
        public const string DELETE_VENDOR_TYPE = "UspDeleteVendorType";
        public const string GET_VENDOR_TYPES = "UspGetVendorTypes";

        //Vendor
        public const string CREATE_VENDOR = "UspCreateVendor";
        public const string DELETE_VENDOR = "UspDeleteVendor";
        public const string GET_VENDORS = "UspGetVendors";

        //Stock
        public const string CREATE_STOCK = "UspCreateStock";
        public const string DELETE_STOCK = "UspDeleteStock";
        public const string GET_STOCKS = "UspGetStocks";
        public const string REMOVE_GRADE_A_STOCK = "UspRemoveGradeAStock";
        public const string GET_REMOVED_GRADE_A_STOCKS = "UspGetRemovedGradeAStocks";
        public const string REMOVE_GRADE_B_STOCK = "UspRemoveGradeBStock";
        public const string GET_REMOVED_GRADE_B_STOCKS = "UspGetRemovedGradeBStocks";
        public const string GET_GRADE_B_STOCKS = "UspGetGradeBStocks";

        //Payments
        public const string GET_PAYMENTS = "UspGetPayments";
        public const string UPDATE_PAYMENT = "UspUpdatePayment";

        //SalesOfficer
        public const string GET_SALES_OFFICERS_DATA = "UspGetSalesOfficersData";
        public const string GET_ORDER_START_END_DATES = "UspGetOrderStartEndDates";

        //Push Notifications
        public const string PUSH_NOTIFICATION = "UspPushNotification";
        public const string DELETE_NOTIFICATION = "UspDeleteNotification";
        public const string GET_NOTIFICATIONS = "UspGetNotifications";

        //Report
        public const string GET_PRODUCT_SALES = "UspGetProductSales";
        public const string GET_CUSTOMER_ORDERS = "UspGetCustomerOrders";
        public const string GET_ORDERS_REPORT = "UspGetOrdersReport";
        public const string GET_PRODUCTS_HISTORY_REPORT = "UspGetProductsHistoryReport";
        public const string GET_DASHBOARD_DATA = "UspGetDashboardData";
    }
}