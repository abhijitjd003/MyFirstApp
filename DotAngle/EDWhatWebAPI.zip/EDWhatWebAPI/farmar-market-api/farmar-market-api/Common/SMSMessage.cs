﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace farmar_market_api.Common
{
    public static class SMSMessage
    {
        public const string OTP_MSG = "Your OTP to register FARMAR is : (otp_number)";

        public const string ORDER_CREATE_MSG = "Thank you for placing order with FARMAR. Your order no is: (order_no). For detailed order summary, please login to our Mobile App";

        public const string ORDER_UPDATE_MSG = "Thank you for updating your order. Your order no is: (order_no). For detailed order summary, please login to our FARMAR Mobile App";
    }
}