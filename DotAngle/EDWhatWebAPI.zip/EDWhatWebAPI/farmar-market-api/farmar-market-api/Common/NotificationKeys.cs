﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace farmar_market_api.Common
{
    public static class NotificationKeys
    {
        public const string SERVER_KEY = "AAAAX7xf2Z0:APA91bH-uqOzNG5mIvfR8BrU3uonoUH8xXnAZIxgytzYYvID7jU7ukbhV7SRiwbkLa3rAVTaYb5HMNUJQoeEoijeRKHZURZStOXnwzYe7uE5COGggVCg2rIV03cv2iDXq509znm8IUFw";
        public const string SENDER_ID = "411182291357";
    }
}