﻿using System;
using System.IO;
using System.Net;

namespace farmar_market_api.Common
{
    public static class SMSService
    {
        public static bool SendSMS(string mobileNO, string message)
        {
            bool flag = false;
            WebRequest request = WebRequest.Create
                    ("https://api-alerts.kaleyra.com/v4/?method=sms&api_key=A8f974a928b8e5ff6d4ac315d78e990aa&to=" + mobileNO + "&sender=MYSORE&message=" + message);
            try
            {
                new StreamReader(request.GetResponse().GetResponseStream()).Close();
                flag = true;
            }
            catch (Exception)
            {

            }
            return flag;
        }
    }
}