﻿using System;
using System.IO;
using System.Net;

namespace farmar_market_api.Common
{
    public static class FTPServer
    {   
        public const string Server = "ftp://myveggiebox.in";
        public const string Username = "veggie_b2b";
        public const string Password = "veggieb2b#2021";

        public static string DeleteFileFromFTPServer(string fileUrlPath)
        {
            try
            {
                FtpWebRequest request = (FtpWebRequest)WebRequest.Create(fileUrlPath.Trim());
                request.Method = WebRequestMethods.Ftp.DeleteFile;
                request.Credentials = new NetworkCredential(Username, Password);

                using (FtpWebResponse response = (FtpWebResponse)request.GetResponse())
                {
                    return response.StatusDescription;
                }
            }
            catch (Exception ex)
            {
                return string.Empty;
            }
        }

        public static void UploadFTPFile(string filename, byte[] bytes, string createdDirectory)
        {
            FtpWebRequest request = (FtpWebRequest)WebRequest.Create(new
                                        Uri(string.Format("{0}/{1}", createdDirectory.Trim(), filename)));
            request.Method = WebRequestMethods.Ftp.UploadFile;
            request.Credentials = new NetworkCredential(Username, Password);
            Stream ftpStream = request.GetRequestStream();

            ftpStream.Write(bytes, 0, bytes.Length);
            ftpStream.Close();
        }

        public static string DeleteDirectoryFromFTPServer(string directory)
        {
            try
            {
                FtpWebRequest request = (FtpWebRequest)WebRequest.Create(directory.Trim());
                request.Method = WebRequestMethods.Ftp.RemoveDirectory;
                request.Credentials = new NetworkCredential(Username, Password);

                using (FtpWebResponse response = (FtpWebResponse)request.GetResponse())
                {
                    return response.StatusDescription;
                }
            }
            catch (Exception ex)
            {
                return string.Empty;
            }
        }

        public static bool CreateFTPDirectory(string[] directories, out string createdDirectory)
        {
            int actualCount = directories.Length;
            int expectedCount = 0;
            string fileDirectory = string.Empty;
            try
            {
                fileDirectory = Server;
                foreach (string directory in directories)
                {
                    fileDirectory = string.Format("{0}/{1}", fileDirectory, directory);

                    FtpWebRequest requestDir = (FtpWebRequest)WebRequest.Create(new Uri(fileDirectory));
                    requestDir.Method = WebRequestMethods.Ftp.MakeDirectory;
                    requestDir.Credentials = new NetworkCredential(Username, Password);
                    requestDir.UsePassive = true;
                    requestDir.UseBinary = true;
                    requestDir.KeepAlive = false;

                    try
                    {
                        expectedCount++;
                        FtpWebResponse response = (FtpWebResponse)requestDir.GetResponse();
                        Stream ftpStream = response.GetResponseStream();

                        ftpStream.Close();
                        response.Close();
                    }
                    catch (WebException ex)
                    {
                        FtpWebResponse response = (FtpWebResponse)ex.Response;
                        if (response.StatusCode == FtpStatusCode.ActionNotTakenFileUnavailable)
                        {
                            response.Close();
                            createdDirectory = fileDirectory;
                            if (expectedCount == actualCount)
                                return true;
                        }
                        else
                        {
                            response.Close();
                            createdDirectory = string.Empty;
                            return false;
                        }
                    }
                }
                createdDirectory = fileDirectory;
                return true;
            }
            catch (Exception)
            {
                createdDirectory = string.Empty;
                return false;
            }
        }

        public static bool CreateFTPDirectory(string conference, out string createdDirectory)
        {
            string PhotoUrlPath = string.Empty;
            try
            {
                PhotoUrlPath = string.Format("{0}/{1}/{2}", Server, "UploadedFiles", conference);

                FtpWebRequest requestDir = (FtpWebRequest)WebRequest.Create(new Uri(PhotoUrlPath));
                requestDir.Method = WebRequestMethods.Ftp.MakeDirectory;
                requestDir.Credentials = new NetworkCredential(Username, Password);
                requestDir.UsePassive = true;
                requestDir.UseBinary = true;
                requestDir.KeepAlive = false;

                try
                {
                    FtpWebResponse response = (FtpWebResponse)requestDir.GetResponse();
                    Stream ftpStream = response.GetResponseStream();

                    ftpStream.Close();
                    response.Close();
                }
                catch (WebException ex)
                {
                    FtpWebResponse response = (FtpWebResponse)ex.Response;
                    if (response.StatusCode == FtpStatusCode.ActionNotTakenFileUnavailable)
                    {
                        response.Close();
                        createdDirectory = PhotoUrlPath;
                        return true;
                    }
                    else
                    {
                        response.Close();
                        createdDirectory = string.Empty;
                        return false;
                    }
                }

                createdDirectory = PhotoUrlPath;
                return true;
            }
            catch (Exception)
            {
                createdDirectory = string.Empty;
                return false;
            }
        }
    }
}