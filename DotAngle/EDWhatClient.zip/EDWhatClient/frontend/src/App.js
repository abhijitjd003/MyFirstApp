import React, { Component } from 'react';
import { Route } from 'react-router';
import Layout from './components/Layout';
import Topics from './components/Topics';
import QuestionDetails from './components/QuestionDetails';
import PollDetails from './components/PollDetails';
import SocialLogin from './components/navmenu/SocialLogin';
import { setHyvorTalkSignon, setLoginInfo, setUserAliasName } from './components/utils/SetLocalStorage';
import MyProfile from './components/MyProfile';
import AddQuestion from './components/AddQuestion';
import { DialogContent, IconButton, Grid, Dialog, TextField, DialogActions, Button, useMediaQuery } from '@material-ui/core';
import CloseIcon from '@material-ui/icons/Close';
import Notifications from './components/Notifications';
import { withRouter } from 'react-router-dom';

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);    
    return <Component mediaQuery={mediaQuery} {...props} />;
};

class App extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            open: false,
            email: '',
            showAlias: false,
            showProfile: false,
            alias_name: '',
            alias_name_err: '',
            prev_page: '',
            isPopular: 0,
            searchValue: '',
            anchorEl: null,
            anchorElProfile: null,
            notification: false,
            readLoginUrl: false,
            hashCode: '',
            userData: '',
        };
    }

    userLogin = () => {
        this.setState({ open: true, anchorEl: null, anchorElProfile: null });
        let name = localStorage.getItem('user_name');
        let email = localStorage.getItem('user_email');
        let alias_name = localStorage.getItem('user_alias_name');

        if(name && email && !alias_name) {
            this.setState({ showAlias: true });
        } else if(name && email && alias_name) {
            const { history } = this.props;
            if (history) history.push({ pathname: '/myprofile' });
        }
    }

    embedHyvorTalk = (isLoggedIn, userId, name, email) => {
        fetch('http://18.118.149.243:4001/hyvorTalkSignon/'+isLoggedIn+'/'+userId+'/'+name+'/'+email)
        .then(res => res.json())
        .then(result => {
            this.setState({ hashCode: result.hash, userData: result.userData });            
            setHyvorTalkSignon(result.hash, result.userData);
        })
        .catch(function (error) {
            console.log(error);
        })
        .then(function () {
        });
    }

    handleClose = () => {
        this.setState({ open: false });        
        this.redirectToOriginalUrl();
    };

    redirectToOriginalUrl = () => {
        let pathname = this.props.location.pathname;
        if(pathname.indexOf('/is_login_url=true') > -1) {
            const { history } = this.props;
            if (history) history.push({
                pathname: pathname.replace('/is_login_url=true','')
            });
        }
    }

    handleAliasClose = () => {
        this.setState({ showAlias: false });
        this.redirectToOriginalUrl();
    }

    handleChange = (event) => {
        this.setState({ 
            alias_name: event.target.value,
            alias_name_err: event.target.value.length <= 0 ? 'Please enter alias name' : ''
        });
    }

    saveChanges = () => {
        if(this.validateAllInputs() && !this.state.alias_name_err) {
            setUserAliasName(this.state.alias_name);
            this.setState({ showAlias: false });
            this.embedHyvorTalk(true, localStorage.getItem('user_id'), 
                localStorage.getItem('user_alias_name'), 
                localStorage.getItem('user_email'))
        } else {
            if (!this.state.alias_name) {
                this.setState({ alias_name_err: 'Please enter alias name' });
            }
        }
    }

    validateAllInputs = () => {
        if(!this.state.alias_name) {
            return false; 
        }
        else{ return true; }
    }

    onGoogleLoginSuccess = (res) => {
        if(res.profileObj) {
            console.log('[Login Success] currentUser: ', res);
            setLoginInfo(res.profileObj.name, res.profileObj.email, res.profileObj.googleId);
            this.setState({ email: res.profileObj.email, open: false, showAlias: true });
        }
    };

    onGoogleLoginFailure = (res) => {
        console.log('[Login Failed] res: ', res);
        //localStorage.clear();
    }

    responseFacebook = (response) => {        
        if(response.name && response.email && response.userId) {
            console.log('[Facebook Login] ', response);
            setLoginInfo(response.name, response.email, response.userId);
            this.setState({ email: response.email, open: false, showAlias: true });
        }
    }

    componentDidMount() {
        let isLoggedIn = localStorage.getItem('user_email') && localStorage.getItem('user_alias_name') ? true : false;
        this.embedHyvorTalk(isLoggedIn, localStorage.getItem('user_id'),
            localStorage.getItem('user_alias_name'), 
            localStorage.getItem('user_email'));

        this.setState({ 
            email: localStorage.getItem('user_email'),
            alias_name: localStorage.getItem('user_alias_name')
        });
    }

    addQuestion = () => {
        this.setState({ anchorEl: null, anchorElProfile: null });       
        let name = localStorage.getItem('user_name');
        let email = localStorage.getItem('user_email');
        let alias_name = localStorage.getItem('user_alias_name');

        if(!name && !email && !alias_name) {
            this.setState({ open: true });
        } else if(name && email && !alias_name) {
            this.setState({ showAlias: true });
        } else if(name && email && alias_name) {
            const { history } = this.props;            
            this.setState({ prev_page: this.props.location.pathname });
            if (history) history.push({
                pathname: '/topics/question/askEDWhat'
            });
        }
    }

    sortByPopular = () => {
        this.setState({isPopular: 1});        
    }

    sortByNew = () => {
        this.setState({isPopular: 0});        
    }

    searchTopics = (event) => {
        this.setState({searchValue: event.target.value});
    }

    handleMobileMenuOpen = (event) => {
        this.setState({ anchorEl: event.currentTarget });
    };
    
    handleMobileMenuClose = () => {
        this.setState({ anchorEl: null });
    };

    handleUserProfileOpen = (event) => {
        this.setState({ anchorElProfile: event.currentTarget });
    };
    
    handleUserProfileClose = () => {
        this.setState({ anchorElProfile: null });
    };

    webNotifications = () => {
        this.setState({ notification: true });
    }

    handleCloseNotification = () => {
        this.setState({ notification: false });
    }

    componentDidUpdate = (prevProps, prevState) => {
        let array = this.props.location.pathname.split('/');
        let is_login_url = array[array.length-1];

        if(is_login_url === 'is_login_url=true') {
            let name = localStorage.getItem('user_name');
            let email = localStorage.getItem('user_email');
            let alias_name = localStorage.getItem('user_alias_name');

            if(!name && !email && !alias_name && !this.state.open) {
                this.setState({ open: true, readLoginUrl: true });
            } else if(name && email && !alias_name && !this.state.showAlias) {
                this.setState({ showAlias: true, readLoginUrl: true });
            }
        }
    }

    userLogout = () => {
        let aliasName = localStorage.getItem('user_alias_name');
        localStorage.clear();
        localStorage.setItem('user_alias_name', aliasName);
        this.setState({ anchorEl: null, anchorElProfile: null });
        let isLoggedIn = localStorage.getItem('user_email') && localStorage.getItem('user_alias_name') ? true : false;
        this.embedHyvorTalk(isLoggedIn, localStorage.getItem('user_id'),
            localStorage.getItem('user_alias_name'), 
            localStorage.getItem('user_email'));
    }

    render() {
        const { mediaQuery } = this.props;
        const name = localStorage.getItem('user_name');
        const email = localStorage.getItem('user_email');
        const alias_name = localStorage.getItem('user_alias_name');
        
        return (
            <Layout userLogin={this.userLogin} 
                userEmail={email} 
                userName={name}
                userAliasName={alias_name} 
                sortByPopular={this.sortByPopular}
                sortByNew={this.sortByNew}
                prev_page={this.state.prev_page}
                addQuestion={this.addQuestion}
                isPopular={this.state.isPopular}
                searchTopics={this.searchTopics}
                handleMobileMenuOpen={this.handleMobileMenuOpen}
                handleMobileMenuClose={this.handleMobileMenuClose}
                anchorEl={this.state.anchorEl}
                anchorElProfile={this.state.anchorElProfile}
                webNotifications={this.webNotifications}
                handleUserProfileOpen={this.handleUserProfileOpen}
                handleUserProfileClose={this.handleUserProfileClose}
                userLogout={this.userLogout}
            >
                
                {/* Social Login (Google/Facebook) */}
                { this.state.open && !name && !email &&
                    <SocialLogin open={this.state.open}
                        handleClose={this.handleClose}
                        onGoogleLoginSuccess={this.onGoogleLoginSuccess}
                        onGoogleLoginFailure={this.onGoogleLoginFailure}
                        responseFacebook={this.responseFacebook}
                    />
                }

                {/* Web Notifications */}
                { this.state.notification &&
                    <Notifications open={this.state.notification}
                        handleCloseNotification={this.handleCloseNotification}
                        userEmail={email}
                        userAliasName={alias_name}
                    />
                }

                {/* If Login Success, Set User Alias Name */}
                { this.state.showAlias && name && email && !alias_name &&
                    <React.Fragment>
                        <Dialog fullWidth open={this.state.showAlias}
                            onClose={this.handleAliasClose} disableBackdropClick
                            aria-labelledby="alert-dialog-title"
                            aria-describedby="alert-dialog-description"
                        >
                            <DialogContent style={{ backgroundColor: '#f6f7f2' }}>
                                <Grid container spacing={0}>
                                    <Grid item xs={ mediaQuery ? 11 : 10 }></Grid>
                                    <Grid item xs={ mediaQuery ? 1 : 2 }>
                                        <IconButton style={{ marginLeft: '22px', marginTop: '-20px' }} onClick={this.handleAliasClose} 
                                            aria-label="settings">
                                            <CloseIcon />
                                        </IconButton>
                                    </Grid>
                                </Grid>
                                <TextField fullWidth name="alias_name" label="Enter alias name" required onChange={this.handleChange} 
                                    noValidate onKeyUp={this.handleKeyPress}
                                    value={alias_name} variant="outlined" style={{ backgroundColor: 'white' }}
                                />
                                { this.state.alias_name_err.length > 0 && 
                                    <span className='error'>{this.state.alias_name_err}</span> }
                            </DialogContent>
                            <DialogActions style={{ backgroundColor: '#f6f7f2' }}>
                                <Button onClick={this.saveChanges} color="primary">
                                    Save
                                </Button>
                            </DialogActions>
                        </Dialog>
                    </React.Fragment>
                }

                <Route exact path='/' render={(props) => 
                    <Topics {...props} 
                        userEmail={email} 
                        userAliasName={alias_name} 
                        isPopular={this.state.isPopular}
                        searchValue={this.state.searchValue} 
                    />} />
                
                <Route exact path='/topics' key='home1' render={(props) => 
                    <Topics {...props} 
                        userEmail={email} 
                        userAliasName={alias_name} 
                        isPopular={this.state.isPopular} 
                        searchValue={this.state.searchValue}
                    />} />

                <Route exact path='/topics/:is_login_url' key='home2' render={(props) => 
                    <Topics {...props} 
                        userEmail={email} 
                        userAliasName={alias_name} 
                        isPopular={this.state.isPopular} 
                        searchValue={this.state.searchValue}
                    />} />
                
                <Route exact path='/topics/question/comments/:topicId/:title' key='que1' render={(props) => 
                    <QuestionDetails {...props} 
                        userEmail={email} 
                        userAliasName={alias_name} 
                        hashCode={this.state.hashCode}
                        userData={this.state.userData}
                    />} />
                
                <Route exact path='/topics/question/comments/:topicId/:title/:is_login_url' key='que2' render={(props) => 
                    <QuestionDetails {...props} 
                        userEmail={email} 
                        userAliasName={alias_name} 
                        hashCode={this.state.hashCode}
                        userData={this.state.userData}
                    />} />
                
                <Route exact path='/topics/poll/comments/:topicId/:title' key='poll1' render={(props) => 
                    <PollDetails {...props} 
                        userEmail={email} 
                        userAliasName={alias_name} 
                    />} />

                <Route exact path='/topics/poll/comments/:topicId/:title/:is_login_url' key='poll2' render={(props) => 
                    <PollDetails {...props} 
                        userEmail={email} 
                        userAliasName={alias_name} 
                        hashCode={this.state.hashCode}
                        userData={this.state.userData}
                    />} />
                
                <Route exact path='/myprofile' render={(props) => 
                    <MyProfile {...props} 
                        userEmail={email} 
                        userAliasName={alias_name} 
                        searchValue={this.state.searchValue} 
                    />} />
                
                <Route exact path='/topics/question/askEDWhat' render={(props) => 
                    <AddQuestion {...props} 
                        userEmail={email}
                        userAliasName={alias_name} 
                    />} />
            </Layout>
        );
    }
}

export default withRouter(withMediaQuery('(min-width:600px)')(App))
