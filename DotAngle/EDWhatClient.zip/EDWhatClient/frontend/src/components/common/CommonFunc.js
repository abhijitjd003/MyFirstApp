export default {
    validateForm(errors) {
        let valid = true;
        Object.keys(errors).map(function (e) {
            if (errors[e].length > 0) {
                valid = false;
            }
        });
        return valid;
    },

    hyvorTalkReload(configData) {
        this.hyvor_talk.reload(configData);
    }
}