export default {
    loginURL: 'http://edwhat.com/#',
    //loginURL: 'http://localhost:3000/#',
    partialURL: 'http://myveggiebox.in/api/'
    //partialURL: 'http://localhost:51878/api/'    
}