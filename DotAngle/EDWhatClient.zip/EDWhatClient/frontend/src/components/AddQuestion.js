import React, { Component, Fragment } from 'react';
import { 
    Grid, withStyles, Button, Card, CardContent, Typography, Backdrop, IconButton, Avatar, TextField, useMediaQuery
} from '@material-ui/core';
import { withRouter } from 'react-router-dom';
import { useStyles } from './common/useStyles';
import './common/Common.css'
import api from './common/APIValues';
import HelpIcon from '@material-ui/icons/Help';
import AdjustIcon from '@material-ui/icons/Adjust';
import RichTextEditor from 'react-rte';
import CommonFunc from './common/CommonFunc';
import axios from 'axios';
import EDWhatLogoIcon from './images/EdWhat-01-01.png';
import ViewImage from './ViewImage';
import CloseIcon from '@material-ui/icons/Close';

const toolbarConfig = {
    display: ['INLINE_STYLE_BUTTONS', 'BLOCK_TYPE_BUTTONS', 'LINK_BUTTONS', 'BLOCK_TYPE_DROPDOWN', 'HISTORY_BUTTONS'],
    INLINE_STYLE_BUTTONS: [
      {label: 'Bold', style: 'BOLD', className: 'custom-css-class'},
      {label: 'Italic', style: 'ITALIC'},
      {label: 'Underline', style: 'UNDERLINE'}
    ],
    BLOCK_TYPE_DROPDOWN: [
      {label: 'Normal', style: 'unstyled'},
      {label: 'Heading Large', style: 'header-one'},
      {label: 'Heading Medium', style: 'header-two'},
      {label: 'Heading Small', style: 'header-three'}
    ],
    BLOCK_TYPE_BUTTONS: [
      {label: 'UL', style: 'unordered-list-item'},
      {label: 'OL', style: 'ordered-list-item'},
      {label: 'Blockquote', style: 'blockquote'},
    ]
};

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);    
    return <Component mediaQuery={mediaQuery} {...props} />;
};

class AddQuestion extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            userTopics: [], loader: false, myProfileCount: {}, type: 'question', topic_value: RichTextEditor.createEmptyValue(),
            topic_title: '', topic_desc: '', err_msg: '', options: [], optionCount: 2, disableAddOption: false,
            fileType: null, fileName: null, fileBase64String: null, disableRemoveOption: true, preViewImage: null,
            Option1: '', 
            Option2: '',
            Option3: '', 
            Option4: '',
            Option5: '', 
            Option6: '',
            Option7: '', 
            Option8: '',
            Option9: '', 
            Option10: '',
            errors: {
                topic_title: '',
                topic_desc: '',
                request_type: '',
                Option1: '',
                topic_image: '',
            }
        }
    }

    componentDidMount() {     
        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });   
        let options = [
            { option : 'Option 1', value: 1 },
            { option : 'Option 2', value: 2 }
        ];
        this.setState({ options });
    }

    addMoreOptions = () => {
        let val = this.state.optionCount + 1;
        let option = { option : 'Option ' + val, value: val };
        let options = this.state.options;
        options.push(option);
        this.setState({ 
            options: options, 
            optionCount: val, 
            disableAddOption: val === 10 ? true : false,
            disableRemoveOption: val === 2 ? true : false 
        });
    }

    removeOptions = () => {
        let val = this.state.optionCount - 1;
        let options = this.state.options;
        options.pop();
        this.setState({ 
            options: options, 
            optionCount: val, 
            disableRemoveOption: val === 2 ? true : false,
            disableAddOption: val === 10 ? true : false, 
        });
    }

    componentDidUpdate = (prevProps, prevState) => {
        if (this.props.userEmail !== prevProps.userEmail || this.props.userAliasName !== prevProps.userAliasName) {
            
        }
    }

    requestType = (type) => {
        this.setState({ type: type });
        let errors = this.state.errors;
        errors.request_type = '';
        this.setState({ errors });
    }

    onChange = (value) => {
        this.setState({ topic_value: value });
        
        let errors = this.state.errors;
        let desc = value.toString('html').replace('<p><br></p>', '');
        errors.topic_desc = desc.length <= 0 ? 'Please enter question description' : '';
        this.setState({ errors, topic_desc: desc });

        if (this.props.onChange) {
            this.props.onChange(
              value.toString('html')
            );
        }
    };

    handleChange = (event) => {
        event.preventDefault();
        const { name, value } = event.target;
        let errors = this.state.errors;

        switch (name) {
            case 'topic_title':
                this.state.topic_title = value;
                errors.topic_title = value.length <= 0 ? 'Please enter question title' : '';
                break;            
            case 'Option2':
                this.state.Option2 = value;
                errors.Option1 = value.length <= 0 ? 'Please enter option 2' : '';
                break;
            case 'Option1':
                this.state.Option1 = value;
                errors.Option1 = value.length <= 0 ? 'Please enter option 1' : '';
                break;
            case 'Option3':
                this.state.Option3 = value;                
                break;
            case 'Option4':
                this.state.Option4 = value;                
                break;
            case 'Option5':
                this.state.Option5 = value;                
                break;
            case 'Option6':
                this.state.Option6 = value;                
                break;
            case 'Option7':
                this.state.Option7 = value;                
                break;
            case 'Option8':
                this.state.Option8 = value;                
                break;
            case 'Option9':
                this.state.Option9 = value;
                break;
            case 'Option10':
                this.state.Option10 = value;                
                break;
        }
        this.setState({ errors, [name]: value });
    }

    validateQueInputs(){
        if(!this.state.topic_title || !this.state.topic_desc || (this.state.fileName &&
            this.state.fileType !== 'image/jpeg' && this.state.fileType !== 'image/jpg' &&
            this.state.fileType !== 'image/png' && this.state.fileType !== 'image/gif')) {
            return false;
        }
        else{ return true; }
    }

    validatePollInputs(){
        if(!this.state.topic_title || !this.state.topic_desc || !this.state.Option1 || !this.state.Option2) {
            return false; 
        }
        else{ return true; }
    }

    createQuestionPoll = () => {
        if(this.state.type) {            
            if(this.state.type === 'question')
                this.createQuestion();
            else if(this.state.type === 'poll')
                this.createPoll();
        } else {
            let errors = this.state.errors;
            errors.request_type = 'Please choose question or poll type';
            this.setState({ errors });
        }
    }

    createPoll = () => {        
        if (CommonFunc.validateForm(this.state.errors) && this.validatePollInputs()) {
            let options = [];
            this.setState({ loader: true });

            if(this.state.Option1){
                options.push(this.state.Option1);
            }
            if(this.state.Option2){
                options.push(this.state.Option2);
            }
            if(this.state.Option3){
                options.push(this.state.Option3);
            }
            if(this.state.Option4){
                options.push(this.state.Option4);
            }
            if(this.state.Option5){
                options.push(this.state.Option5);
            }
            if(this.state.Option6){
                options.push(this.state.Option6);
            }
            if(this.state.Option7){
                options.push(this.state.Option7);
            }
            if(this.state.Option8){
                options.push(this.state.Option8);
            }
            if(this.state.Option9){
                options.push(this.state.Option9);
            }
            if(this.state.Option10){
                options.push(this.state.Option10);
            }

            let rowData = {
                TOPIC_TITLE: this.state.topic_title,
                TOPIC_DESC: this.state.topic_desc,                
                TOPIC_CREATE_USER_ID: this.props.userEmail,
                TOPIC_CREATE_USER_NM: this.props.userAliasName,
                TOPIC_VOTE_OPTNS: options
            }

            axios({
                method: 'post',
                url: api.partialURL + 'AddPoll/CreateUserPoll',
                data: JSON.stringify(rowData),
                headers: { 'Content-Type': 'application/json' },
                mode: 'cors',
            })
            .then(res => {
                if(res) {
                    this.setState({ loader: false });
                    if (res.data === 'success') {
                        const { history } = this.props;
                        if (history) history.push({ pathname: '/topics' });
                    } else {
                        this.setState({ err_msg: 'Failed to create poll' });
                    }
                }
            })
            .catch(function (response) {
                this.setState({ err_msg: response });
            });
        } else {
            let errors = this.state.errors;
            if (!this.state.topic_title) {
                errors.topic_title = 'Please enter question title';
            }
            if (!this.state.topic_desc) {
                errors.topic_desc = 'Please enter question description';
            }            
            if (!this.state.Option2) {
                errors.Option1 = 'Please enter option 2';
            }
            if (!this.state.Option1) {
                errors.Option1 = 'Please enter option 1';
            }
            this.setState({ errors });
        }
    }

    createQuestion = () => {        
        if (CommonFunc.validateForm(this.state.errors) && this.validateQueInputs()) {
            this.setState({ loader: true });
            let rowData = {
                TOPIC_TITLE: this.state.topic_title,
                TOPIC_DESC: this.state.topic_desc,
                TOPIC_FILE_TYPE: this.state.fileType,
                TOPIC_FILE_NM: this.state.fileName,
                TOPIC_FILE_BASE_64_STRNG: this.state.fileBase64String,
                TOPIC_CREATE_USER_ID: this.props.userEmail,
                TOPIC_CREATE_USER_NM: this.props.userAliasName
            }

            axios({
                method: 'post',
                url: api.partialURL + 'AddQuestion/CreateUserQuestion',
                data: JSON.stringify(rowData),
                headers: { 'Content-Type': 'application/json' },
                mode: 'cors',
            })
            .then(res => {
                if(res) {
                    this.setState({ loader: false });
                    if (res.data === 'success') {
                        const { history } = this.props;
                        if (history) history.push({ pathname: '/topics' });
                    } else {
                        this.setState({ err_msg: 'Failed to create question' });
                    }
                }
            })
            .catch(function (response) {
                this.setState({ err_msg: response, loader: false });
            });
        } else {
            let errors = this.state.errors;
            if (!this.state.topic_title) {
                errors.topic_title = 'Please enter question title';
            }
            if (!this.state.topic_desc) {
                errors.topic_desc = 'Please enter question description';
            }
            if(this.state.fileName && (this.state.fileType !== 'image/jpeg' || this.state.fileType !== 'image/jpg' ||
                this.state.fileType !== 'image/png' || this.state.fileType !== 'image/gif')) {
                errors.topic_image = 'This file format is not supported';
            } else {
                errors.topic_image = '';
            }
            this.setState({ errors });
        }
    }

    onFileUploadChange = (event) => {
        var file = event.target.files[0];
        if(file) {
            this.setState({ preViewImage: URL.createObjectURL(file) });
            var blob = file.slice();
            var reader = new FileReader();

            reader.onloadend = function (evt) {
                if (evt.target.readyState == FileReader.DONE) {
                    var cont = evt.target.result
                    var base64String = getB64Str(cont);

                    this.setState ({
                        fileType: file.type,
                        fileBase64String: base64String,
                        fileName: file.name
                    });
                }
            }.bind(this);

            reader.readAsArrayBuffer(blob);
        } else {
            this.setState ({
                fileType: null,
                fileBase64String: null,
                fileName: null
            });
        }
    }

    // preViewImage = () => {
    //     this.setState({ viewImage: true });
    // }

    // handleViewImgClose = () => {
    //     this.setState({ viewImage: false });
    // }

    closeImageIcon = () => {
        this.setState({ preViewImage: false });
    }

    render() {
        const { classes, mediaQuery } = this.props;
        const col212 = mediaQuery ? 2 : 12;
        const col26 = mediaQuery ? 2 : 6;
        const col4 = mediaQuery ? 4 : 2;
        const col1 = mediaQuery ? 2 : 1;
        const col3 = mediaQuery ? 3 : 6;
        const col211 = mediaQuery ? 2 : 11;
        
        return (
            <Fragment>
                <Backdrop className={classes.backdrop} open={this.state.loader}>
                    <img src={EDWhatLogoIcon} height={50} alt="Logo" />
                </Backdrop>

                {/* { this.state.viewImage &&
                    <ViewImage
                        open={this.state.viewImage}
                        preViewImage={this.state.preViewImage}
                        handleViewImgClose={this.handleViewImgClose}
                    />
                } */}

                <Grid container spacing={0} style={{ marginTop: mediaQuery ? '55px' : '90px' }}>
                    <Grid item xs={12}>
                        <Typography className={classes.title} color="textSecondary">
                            Please mind your language. Try to keep it short and to the point. Make sure it is education related.
                        </Typography>
                    </Grid>
                </Grid>

                <Grid container spacing={col4} style={{ marginTop: '0px' }}>
                    <Grid item xs={col212}>
                        <Card>
                            <CardContent>
                                <Typography style={{ textAlign: 'center', color: '#333233' }}>
                                    CHOOSE TYPE
                                </Typography>
                            </CardContent>
                        </Card>
                    </Grid>
                    <Grid item xs={col26}>
                        <Card style={{ cursor: 'pointer' }} onClick={()=> this.requestType('question')}>
                            <CardContent style={{ paddingBottom: '10px' }}>
                                <Grid container spacing={0}>                            
                                    <Grid item xs={3}>
                                        <HelpIcon className={this.state.type === 'question' ? classes.iconMedSize1 : classes.iconMedSize} />
                                    </Grid>
                                    <Grid item xs={9} style={{ marginTop: '3%' }}>
                                        <Typography className={this.state.type === 'question' ? classes.activeColor : classes.inactiveColor}>
                                            QUESTION
                                        </Typography>
                                    </Grid>
                                </Grid>
                            </CardContent>
                        </Card>
                    </Grid>
                    <Grid item xs={col26}>
                        <Card style={{ cursor: 'pointer' }} onClick={()=> this.requestType('poll')}>
                            <CardContent style={{ paddingBottom: '10px' }}>
                                <Grid container spacing={0}>                            
                                    <Grid item xs={3}>
                                        <AdjustIcon className={this.state.type === 'poll' ? classes.iconMedSize1 : classes.iconMedSize} />
                                    </Grid>
                                    <Grid item xs={9} style={{ marginTop: '3%' }}>
                                        <Typography className={this.state.type === 'poll' ? classes.activeColor : classes.inactiveColor}>
                                            POLL
                                        </Typography>
                                    </Grid>
                                </Grid>
                            </CardContent>
                        </Card>
                    </Grid>                 
                </Grid>

                { this.state.errors.request_type.length > 0 && 
                            <span className='error'>{this.state.errors.request_type}</span> }

                <Grid container spacing={2} style={{ marginTop: '20px' }}>
                    <Grid item>
                        <Avatar style={{ backgroundColor: '#333233' }} onClick={this.props.userLogin}
                            src="/static/images/avatar/1.jpg" />
                    </Grid>
                    <Grid item style={{ marginTop: '0.5%' }}>
                        <Typography className={classes.activeColor}>
                            { this.props.userAliasName }
                        </Typography>
                    </Grid>
                    <Grid item style={{ marginTop: '0.8%' }}>
                        <Typography className={classes.subTitle} color="textSecondary">
                            (Your alias will be used to show the name, please change it in the profile section)
                        </Typography>
                    </Grid>
                </Grid>
                
                <Grid container spacing={2} style={{ marginTop: '10px' }}>
                    <Grid item xs={12}>
                        <TextField fullWidth name="topic_title" label="Type your question here" required
                            onChange={this.handleChange} noValidate value={this.state.topic_title}
                            variant="outlined" style={{ backgroundColor: 'white' }} />
                        { this.state.errors.topic_title.length > 0 && 
                            <span className='error'>{this.state.errors.topic_title}</span> }
                    </Grid>
                    <Grid item xs={12}>
                        <RichTextEditor style={{ width: '100%' }}
                            value={this.state.topic_value}
                            onChange={this.onChange}
                            placeholder='Type your question description here *'
                            name="topic_desc"
                            toolbarConfig={toolbarConfig}
                        />
                        { this.state.errors.topic_desc.length > 0 && 
                            <span className='error'>{this.state.errors.topic_desc}</span> }
                    </Grid>
                    { this.state.type === 'question' &&
                        <Grid item xs={12}>
                            <TextField fullWidth name="topic_image" type="file" onChange={ e => {this.onFileUploadChange(e)}}
                                label="Upload Image (.jpeg | .png | .jpg | .gif)" variant="outlined" InputLabelProps={{shrink: true}}
                                inputProps={{ accept: '.png, .jpeg, .jpg, .gif', }}
                                style={{ backgroundColor: 'white' }}/>
                            {this.state.errors.topic_image.length > 0 &&
                                <span className='error'>{this.state.errors.topic_image}</span>}
                        </Grid>
                    }
                    { this.state.type === 'poll' &&
                        <Grid item xs={12}>
                            <Typography className={classes.subTitle} color="textSecondary">
                                * Minimum 2 options for poll and max 10
                            </Typography>
                        </Grid>
                    }
                    { this.state.type === 'poll' && this.state.options.map((option, row) => (
                        <Grid item xs={col3}>
                            <TextField fullWidth name={option.option.slice(0, -2) + '' + option.value} label={option.option}
                                onChange={this.handleChange} noValidate required={ option.value > 2 ? false : true}
                                value={                                    
                                    option.value === 1 ? this.state.Option1 : option.value === 2 ? this.state.Option2 :
                                    option.value === 3 ? this.state.Option3 : option.value === 4 ? this.state.Option4 :
                                    option.value === 5 ? this.state.Option5 : option.value === 6 ? this.state.Option6 :
                                    option.value === 7 ? this.state.Option7 : option.value === 8 ? this.state.Option8 :
                                    option.value === 9 ? this.state.Option9 : this.state.option10
                                }
                            variant="outlined" style={{ backgroundColor: 'white' }} />
                        </Grid>
                    ))}
                    { this.state.type === 'poll' &&
                        <Grid item xs={12}>
                            { this.state.errors.Option1.length > 0 && 
                            <span className='error'>{this.state.errors.Option1}</span> }
                        </Grid>
                    }
                </Grid>
                
                { this.state.preViewImage &&
                    <Grid container spacing={0} style={{ marginTop: '10px' }}>                        
                        <Grid item xs={col211}>
                            <img src={this.state.preViewImage} style={{width: '100%'}}
                                alt="pre-view image" />
                        </Grid>
                        <Grid item xs={1}>
                            <IconButton style={{marginTop: '-18px', marginLeft: '-10px'}} onClick={this.closeImageIcon} 
                                aria-label="settings">
                                <CloseIcon />
                            </IconButton>
                        </Grid>
                    </Grid>
                }
                
                <Grid container spacing={col1} style={{ marginTop: '5px' }}>
                    { this.state.type === 'poll' && !this.state.disableAddOption &&
                        <Grid item>
                            <Button variant="contained" color="primary" className={classes.customButtonPrimary}
                                onClick={this.addMoreOptions}>
                                    Add More Options
                            </Button>                        
                        </Grid>
                    }
                    { this.state.type === 'poll' && !this.state.disableRemoveOption &&
                        <Grid item>
                            <Button variant="contained" color="primary" className={classes.customButtonPrimary}
                                onClick={this.removeOptions}>
                                    Remove Options
                            </Button>                        
                        </Grid>
                    }
                    <Grid item>
                        <Button variant="contained" color="primary" className={classes.customButtonPrimary}
                            onClick={this.createQuestionPoll}>Create Question
                        </Button>                        
                    </Grid>
                    <Grid item xs={12}>
                        { this.state.err_msg.length > 0 && <span className='error'>{this.state.err_msg}</span> }
                    </Grid>
                </Grid>
            </Fragment>
        );
    }
}

export default withRouter(withStyles(useStyles)(withMediaQuery('(min-width:600px)')(AddQuestion)))

function getB64Str (buffer) {
    var binary = '';
    var bytes = new Uint8Array(buffer);
    var len = bytes.byteLength;
    for (var i = 0; i < len; i++) {
        binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
}