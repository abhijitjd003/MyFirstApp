import React from 'react';
import { DialogContent, IconButton, Grid, Dialog, DialogContentText, useMediaQuery } from '@material-ui/core';
import CloseIcon from '@material-ui/icons/Close';
import { GoogleLogin } from 'react-google-login';
import FacebookLogin from 'react-facebook-login';
import GoogleButton from 'react-google-button'
import '../common/Common.css'

//Abhijit
const clientId = '301408168466-fkmdd8em0pkto10hphn1circmf5ompmi.apps.googleusercontent.com';

//edwhat
//const clientId = '644866324781-u374h6u23un8r8pbieuecc2qi9euhdkq.apps.googleusercontent.com';

export default function SocialLogin(props) {
    const [open, setOpen] = React.useState(props.open);
    const matches = useMediaQuery('(min-width:600px)');

    return (
        <React.Fragment>
            <Dialog fullWidth open={open}
                onClose={props.handleClose} disableBackdropClick
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <DialogContent style={{ backgroundColor: '#f6f7f2' }}>
                    <Grid container spacing={0}>
                        <Grid item xs={ matches ? 11 : 10 }></Grid>
                        <Grid item xs={ matches ? 1 : 2 }>
                            <IconButton style={{ marginLeft: '22px', marginTop: '-20px' }} onClick={props.handleClose} aria-label="settings">
                                <CloseIcon />
                            </IconButton>
                        </Grid>
                    </Grid>
                    <GoogleLogin
                        clientId={clientId}
                        buttonText='Continue with Google'
                        onSuccess={props.onGoogleLoginSuccess}
                        onFailure={props.onGoogleLoginFailure}
                        cookiePolicy={'single_host_origin'}     
                        render={renderProps => (
                            <GoogleButton type="light" label='Continue with Google' onClick={renderProps.onClick} 
                            style={{ width: '100%', color: '#333233', textAlign: 'left', borderRadius: 4 }} />
                        )}
                    />
                    <FacebookLogin style={{ marginTop: 10 }}
                        appId="998162274289044"
                        fields="name,email,picture"
                        callback={props.responseFacebook}
                        cssClass="btnFacebook"
                        icon="fa fa-facebook circle"
                        textButton = "&nbsp;&nbsp;Continue with Facebook"
                    />
                    <DialogContentText style={{ marginTop: 35, textAlign: 'center' }} id="alert-dialog-description">
                        I agree to the terms and conditions and privacy policy
                    </DialogContentText>
                </DialogContent>
            </Dialog>
        </React.Fragment>
    );
}
