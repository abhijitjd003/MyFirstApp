import React from 'react';
import { DialogContent, IconButton, Grid, Dialog, TextField, DialogActions, Button, useMediaQuery } from '@material-ui/core';
import CloseIcon from '@material-ui/icons/Close';
import { setUserAliasName } from '../utils/SetLocalStorage';

export default function UserAlias(props) {
    const [show, setShow] = React.useState(props.show);
    const [alias_name, setAliasName] = React.useState('');
    const [alias_name_err, setAliasNameErr] = React.useState('');
    const matches = useMediaQuery('(min-width:600px)');

    const handleClose = () => {
        setShow(false);
    }

    const handleChange = (event) => {
        setAliasName(event.target.value);
        setAliasNameErr(event.target.value.length <= 0 ? 'Please enter alias name' : '');
        setUserAliasName(event.target.value);
    }

    const saveChanges = () => {
        if(validateAllInputs() && !alias_name_err) {
            setUserAliasName(alias_name);
            setShow(false);
        } else {
            if (!alias_name) {
                setAliasNameErr('Please enter alias name');
            }
        }
    }

    const validateAllInputs = () => {
        if(!alias_name) {
            return false; 
        }
        else{ return true; }
    }

    return (
        <React.Fragment>
            <Dialog fullWidth open={show}
                onClose={handleClose} disableBackdropClick
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <DialogContent style={{ backgroundColor: '#f6f7f2' }}>
                    <Grid container spacing={0}>
                        <Grid item xs={ matches ? 11 : 9 }></Grid>
                        <Grid item xs={ matches ? 1 : 3 }>
                            <IconButton style={{ marginLeft: '22px', marginTop: '-20px' }} onClick={handleClose} 
                                aria-label="settings">
                                <CloseIcon />
                            </IconButton>
                        </Grid>
                    </Grid>
                    <TextField fullWidth name="alias_name" label="Enter alias name" required onChange={handleChange} noValidate 
                        value={alias_name} variant="outlined" style={{ backgroundColor: 'white' }}
                    />
                    { alias_name_err.length > 0 && <span className='error'>{alias_name_err}</span> }
                </DialogContent>
                <DialogActions style={{ backgroundColor: '#f6f7f2' }}>
                    <Button onClick={saveChanges} color="primary">
                        Save
                    </Button>
                </DialogActions>
            </Dialog>
        </React.Fragment>
    );
}
