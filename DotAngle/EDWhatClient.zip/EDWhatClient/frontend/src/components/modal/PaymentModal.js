import React, { Component } from 'react';
import CloseIcon from '@material-ui/icons/Close';
import Popup from "reactjs-popup";
import { Button, TextField, Grid, withStyles, Select, MenuItem } from '@material-ui/core';
import './Modal.css';
import PropTypes from 'prop-types';
import SaveIcon from '@material-ui/icons/Check';
import 'date-fns';
import DateFnsUtils from '@date-io/date-fns';
import { MuiPickersUtilsProvider, KeyboardDatePicker, KeyboardTimePicker } from '@material-ui/pickers';
import api from '../common/APIValues';
import { useStyles } from '../common/useStyles';

// const useStyles = theme => ({
//     leftIcon: {
//         marginRight: theme.spacing.unit,
//     },
//     root: {
//         fontSize: 12, height: '2.1rem',
//         backgroundColor: "#0079c2",
//         "&:hover": {
//             backgroundColor: "#0079c2"
//         },
//         "&:disabled": {
//             backgroundColor: "rgba(0, 0, 0, 0.12)"
//         },
//     },
// });

const validateForm = (errors) => {
    let valid = true;
    Object.keys(errors).map(function (e) {
        if (errors[e].length > 0) {
            valid = false;
        }        
    });
    return valid;
}

class PaymentModal extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            open: false, paymentStatus: '0', receivedAmount: null, errorMessage: '', price: null,
            errors: {
                receivedAmount: '',
                paymentStatus: '',
            }
        };

        this.openModal = this.openModal.bind(this);
        this.closeModal = this.closeModal.bind(this);
        this.popupOnClose = this.popupOnClose.bind(this);
        this.onStatusChanged = this.onStatusChanged.bind(this);
    }

    openModal(price, receivedAmount, paymentStatus) {        
        this.setState({ open: true, price: price, receivedAmount: receivedAmount, paymentStatus: paymentStatus });
    }

    closeModal() {        
        this.setState({ 
            open: false, status: '0', deliveryDate: null, deliveryFromTime: null, deliveryToTime: null, errorMessage: ''
        });
    }
    popupOnClose() { }

    updatePayment = () => {
        if (validateForm(this.state.errors) && (this.state.paymentStatus !== '0' || this.state.receivedAmount)) {
            if(Number(this.state.price) === Number(this.state.receivedAmount) && this.state.paymentStatus !== 'Received') {
                this.setState({ errorMessage: 'Payment status should be Received.' });               
            } 
            else if(Number(this.state.price) !== Number(this.state.receivedAmount) && Number(this.state.receivedAmount) > 0 
                && this.state.paymentStatus !== 'Partial') {
                this.setState({ errorMessage: 'Payment status should be Partial.' });
            }
            else if((Number(!this.state.receivedAmount) || Number(this.state.receivedAmount) === 0) 
                && this.state.paymentStatus !== 'Pending') {
                this.setState({ errorMessage: 'Payment status should be Pending.' });
            } 
            else {            
                if (typeof this.props.onClick === 'function') {               
                    this.props.onClick(this.state.paymentStatus, this.state.receivedAmount);
                    this.closeModal();
                }
            }
        } else {
            let errors = this.state.errors;
            if (this.state.paymentStatus === 0) {
                errors.paymentStatus = 'Select payment status';
            }
            if (!this.state.receivedAmount) {
                errors.receivedAmount = 'Received amount is required';
            }
            this.setState({ errors });
        }
    }

    onStatusChanged(e) {
        this.setState({ paymentStatus: e.target.value });
        let paymentStatus = e.target.value; 
        if(paymentStatus === 0){
            this.state.errors.paymentStatus = 'Select payment status';
        }else{
            this.state.errors.paymentStatus = '';
        }
    };

    handleChange = (event) => {
        event.preventDefault();
        const { name, value } = event.target;
        let errors = this.state.errors;

        switch (name) {
            case 'receivedAmount':
                this.state.receivedAmount = value;
                errors.receivedAmount = value.length <= 0 ? 'Received amount is required' : !Number(value) ? 'Received amount is not valid' : '';
                break;
        }
        this.setState({ errors, [name]: value });
    }

    render() {
        const { classes } = this.props;

        return (
            <div>
                <Popup contentStyle={{ width: "500px", height: "220px", borderRadius: "5px" }} open={this.state.open}
                    className="popup-modal-container-box" modal onOpen={e => this.popupOnClose(e)}
                    onClose={this.popupOnClose} lockScroll={true} closeOnDocumentClick={false}>
                    <div className="modal-custom">
                        <div className="header">Update Payment</div>
                        <div className="content-reject">
                            <Grid container spacing={2}>                                                            
                                <Grid item xs={6}>
                                    <Select fullWidth id="ddlStatus" value={this.state.paymentStatus} className="selectTopMargin"
                                        onChange={ this.onStatusChanged }>
                                        <MenuItem value="0">Choose Payment Status</MenuItem>
                                        <MenuItem value="Pending">Pending</MenuItem>
                                        <MenuItem value="Partial">Partial</MenuItem>
                                        <MenuItem value="Received">Received</MenuItem>
                                    </Select>
                                    {this.state.errors.paymentStatus.length > 0 &&
                                        <span className='error'>{this.state.errors.paymentStatus}</span>} 
                                </Grid>
                                <Grid item xs={6}>
                                    <TextField fullWidth name="receivedAmount" id="txtReceivedAmount" 
                                        label="Received Amount" onChange={this.handleChange} noValidate value={this.state.receivedAmount} />
                                    {this.state.errors.receivedAmount.length > 0 &&
                                        <span className='error'>{this.state.errors.receivedAmount}</span>}
                                </Grid>                                
                            </Grid>
                        </div>
                        <Grid className="actions" container spacing={1}>
                            <Grid item xs={6}>
                                {this.state.errorMessage.length > 0 &&
                                    <span className='error'>{this.state.errorMessage}</span>}
                            </Grid>
                            <Grid item xs={3}>
                                <Button className={classes.rootModal} color="primary" variant="contained" 
                                    onClick={() => this.updatePayment()}>
                                    <SaveIcon className={classes.leftIcon} />Update</Button>
                            </Grid>
                            <Grid item xs={3}>
                                <Button className={classes.rootModal} color="primary" variant="contained" onClick={this.closeModal}>
                                    <CloseIcon className={classes.leftIcon} />Close</Button>
                            </Grid>
                        </Grid>
                    </div>
                </Popup>
            </div>
        );
    }
}

PaymentModal.propTypes = {
    onClick: PropTypes.func
};

export default withStyles(useStyles)(PaymentModal)