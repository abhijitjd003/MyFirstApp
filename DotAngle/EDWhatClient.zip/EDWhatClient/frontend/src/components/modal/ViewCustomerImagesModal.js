import React, { Component } from 'react';
import CloseIcon from '@material-ui/icons/Close';
import Popup from "reactjs-popup";
import { Button, Grid, withStyles } from '@material-ui/core';
import './Modal.css';
import PropTypes from 'prop-types';
import api from '../common/APIValues';
import SimpleImageSlider from "react-simple-image-slider";
import { useStyles } from '../common/useStyles';

// const useStyles = theme => ({
//     leftIcon: {
//         marginRight: theme.spacing.unit,
//     },
//     root: {
//         fontSize: 12, height: '2.1rem',
//         backgroundColor: "#0079c2",
//         "&:hover": {
//             backgroundColor: "#0079c2"
//         },
//         "&:disabled": {
//             backgroundColor: "rgba(0, 0, 0, 0.12)"
//         },
//     },
// });

class ViewCustomerImagesModal extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            open: false, shopId: null, shopImages: [],
        };
        this.openModal = this.openModal.bind(this);
        this.closeModal = this.closeModal.bind(this);
        this.popupOnClose = this.popupOnClose.bind(this);
    }

    openModal(shopImages) {        
        this.setState({ open: true, shopImages: shopImages });
        console.log(this.state.shopImages)
    }

    closeModal() {
        this.setState({ open: false, shopImages: [] });
    }
    popupOnClose() { }

    componentDidMount() {        
        
    }

    render() {
        const { classes } = this.props;

        return (
            <div>
                <Popup contentStyle={{ width: "810px", height: "535px", borderRadius: "5px" }} open={this.state.open}
                    className="popup-modal-container-box" modal onOpen={e => this.popupOnClose(e)}
                    onClose={this.popupOnClose} lockScroll={true} closeOnDocumentClick={false}>
                    <div className="modal-custom">
                        <div className="header">
                            <Grid container spacing={1}>
                                <Grid item xs={10}>
                                    Shop Images
                                </Grid>                            
                                <Grid item xs={2}>
                                    <Button className={classes.rootModal} color="primary" variant="contained" onClick={this.closeModal}>
                                        <CloseIcon className={classes.leftIcon} />Close</Button>
                                </Grid>
                            </Grid>
                        </div>
                        <div className="content-reject">
                            <Grid container spacing={0}>                                                                                            
                                <Grid item xs={12}>
                                    { this.state.shopImages.length > 0 ?
                                    <SimpleImageSlider
                                        width={740}
                                        height={450}
                                        images={this.state.shopImages}
                                    /> : <span className='error'>No shop images found.</span>}
                                </Grid>                                
                            </Grid>
                        </div>
                    </div>
                </Popup>
            </div>
        );
    }
}

ViewCustomerImagesModal.propTypes = {
    onClick: PropTypes.func
};

export default withStyles(useStyles)(ViewCustomerImagesModal)