import React, { Component } from 'react';
import CloseIcon from '@material-ui/icons/Close';
import Popup from "reactjs-popup";
import { Button, TextField, Grid, withStyles, Select, MenuItem } from '@material-ui/core';
import './Modal.css';
import PropTypes from 'prop-types';
import SaveIcon from '@material-ui/icons/Check';
import 'date-fns';
import DateFnsUtils from '@date-io/date-fns';
import { MuiPickersUtilsProvider, KeyboardDatePicker, KeyboardTimePicker } from '@material-ui/pickers';
import api from '../common/APIValues';
import { useStyles } from '../common/useStyles';

// const useStyles = theme => ({
//     leftIcon: {
//         marginRight: theme.spacing.unit,
//     },
//     root: {
//         fontSize: 12, height: '2.1rem',
//         backgroundColor: "#0079c2",
//         "&:hover": {
//             backgroundColor: "#0079c2"
//         },
//         "&:disabled": {
//             backgroundColor: "rgba(0, 0, 0, 0.12)"
//         },
//     },
// });

const validateForm = (errors) => {
    let valid = true;
    Object.keys(errors).map(function (e) {
        if (errors[e].length > 0) {
            valid = false;
        }        
    });
    return valid;
}

class OrderModal extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            open: false, status: '0', deliveryDate: null, deliveryFromTime: null, deliveryToTime: null, errorMessage: '',
            deliveryUsers: [], deliveryUserId: 0, orderMode: '0',
        };

        this.openModal = this.openModal.bind(this);
        this.closeModal = this.closeModal.bind(this);
        this.popupOnClose = this.popupOnClose.bind(this);
        this.onStatusChanged = this.onStatusChanged.bind(this);
        this.onOrderModeChanged = this.onOrderModeChanged.bind(this);
        this.onUserChanged = this.onUserChanged.bind(this);
    }

    openModal() {        
        this.setState({ open: true });
    }

    closeModal() {        
        this.setState({ 
            open: false, status: '0', deliveryDate: null, deliveryFromTime: null, deliveryToTime: null, errorMessage: ''
        });
    }
    popupOnClose() { }

    updateOrder = () => {
        if (this.state.status !== '0' || this.state.deliveryUserId !== '0' || this.state.deliveryDate 
            || (this.state.deliveryFromTime && this.state.deliveryToTime) || this.state.orderMode !== '0' ) {
            if (typeof this.props.onClick === 'function') {
                let deliveryFromTime = this.state.deliveryFromTime ? this.state.deliveryFromTime
                    .toLocaleTimeString(navigator.language, {hour: '2-digit', minute:'2-digit'}) : '';
                let deliveryToTime = this.state.deliveryToTime ? this.state.deliveryToTime
                    .toLocaleTimeString(navigator.language, {hour: '2-digit', minute:'2-digit'}) : '';
                    
                this.props.onClick(this.state.status, this.state.deliveryDate, deliveryFromTime + ' - ' + deliveryToTime
                    , this.state.deliveryUserId, this.state.orderMode);
                this.closeModal();
            }
        } else {            
            this.setState({ errorMessage: 'Enter at least one input.' });
        }
    }

    onStatusChanged(e) {
        this.setState({ status: e.target.value });
    };
    onDeliveryDateChanged = (date) => { 
        this.setState({ deliveryDate: date }); 
    };
    onDeliveryFromTimeChanged = (date) => { 
        this.setState({ deliveryFromTime: date }); 
    };
    onDeliveryToTimeChanged = (date) => { 
        this.setState({ deliveryToTime: date }); 
    };

    onOrderModeChanged(e) {
        let mode = e.target.value;
        this.setState({ orderMode: mode });
    };

    loadDeliveryUsers(){
        let partialUrl = api.URL;
        fetch(partialUrl + 'Order/GetDeliveryUsers')
            .then(res => res.json())
            .then(result => this.setState({ deliveryUsers: result, }))
            .catch(err => console.log(err));
    }

    componentDidMount() {        
        this.loadDeliveryUsers();        
    }

    onUserChanged(e) {
        let userId = e.target.value; 
        this.setState({ deliveryUserId: userId });
    };

    render() {
        const { classes } = this.props;
        let users = this.state.deliveryUsers;
        let deliveryUsers = users.map((user) =>
                <MenuItem value={user.UserId}>{user.FullName}</MenuItem>
            );

        return (
            <div>
                <Popup contentStyle={{ width: "500px", height: "335px", borderRadius: "5px" }} open={this.state.open}
                    className="popup-modal-container-box" modal onOpen={e => this.popupOnClose(e)}
                    onClose={this.popupOnClose} lockScroll={true} closeOnDocumentClick={false}>
                    <div className="modal-custom">
                        <div className="header">Update Order</div>
                        <div className="content-reject">
                            <Grid container spacing={2}>                                                            
                                <Grid item xs={6}>
                                    <Select fullWidth id="ddlStatus" value={this.state.status} className="selectTopMargin"
                                        onChange={ this.onStatusChanged }>
                                        <MenuItem value="0">Choose Status</MenuItem>
                                        <MenuItem value="Initiated">Initiated</MenuItem>
                                        <MenuItem value="Dispatched">Dispatched</MenuItem>
                                        <MenuItem value="Delivered">Delivered</MenuItem>
                                        <MenuItem value="Cancelled">Cancelled</MenuItem>
                                    </Select>
                                </Grid>
                                <Grid item xs={6}>
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <KeyboardDatePicker fullWidth format="dd/MM/yyyy"
                                            id="dateDelivery" label="Delivery Date"
                                            value={this.state.deliveryDate}
                                            onChange={this.onDeliveryDateChanged}
                                            KeyboardButtonProps={{
                                                'aria-label': 'change date',
                                            }}
                                        />
                                    </MuiPickersUtilsProvider>
                                </Grid>
                                <Grid item xs={6}>
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <KeyboardTimePicker fullWidth
                                            id="fromTimeDelivery" label="Delivery From Time"
                                            value={this.state.deliveryFromTime}
                                            onChange={this.onDeliveryFromTimeChanged}
                                            KeyboardButtonProps={{
                                                'aria-label': 'change time',
                                            }}
                                        />
                                    </MuiPickersUtilsProvider>
                                </Grid>
                                <Grid item xs={6}>
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <KeyboardTimePicker fullWidth
                                            id="toTimeDelivery" label="Delivery To Time"
                                            value={this.state.deliveryToTime}
                                            onChange={this.onDeliveryToTimeChanged}
                                            KeyboardButtonProps={{
                                                'aria-label': 'change time',
                                            }}
                                        />
                                    </MuiPickersUtilsProvider>
                                </Grid>
                                <Grid item xs={6}>
                                    <Select fullWidth id="ddlUser" value={this.state.deliveryUserId} onChange={ this.onUserChanged }
                                        className="selectTopMargin">
                                        {deliveryUsers}
                                    </Select>
                                </Grid>
                                <Grid item xs={6}>
                                    <Select fullWidth id="ddlOrderMode" value={this.state.orderMode} className="selectTopMargin"
                                        onChange={ this.onOrderModeChanged }>
                                       <MenuItem value="0">Choose Order Mode</MenuItem>
                                        <MenuItem value="Delivery">Delivery</MenuItem>
                                        <MenuItem value="Pickup">PickUp</MenuItem>
                                    </Select>
                                </Grid>
                            </Grid>
                        </div>
                        <Grid className="actions" container spacing={1}>
                            <Grid item xs={6}>
                                {this.state.errorMessage.length > 0 &&
                                    <span className='error'>{this.state.errorMessage}</span>}
                            </Grid>
                            <Grid item xs={3}>
                                <Button className={classes.rootModal} color="primary" variant="contained" 
                                    onClick={() => this.updateOrder()}>
                                    <SaveIcon className={classes.leftIcon} />Update</Button>
                            </Grid>
                            <Grid item xs={3}>
                                <Button className={classes.rootModal} color="primary" variant="contained" onClick={this.closeModal}>
                                    <CloseIcon className={classes.leftIcon} />Close</Button>
                            </Grid>
                        </Grid>
                    </div>
                </Popup>
            </div>
        );
    }
}

OrderModal.propTypes = {
    onClick: PropTypes.func
};

export default withStyles(useStyles)(OrderModal)