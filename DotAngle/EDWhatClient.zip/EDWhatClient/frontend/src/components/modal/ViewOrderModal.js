import React, { Component } from 'react';
import CloseIcon from '@material-ui/icons/Close';
import Popup from "reactjs-popup";
import { Button, InputLabel, Grid, withStyles, useMediaQuery } from '@material-ui/core';
import ConfirmationNumber from '@material-ui/icons/ConfirmationNumber';
import './Modal.css';
import PropTypes from 'prop-types';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import { useStyles } from '../common/useStyles';

// const useStyles = theme => ({
//     leftIcon: {
//         marginRight: theme.spacing.unit,
//     },
//     root: {
//         fontSize: 12, height: '2.1rem',
//         backgroundColor: "#0079c2",
//         "&:hover": {
//             backgroundColor: "#0079c2"
//         },
//         "&:disabled": {
//             backgroundColor: "rgba(0, 0, 0, 0.12)"
//         },
//     },
// });

class ViewOrderModal extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            open: false, rowData: [], width: null, shopName: null,
            columnDefs: [                              
                { headerName: 'Product Name', field: 'ProductName', cellStyle: { textAlign: 'center' } },
                { headerName: 'Price / Kg', field: 'RatePerKg', cellStyle: { textAlign: 'center' } },
                { headerName: 'Quantity', field: 'CategoryId', cellStyle: { textAlign: 'center' } },
            ],            
            rowData: [],
            defaultColDef: { flex: 1, sortable: true, resizable: true, filter: true },
            rowClassRules: {
                'grid-row-even': function (params) { return params.node.rowIndex % 2 === 0; },
                'grid-row-odd': function (params) { return params.node.rowIndex % 2 !== 0; }
            },
        };
        this.openModal = this.openModal.bind(this);
        this.closeModal = this.closeModal.bind(this);
        this.popupOnClose = this.popupOnClose.bind(this);
    }

    openModal(rowData, width, shopName) {
        console.log(width);
        this.setState({
            open: true, rowData: rowData, width: width, shopName: shopName
        });
    }

    closeModal() { this.setState({ open: false }); }
    popupOnClose() { }

    createOrders = () => {        
        if (typeof this.props.onClick === 'function') {
            this.props.onClick();
            this.closeModal();
        }
    }

    render() {
        const { classes } = this.props;        

        return (
            <div>
                <Popup contentStyle={{ width: this.state.width <= 755 ? "95%" : "60%", height: "80%", borderRadius: "5px" }} 
                    open={this.state.open}
                    className="popup-modal-container-box" modal onOpen={e => this.popupOnClose(e)}
                    onClose={this.popupOnClose} lockScroll={true} closeOnDocumentClick={false}>
                    <div className="modal-custom">
                        <div className="header">
                        <Grid container spacing={1}>
                            <Grid item xs={4}>
                                View Order
                            </Grid>                            
                            <Grid item xs={4}>
                                <Button fullWidth className={classes.rootModal} color="primary" variant="contained" onClick={this.closeModal}>
                                    Add More Products </Button>
                            </Grid>
                            <Grid item xs={4}>
                                <Button fullWidth className={classes.rootModal} color="primary" variant="contained" onClick={() => this.createOrders()}>
                                    Confirm Order </Button>
                            </Grid>
                        </Grid>
                        </div>
                        <div style={{ fontSize: 14 }}>Customer Name: {this.state.shopName}</div>
                        <div className="content-confirm">
                            <div className="ag-theme-alpine" style={{ width: "100%", height: 450, marginTop: 0 }}>
                                <AgGridReact
                                    columnDefs={this.state.columnDefs} rowData={this.state.rowData}
                                    onGridReady={this.onGridReady} defaultColDef={this.state.defaultColDef}
                                    frameworkComponents={this.state.frameworkComponents} context={this.state.context}
                                    gridOptions={this.gridOptions} paginationPageSize={50}
                                    components={this.state.components} rowClassRules={this.state.rowClassRules}                                     
                                />
                            </div>
                        </div>                        
                    </div>
                </Popup>
            </div>
        );
    }
}

ViewOrderModal.propTypes = {
    onClick: PropTypes.func
};

export default withStyles(useStyles)(ViewOrderModal)