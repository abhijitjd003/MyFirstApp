import React, { Component } from 'react';
import NavMenu from './NavMenu';
import { withStyles } from '@material-ui/core/styles';
import { useMediaQuery } from '@material-ui/core';
import BottomAppBar from './BottomAppBar';

const useStyles = theme => ({
    root: {
        display: 'flex',
        paddingBottom: '5rem',
        backgroundColor: '#f6f7f2',
    },
    toolbar: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'flex-end',
        padding: theme.spacing(0, 1),
        ...theme.mixins.toolbar,
    },
    content: {
        flexGrow: 1,
        padding: theme.spacing(5, 10, 2, 10),
        backgroundColor: '#f6f7f2',
    },
    contentsm: {
        flexGrow: 1,
        padding: theme.spacing(0, 2, 0, 2),
        backgroundColor: '#f6f7f2',
    },
});

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);    
    return <Component mediaQuery={mediaQuery} {...props} />;
};

class Layout extends Component {
    constructor(props) {
        super(props);
        this.state = { };
    }

    render() {
        const { classes, mediaQuery } = this.props;
        const cols = mediaQuery ? 3 : 12;

        return (
            <div style={{ position: 'relative', minHeight: '100vh', backgroundColor: '#f6f7f2' }}>
                <div className={classes.root}>
                    <NavMenu userLogin={this.props.userLogin} 
                        userEmail={this.props.userEmail} 
                        userName={this.props.userName} 
                        userAliasName={this.props.userAliasName}
                        sortByPopular={this.props.sortByPopular}
                        sortByNew={this.props.sortByNew}
                        prev_page={this.props.prev_page}
                        addQuestion={this.props.addQuestion}
                        isPopular={this.props.isPopular}
                        searchTopics={this.props.searchTopics}
                        handleMobileMenuOpen={this.props.handleMobileMenuOpen}
                        handleMobileMenuClose={this.props.handleMobileMenuClose}
                        anchorEl={this.props.anchorEl}
                        anchorElProfile={this.props.anchorElProfile}
                        webNotifications={this.props.webNotifications}
                        handleUserProfileOpen={this.props.handleUserProfileOpen}
                        handleUserProfileClose={this.props.handleUserProfileClose}
                        userLogout={this.props.userLogout}
                    />
                    <main className={ mediaQuery ? classes.content : classes.contentsm }>
                        <div className={classes.toolbar} />
                        {this.props.children}
                    </main>                    
                </div>
                <BottomAppBar />
            </div>
        );
    }
}

export default withStyles(useStyles)(withMediaQuery('(min-width:600px)')(Layout))
