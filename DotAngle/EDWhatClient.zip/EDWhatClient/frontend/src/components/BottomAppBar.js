import React, { useState } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { Grid, ListItem, ListItemText, Menu, MenuItem, IconButton, useMediaQuery } from '@material-ui/core';
import MoreIcon from '@material-ui/icons/MoreVert';

const useStyles = makeStyles((theme) => ({
  text: {
    padding: theme.spacing(2, 2, 0),
  },
  paper: {
    paddingBottom: 50,
  },
  marginLeft: {
    marginLeft: theme.spacing(7),
    //marginTop: theme.spacing(1),
  },
  subheader: {
    backgroundColor: theme.palette.background.paper,
  },
  appBar: {
    top: 'auto',
    bottom: 0
  },
  grow: {
    flexGrow: 1,
  },
  footerBar: {
    backgroundColor: '#c2272d', 
    width: '100%', 
    position: 'absolute', 
    bottom: 0, 
    margin: 0, 
    height: '5rem'
  },
}));

export default function BottomAppBar() {
  const classes = useStyles();
  const matches = useMediaQuery('(min-width:600px)');
  const [anchorEl, setAnchorEl] = useState(null);

  const handleMobileMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMobileMenuClose = () => {
    setAnchorEl(null);
  };

  return (
    <React.Fragment>
            { matches ?
            <Grid container spacing={4} className={classes.footerBar}>
                <Grid item className={classes.marginLeft}>
                    <ListItem button>
                        <ListItemText className="drawerItems" primary='About' />
                    </ListItem>
                </Grid>
                <Grid item>
                    <ListItem button>
                        <ListItemText className="drawerItems" primary='Careers' />
                    </ListItem>
                </Grid>
                <Grid item>
                    <ListItem button>
                        <ListItemText className="drawerItems" primary='Terms' />
                    </ListItem>
                </Grid>
                <Grid item>
                    <ListItem button>
                        <ListItemText className="drawerItems" primary='Privacy' />
                    </ListItem>
                </Grid>
                <Grid item>
                    <ListItem button>
                        <ListItemText className="drawerItems" primary='Acceptable Use' />
                    </ListItem>
                </Grid>
                <Grid item>
                    <ListItem button>
                        <ListItemText className="drawerItems" primary='Businesses' />
                    </ListItem>
                </Grid>
                <Grid item>
                    <ListItem button>
                        <ListItemText className="drawerItems" primary='Your Ad Choices' />
                    </ListItem>
                </Grid>
            </Grid> :

            <React.Fragment>
            <IconButton
                                        aria-label="show more"                                        
                                        aria-haspopup="true"
                                        onClick={handleMobileMenuOpen}
                                        className={classes.activeColor}
                                    >
                                        <MoreIcon />
                                    </IconButton>
                                    <Menu
                                        id="simple-menu"
                                        anchorEl={anchorEl}
                                        keepMounted
                                        open={Boolean(anchorEl)}
                                        onClose={handleMobileMenuClose}
                                    >
                                        <MenuItem onClick >
                                          About
                                        </MenuItem>
                                        <MenuItem onClick >
                                          Careers
                                        </MenuItem>
                                        <MenuItem onClick >
                                          Terms
                                        </MenuItem>
                                        <MenuItem onClick >
                                          Privacy
                                        </MenuItem>
                                        <MenuItem onClick >
                                          Acceptable Use
                                        </MenuItem>
                                        <MenuItem onClick >
                                          Businesses
                                        </MenuItem>
                                        <MenuItem onClick >
                                          Your Ad Choices
                                        </MenuItem>
                                    </Menu>
                                    </React.Fragment> }
    </React.Fragment>
  );
}
