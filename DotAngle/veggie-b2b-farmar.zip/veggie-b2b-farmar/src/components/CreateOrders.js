import React, { Component } from 'react';
import './common/Common.css';
import { 
    Grid, withStyles, Button, Select, MenuItem, TextField, Table, TableBody, TableContainer, TableCell, TableHead, TableRow,
    Paper, useMediaQuery, Card, CardContent, InputLabel, FormControlLabel, Switch
} from '@material-ui/core';
import './common/CommonModal.css';
import { withRouter } from 'react-router-dom';
import Loader from './loader/Loader';
import ViewOrderModal from './modal/ViewOrderModal';
import ErrorModal from './modal/ErrorModal';
import api from './common/APIValues';
import CreateIcon from '@material-ui/icons/Create';
import Autocomplete from '@material-ui/lab/Autocomplete';
import AddIcon from '@material-ui/icons/Add';
import RemoveIcon from '@material-ui/icons/Remove';
import { useStyles } from './common/useStyles';

// const useStyles = theme => ({
//     leftIcon: {
//         marginRight: theme.spacing.unit,
//     },
//     topMargin: {
//         marginTop: 10
//     },
//     root: {
//         fontSize: 12, height: '2.1rem', marginTop: 30,
//         backgroundColor: "#0079c2",
//         "&:hover": {
//             backgroundColor: "#0079c2"
//         },
//         "&:disabled": {
//             backgroundColor: "rgba(0, 0, 0, 0.12)"
//         },
//     },
//     rootEdit: {
//         fontSize: 12, height: '2.1rem', marginTop: 5,
//         backgroundColor: "#0079c2",
//         "&:hover": {
//             backgroundColor: "#0079c2"
//         },
//         "&:disabled": {
//             backgroundColor: "rgba(0, 0, 0, 0.12)"
//         },
//     },
//     table: {
//         minWidth: 300,
//     },
// });

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);    
    return <Component mediaQuery={mediaQuery} {...props} />;
};

const validateForm = (errors) => {
    let valid = true;
    Object.keys(errors).map(function (e) {
        if (errors[e].length > 0) {
            valid = false;
        }        
    });
    return valid;
}

class CreateOrders extends Component {
    constructor(props) {
        super(props);
        this.state = {
            shopId: 0, userId: null, vendors: [], quantity: 0, shopName: null, orderNo: null, quantityOne: false,
            showDetails: false, contactPerson: null, mobileNo: null, lastOrderedDate: null, outstanding: null,
            errors: {
                vendor: '',
            },
            rowData: [],            
        };
        this.onVendorChanged = this.onVendorChanged.bind(this);
    }

    loadVendors(){
        let status = 'Approved';
        let partialUrl = api.URL;
        fetch(partialUrl + 'Customer/GetCustomers?Status=' + status)
            .then(res => res.json())
            .then(result => {
                this.setState({ vendors: result, })
            })
            .catch(err => console.log(err));
    }

    loadProducts(){
        let partialUrl = api.URL;       
        fetch(partialUrl + 'Product/GetProductsInOrder')
            .then(res => res.json())
            .then(result => {
                this.setState({ rowData: result, loading: false })
                let orderNo = this.props.location.orderNoRef;
                if(orderNo){
                    let shopId = this.props.location.shopIdRef;
                    this.setState({ shopId: shopId, orderNo: orderNo });
                    this.loadOrderProducts(orderNo);                    
                }
                console.log(this.state.rowData);
            })
            .catch(err => console.log(err));
    }

    loadOrderProducts(orderNo){
        let partialUrl = api.URL;
        fetch(partialUrl + 'Order/GetOrderProducts?OrderNo='+ orderNo)
            .then(res => res.json())
            .then(result => {
                let rowData = this.state.rowData;
                result.orders.map((orderData) => {
                    this.state.rowData.map((data, index) => {
                        if(orderData.ProductId === data.ProductId) {
                            if(this.state.quantityOne) {
                                rowData[index].Quantity = Number(orderData.TotalWeight);
                            } else {
                                rowData[index].Quantity = Number(orderData.TotalWeight)/Number(data.MinPurchaseQuantity);
                            }
                            rowData[index].CategoryId = Number(orderData.TotalWeight);
                        }
                    });
                });
                this.setState({ rowData, loading: false });
            })
            .catch(err => console.log(err));
    }

    viewOrder() {
        if (validateForm(this.state.errors) && this.state.shopId > 0) {
            let isValid = false;
            this.state.rowData.map((data) => {
                if(data.Quantity > 0){
                    isValid = true;
                }
            });

            if(isValid) {
                let orderData = [];
                this.state.rowData.map((data) => {
                    if(data.Quantity > 0){
                        orderData.push(data)
                    }
                });
                this.refs.viewOrderModalComp.openModal(orderData, window.innerWidth, this.state.shopName);
            } else {
                var errorMsg = 'Add at least one product to create order.';
                this.refs.errModalComp.openModal(errorMsg);
            }
        } else {
            let errors = this.state.errors;
            if (this.state.shopId === 0) {
                errors.vendor = 'Select vendor name';
            }
            this.setState({ errors });
        }
    }

    createOrders = () => {
        if (validateForm(this.state.errors) && this.state.shopId > 0) {
            let isValid = false;
            this.state.rowData.map((data) => {
                if(data.Quantity > 0){
                    isValid = true;
                }
            });

            if(isValid) {
                this.setState({ loading: true })
                if(this.state.orderNo){
                    this.updateOrders();
                } else {
                    this.createNewOrders();
                }
            } else {
                var errorMsg = 'Add at least one product to create order.';
                this.refs.errModalComp.openModal(errorMsg);
            }
        } else {
            let errors = this.state.errors;
            if (this.state.shopId === 0) {
                errors.vendor = 'Select vendor name';
            }
            this.setState({ errors });
        }
    }

    createNewOrders(){
        let orderDetails = {};
        orderDetails.Products = this.state.rowData;
        orderDetails.ShopId = this.state.shopId;
        orderDetails.UserId = this.state.userId;
        orderDetails.QuantityOne = this.state.quantityOne;
        orderDetails.OrderMode = 'Delivery';
        let partialUrl = api.URL;
        fetch(partialUrl + 'Order/CreateOrders', {
            method: 'POST',
            mode: 'cors',
            body: JSON.stringify(orderDetails),
            headers: { 'Content-Type': 'application/json' }
        }).then((response) => response.json())
            .then((responseJson) => {
                if (responseJson) {
                    this.setState({ loading: false })
                    const { history } = this.props;
                    if (history) history.push('/ManageOrders');
                }
            })
    }

    updateOrders(){
        let orderDetails = {};
        orderDetails.Products = this.state.rowData;
        orderDetails.OrderNo = this.state.orderNo;
        orderDetails.UserId = this.state.userId;
        orderDetails.QuantityOne = this.state.quantityOne;
        let partialUrl = api.URL;
        fetch(partialUrl + 'Order/UpdateCreatedOrders', {
            method: 'POST',
            mode: 'cors',
            body: JSON.stringify(orderDetails),
            headers: { 'Content-Type': 'application/json' }
        }).then((response) => response.json())
            .then((responseJson) => {
                if (responseJson) {
                    this.setState({ loading: false })
                    const { history } = this.props;
                    if (history) history.push('/ManageOrders');
                }
            })
    }

    componentDidMount() {
        this.setState({ loading: true });
        let loggedInUser = sessionStorage.getItem('loggedInUser');

        if(loggedInUser) {
            this.setState({ userId: loggedInUser });
            this.loadVendors();
            this.loadProducts();            
        } else {
            const { history } = this.props;
            if (history) history.push('/Home');
        }
    }

    onVendorChanged(e) {
        let shopId = e.target.value; 
        this.setState({ shopId: shopId });
        if(shopId === 0){
            this.state.errors.vendor = 'Select vendor name';
        }else{
            this.state.errors.vendor = '';            
        }
    };

    getCustomerDetails(shopId) {
        let partialUrl = api.URL;
        fetch(partialUrl + 'Customer/GetCustomer?ShopId=' + shopId)
            .then(res => res.json())
            .then(result => {
                this.setState({
                    showDetails: true,
                    mobileNo: result.MobileNo,
                    contactPerson: result.ContactPerson,
                    lastOrderedDate: result.LastOrderedDate,
                    outstanding: result.Outstanding,
                })
            })
            .catch(err => console.log(err));
    }

    handleChange = (productId, index, event) => {
        const { name, value } = event.target;
        let rowData = this.state.rowData;
        this.state.rowData.map((data) => {
            if(productId === data.ProductId){        
                rowData[index].Quantity = Number(value);
            }
        });
        this.setState({ rowData });
    }

    handleToggle = (event) => {
        this.setState({ quantityOne: event.target.checked, loading: true });
        if(this.state.orderNo) {
            this.loadOrderProducts(this.state.orderNo);
        } else {
            this.setState({ loading: false });
        }
    }

    increment(productId, index){
        let rowData = this.state.rowData;
        this.state.rowData.map((data) => {
            if(productId === data.ProductId){
                let currentValue = rowData[index].Quantity;
                rowData[index].Quantity = Number(currentValue + 1);
                let displayValue = rowData[index].CategoryId;
                rowData[index].CategoryId = this.state.quantityOne ? Number(displayValue + 1) 
                    : Number(displayValue + data.MinPurchaseQuantity);
            }
        });
        this.setState({ rowData });
    }

    decrement(productId, index){
        let rowData = this.state.rowData;
        this.state.rowData.map((data) => {
            if(productId === data.ProductId){
                let currentValue = rowData[index].Quantity;
                let displayValue = rowData[index].CategoryId;
                if(currentValue > 0 && displayValue > 0) {
                    rowData[index].Quantity = Number(currentValue - 1);
                    rowData[index].CategoryId = this.state.quantityOne ? Number(displayValue - 1) : 
                        Number(displayValue - data.MinPurchaseQuantity);
                }
            }
        });
        this.setState({ rowData });
    }

    render() {
        const { classes, mediaQuery } = this.props;
        const col3 = mediaQuery ? 3 : 12;
        const col2 = mediaQuery ? 2 : 6;
        const col0 = mediaQuery ? 6 : 0;
        const col1 = mediaQuery ? 1 : 0;
        const col12 = mediaQuery ? 12 : 12;
        const col6 = mediaQuery ? 3 : 6;
        const height = mediaQuery ? '50%' : '20%';

        let vendors = this.state.vendors;
        let vendorNames = vendors.map((vendor) =>
            <MenuItem value={vendor.ShopId}>{vendor.ShopName}</MenuItem>
        );
        
        return (
            <div>
                {this.state.loading ? (
                    <Loader />
                ) : (
                    <div>
                        <ErrorModal ref="errModalComp" />
                        <ViewOrderModal ref="viewOrderModalComp" onClick={() => this.createOrders()} />
                        <h2 className="header-text-color">Create Orders</h2>

                        <Grid container spacing={0}>
                            <Grid item xs={col3}>
                                { this.state.orderNo ?
                                (<Select fullWidth disabled id="ddlVendor" value={this.state.shopId} className={classes.topMarginMd}
                                    onChange={ this.onVendorChanged }>
                                    <MenuItem value={0}>Choose Customer Name</MenuItem>
                                    {vendorNames}
                                </Select>) :
                                (<Autocomplete debug id="debug" options={vendors} getOptionLabel={(option) => option.ShopName}                                   
                                    onChange={(event, value) => {
                                        if(value){
                                            let shopId = value.ShopId;
                                            this.setState({shopId: shopId, shopName: value.ShopName});
                                            if(shopId === 0){
                                                this.state.errors.vendor = 'Select customer name';
                                            }else{
                                                this.state.errors.vendor = '';                                                
                                                this.getCustomerDetails(shopId);
                                            }                                            
                                        } else { this.setState({shopId: 0}); }
                                    }}
                                    renderInput={params => (
                                        <TextField {...params} label="Choose Customer Name" margin="normal" fullWidth />
                                    )}
                                />)                                
                                }
                                {this.state.errors.vendor.length > 0 &&
                                    <span className='error'>{this.state.errors.vendor}</span>}
                            </Grid>
                            <Grid item xs={col1}></Grid>
                            <Grid item xs={col0}>                                
                                <FormControlLabel style={{ marginTop: 32 }}
                                    control={<Switch checked={this.state.quantityOne} onChange={this.handleToggle} color="primary" 
                                    name="quantityOne" style={{ color: this.state.quantityOne ? '#347f58' : '' }} />}
                                    label="Set Quantity Incremental To 1"
                                />
                            </Grid>
                            <Grid item xs={col2}>                                
                                <Button fullWidth className={this.state.orderNo ? classes.rootEdit : classes.rootCreate} variant="contained"
                                    color="primary" onClick={() => this.viewOrder()}>
                                    <CreateIcon className={classes.leftIcon} />Create</Button>
                            </Grid>                            
                        </Grid>
                        
                        { this.state.showDetails &&
                        <Grid container spacing={0}>                                                            
                            <Grid item xs={col12}>
                                <Card style={{ border: '1px solid #f16623' }}>
                                    <CardContent> 
                                        <Grid container spacing={0}>                                                            
                                            <Grid item xs={col6}>
                                                Name: { this.state.contactPerson }
                                            </Grid>                            
                                            <Grid item xs={col6}>
                                                Mobile No: { this.state.mobileNo }
                                            </Grid>  
                                            <Grid item xs={col6}>
                                                Last Order Date: { this.state.lastOrderedDate }
                                            </Grid>
                                            <Grid item xs={col6}>
                                                Outstanding: { this.state.outstanding }
                                            </Grid>                              
                                        </Grid>                                                                  
                                    </CardContent>
                                </Card>
                            </Grid>
                        </Grid>
                        }

                        <Grid container spacing={0}>
                            <Grid item xs={col12}>
                                <TableContainer style={{ width: !mediaQuery ? '99%' : '100%' }} component={Paper} className={classes.topMarginTab}>
                                    { mediaQuery ?
                                    (<Table className={classes.table} size="small" aria-label="simple table">
                                        <TableHead className="table-header-custom">
                                            <TableRow>                                                
                                                <TableCell style={{ color: 'white', fontSize: 16 }} align="center">Product Name</TableCell>
                                                <TableCell align="center"></TableCell>                                                
                                                <TableCell style={{ color: 'white', fontSize: 16 }} align="center">Price / Kg</TableCell>
                                                <TableCell style={{ color: 'white', fontSize: 16 }} align="center">Quantity In Kg</TableCell>                                                
                                                <TableCell style={{ color: 'white', fontSize: 16 }} align="center">Min Quantity In Kg</TableCell>                                                                                  
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                        {this.state.rowData.map((data, index) => (
                                            <TableRow key={data.ProductId}>                                                
                                                <TableCell align="center">{data.ProductName}</TableCell>
                                                <TableCell component="th" scope="row" align="center">
                                                    <img src={data.FileName} height={height} />
                                                </TableCell>                                                
                                                <TableCell align="center">{data.RatePerKg}</TableCell>
                                                <TableCell align="center">                                                                                                        
                                                    <RemoveIcon onClick={() => this.decrement(data.ProductId, index)} className={classes.leftIcon} />
                                                    <TextField InputProps={{ inputProps: { style: { textAlign: 'center', width: 65 } } }}
                                                            onChange={this.handleChange.bind(this, data.ProductId, index)} 
                                                        value={data.CategoryId} InputLabelProps={{ shrink: true, style: { fontSize: 18 } }}/>                                                    
                                                    <AddIcon onClick={() => this.increment(data.ProductId, index)} className={classes.leftIcon} />
                                                </TableCell>                                                
                                                <TableCell align="center">{data.MinPurchaseQuantity}</TableCell>                                                
                                            </TableRow>
                                        ))}
                                        </TableBody>
                                    </Table>) :
                                    (
                                        <Table className={classes.table} size="small" aria-label="simple table">
                                        <TableHead className="table-header-custom">
                                            <TableRow>                                                
                                                <TableCell style={{ color: 'white', fontSize: 16 }} align="center"></TableCell>
                                                <TableCell align="center"></TableCell>                                                
                                                <TableCell style={{ color: 'white', fontSize: 16 }} align="center">Quantity</TableCell>                                                                                                
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                        {this.state.rowData.map((data, index) => (
                                            <TableRow key={data.ProductId}>                                                
                                                <TableCell align="center">
                                                    {data.ProductName} <br></br>
                                                    Price / Kg: {data.RatePerKg} <br></br>
                                                    Min Quantity: {data.MinPurchaseQuantity}
                                                </TableCell>
                                                <TableCell component="th" scope="row" align="center">
                                                    <img src={data.FileName} height={height} />
                                                </TableCell>                                                
                                                <TableCell align="center">                                                                                                        
                                                    <RemoveIcon onClick={() => this.decrement(data.ProductId, index)} className={classes.leftIcon} />
                                                    <TextField InputProps={{ inputProps: { style: { textAlign: 'center', width: 65 } } }}
                                                            onChange={this.handleChange.bind(this, data.ProductId, index)} 
                                                        value={data.CategoryId} InputLabelProps={{ shrink: true, style: { fontSize: 18 } }}/>                                                    
                                                    <AddIcon onClick={() => this.increment(data.ProductId, index)} className={classes.leftIcon} />
                                                </TableCell>                                                                                                
                                            </TableRow>
                                        ))}
                                        </TableBody>
                                    </Table>
                                    )}
                                </TableContainer>
                            </Grid>                            
                        </Grid>
                    </div>
                    )}
            </div>
        );
    }
}

export default withRouter(withStyles(useStyles)(withMediaQuery('(min-width:600px)')(CreateOrders)))