import React, { Component } from 'react';
import './common/Common.css';
import { Button, TextField, Grid, withStyles, useMediaQuery, Select, MenuItem } from '@material-ui/core';
import './common/CommonModal.css';
import { withRouter } from 'react-router-dom';
import Loader from './loader/Loader';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import ConfirmModal from './modal/ConfirmModal';
import ErrorModal from './modal/ErrorModal';
import api from './common/APIValues';
import CreateIcon from '@material-ui/icons/Create';
import DeleteForeverIcon from '@material-ui/icons/DeleteForever';
import { useStyles } from './common/useStyles';

// const useStyles = theme => ({
//     leftIcon: {
//         marginRight: theme.spacing.unit,
//     },
//     topMargin: {
//         marginTop: 16,
//     },
//     root: {
//         fontSize: 12, height: '2.1rem', marginTop: 20,
//         backgroundColor: "#0079c2",
//         "&:hover": {
//             backgroundColor: "#0079c2"
//         },
//         "&:disabled": {
//             backgroundColor: "rgba(0, 0, 0, 0.12)"
//         },
//     },
// });

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);    
    return <Component mediaQuery={mediaQuery} {...props} />;
};

const validateForm = (errors) => {
    let valid = true;
    Object.keys(errors).map(function (e) {
        if (errors[e].length > 0) {
            valid = false;
        }        
    });
    return valid;
}

class GradeAStock extends Component {
    constructor(props) {
        super(props);
        this.state = {
            productName: null, weight: null, reasonType: 0, productId: 0,
            errorMessage: null, loading: false, userId: null, products: [],
            errors: {
                productId: '',
                weight: '',
                reasonType: ''
            },
            columnDefs: [                
                { headerName: 'Product Name', field: 'ProductName', cellStyle: { 'text-align': "center" } },
                { headerName: 'Weight', field: 'TotalWeight', cellStyle: { 'text-align': "center" } },
                { headerName: 'Reason', field: 'ReasonType', cellStyle: { 'text-align': "center" } },
                { headerName: 'Removed Date', field: 'CreatedDateTime', cellStyle: { 'text-align': "center" } },
                { headerName: 'Removed User', field: 'CreatedUserId', cellStyle: { 'text-align': "center" } },                
            ],
            context: { componentParent: this },
            frameworkComponents: { },
            rowData: [],
            defaultColDef: { flex: window.innerWidth <= 600 ? 0 : 1, width: 110, sortable: true, resizable: true, filter: true },
            rowClassRules: {
                'grid-row-even': function (params) { return params.node.rowIndex % 2 === 0; },
                'grid-row-odd': function (params) { return params.node.rowIndex % 2 !== 0; }
            },
        };

        this.onProductChanged = this.onProductChanged.bind(this);
        this.onReasonChanged = this.onReasonChanged.bind(this);
    }

    validateAllInputs(){
        if(this.state.productId === 0 || this.state.reasonType === '0' || !this.state.weight){
            return false;
        }
        else{
            return true;
        }
    }

    remove = (event) => {
        event.preventDefault();
        if (validateForm(this.state.errors) && this.validateAllInputs()) {
            this.setState({ loading: true });
            let mainStock = {};            
            mainStock.ProductId = this.state.productId;
            mainStock.TotalWeight = this.state.weight;
            mainStock.ReasonType = this.state.reasonType;
            mainStock.CreatedUserId = this.state.userId;
            this.removeMainStock(mainStock);
        } else {
            let errors = this.state.errors;
            if (this.state.productId === 0) {
                errors.productId = 'Select product name';
            }
            if (!this.state.weight) {
                errors.weight = 'Weight is required';
            }
            if (this.state.reasonType === 0) {
                errors.reasonType = 'Select reason type';
            }
            this.setState({ errors, errorMessage: null });
        }
    }

    loadRemovedGradeAStocks(){
        let partialUrl = api.URL;
        fetch(partialUrl + 'Stock/GetRemovedGradeAStocks')
            .then(res => res.json())
            .then(result => this.setState({ rowData: result, loading: false }))
            .catch(err => console.log(err));
    }

    loadProducts(){
        let partialUrl = api.URL;
        fetch(partialUrl + 'Product/GetValidProducts')
            .then(res => res.json())
            .then(result => this.setState({ products: result, loading: false }))
            .catch(err => console.log(err));
    }

    componentDidMount() {
        let loggedInUser = sessionStorage.getItem('loggedInUser');

        if(loggedInUser) {
            this.setState({ userId: loggedInUser, loading: true });
            this.loadProducts();
            this.loadRemovedGradeAStocks();
        } else {
            const { history } = this.props;
            if (history) history.push('/Home');
        }
    }

    removeMainStock(mainStock) {
        let partialUrl = api.URL;
        fetch(partialUrl + 'Stock/RemoveGradeAStock', {
            method: 'POST',
            mode: 'cors',
            body: JSON.stringify(mainStock),
            headers: { 'Content-Type': 'application/json' }
        }).then((response) => response.json())
            .then((responseJson) => {
                if (responseJson) {
                    this.loadRemovedGradeAStocks();
                    this.setState({ 
                        loading: false, productId: 0, reasonType: '0', weight: null
                    });
                } else {
                    this.setState({ 
                        loading: false, productId: 0, reasonType: '0', weight: null
                    });
                    var errorMsg = 'Grade A stocks are already closed for this product.';
                    this.refs.errModalComp.openModal(errorMsg);
                }
            })
    }

    handleChange = (event) => {
        event.preventDefault();
        const { name, value } = event.target;
        let errors = this.state.errors;

        switch (name) {
            case 'weight':
                this.state.weight = value;
                errors.weight = value.length <= 0 ? 'Weight is required' : !Number(value) ? 'weight is not valid' : '';
                break;            
            default:
                break;
        }
        this.setState({ errors, [name]: value });
    }

    onProductChanged(e) {
        let productId = e.target.value; 
        this.setState({ productId: productId });
        if(productId === 0){
            this.state.errors.productId = 'Select product name';
        }else{
            this.state.errors.productId = '';
        }
    };

    onReasonChanged(e) {
        let reasonType = e.target.value; 
        this.setState({ reasonType: reasonType });
        if(reasonType === 0){
            this.state.errors.reasonType = 'Select reason type';
        }else{
            this.state.errors.reasonType = '';
        }
    };

    render() {
        const { classes, mediaQuery } = this.props;
        const col3 = mediaQuery ? 3 : 12;        
        const col4 = mediaQuery ? 4 : 12;
        const col2 = mediaQuery ? 2 : 12;

        let products = this.state.products.map((product) =>
            <MenuItem value={product.ProductId}>{product.ProductName}</MenuItem>
        );
        
        return (
            <div>
                {this.state.loading ? (
                    <Loader />
                ) : (
                    <div>
                        <ErrorModal ref="errModalComp" />
                        <ConfirmModal ref="cnfrmModalComp" onClick={(e) => this.DeleteRecord(e)} />

                        <form onSubmit={this.loginToDashboard} noValidate>
                            <h2 className="header-text-color">Remove Grade A Stocks</h2>
                            <Grid container spacing={3}>
                                <Grid item xs={col3}>
                                    <Select fullWidth id="ddlProduct" value={this.state.productId} className="selectTopMargin"
                                        onChange={ this.onProductChanged }>
                                        <MenuItem value={0}>Choose Product</MenuItem>
                                        {products}
                                    </Select>
                                    {this.state.errors.productId.length > 0 &&
                                        <span className='error'>{this.state.errors.productId}</span>}    
                                </Grid>
                                <Grid item xs={col3}>
                                    <TextField fullWidth name="weight" id="txtWeight" 
                                        label="Weight" InputLabelProps={{ shrink: true, style: { fontSize: 18 } }}
                                        onChange={this.handleChange} noValidate value={this.state.weight} />
                                    {this.state.errors.weight.length > 0 &&
                                        <span className='error'>{this.state.errors.weight}</span>}                                
                                </Grid>
                                <Grid item xs={col4}>
                                    <Select fullWidth id="ddlReasonType" value={this.state.reasonType} className="selectTopMargin"
                                        onChange={ this.onReasonChanged }>
                                        <MenuItem value="0">Choose Reason Type</MenuItem>
                                        <MenuItem value="Waste">Waste</MenuItem>
                                        <MenuItem value="Rejected">Rejected</MenuItem>
                                        <MenuItem value="Expired">Expired</MenuItem>
                                        <MenuItem value="Others">Others</MenuItem>
                                    </Select>
                                    {this.state.errors.reasonType.length > 0 &&
                                        <span className='error'>{this.state.errors.reasonType}</span>}
                                </Grid>
                                <Grid item xs={col2}>
                                    <Button fullWidth className={classes.root} variant="contained"
                                        color="primary" onClick={this.remove}>
                                        <DeleteForeverIcon className={classes.leftIcon} />Remove</Button>
                                </Grid>
                            </Grid>
                        </form>

                        <Grid container spacing={0}>
                            <Grid item xs={12}>
                                <div className="ag-theme-alpine" style={{ width: "100%", height: 550, marginTop: 10 }}>
                                    <AgGridReact
                                        columnDefs={this.state.columnDefs} rowData={this.state.rowData}
                                        onGridReady={this.onGridReady} defaultColDef={this.state.defaultColDef}
                                        frameworkComponents={this.state.frameworkComponents} context={this.state.context}
                                        pagination={true} gridOptions={this.gridOptions} paginationAutoPageSize={true}
                                        components={this.state.components} rowClassRules={this.state.rowClassRules} suppressClickEdit={true}
                                    />
                                </div>
                            </Grid>                        
                        </Grid>
                    </div>
                    )}
            </div>
        );
    }
}

export default withRouter(withStyles(useStyles)(withMediaQuery('(min-width:600px)')(GradeAStock)))