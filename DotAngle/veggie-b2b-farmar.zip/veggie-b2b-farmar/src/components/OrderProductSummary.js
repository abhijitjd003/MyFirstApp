import React, { Component } from 'react';
import { 
    Grid, withStyles, Paper, useMediaQuery, Card, CardContent, Button
} from '@material-ui/core';
import api from './common/APIValues';
import Loader from './loader/Loader';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import { useStyles } from './common/useStyles';

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);    
    return <Component mediaQuery={mediaQuery} {...props} />;
};

class OrderProductSummary extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            open: false, rowData: [], loading: false, orderedDate: null, productName: null, totalWeight: null,
            columnDefs: [
                { headerName: 'Shop Name', field: 'ShopName', cellStyle: { 'text-align': "center" } },
                { headerName: 'Ordered Weight', field: 'TotalWeight', cellStyle: { 'text-align': "center" } }
            ],
            context: { componentParent: this },
            frameworkComponents: { },
            rowData: [],
            defaultColDef: { sortable: true, resizable: true, filter: true, flex: 1 },
            rowClassRules: {
                'grid-row-even': function (params) { return params.node.rowIndex % 2 === 0; },
                'grid-row-odd': function (params) { return params.node.rowIndex % 2 !== 0; }
            },
            suppressRowClickSelection: true,
            rowSelection: 'multiple',
        };
    }

    loadProductSummary(orderedDate, productId) {
        let partialUrl = api.URL;
        fetch(partialUrl + 'OrderSummary/GetProductSummary?OrderedDate='+ orderedDate + '&ProductId=' + productId)
            .then(res => res.json())
            .then(result => {
                this.setState({ rowData: result, loading: false, orderedDate: orderedDate });
            })
            .catch(err => console.log(err));
    }

    componentDidMount() {
        let loggedInUser = sessionStorage.getItem('loggedInUser');
        
        if(loggedInUser) {
            if(this.props.location.productData) {
                let orderedDateRef = sessionStorage.getItem('OrderedDateRef');
                let productIdRef = this.props.location.productData.productIdRef;
                let productNameRef = this.props.location.productData.productNameRef;
                let totalWeightRef = this.props.location.productData.totalWeightRef;
                if(orderedDateRef && productIdRef && productNameRef && totalWeightRef) {
                    this.setState({ loading: true, productName: productNameRef, totalWeight: totalWeightRef });
                    this.loadProductSummary(orderedDateRef, productIdRef);
                }
            }
        } else {
            const { history } = this.props;
            if (history) history.push('/Home');
        }
    }

    goBack = () => {
        const { history } = this.props;
        if (history) history.push('/OrderSummaryReport');
    };

    render() {
        const { classes, mediaQuery } = this.props;
        const col7 = mediaQuery ? 10 : 8;
        const col2 = mediaQuery ? 2 : 4;
        const col9 = mediaQuery ? 9 : 12;

        return (
            <div>
                {this.state.loading ? (
                    <Loader />
                ) : (
                    <div>
                        <Grid container spacing={1}>
                            <Grid item xs={col7}>
                                <h2 className="header-text-color">Order Product Breakup</h2>
                            </Grid>
                            <Grid item xs={col2}>
                                <Button fullWidth className={classes.root} variant="contained"
                                    color="primary" onClick={this.goBack}>
                                    <ArrowBackIcon className={classes.leftIcon} />Go Back</Button>
                            </Grid>
                        </Grid>

                        <Grid container spacing={0}>                                                            
                            <Grid item xs={12}>
                                <Card style={{ border: '1px solid #ff9800' }}>
                                    <CardContent> 
                                        <Grid container spacing={0}>
                                            <Grid item xs={4}>
                                                Product Name: { this.state.productName }
                                            </Grid>                                                             
                                            <Grid item xs={4}>
                                                Order Date: { sessionStorage.getItem('OrderedDateRef') }
                                            </Grid>                                                                       
                                            <Grid item xs={4}>
                                                Ordered Total Weight: { this.state.totalWeight }
                                            </Grid>
                                        </Grid>
                                    </CardContent>
                                </Card>
                            </Grid>
                        </Grid>

                        <Grid container spacing={0}>
                            <Grid item xs={12}>
                                <div className="ag-theme-alpine" style={{ width: "100%", height: 525, marginTop: 10 }}>
                                    <AgGridReact
                                        columnDefs={this.state.columnDefs} rowData={this.state.rowData}
                                        onGridReady={this.onGridReady} defaultColDef={this.state.defaultColDef}
                                        frameworkComponents={this.state.frameworkComponents} context={this.state.context}
                                        pagination={true} gridOptions={this.gridOptions} paginationPageSize={100}
                                        components={this.state.components} rowClassRules={this.state.rowClassRules} 
                                        suppressClickEdit={true}
                                        rowSelection={this.state.rowSelection} suppressRowClickSelection={true}
                                    />
                                </div>
                            </Grid>                        
                        </Grid>
                    </div>
                    )}
            </div>
        );
    }
}

export default withStyles(useStyles)(withMediaQuery('(min-width:600px)')(OrderProductSummary))