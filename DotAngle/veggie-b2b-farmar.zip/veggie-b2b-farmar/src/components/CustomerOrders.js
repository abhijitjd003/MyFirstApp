import React, { Component } from 'react';
import './common/Common.css';
import {  Grid, withStyles, TextField, useMediaQuery, Select, MenuItem, CardContent, Card } from '@material-ui/core';
import './common/CommonModal.css';
import { withRouter } from 'react-router-dom';
import Loader from './loader/Loader';
import api from './common/APIValues';
import 'date-fns';
import DateFnsUtils from '@date-io/date-fns';
import { MuiPickersUtilsProvider, KeyboardDatePicker } from '@material-ui/pickers';
import {
    PieChart, Pie, Cell, ComposedChart, Line, Area, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
    ResponsiveContainer, AreaChart, LineChart
} from 'recharts';
import Autocomplete from '@material-ui/lab/Autocomplete';
import { useStyles } from './common/useStyles';

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);    
    return <Component mediaQuery={mediaQuery} {...props} />;
};

class CustomerOrders extends Component {
    constructor(props) {
        super(props);
        this.state = {
            fromDate: null, toDate: null, fromDateFormat: null, toDateFormat: null, rowData: [], shopId: 7,
            header: null, customers: [], avgQuantity: null, unitType: '30D', avgCost: null, productData: {},
            shopName: {},
        };

        this.onUnitChanged = this.onUnitChanged.bind(this);
    }

    onFromDateChanged = (date) => { 
        this.setState({ fromDate: date, loading: true });        
        let fromDate = '';
        if(date){
            var dd = String(date.getDate()).padStart(2, '0');
            var mm = String(date.getMonth() + 1).padStart(2, '0');
            var yyyy = date.getFullYear();
            fromDate = yyyy + "-" + mm + "-" + dd;
        }
        this.setState({ fromDateFormat: fromDate });
        this.loadCustomerOrders(fromDate, this.state.toDateFormat, this.state.shopId);
    };

    onToDateChanged = (date) => { 
        this.setState({ toDate: date, loading: true });
        let toDate = '';
        if(date){
            var dd = String(date.getDate()).padStart(2, '0');
            var mm = String(date.getMonth() + 1).padStart(2, '0');
            var yyyy = date.getFullYear();
            toDate = yyyy + "-" + mm + "-" + dd;
        }
        this.setState({ toDateFormat: toDate });
        this.loadCustomerOrders(this.state.fromDateFormat, toDate, this.state.shopId);
    };

    loadCustomerOrders(fromDate, toDate, shopId) {
        let partialUrl = api.URL;
        fetch(partialUrl + 'Report/GetCustomerOrders?FromDate='+ fromDate + '&ToDate='+ toDate + '&ShopId='+ shopId)
            .then(res => res.json())
            .then(result => {
                this.setState({ 
                    rowData: result.orders, avgCost: result.AvgCost, loading: false,
                    productData: result.productData
                });
            })
            .catch(err => console.log(err));
    }

    loadOrderStartEndDates() {
        let partialUrl = api.URL;
        fetch(partialUrl + 'SalesOfficer/GetOrderStartEndDates/')
            .then(res => res.json())
            .then(result => {
                this.setState({ 
                    fromDate: result.MonthDate, toDate: result.ToDate,
                    fromDateFormat: result.MonthDateFormat, toDateFormat: result.ToDateYearFormat,
                });

                this.loadCustomerOrders(this.state.fromDateFormat, this.state.toDateFormat, this.state.shopId);
            })
            .catch(err => console.log(err));
    }

    componentDidMount() {
        let loggedInUser = sessionStorage.getItem('loggedInUser');
        
        if(loggedInUser) {
            this.setState({ loading: true });
            this.loadOrderStartEndDates();
            this.loadCustomers();
        } else {
            const { history } = this.props;
            if (history) history.push('/Home');
        }
    }

    loadCustomers(){
        let status = 'Approved';
        let partialUrl = api.URL;
        fetch(partialUrl + 'Customer/GetCustomers?Status=' + status)
            .then(res => res.json())
            .then(result => {
                this.setState({ customers: result, shopName: result[0] })
            })
            .catch(err => console.log(err));
    }

    onUnitChanged(e) {
        let unitType = e.target.value;
        var currentDate = new Date();

        switch(unitType){
            case '30D':
                currentDate.setDate(currentDate.getDate() - 30);
                this.setState({ 
                    fromDate: currentDate,
                    toDate: new Date(),
                });
                break;
            case '21D':
                currentDate.setDate(currentDate.getDate() - 21);
                this.setState({ 
                    fromDate: currentDate,
                    toDate: new Date(),
                });
                break;
            case '14D':
                currentDate.setDate(currentDate.getDate() - 14);
                this.setState({ 
                    fromDate: currentDate,
                    toDate: new Date(),
                });
                break;
            case '7D':
                currentDate.setDate(currentDate.getDate() - 7);
                this.setState({ 
                    fromDate: currentDate,
                    toDate: new Date(),
                });
                break;
        }
        
        let fromDate = ''; let toDate = '';        
        if(currentDate){
            var dd = String(currentDate.getDate()).padStart(2, '0');
            var mm = String(currentDate.getMonth() + 1).padStart(2, '0');
            var yyyy = currentDate.getFullYear();
            fromDate = yyyy + "-" + mm + "-" + dd;
        }        
        if(new Date()){
            var dd = String(new Date().getDate()).padStart(2, '0');
            var mm = String(new Date().getMonth() + 1).padStart(2, '0');
            var yyyy = new Date().getFullYear();
            toDate = yyyy + "-" + mm + "-" + dd;
        }

        this.setState({ unitType: unitType, loading: true });
        this.loadCustomerOrders(fromDate, toDate, this.state.shopId);
    };

    render() {
        const { classes, mediaQuery } = this.props;
        const col4 = mediaQuery ? 3 : 12;
        
        return (
            <div>
                {this.state.loading ? (
                    <Loader />
                ) : (
                    <div>
                        <Grid container spacing={0}>
                            <Grid item xs={12}>                     
                                <h2 className="header-text-color">Customer Orders Report</h2>
                            </Grid>
                        </Grid>

                        <Grid container spacing={4}>
                            <Grid item xs={col4}>
                                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                    <KeyboardDatePicker fullWidth format="dd/MM/yyyy"
                                        id="dateOrder" label="From Date"
                                        value={this.state.fromDate}
                                        onChange={this.onFromDateChanged}
                                        KeyboardButtonProps={{
                                            'aria-label': 'change date',
                                        }}
                                    />
                                </MuiPickersUtilsProvider>
                            </Grid>
                            <Grid item xs={col4}>
                                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                    <KeyboardDatePicker fullWidth format="dd/MM/yyyy"
                                        id="dateOrder" label="To Date"
                                        value={this.state.toDate}
                                        onChange={this.onToDateChanged}
                                        KeyboardButtonProps={{
                                            'aria-label': 'change date',
                                        }}
                                    />
                                </MuiPickersUtilsProvider>
                            </Grid>
                            <Grid item xs={col4}>
                                <Autocomplete debug id="debug" value={ this.state.shopName } options={this.state.customers} 
                                    getOptionLabel={(option) => option.ShopName}                                   
                                    onChange={(event, value) => {
                                        if(value){
                                            let shopId = value.ShopId;
                                            this.setState({ shopId: shopId, shopName: value });
                                            this.loadCustomerOrders(this.state.fromDateFormat, this.state.toDateFormat, shopId);
                                        }
                                    }}
                                    renderInput={params => (
                                        <TextField {...params} margin="normal" fullWidth />
                                    )}
                                />
                            </Grid>
                            <Grid item xs={col4}>
                                <Select fullWidth id="ddlUnitType" value={this.state.unitType} className="selectTopMargin"
                                    onChange={ this.onUnitChanged }>
                                    <MenuItem value="7D">Last 7 days</MenuItem>
                                    <MenuItem value="14D">Last 14 days</MenuItem>
                                    <MenuItem value="21D">Last 21 days</MenuItem>
                                    <MenuItem value="30D">Last 30 days</MenuItem>                                     
                                </Select>
                            </Grid>  
                        </Grid>
                        
                        <Grid container spacing={0}>
                            <Grid item xs={12}>
                                <Card className={classes.rootCard}>
                                    <CardContent>
                                        <Grid container spacing={0}>
                                            <Grid item xs={6}>
                                                <span className="dashboard-text-color">
                                                    CUSTOMER ORDERS
                                                </span>
                                            </Grid>
                                            <Grid item xs={2}>
                                                <span className="graph-sub-text">
                                                    AVERAGE COST: { Math.round(this.state.avgCost) }
                                                </span>
                                            </Grid>
                                            <Grid item xs={4}>
                                                <span className="graph-sub-text">
                                                    MAX PRODUCT ORDER: { this.state.productData.ProductName } - { Math.round(this.state.productData.TotalWeight) } { this.state.productData.UnitType }
                                                </span>
                                            </Grid>
                                        </Grid>

                                        <ResponsiveContainer className={classes.chart} height={400} width='100%'>
                                            <ComposedChart data={this.state.rowData}
                                                margin={{ top: 40, bottom: 10 }}>
                                                <YAxis type="number" />
                                                <XAxis dataKey="OrderedDateTime" type="category" />
                                                <Tooltip/>
                                                <Legend/>
                                                <Bar dataKey='Cost' barSize={15} fill='#347f58' label={{ position: 'top' }}>
                                                </Bar>
                                            </ComposedChart>
                                        </ResponsiveContainer>
                                    </CardContent>
                                </Card>
                            </Grid>                    
                        </Grid>
                    </div>
                    )}
            </div>
        );
    }
}

export default withRouter(withStyles(useStyles)(withMediaQuery('(min-width:600px)')(CustomerOrders)))