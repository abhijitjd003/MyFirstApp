import React, { Component } from 'react';
import './common/Common.css';
import { Grid, withStyles, useMediaQuery } from '@material-ui/core';
import './common/CommonModal.css';
import { withRouter } from 'react-router-dom';
import Loader from './loader/Loader';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import api from './common/APIValues';
import 'date-fns';
import DateFnsUtils from '@date-io/date-fns';
import { MuiPickersUtilsProvider, KeyboardDatePicker } from '@material-ui/pickers';
import { useStyles } from './common/useStyles';

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);    
    return <Component mediaQuery={mediaQuery} {...props} />;
};

class SalesOfficerBoard extends Component {
    constructor(props) {
        super(props);
        this.state = {
            fromDate: null, toDate: null, fromDateFormat: null, toDateFormat: null,
            columnDefs: [                
                { headerName: 'Sales Officer Name', field: 'SalesOfficerName', cellStyle: { textAlign: 'center' }, flex: 1 },
                { headerName: 'Registered Customers', field: 'RegisteredCustomers', cellStyle: { textAlign: 'center' }, width: 205 },
                { headerName: 'Active Customers', field: 'ActiveCustomers', cellStyle: { textAlign: 'center' }, width: 175 },
                { headerName: 'InActive Customers', field: 'InActiveCustomers', cellStyle: { textAlign: 'center' }, width: 190 },
                { headerName: 'Total Orders', field: 'TotalOrders', cellStyle: { textAlign: 'center' }, width: 140 },
                { headerName: 'Total Sales', field: 'TotalSales', cellStyle: { textAlign: 'center' }, width: 130 }
            ],
            context: { componentParent: this },
            rowData: [],
            defaultColDef: { sortable: true, resizable: true, filter: true },
            rowClassRules: {
                'grid-row-even': function (params) { return params.node.rowIndex % 2 === 0; },
                'grid-row-odd': function (params) { return params.node.rowIndex % 2 !== 0; }
            },            
            rowSelection: 'multiple',
        };
    }

    onGridReady = params => { this.gridApi = params.api; this.gridColumnApi = params.columnApi; };

    onFromDateChanged = (date) => { 
        this.setState({ fromDate: date });
        let fromDate = '';
        if(date){
            var dd = String(date.getDate()).padStart(2, '0');
            var mm = String(date.getMonth() + 1).padStart(2, '0');
            var yyyy = date.getFullYear();
            fromDate = yyyy + "-" + mm + "-" + dd;
        }
        this.setState({ fromDateFormat: fromDate });
        this.loadSalesOfficerBoard(fromDate, this.state.toDateFormat);
    };

    onToDateChanged = (date) => { 
        this.setState({ toDate: date });
        let toDate = '';
        if(date){
            var dd = String(date.getDate()).padStart(2, '0');
            var mm = String(date.getMonth() + 1).padStart(2, '0');
            var yyyy = date.getFullYear();
            toDate = yyyy + "-" + mm + "-" + dd;
        }
        this.setState({ toDateFormat: toDate });
        this.loadSalesOfficerBoard(this.state.fromDateFormat, toDate);
    };

    loadSalesOfficerBoard(fromDate, toDate) {
        let partialUrl = api.URL;
        fetch(partialUrl + 'SalesOfficer/GetSalesOfficersData?FromDate='+ fromDate + '&ToDate='+ toDate)
            .then(res => res.json())
            .then(result => {
                this.setState({ rowData: result, loading: false });
            })
            .catch(err => console.log(err));
    }

    loadOrderStartEndDates() {
        let partialUrl = api.URL;
        fetch(partialUrl + 'SalesOfficer/GetOrderStartEndDates/')
            .then(res => res.json())
            .then(result => {
                this.setState({ 
                    fromDate: result.FromDate, toDate: result.ToDate,
                    fromDateFormat: result.FromDateFormat, toDateFormat: result.ToDateFormat,
                });

                this.loadSalesOfficerBoard(this.state.fromDateFormat, this.state.toDateFormat);
            })
            .catch(err => console.log(err));
    }

    componentDidMount() {
        let loggedInUser = sessionStorage.getItem('loggedInUser');
        
        if(loggedInUser) {
            this.setState({ loading: true });
            this.loadOrderStartEndDates();
        } else {
            const { history } = this.props;
            if (history) history.push('/Home');
        }
    }

    render() {
        const { classes, mediaQuery } = this.props;
        const col3 = mediaQuery ? 3 : 6;
        const col1 = mediaQuery ? 1 : 4;
        const col8 = mediaQuery ? 8 : 2;
        
        return (
            <div>
                {this.state.loading ? (
                    <Loader />
                ) : (
                    <div>                        
                        <h2 className="header-text-color">Sales Officer Board</h2>

                        <Grid container spacing={4}>
                            <Grid item xs={col3}>
                                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                    <KeyboardDatePicker fullWidth format="dd/MM/yyyy"
                                        id="dateOrder" label="From Date"
                                        value={this.state.fromDate}
                                        onChange={this.onFromDateChanged}
                                        KeyboardButtonProps={{
                                            'aria-label': 'change date',
                                        }}
                                    />
                                </MuiPickersUtilsProvider>
                            </Grid>
                            <Grid item xs={col3}>
                                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                    <KeyboardDatePicker fullWidth format="dd/MM/yyyy"
                                        id="dateOrder" label="To Date"
                                        value={this.state.toDate}
                                        onChange={this.onToDateChanged}
                                        KeyboardButtonProps={{
                                            'aria-label': 'change date',
                                        }}
                                    />
                                </MuiPickersUtilsProvider>
                            </Grid>
                        </Grid>
                        
                        <Grid container spacing={0}>
                            <Grid item xs={12}>
                                <div className="ag-theme-alpine" style={{ width: "100%", height: 550, marginTop: 10 }}>
                                    <AgGridReact
                                        columnDefs={this.state.columnDefs} rowData={this.state.rowData}
                                        onGridReady={this.onGridReady} defaultColDef={this.state.defaultColDef}
                                        frameworkComponents={this.state.frameworkComponents} context={this.state.context}
                                        pagination={true} gridOptions={this.gridOptions} paginationPageSize={20}
                                        components={this.state.components} rowClassRules={this.state.rowClassRules} 
                                        singleClickEdit={true}
                                    />
                                </div>
                            </Grid>                        
                        </Grid>
                    </div>
                    )}
            </div>
        );
    }
}

export default withRouter(withStyles(useStyles)(withMediaQuery('(min-width:600px)')(SalesOfficerBoard)))