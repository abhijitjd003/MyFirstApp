import React, { Component } from 'react';
import './common/Common.css';
import { Button, TextField, Grid, withStyles, useMediaQuery, CardContent, Card, Select, MenuItem }
    from '@material-ui/core';
import './common/CommonModal.css';
import { withRouter } from 'react-router-dom';
import Loader from './loader/Loader';
import api from './common/APIValues';
import CheckIcon from '@material-ui/icons/Check';
import 'date-fns';
import DateFnsUtils from '@date-io/date-fns';
import { MuiPickersUtilsProvider, KeyboardTimePicker } from '@material-ui/pickers';
import { useStyles } from './common/useStyles';

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);
    return <Component mediaQuery={mediaQuery} {...props} />;
};

const validateForm = (errors) => {
    let valid = true;
    Object.keys(errors).map(function (e) {
        if (errors[e].length > 0) {
            valid = false;
        }
    });
    return valid;
}

class Settings extends Component {
    constructor(props) {
        super(props);
        this.state = {
            pickupAddress: null, contactNo1: null, contactNo2: null, deliveryCharges: null, orderFromTime: null, orderToTime: null,
            errorMessage: null, loading: false, expanded: true, orderMode: '0', cancelFromTime: null, cancelToTime: null,
            interval: null, minOrderWeight: null, customMsg: null,
            errors: {
                pickupAddress: '',
                contactNo1: '',
                orderFromTime: '',
                orderToTime: '',
                cancelFromTime: '',
                cancelToTime: '',
                orderMode: '',
                interval: '',
                minOrderWeight: '',
            },
        };

        this.onModeChanged = this.onModeChanged.bind(this);
    }

    validateAllInputs(){
        if(!this.state.contactNo1 || !this.state.pickupAddress || !this.state.orderFromTime || !this.state.orderToTime 
            || !this.state.cancelFromTime || !this.state.cancelToTime 
            || !this.state.interval || this.state.orderMode === '0'){
            return false;
        }
        else{
            return true;
        }
    }

    update = (event) => {
        event.preventDefault();
        if (validateForm(this.state.errors) && this.validateAllInputs()) {
            this.setState({ loading: true });
            let details = {};
            details.PickupAddress = this.state.pickupAddress;
            details.ContactNo1 = this.state.contactNo1;
            details.ContactNo2 = this.state.contactNo2;
            details.DeliveryCharges = this.state.deliveryCharges;
            details.OrderFromTime = this.state.orderFromTime;
            details.OrderToTime = this.state.orderToTime;
            details.CancelFromTime = this.state.cancelFromTime;
            details.CancelToTime = this.state.cancelToTime;
            details.OrderMode = this.state.orderMode;
            details.Interval = this.state.interval;
            details.MinOrderWeight = this.state.minOrderWeight;
            details.CustomMessage = this.state.customMsg
            this.updateSettings(details);
        } else {
            let errors = this.state.errors;
            if (!this.state.pickupAddress) {
                errors.pickupAddress = 'Pickup address is required';
            }
            if (!this.state.contactNo1) {
                errors.contactNo1 = 'Contact number 1 is required';
            }
            if (!this.state.orderFromTime) {
                errors.orderFromTime = 'Create order from time is required';
            }
            if (!this.state.orderToTime) {
                errors.orderToTime = 'Create order to time is required';
            }
            if (!this.state.cancelFromTime) {
                errors.cancelFromTime = 'Cancel order from time is required';
            }
            if (!this.state.cancelToTime) {
                errors.cancelToTime = 'Cancel order to time is required';
            }
            if (!this.state.interval) {
                errors.interval = 'Display interval is required';
            }
            if (this.state.orderMode === '0') {
                errors.orderMode = 'Select order mode';
            }
            this.setState({ errors, errorMessage: null });
        }
    }

    loadSettingsData(){
        let partialUrl = api.URL;
        fetch(partialUrl + 'Setting/GetConfigData')
            .then(res => res.json())
            .then(result => this.setState({
                pickupAddress: result.PickupAddress,
                contactNo1: result.ContactNo1,
                contactNo2: result.ContactNo2,
                deliveryCharges: result.DeliveryCharges,
                orderFromTime: result.OrderFromTime,
                orderToTime: result.OrderToTime,
                cancelFromTime: result.CancelFromTime,
                cancelToTime: result.CancelToTime,
                orderMode: result.OrderMode,
                interval: result.Interval,
                minOrderWeight: result.MinOrderWeight,
                customMsg: result.CustomMessage,
                loading: false
            }))
            .catch(err => console.log(err));
    }

    componentDidMount() {
        let loggedInUser = sessionStorage.getItem('loggedInUser');

        if(loggedInUser) {
            this.setState({ userId: loggedInUser, loading: true });
            this.loadSettingsData();
        } else {
            const { history } = this.props;
            if (history) history.push('/Home');
        }
    }

    updateSettings(details) {
        let partialUrl = api.URL;
        fetch(partialUrl + 'Setting/UpdateConfigData', {
            method: 'POST',
            mode: 'cors',
            body: JSON.stringify(details),
            headers: { 'Content-Type': 'application/json' }
        }).then((response) => response.json())
            .then((responseJson) => {
                if (responseJson) {
                    this.loadSettingsData();
                    this.setState({
                        loading: false
                    });
                }
            })
    }

    onModeChanged(e) {
        let mode = e.target.value;
        let errors = this.state.errors;
        if(mode === '0'){
            errors.orderMode = 'Select order mode';
        }else{
            errors.orderMode = '';
        }        
        this.setState({ orderMode: mode, errors });
    };

    onOrderFromTimeChanged = (date) => {         
        let errors = this.state.errors;
        errors.orderFromTime = date.length <= 0 ? 'Create order from time is required' : '';
        this.setState({ orderFromTime: date, errors });
    };
    onOrderToTimeChanged = (date) => {
        let errors = this.state.errors;
        errors.orderToTime = date.length <= 0 ? 'Create order to time is required' : '';
        this.setState({ orderToTime: date, errors }); 
    };
    onCancelFromTimeChanged = (date) => { 
        let errors = this.state.errors;
        errors.cancelFromTime = date.length <= 0 ? 'Cancel order from time is required' : '';
        this.setState({ cancelFromTime: date, errors });
    };
    onCancelToTimeChanged = (date) => {
        let errors = this.state.errors;
        errors.cancelToTime = date.length <= 0 ? 'Cancel order to time is required' : ''; 
        this.setState({ cancelToTime: date, errors }); 
    };

    handleChange = (event) => {
        event.preventDefault();
        const { name, value } = event.target;
        let errors = this.state.errors;

        switch (name) {
            case 'pickupAddress':
                this.state.pickupAddress = value;
                errors.pickupAddress = value.length <= 0 ? 'Pickup address is required' : '';
                break;
            case 'contactNo1':
                this.state.contactNo1 = value;
                errors.contactNo1 = value.length <= 0 ? 'Contact number 1 is required' : !Number(value) ? 'Contact number 1 is not valid' : '';
                break;
            case 'interval':
                this.state.interval = value;
                errors.interval = value.length <= 0 ? 'Display interval is required' : !Number(value) ? 'Display interval is not valid' : '';
                break;
            default:
                break;
        }
        this.setState({ errors, [name]: value });
    }

    render() {
        const { classes, mediaQuery } = this.props;
        const col4 = mediaQuery ? 3 : 12;
        const col9 = mediaQuery ? 9 : 12;

        return (
            <div>
                {this.state.loading ? (
                    <Loader />
                ) : (
                    <div>
                        <Card className={classes.rootCard}>
                            <CardContent className={classes.pos}>
                                <h2 className="header-text-color">Order Details</h2>
                                <Grid container spacing={3}>
                                    <Grid item xs={col9}>
                                        <TextField fullWidth name="pickupAddress" id="txtPickupAddress"
                                            label="Pickup Address" InputLabelProps={{ shrink: true, style: { fontSize: 18 } }}
                                            onChange={this.handleChange} noValidate value={this.state.pickupAddress} />
                                        {this.state.errors.pickupAddress.length > 0 &&
                                            <span className='error'>{this.state.errors.pickupAddress}</span>}
                                    </Grid>
                                    <Grid item xs={col4}>
                                        <Select fullWidth id="ddlMode" name="orderMode" value={this.state.orderMode} className="selectTopMargin"
                                            onChange={ this.onModeChanged }>
                                            <MenuItem value="0">Choose Order Mode</MenuItem>
                                            <MenuItem value="Delivery">Delivery</MenuItem>
                                            <MenuItem value="Pickup">PickUp</MenuItem>
                                        </Select>
                                        {this.state.errors.orderMode.length > 0 &&
                                            <span className='error'>{this.state.errors.orderMode}</span>}
                                    </Grid>
                                    <Grid item xs={col4}>
                                        <TextField fullWidth name="contactNo1" id="txtContactNo1"
                                            label="Contact Number 1" InputLabelProps={{ shrink: true, style: { fontSize: 18 } }}
                                            onChange={this.handleChange} noValidate value={this.state.contactNo1} />
                                        {this.state.errors.contactNo1.length > 0 &&
                                            <span className='error'>{this.state.errors.contactNo1}</span>}
                                    </Grid>
                                    <Grid item xs={col4}>
                                        <TextField fullWidth name="contactNo2" id="txtContactNo2"
                                            label="Contact Number 2" InputLabelProps={{ shrink: true, style: { fontSize: 18 } }}
                                            onChange={this.handleChange} noValidate value={this.state.contactNo2} />
                                    </Grid>
                                    <Grid item xs={col4}>
                                        <TextField fullWidth name="deliveryCharges" id="txtDeliveryCharges"
                                            label="Delivery Charges" InputLabelProps={{ shrink: true, style: { fontSize: 18 } }}
                                            onChange={this.handleChange} noValidate value={this.state.deliveryCharges} />
                                    </Grid>
                                    <Grid item xs={col4}>
                                        <TextField fullWidth name="minOrderWeight" id="txtMinOrderWeight"
                                            label="Minimum Order Weight In Kg" InputLabelProps={{ shrink: true, style: { fontSize: 18 } }}
                                            onChange={this.handleChange} noValidate value={this.state.minOrderWeight} />                                        
                                    </Grid>                                                                        
                                </Grid>
                            </CardContent>
                        </Card>
                        <Card className={classes.rootCard}>
                            <CardContent className={classes.pos}>
                                <h2 className="header-text-color">Create & Cancel Order Time</h2>
                                <Grid container spacing={2}>
                                    <Grid item xs={col4}>
                                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                            <KeyboardTimePicker fullWidth
                                                id="fromTimeDelivery" label="Create Order From Time"
                                                value={this.state.orderFromTime} name="orderFromTime"
                                                onChange={this.onOrderFromTimeChanged}
                                                KeyboardButtonProps={{
                                                    'aria-label': 'change time',
                                                }}
                                            />
                                        </MuiPickersUtilsProvider>
                                        {this.state.errors.orderFromTime.length > 0 &&
                                            <span className='error'>{this.state.errors.orderFromTime}</span>}
                                    </Grid>
                                    <Grid item xs={col4}>
                                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                            <KeyboardTimePicker fullWidth
                                                id="toTimeDelivery" label="Create Order To Time"
                                                value={this.state.orderToTime} name="orderToTime"
                                                onChange={this.onOrderToTimeChanged}
                                                KeyboardButtonProps={{
                                                    'aria-label': 'change time',
                                                }}
                                            />
                                        </MuiPickersUtilsProvider>
                                        {this.state.errors.orderToTime.length > 0 &&
                                            <span className='error'>{this.state.errors.orderToTime}</span>}
                                    </Grid>
                                    <Grid item xs={col4}>
                                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                            <KeyboardTimePicker fullWidth
                                                id="fromTimeDelivery" label="Cancel Order From Time"
                                                value={this.state.cancelFromTime} name="cancelFromTime"
                                                onChange={this.onCancelFromTimeChanged}
                                                KeyboardButtonProps={{
                                                    'aria-label': 'change time',
                                                }}
                                            />
                                        </MuiPickersUtilsProvider>
                                        {this.state.errors.cancelFromTime.length > 0 &&
                                            <span className='error'>{this.state.errors.cancelFromTime}</span>}
                                    </Grid>
                                    <Grid item xs={col4}>
                                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                            <KeyboardTimePicker fullWidth
                                                id="toTimeDelivery" label="Cancel Order To Time"
                                                value={this.state.cancelToTime} name="cancelToTime"
                                                onChange={this.onCancelToTimeChanged}
                                                KeyboardButtonProps={{
                                                    'aria-label': 'change time',
                                                }}
                                            />
                                        </MuiPickersUtilsProvider>
                                        {this.state.errors.cancelToTime.length > 0 &&
                                            <span className='error'>{this.state.errors.cancelToTime}</span>}
                                    </Grid>
                                </Grid>
                            </CardContent>
                        </Card>
                        <Card className={classes.rootCard}>
                            <CardContent className={classes.pos}>
                                <h2 className="header-text-color">Display & Custom Message</h2>
                                <Grid container spacing={2}>
                                    <Grid item xs={12}>
                                        <TextField fullWidth name="interval" id="txtInterval"
                                            label="Interval In Seconds" InputLabelProps={{ shrink: true, style: { fontSize: 18 } }}
                                            onChange={this.handleChange} noValidate value={this.state.interval} />
                                        {this.state.errors.interval.length > 0 &&
                                            <span className='error'>{this.state.errors.interval}</span>}
                                    </Grid>
                                    <Grid item xs={12}>
                                        <TextField fullWidth name="customMsg" id="txtCustomMsg"
                                            label="Custom Message (* Please do not update this message, unless you want to shut down / close ordering on the Customer Mobile App)" 
                                            InputLabelProps={{ shrink: true, style: { fontSize: 18 } }}
                                            onChange={this.handleChange} noValidate value={this.state.customMsg} />                                        
                                    </Grid>
                                </Grid>
                            </CardContent>
                        </Card>
                        
                        <div className={classes.posBottom}>
                            <Grid container spacing={0}>
                                <Grid item xs={12}>
                                    <Button fullWidth className={classes.root} variant="contained"
                                        color="primary" onClick={this.update}>
                                    <CheckIcon className={classes.leftIcon} />Setup</Button>
                                </Grid>
                            </Grid>
                        </div>
                    </div>
                    )}
            </div>
        );
    }
}

export default withRouter(withStyles(useStyles)(withMediaQuery('(min-width:600px)')(Settings)))