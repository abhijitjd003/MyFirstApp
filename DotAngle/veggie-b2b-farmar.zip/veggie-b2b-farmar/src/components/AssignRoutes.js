import React, { Component } from 'react';
import './common/Common.css';
import { Grid, withStyles, Button, useMediaQuery } from '@material-ui/core';
import './common/CommonModal.css';
import { withRouter } from 'react-router-dom';
import Loader from './loader/Loader';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import RouteModal from './modal/RouteModal';
import ErrorModal from './modal/ErrorModal';
import api from './common/APIValues';
import 'date-fns';
import DateFnsUtils from '@date-io/date-fns';
import { MuiPickersUtilsProvider, KeyboardDatePicker } from '@material-ui/pickers';
import PrintIcon from '@material-ui/icons/Print';
import { useStyles } from './common/useStyles';
import AssignmentTurnedInIcon from '@material-ui/icons/AssignmentTurnedIn';

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);    
    return <Component mediaQuery={mediaQuery} {...props} />;
};

class AssignRoutes extends Component {
    constructor(props) {
        super(props);
        this.state = {
            shopId: 0, userId: null, disableApprove: false, disableReject: false, disable: false, orderedDate: new Date(),
            tabIndex: 0, activeTab: 'tabInProgress', actionDisable: 'Disable', loading: false, orderedFormatDate: '',
            overallWeight: 0, totalCustomers: 0,
            columnDefs: [
                { 
                    headerName: 'Shop Name', field: 'ShopName', headerCheckboxSelection: true, checkboxSelection: true, 
                    headerCheckboxSelectionFilteredOnly: true, flex: 1, cellStyle: { 'text-align': "center" }
                },
                { headerName: 'Total Weight', field: 'TotalWeight', width: 140, cellStyle: { 'text-align': "center" } },
                { headerName: 'Location', field: 'Location', flex: 1, cellStyle: { 'text-align': "center" } },
                { headerName: 'Pin Code', field: 'PinCode', width: 140, cellStyle: { 'text-align': "center" } },                
                { headerName: 'Route', field: 'Route', width: 140, cellStyle: { 'text-align': "center" } },
            ],
            context: { componentParent: this },
            frameworkComponents: { },
            rowData: [],
            defaultColDef: { sortable: true, resizable: true, filter: true },
            rowClassRules: {
                'grid-row-even': function (params) { return params.node.rowIndex % 2 === 0; },
                'grid-row-odd': function (params) { return params.node.rowIndex % 2 !== 0; }
            },
            suppressRowClickSelection: true,
            rowSelection: 'multiple',
        };
    }

    onGridReady = params => { this.gridApi = params.api; this.gridColumnApi = params.columnApi; };    

    onSelectionChanged = () => {
        let selectedNodes = this.gridApi.getSelectedNodes();
        let orders = selectedNodes.map(node => node.data);
        if(orders.length > 0) {
            let overallWeight = 0;
            orders.map((data) => {
                overallWeight += data.TotalWeight;
            });

            this.setState({ overallWeight: overallWeight, totalCustomers: orders.length })
        } else {
            this.setState({ overallWeight: 0, totalCustomers: 0 })
        }        
    }

    loadOrders(orderedDate){
        let partialUrl = api.URL;
        fetch(partialUrl + 'Customer/GetAssignedRoutes?&OrderedDate=' + orderedDate + '&CondOper=1&RouteCategory=')
            .then(res => res.json())
            .then(result => {
                this.setState({ rowData: result, loading: false })
            })
            .catch(err => console.log(err));
    }

    showRoutePopup() {
        let selectedNodes = this.gridApi.getSelectedNodes();
        let orders = selectedNodes.map(node => node.data);
        if(orders.length > 0) {
            this.refs.routeModalComp.openModal();
        } else {
            var errorMsg = 'Select at least one order to Assign Route.';
            this.refs.errModalComp.openModal(errorMsg);
        }
    }

    assignRoute = (Route) => {
        let selectedNodes = this.gridApi.getSelectedNodes();
        let orders = selectedNodes.map(node => node.data);

        if(orders.length > 0) {
            this.setState({ loading: true });
            let orderData = {};
            orderData.RouteCategory = Route;
            orderData.OrderNos = selectedNodes.map(node => node.data.OrderNo);
            let partialUrl = api.URL;
            fetch(partialUrl + 'Customer/AssignRoute', {
                method: 'POST',
                mode: 'cors',
                body: JSON.stringify(orderData),
                headers: { 'Content-Type': 'application/json' }
            }).then((response) => response.json())
                .then((responseJson) => {
                    if (responseJson) {
                        this.loadOrders(this.state.orderedFormatDate);
                        this.setState({ loading: false, overallWeight: 0, totalCustomers: 0 });
                        var successMsg = 'Route assigned successfully.';
                        this.refs.errModalComp.openModal(successMsg, 'Informations');
                    }
                })
        }
    }

    onDateChanged = (date) => { 
        this.setState({ orderedDate: date });
        let orderedDate = '';
        if(date){
            var dd = String(date.getDate()).padStart(2, '0');
            var mm = String(date.getMonth() + 1).padStart(2, '0');
            var yyyy = date.getFullYear();
            orderedDate = dd + "/" + mm + "/" + yyyy;
        }
        this.setState({ orderedFormatDate: orderedDate });
        this.loadOrders(orderedDate);
    };

    componentDidMount() {
        let loggedInUser = sessionStorage.getItem('loggedInUser');

        if(loggedInUser) {
            this.setState({ userId: loggedInUser, loading: true });
            let orderedDate = '';
            if(this.state.orderedDate){
                var dd = String(this.state.orderedDate.getDate()).padStart(2, '0');
                var mm = String(this.state.orderedDate.getMonth() + 1).padStart(2, '0');
                var yyyy = this.state.orderedDate.getFullYear();
                orderedDate = dd + "/" + mm + "/" + yyyy;
            }
            this.loadOrders(orderedDate);
        } else {
            const { history } = this.props;
            if (history) history.push('/Home');
        }
    }

    printRoutes = () => {
        sessionStorage.setItem('OrderedDateFormatRef', this.state.orderedFormatDate);
        const { history } = this.props;
        if (history) history.push('/AssignRoutesReport');
    }

    render() {
        const { classes, mediaQuery } = this.props;        
        const col2 = mediaQuery ? 2 : 4;
        const col22 = mediaQuery ? 2 : 6;
        const col3 = mediaQuery ? 3 : 4;
        
        return (
            <div>
                {this.state.loading ? (
                    <Loader />
                ) : (
                    <div>
                        <ErrorModal ref="errModalComp" />
                        <RouteModal ref="routeModalComp" onClick={(routeCategory) => this.assignRoute(routeCategory)} />
                        
                        <Grid container spacing={0}>                            
                            <Grid item xs={12}>
                                <h2 className="header-text-color">Assign Routes</h2>
                            </Grid>                            
                        </Grid>

                        <Grid container spacing={1}>                            
                            <Grid item xs={col3}>
                                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                    <KeyboardDatePicker fullWidth format="dd/MM/yyyy"
                                        id="dateUpdated" label="Ordered Date"
                                        value={this.state.orderedDate}
                                        onChange={this.onDateChanged}
                                        KeyboardButtonProps={{
                                            'aria-label': 'change date',
                                        }}
                                    />
                                </MuiPickersUtilsProvider>
                            </Grid>                            
                            <Grid item xs={col2}>
                                <div style={{ fontSize: 16, marginTop: 30 }}>
                                    Overall Weight In Kg: { this.state.overallWeight }
                                </div>
                            </Grid>
                            <Grid item xs={col3}>
                                <div style={{ fontSize: 16, marginTop: 30 }}>
                                    Total Customers: { this.state.totalCustomers }
                                </div>
                            </Grid>
                            <Grid item xs={col22}>                                
                                    <Button fullWidth className={classes.root} variant="contained"
                                        color="primary" onClick={() => this.showRoutePopup()}>
                                        <AssignmentTurnedInIcon className={classes.leftIcon} />Assign Route</Button>
                            </Grid>
                            <Grid item xs={col22}>
                                <Button fullWidth variant="contained" className={classes.root}
                                    color="primary" onClick={this.printRoutes}>
                                    <PrintIcon className={classes.leftIcon} />Print Routes
                                </Button>
                            </Grid>
                        </Grid>
                        
                        <Grid container spacing={0}>
                            <Grid item xs={12}>
                                <div className="ag-theme-alpine" style={{ width: "100%", height: 525, marginTop: 10 }}>
                                    <AgGridReact
                                        columnDefs={this.state.columnDefs} rowData={this.state.rowData}
                                        onGridReady={this.onGridReady} defaultColDef={this.state.defaultColDef}
                                        frameworkComponents={this.state.frameworkComponents} context={this.state.context}
                                        pagination={true} gridOptions={this.gridOptions} paginationPageSize={100}
                                        components={this.state.components} rowClassRules={this.state.rowClassRules} 
                                        suppressClickEdit={true} onSelectionChanged={this.onSelectionChanged.bind(this)}
                                        rowSelection={this.state.rowSelection} suppressRowClickSelection={true}
                                    />
                                </div>
                            </Grid>                        
                        </Grid>
                    </div>
                    )}
            </div>
        );
    }
}

export default withRouter(withStyles(useStyles)(withMediaQuery('(min-width:600px)')(AssignRoutes)))