import React, { Component } from 'react';
import './common/Common.css';
import { Button, TextField, Grid, withStyles, Select, MenuItem, useMediaQuery } from '@material-ui/core';
import './common/CommonModal.css';
import { withRouter } from 'react-router-dom';
import Loader from './loader/Loader';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import EditRenderer from './common/EditRenderer';
import ConfirmModal from './modal/ConfirmModal';
import ErrorModal from './modal/ErrorModal';
import CreateIcon from '@material-ui/icons/Create';
import api from './common/APIValues';
import SystemUpdateAltIcon from '@material-ui/icons/SystemUpdateAlt';
import { useStyles } from './common/useStyles';

// const useStyles = theme => ({
//     leftIcon: {
//         marginRight: theme.spacing.unit,
//     },
//     topMargin: {
//         marginTop: 16,
//     },
//     root: {
//         fontSize: 12, height: '2.1rem', marginTop: 20,
//         backgroundColor: "#2b494b",
//         "&:hover": {
//             backgroundColor: "#2b494b"
//         },
//         "&:disabled": {
//             backgroundColor: "rgba(0, 0, 0, 0.12)"
//         },
//     },
// });

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);
    return <Component mediaQuery={mediaQuery} {...props} />;
  };

const validateForm = (errors) => {
    let valid = true;
    Object.keys(errors).map(function (e) {
        if (errors[e].length > 0) {
            valid = false;
        }
    });
    return valid;
}

const validDecimalRegex = RegExp(/^[0-9]\d*(\.\d+)?$/i);

class Products extends Component {
    constructor(props) {
        super(props);
        this.state = {
            category: 0, productName: null, rate: null, minPurchaseQuantity: null, productCategories: [], productId: 0,
            errorMessage: null, loading: false, actionName: 'CREATE', userId: null, deactivate: false, totalStock: null,
            fileType: null, fileName: null, fileBase64String: null, unitType: 0, productNameKannada: null,
            errors: {
                productName: '',
                rate: '',
                minPurchaseQuantity: '',
                category: '',
                totalStock: '',
                productImage: '',
                unitType: '',
                productNameKannada: '',
            },
            columnDefs: [
                { headerName: 'Category', field: 'CategoryName', cellStyle: { 'text-align': "center" }, width: 115 },
                { headerName: 'Product Name', field: 'ProductName', cellStyle: { 'text-align': "center" }, width: 250 },
                { headerName: 'Product In Kannada', field: 'ProductNameKannada', cellStyle: { 'text-align': "center" }, width: 200 },
                { headerName: 'Unit', field: 'UnitType', cellStyle: { 'text-align': "center" }, width: 85 },
                { headerName: 'Price', field: 'RatePerKg', editable: true, cellStyle: { 'text-align': "center" }, width: 90 },
                { headerName: 'Min Qty', field: 'MinPurchaseQuantity', cellStyle: { 'text-align': "center" }, width: 110 },
                {
                    headerName: 'Disable', field: 'IsDeactivate', editable: true, cellEditor: 'agSelectCellEditor',
                    cellEditorParams: { values: extractValues(types) }, cellStyle: { 'text-align': "center" }, width: 115,
                    valueFormatter: function (params) {
                        return lookupValue(types, params.value);
                    },
                    valueParser: function (params) { return lookupKey(types, params.newValue); },
                },
                { headerName: 'Updated Date', field: 'UpdatedDate', cellStyle: { 'text-align': "center" }, width: 195 },
                { headerName: 'Updated User', field: 'UserId', cellStyle: { 'text-align': "center" }, width: 145 },
                {
                    headerName: 'Action', field: 'Action', sorting: false, filter: false, cellRenderer: 'editRenderer',
                    cellStyle: { 'text-align': "center" }, width: 90
                },
            ],
            context: { componentParent: this },
            frameworkComponents: { editRenderer: EditRenderer },
            rowData: [],
            defaultColDef: { width: 110, sortable: true, resizable: true, filter: true },
            rowClassRules: {
                'grid-row-even': function (params) { return params.node.rowIndex % 2 === 0; },
                'grid-row-odd': function (params) { return params.node.rowIndex % 2 !== 0; }
            },
        };

        this.onCategoryChanged = this.onCategoryChanged.bind(this);
        this.onUnitChanged = this.onUnitChanged.bind(this);
    }

    onGridReady = params => { this.gridApi = params.api; this.gridColumnApi = params.columnApi; };

    validateAllInputs(){
        if(!this.state.productName || !this.state.productNameKannada || this.state.unitType === 0 || !this.state.rate
            || !this.state.minPurchaseQuantity || this.state.category === 0 ||
            (!this.state.fileName && this.state.productId === 0 )){
            return false;
        }
        else{
            return true;
        }
    }

    create = (event) => {
        event.preventDefault();
        if (validateForm(this.state.errors) && this.validateAllInputs()) {
            this.setState({ loading: true });
            let newProduct = {};
            newProduct.ProductId = this.state.productId;
            newProduct.CategoryId = this.state.category;
            newProduct.ProductName = this.state.productName;
            newProduct.ProductNameKannada = this.state.productNameKannada;
            newProduct.UnitType = this.state.unitType;
            newProduct.RatePerKg = this.state.rate;
            newProduct.MinPurchaseQuantity = this.state.minPurchaseQuantity;
            newProduct.UserId = this.state.userId;
            newProduct.FileType = this.state.fileType;
            newProduct.FileName = this.state.fileName;
            newProduct.FileBase64String = this.state.fileBase64String;
            this.createProduct(newProduct);
        } else {
            let errors = this.state.errors;
            if (!this.state.productName) {
                errors.productName = 'Product name is required';
            }
            if (!this.state.productNameKannada) {
                errors.productNameKannada = 'Product name in kannada is required';
            }
            if (this.state.unitType === 0) {
                errors.unitType = 'Unit type is required';
            }
            if (!this.state.rate) {
                errors.rate = 'Price per kg/peice is required';
            }
            if (!this.state.minPurchaseQuantity) {
                errors.minPurchaseQuantity = 'Minimum purchase quantity is required';
            }
            if (this.state.category === 0) {
                errors.category = 'Select product category';
            }
            if (!this.state.fileName && this.state.productId === 0) {
                errors.productImage = 'Upload product image';
            } else {
                errors.productImage = '';
            }
            this.setState({ errors, errorMessage: null });
        }
    }

    loadProductCategories(){
        let partialUrl = api.URL;
        fetch(partialUrl + 'Product/GetProductCategories')
            .then(res => res.json())
            .then(result => this.setState({ productCategories: result, }))
            .catch(err => console.log(err));
    }

    loadProducts(){
        let partialUrl = api.URL;
        fetch(partialUrl + 'Product/GetProducts')
            .then(res => res.json())
            .then(result => { 
                this.setState({ rowData: result, loading: false });
                console.log(result);
            })
            .catch(err => console.log(err));
    }

    DeleteRecord(){
        this.setState({ loading: true });
        let ProductId = this.state.productId;
        let UserId = this.state.userId;
        let partialUrl = api.URL;
        fetch(partialUrl + 'Product/RemoveProduct?ProductId=' + ProductId + '&UserId=' + UserId, {
            method: 'POST',
            mode: 'cors'
        }).then(data => {
            this.loadProducts();
            this.setState({
                actionName: 'CREATE', productId: 0, productName: null, fileName: null, fileType: null, fileBase64String: null,
                minPurchaseQuantity: null, rate: null, category: 0, totalStock: null, unitType: 0, productNameKannada: null,
            });
        });
    }

    componentDidMount() {
        this.setState({ loading: true });
        let loggedInUser = sessionStorage.getItem('loggedInUser');

        if(loggedInUser) {
            this.setState({ userId: loggedInUser });
            this.loadProductCategories();
            this.loadProducts();
        } else {
            const { history } = this.props;
            if (history) history.push('/Home');
        }
    }

    onCategoryChanged(e) {
        let categoryId = e.target.value;
        this.setState({ category: categoryId });
        if(categoryId === 0){
            this.state.errors.category = 'Select product category';
        }else{
            this.state.errors.category = '';
        }
    };

    editGridRow = row => {
        let errors = this.state.errors;
        errors.productName = errors.rate = errors.minPurchaseQuantity = errors.totalStock = errors.category =
        errors.productImage = errors.unitType = errors.productNameKannada = '';
        this.setState({ errors });

        this.setState({
            productId: row.ProductId,
            category: row.CategoryId,
            productName: row.ProductName,
            productNameKannada: row.ProductNameKannada,
            unitType: row.UnitType,
            rate: row.RatePerKg,
            minPurchaseQuantity: row.MinPurchaseQuantity,
            actionName: 'UPDATE'
        })
    };

    showConfirmPopup = row => {
        this.setState({ productId: row.ProductId })
        this.refs.cnfrmModalComp.openModal();
    }

    createProduct(newProduct) {
        let partialUrl = api.URL;
        fetch(partialUrl + 'Product/CreateProduct', {
            method: 'POST',
            mode: 'cors',
            body: JSON.stringify(newProduct),
            headers: { 'Content-Type': 'application/json' }
        }).then((response) => response.json())
            .then((responseJson) => {
                if (responseJson) {
                    this.loadProducts();
                    this.setState({
                        actionName: 'CREATE', productId: 0, productName: null, deactivate: false,
                        minPurchaseQuantity: null, rate: null, category: 0, totalStock: null,
                        fileName: null, fileType: null, fileBase64String: null, unitType: 0,
                        productNameKannada: null,
                    });
                } else {
                    var errorMsg = 'Duplicate product found.';
                    this.refs.errModalComp.openModal(errorMsg);
                }
            })
    }

    updatePrices = (event) => {
        event.preventDefault();
        this.setState({ loading: true });
        let updatedPriceData = [];
        this.gridApi.forEachNode(function (node) { updatedPriceData.push(node.data); });

        let partialUrl = api.URL;
        fetch(partialUrl + 'Product/UpdateProducts', {
            method: 'POST',
            mode: 'cors',
            body: JSON.stringify(updatedPriceData),
            headers: { 'Content-Type': 'application/json' }
        }).then((response) => response.json())
            .then((responseJson) => {
                if (responseJson) {
                    this.loadProducts();
                    this.setState({
                        actionName: 'CREATE', productId: 0, productName: null, deactivate: false,
                        minPurchaseQuantity: null, rate: null, category: 0, totalStock: null,
                        fileName: null, fileType: null, fileBase64String: null, unitType: 0,
                        productNameKannada: null,
                    });
                }
            })
    }

    handleChange = (event) => {
        event.preventDefault();
        const { name, value } = event.target;
        let errors = this.state.errors;

        switch (name) {
            case 'productName':
                this.state.productName = value;
                errors.productName = value.length <= 0
                    ? 'Product name is required' : '';
                break;
            case 'productNameKannada':
                this.state.productNameKannada = value;
                errors.productNameKannada = value.length <= 0
                    ? 'Product name in kannada is required' : '';
                break;
            case 'rate':
                this.state.rate = value;
                errors.rate = value.length <= 0
                    ? 'Price per kg is required' : !validDecimalRegex.test(value) ? 'Price is not valid' : '';
                break;
            case 'minPurchaseQuantity':
                this.state.minPurchaseQuantity = value;
                errors.minPurchaseQuantity = value.length <= 0
                    ? 'Minimum purchase quantity is required' : !validDecimalRegex.test(value) ? 'Purchase quantity is not valid' : '';
                break;
            default:
                break;
        }
        this.setState({ errors, [name]: value });
    }

    onFileUploadChange = (event) => {
        var file = event.target.files[0];
        var blob = file.slice();
        var reader = new FileReader();

        reader.onloadend = function (evt) {
            if (evt.target.readyState == FileReader.DONE) {
                var cont = evt.target.result
                var base64String = getB64Str(cont);

                this.setState ({
                    fileType: file.type,
                    fileBase64String: base64String,
                    fileName: file.name
                });
            }
        }.bind(this);

        reader.readAsArrayBuffer(blob);
    }

    onUnitChanged(e) {
        let unitType = e.target.value;
        this.setState({ unitType: unitType });
        if(unitType === 0){
            this.state.errors.unitType = 'Select unit type';
        }else{
            this.state.errors.unitType = '';
        }
    };

    render() {
        const { classes, mediaQuery } = this.props;
        const cols = mediaQuery ? 3 : 12;
        const col6 = mediaQuery ? 6 : 12;
        const col3 = mediaQuery ? 2 : 6;
        const col10 = mediaQuery ? 8 : 0;
        let categories = this.state.productCategories;
        let categoryItems = categories.map((category) =>
                <MenuItem value={category.CategoryId}>{category.CategoryName}</MenuItem>
            );

        return (
            <div>
                {this.state.loading ? (
                    <Loader />
                ) : (
                    <div>
                        <ErrorModal ref="errModalComp" />
                        <ConfirmModal ref="cnfrmModalComp" onClick={(e) => this.DeleteRecord(e)} />

                        <form onSubmit={this.loginToDashboard} noValidate>
                            <Grid container spacing={1}>
                                <Grid item xs={col10}>
                                    <h2 className="header-text-color">Add Product</h2>
                                </Grid>
                            </Grid>
                            <Grid container spacing={3}>
                                <Grid item xs={cols}>
                                    <Select fullWidth id="ddlCategory" value={this.state.category} className="selectTopMargin"
                                        onChange={ this.onCategoryChanged }>
                                        {categoryItems}
                                    </Select>
                                    {this.state.errors.category.length > 0 &&
                                        <span className='error'>{this.state.errors.category}</span>}
                                </Grid>
                                <Grid item xs={cols}>
                                    <TextField fullWidth required="true" name="productName" id="txtProductName" label="Product Name"
                                        onChange={this.handleChange} noValidate value={this.state.productName}
                                        InputLabelProps={{ shrink: true, style: { fontSize: 18 } }}/>
                                    {this.state.errors.productName.length > 0 &&
                                        <span className='error'>{this.state.errors.productName}</span>}
                                </Grid>
                                <Grid item xs={cols}>
                                    <TextField fullWidth required="true" name="productNameKannada" id="txtProductNameKannada" label="Product Name In Kannada"
                                        onChange={this.handleChange} noValidate value={this.state.productNameKannada}
                                        InputLabelProps={{ shrink: true, style: { fontSize: 18 } }}/>
                                    {this.state.errors.productNameKannada.length > 0 &&
                                        <span className='error'>{this.state.errors.productNameKannada}</span>}
                                </Grid>
                                <Grid item xs={cols}>
                                    <Select fullWidth id="ddlUnitType" value={this.state.unitType} className="selectTopMargin"
                                        onChange={ this.onUnitChanged }>
                                        <MenuItem value="0">Choose Unit Type</MenuItem>
                                        <MenuItem value="KG">KG</MenuItem>
                                        <MenuItem value="Piece">Piece</MenuItem>
                                    </Select>
                                    {this.state.errors.unitType.length > 0 &&
                                        <span className='error'>{this.state.errors.unitType}</span>}
                                </Grid>
                            </Grid>
                            <Grid container spacing={3}>
                                <Grid item xs={cols}>
                                    <TextField fullWidth required="true" name="rate" id="txtRate" label="Price Per Kg/Piece"
                                        onChange={this.handleChange} noValidate value={this.state.rate}
                                        InputLabelProps={{ shrink: true, style: { fontSize: 18 } }}/>
                                    {this.state.errors.rate.length > 0 &&
                                        <span className='error'>{this.state.errors.rate}</span>}
                                </Grid>
                                <Grid item xs={cols}>
                                    <TextField fullWidth required="true" name="minPurchaseQuantity" id="txtMinPurchaseQuantity" label="Minimum Purchase Quantity"
                                        onChange={this.handleChange} noValidate value={this.state.minPurchaseQuantity}
                                        InputLabelProps={{ shrink: true, style: { fontSize: 18 } }}/>
                                    {this.state.errors.minPurchaseQuantity.length > 0 &&
                                        <span className='error'>{this.state.errors.minPurchaseQuantity}</span>}
                                </Grid>
                                <Grid item xs={col6}>
                                    <TextField fullWidth required="true" name="productImage" type="file" onChange={ e => {this.onFileUploadChange(e)}}
                                        label="Upload Product Image" InputLabelProps={{ shrink: true, style: { fontSize: 18 } }} />
                                    {this.state.errors.productImage.length > 0 &&
                                        <span className='error'>{this.state.errors.productImage}</span>}
                                </Grid>
                            </Grid>
                            <Grid container spacing={ mediaQuery ? 1  : 0 }>
                                <Grid item xs={col10}></Grid>
                                <Grid item xs={col3}>
                                    <Button fullWidth className={classes.root} variant="contained"
                                        color="primary" onClick={this.updatePrices}>
                                        <SystemUpdateAltIcon className={classes.leftIcon} />Update Price</Button>
                                </Grid>
                                <Grid item xs={col3}>
                                    <Button fullWidth className={classes.root} variant="contained"
                                        color="primary" onClick={this.create}>
                                        <CreateIcon className={classes.leftIcon} />{ this.state.actionName }</Button>
                                </Grid>
                            </Grid>
                        </form>

                        <Grid container spacing={0}>
                            <Grid item xs={12}>
                                <div className="ag-theme-alpine" style={{ width: "100%", height: 440, marginTop: 10 }}>
                                    <AgGridReact
                                        columnDefs={this.state.columnDefs} rowData={this.state.rowData}
                                        onGridReady={this.onGridReady} defaultColDef={this.state.defaultColDef}
                                        frameworkComponents={this.state.frameworkComponents} context={this.state.context}
                                        pagination={true} gridOptions={this.gridOptions} paginationPageSize={100}
                                        components={this.state.components} rowClassRules={this.state.rowClassRules}
                                        singleClickEdit={true}
                                    />
                                </div>
                            </Grid>
                        </Grid>
                    </div>
                    )}
            </div>
        );
    }
}

export default withRouter(withStyles(useStyles)(withMediaQuery('(min-width:600px)')(Products)))

var types = {
    "NO": "NO",
    "YES": "YES"
};

function lookupValue(mappings, key) {
    return mappings[key];
};

function extractValues(mappings) {
    return Object.keys(mappings);
};

function lookupKey(mappings, name) {
    for (var key in mappings) {
        if (mappings.hasOwnProperty(key)) {
            if (name === mappings[key]) {
                return key;
            }
        }
    }
};

function getB64Str (buffer) {
    var binary = '';
    var bytes = new Uint8Array(buffer);
    var len = bytes.byteLength;
    for (var i = 0; i < len; i++) {
        binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
}