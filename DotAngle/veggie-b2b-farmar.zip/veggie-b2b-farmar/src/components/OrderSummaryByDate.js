import React, { Component } from 'react';
import { 
    Grid, withStyles, Table, TableBody, TableContainer, TableCell, TableHead, TableRow,
    Paper, useMediaQuery, Card, CardContent, MenuItem, Select
} from '@material-ui/core';
import api from './common/APIValues';
import Loader from './loader/Loader';
import { Link } from "react-router-dom";
import { useStyles } from './common/useStyles';

// const useStyles = theme => ({
//     leftIcon: {
//         marginRight: theme.spacing.unit,
//     },
//     topMargin: {
//         marginTop: 10,
//     },
//     root: {
//         fontSize: 12, height: '2.1rem', marginTop: 20,
//         backgroundColor: "#0079c2",
//         "&:hover": {
//             backgroundColor: "#0079c2"
//         },
//         "&:disabled": {
//             backgroundColor: "rgba(0, 0, 0, 0.12)"
//         },
//     },
// });

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);    
    return <Component mediaQuery={mediaQuery} {...props} />;
};

class OrderSummaryByDate extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            open: false, rowData: [], loading: false, orderedDate: null, OrderSummaryDetails: {},
            rowData: [], routes: [], route: '0'
        };

        this.onRouteChanged = this.onRouteChanged.bind(this);
    }

    loadRoutes(){
        let partialUrl = api.URL;
        fetch(partialUrl + 'Customer/GetRoutes')
            .then(res => res.json())
            .then(result => this.setState({ routes: result, }))
            .catch(err => console.log(err));
    }

    onRouteChanged(e) {
        let route = e.target.value;
        this.setState({ route: route });
        let orderedDateRef = sessionStorage.getItem('OrderedDateRef');
        this.loadOrderSummaryByDate(orderedDateRef, route);
    };

    loadOrderSummaryByDate(orderedDate, route) {
        let partialUrl = api.URL;
        fetch(partialUrl + 'OrderSummary/GetTotalWeightPerProduct?OrderedDate='+ orderedDate + '&Route='+ route)
            .then(res => res.json())
            .then(result => {
                this.setState({ rowData: result, loading: false, orderedDate: orderedDate });
            })
            .catch(err => console.log(err));
    }

    componentDidMount() {
        let loggedInUser = sessionStorage.getItem('loggedInUser');
        console.log(this.props.history, 'abhi');
        if(loggedInUser) {
            let orderedDateRef = sessionStorage.getItem('OrderedDateRef');
            if(orderedDateRef) {
                this.setState({ loading: true });
                this.loadOrderSummaryByDate(orderedDateRef, '');
                this.loadRoutes();
            }
        } else {
            const { history } = this.props;
            if (history) history.push('/Home');
        }
    }

    showProductsSPlitUp (productId, productName) {
        console.log(this.props);
        const { history } = this.props;
        if (history) history.push({ 
            pathname: '/OrderProductSummary', productIdRef: productId, productNameRef: productName
        });
    }

    render() {
        const { classes, mediaQuery } = this.props;
        const col10 = mediaQuery ? 10 : 8;
        const col2 = mediaQuery ? 2 : 4;
        let _routes = this.state.routes;
        let routes = _routes.map((route) =>
                <MenuItem value={route.RouteCategory}>{route.RouteName}</MenuItem>
            );

        return (
            <div>
                {this.state.loading ? (
                    <Loader />
                ) : (
                    <div>
                        <Grid container spacing={0}>                            
                            <Grid item xs={col10}>
                                <h2 className="header-text-color">Order Summary</h2>
                            </Grid>
                            <Grid item xs={col2}>
                                <Select fullWidth id="ddRoute" value={this.state.route} onChange={ this.onRouteChanged }
                                    className="selectTopMargin">
                                    {routes}
                                </Select>
                            </Grid>
                        </Grid>

                        <Grid container spacing={0}>                                                            
                            <Grid item xs={12}>
                                <Card style={{ border: '1px solid #f16623' }}>
                                    <CardContent> 
                                        <Grid container spacing={4}>                                                            
                                            <Grid item xs={3}>
                                                Order Date: { sessionStorage.getItem('OrderedDateRef') }
                                            </Grid>                            
                                            <Grid item xs={3}>
                                                Total Orders: { sessionStorage.getItem('TotalOrdersRef') }
                                            </Grid>                                            
                                            <Grid item xs={3}>
                                                Total Price: { sessionStorage.getItem('TotalPriceRef') }
                                            </Grid>                 
                                            <Grid item xs={3}>
                                                Delivery Charges: { sessionStorage.getItem('DeliveryChargesRef') }
                                            </Grid>              
                                        </Grid>
                                        <Grid container spacing={4}>
                                            <Grid item xs={3}>
                                                Total Customers Ordered: { sessionStorage.getItem('TotalVendorsOrderedRef') }
                                            </Grid>
                                            <Grid item xs={3}>
                                                Overall Total Weight: { sessionStorage.getItem('TotalWeightRef') } Kg
                                            </Grid>
                                            <Grid item xs={3}>
                                                Overall Total Pieces: { sessionStorage.getItem('TotalPiecesRef') }
                                            </Grid>                              
                                        </Grid>
                                    </CardContent>
                                </Card>
                            </Grid>
                        </Grid>

                        <Grid container spacing={0}>
                            <Grid item xs={12}>
                                <TableContainer component={Paper} className={classes.topMargin}>                                    
                                    <Table className={classes.table} aria-label="simple table">
                                        <TableHead className="table-header-custom">
                                            <TableRow>                                                
                                                <TableCell style={{ color: 'white', fontSize: 16 }} align="center">Product Name</TableCell>                                             
                                                <TableCell style={{ color: 'white', fontSize: 16 }} align="left">Total Weight</TableCell>
                                                <TableCell style={{ color: 'white', fontSize: 16 }} align="center"></TableCell>
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                        {this.state.rowData.map((data, index) => (
                                            <TableRow key={data.ProductId}>                                                
                                                <TableCell align="center">{data.ProductName}</TableCell>
                                                <TableCell align="left">
                                                    <Link to={{ pathname: '/OrderProductSummary', productData: { 
                                                            productIdRef : data.ProductId, productNameRef : data.ProductName,
                                                            totalWeightRef: data.TotalWeight
                                                        } }}>
                                                        {data.TotalWeight}
                                                    </Link>
                                                </TableCell>
                                                <TableCell align="center"></TableCell>                                                
                                            </TableRow>
                                        ))}
                                        </TableBody>
                                    </Table>
                                </TableContainer>
                            </Grid>                        
                        </Grid>
                    </div>
                    )}
            </div>
        );
    }
}

export default withStyles(useStyles)(withMediaQuery('(min-width:600px)')(OrderSummaryByDate))