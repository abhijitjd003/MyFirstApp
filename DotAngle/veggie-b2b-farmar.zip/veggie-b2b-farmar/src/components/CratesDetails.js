import React, { Component } from 'react';
import { Button, Grid, withStyles, useMediaQuery, Typography, Paper, ButtonBase } from '@material-ui/core';
import { useStyles } from './common/useStyles';
import api from './common/APIValues';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import Loader from './loader/Loader';

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);    
    return <Component mediaQuery={mediaQuery} {...props} />;
};

class CratesDetails extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            open: false, rowData: {}, loading: false, orderedDate: null, count: 0, overallWeight: null, productsData: [],
            cratesCount: [],
        };
    }

    loadProducts(orderedDate, productId){
        let partialUrl = api.URL;       
        fetch(partialUrl + 'OrderSummary/GetCratesDetails?OrderedDate='+ orderedDate + '&ProductId='+ productId)
            .then(res => res.json())
            .then(result => {                
                this.setState({ rowData: result.orderSummary, cratesCount: result.orderCrates, loading: false })
            })
            .catch(err => console.log(err));
    }

    loadOrderSummaryByDate(orderedDate) {
        let partialUrl = api.URL;
        fetch(partialUrl + 'OrderSummary/GetTotalWeightPerProduct?OrderedDate='+ orderedDate + '&Route=')
            .then(res => res.json())
            .then(result => {
                this.setState({ productsData: result });
            })
            .catch(err => console.log(err));
    }

    componentDidMount() {
        let loggedInUser = sessionStorage.getItem('loggedInUser');
        let orderedDate = sessionStorage.getItem('OrderedDateRef');
        this.setState({ overallWeight: sessionStorage.getItem('TotalWeightRef') });
        
        if(loggedInUser) {            
                this.setState({ loading: true })
                let intervalCount = sessionStorage.getItem('IntervalCount');
                const interval = setInterval(() => {

                    this.loadOrderSummaryByDate(orderedDate);
                    
                    let productIds = ''; let maxCount = 0;
                    this.state.productsData.map((data) => {
                        productIds = productIds + data.ProductId + ',';
                        maxCount = Number(maxCount) + 1;
                    });

                    if(productIds) {
                        this.loadProducts(orderedDate, Number(productIds.split(',')[this.state.count]));
                        if(this.state.count < maxCount - 1) {
                            this.setState({ count: this.state.count + 1 });
                        } else {
                            this.setState({ count: 0 });
                        }
                    }

                }, intervalCount);
                return () => clearInterval(interval);
        } else {
            const { history } = this.props;
            if (history) history.push('/Home');
        }
    }

    goBack = () => {
        const { history } = this.props;
        if (history) history.push('/OrderSummary');
    };

    render() {
        const { classes, mediaQuery } = this.props;

        return (
            <div>
                {this.state.loading ? (
                    <Loader />
                ) : (
            <div>
                <Grid container spacing={0}>                                                      
                    <Grid item xs={2}>
                        <Button fullWidth className={classes.root} variant="contained"
                            color="primary" onClick={this.goBack}>
                        <ArrowBackIcon className={classes.leftIcon} />Go Back</Button>
                    </Grid>
                </Grid>

                <Grid style={{ marginTop: 0 }} container spacing={2}>                
                <Grid item xs={12}>
                <Paper className={classes.paper}>
                    <Grid container spacing={2}>
                        <Grid item xs={12}>
                        <Typography gutterBottom style={{ textAlign: 'center', color: '#347f58', fontWeight: 'bold', fontSize: 60 }} 
                            variant="subtitle1">                            
                            {this.state.rowData.ProductName}
                        </Typography>
                        </Grid>
                        <Grid style={{ marginLeft: 70 }} item>
                            <ButtonBase className={classes.image}>                                
                                <img className={classes.img} alt="complex" src={ this.state.rowData.ProductImagePath } />
                            </ButtonBase>
                        </Grid>
                        <Grid style={{ marginLeft: 70 }} item xs={12} sm container>
                            <Grid item xs container direction="row" spacing={2}>
                                <Grid item xs={5}>                                
                                    <Typography variant="body2" style={{ textAlign: 'left', fontSize: 43 }} color="textSecondary">
                                        Weight: { this.state.rowData.TotalWeight } { this.state.rowData.UnitType }                                        
                                    </Typography>
                                </Grid>
                                <Grid item xs={7}>                                
                                    <Typography variant="body2" style={{ textAlign: 'left', fontSize: 43 }} color="textSecondary">
                                        Total Orders: { this.state.rowData.OverallWeight } Kg
                                    </Typography>
                                </Grid>
                                {this.state.cratesCount.map((data, index) => (
                                    <Grid item xs={4}>
                                        <Typography variant="body2" style={{ textAlign: 'left', fontSize: 43 }} color="textSecondary">
                                            <b>{data.Weight}</b> X {data.OrderCount}
                                        </Typography>
                                    </Grid>
                                ))}                                                      
                            </Grid>
                        </Grid>
                    </Grid>
                </Paper>
                </Grid>
                </Grid>                
            </div>
            )}
            </div>
        );
    }
}

export default withStyles(useStyles)(withMediaQuery('(min-width:600px)')(CratesDetails))