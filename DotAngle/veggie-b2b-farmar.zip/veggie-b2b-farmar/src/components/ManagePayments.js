import React, { Component } from 'react';
import './common/Common.css';
import { Grid, withStyles, Button, useMediaQuery, InputLabel, TextField, MenuItem, Select } from '@material-ui/core';
import './common/CommonModal.css';
import { withRouter, Link } from 'react-router-dom';
import Loader from './loader/Loader';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import LinkRenderer from './common/LinkRenderer';
import EditRenderer from './common/EditRenderer';
import PaymentModal from './modal/PaymentModal';
import api from './common/APIValues';
import BuildIcon from '@material-ui/icons/Build';
import 'date-fns';
import DateFnsUtils from '@date-io/date-fns';
import { MuiPickersUtilsProvider, KeyboardDatePicker } from '@material-ui/pickers';
import ConfirmModal from './modal/ConfirmModal';
import ErrorModal from './modal/ErrorModal';
import CloseIcon from '@material-ui/icons/Close';
import Popup from "reactjs-popup";
import Autocomplete from '@material-ui/lab/Autocomplete';
import { useStyles } from './common/useStyles';

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);    
    return <Component mediaQuery={mediaQuery} {...props} />;
};

class ManagePayments extends Component {
    constructor(props) {
        super(props);
        this.state = {
            orderNo: 0, userId: null, loading: false, orderedDate: null, totalPrice: null, totalOutstanding: null,
            showDetails: false, orderedFormatDate: '', shopId: 0, open: false, errorTypeMsg: '', header: '', vendors: [],
            status: 0,
            columnDefs: [
                { 
                    headerName: '', field: 'Action', width: 60, sorting: false, filter: false, 
                    cellRenderer: 'editRenderer',
                },
                { headerName: 'Order No', field: 'OrderNo', width: 125, cellStyle: { 'text-align': "center" } },                
                { headerName: 'Shop Name', field: 'ShopName', flex: 1, cellStyle: { 'text-align': "center" } },
                { headerName: 'Price', field: 'Price', width: 125, cellStyle: { 'text-align': "center" } },
                { headerName: 'Delivery Charges', field: 'DeliveryCharges', width: 170, cellStyle: { 'text-align': "center" } },
                { headerName: 'Received', field: 'Received', width: 125, cellStyle: { 'text-align': "center" } },
                { headerName: 'Outstanding', field: 'Outstanding', width: 140, cellStyle: { 'text-align': "center" } },                
                { headerName: 'Payment Status', field: 'PaymentStatus', width: 160, cellStyle: { 'text-align': "center" } },
            ],
            context: { componentParent: this },
            frameworkComponents: { linkRenderer: LinkRenderer, editRenderer: EditRenderer },
            rowData: [],
            defaultColDef: { sortable: true, resizable: true, filter: true },
            rowClassRules: {
                'grid-row-even': function (params) { return params.node.rowIndex % 2 === 0; },
                'grid-row-odd': function (params) { return params.node.rowIndex % 2 !== 0; }
            },
            suppressRowClickSelection: true,
            rowSelection: 'multiple',
        };
        this.onStatusChanged = this.onStatusChanged.bind(this);
    }

    onGridReady = params => { this.gridApi = params.api; this.gridColumnApi = params.columnApi; };
    
    onDateChanged = (date) => { 
        this.setState({ orderedDate: date });
        let shopId = this.state.shopId;
        let orderedDate = '';
        if(date){
            var dd = String(date.getDate()).padStart(2, '0');
            var mm = String(date.getMonth() + 1).padStart(2, '0');
            var yyyy = date.getFullYear();
            orderedDate = dd + "/" + mm + "/" + yyyy;
        }
        this.setState({ orderedFormatDate: orderedDate });
        this.loadOrders(shopId, orderedDate, this.state.status);
    };

    onStatusChanged(e) {
        this.setState({ status: e.target.value });
        let status = e.target.value;
        this.loadOrders(this.state.shopId, this.state.orderedFormatDate, status);
    };

    loadVendors(){
        let status = 'Approved';
        let partialUrl = api.URL;
        fetch(partialUrl + 'Customer/GetCustomers?Status=' + status)
            .then(res => res.json())
            .then(result => {
                this.setState({ vendors: result, })
            })
            .catch(err => console.log(err));
    }

    loadOrders(shopId, orderedDate, status){
        let partialUrl = api.URL;
        let customerId = 0; if (shopId) {
            customerId = shopId;
        }

        fetch(partialUrl + 'Payment/GetPayments?ShopId=' + customerId + '&OrderedDate=' + orderedDate + '&Status=' + status)
            .then(res => res.json())
            .then(result => {
                this.setState({ rowData: result.payments, totalPrice: result.TotalPrice, 
                    totalOutstanding: result.TotalOutstanding, loading: false })
                if(customerId > 0) {
                    this.setState({ showDetails: true });
                }
            })
            .catch(err => console.log(err));
    }

    editGridRow = row => {
        let orderNo = row.OrderNo;
        this.setState({ orderNo: orderNo });
        this.refs.paymentModalComp.openModal( Number(row.Price) + Number(row.DeliveryCharges), row.Received, row.PaymentStatus);
    };

    updatePayment = (paymentStatus, receivedAmount) => {
        this.setState({ loading: true });
        let orderData = {};
        orderData.PaymentStatus = paymentStatus !== '0' ? paymentStatus : '';
        orderData.Received = receivedAmount;
        orderData.OrderNo = this.state.orderNo;
        let partialUrl = api.URL;
        fetch(partialUrl + 'Payment/UpdatePayment', {
             method: 'POST',
            mode: 'cors',
            body: JSON.stringify(orderData),
            headers: { 'Content-Type': 'application/json' }
        }).then((response) => response.json())
            .then((responseJson) => {
                if (responseJson) {
                    this.loadOrders(this.state.shopId, this.state.orderedFormatDate, this.state.status);
                    this.setState({ loading: false });                    
                }
            })
    }

    componentDidMount() {
        let loggedInUser = sessionStorage.getItem('loggedInUser');
        
        if(loggedInUser) {
            this.setState({ userId: loggedInUser, loading: true });
            let orderedDate = '';
            if(this.state.orderedDate){
                var dd = String(this.state.orderedDate.getDate()).padStart(2, '0');
                var mm = String(this.state.orderedDate.getMonth() + 1).padStart(2, '0');
                var yyyy = this.state.orderedDate.getFullYear();
                orderedDate = dd + "/" + mm + "/" + yyyy;
            }
            this.loadOrders(0, orderedDate, 0);
            this.loadVendors();
        } else {
            const { history } = this.props;
            if (history) history.push('/Home');
        }
    }

    render() {
        const { classes, mediaQuery } = this.props;        
        const col3 = mediaQuery ? 3 : 4;
        const col5 = mediaQuery ? 5 : 0;
        const col23 = mediaQuery ? 2 : 3;
        let vendors = this.state.vendors;
        
        return (
            <div>
                {this.state.loading ? (
                    <Loader />
                ) : (
                    <div>                        
                        <PaymentModal ref="paymentModalComp" onClick={(paymentStatus, receivedAmount) => 
                            this.updatePayment(paymentStatus, receivedAmount)} />

                        <Grid container spacing={0}>
                            <Grid item xs={8}>
                                <h2 className="header-text-color">Manage Payments</h2>
                            </Grid>
                            { this.state.shopId > 0 &&
                                <Grid item xs={2}>                                
                                    <div style={{ marginTop: 30 }}>
                                        Total Price: { this.state.totalPrice }
                                    </div>                               
                                </Grid>
                            }
                            { this.state.shopId > 0 &&
                                <Grid item xs={2}>
                                    <div style={{ marginTop: 30 }}>                                                                            
                                        Total Outstanding: { this.state.totalOutstanding }
                                    </div>
                                </Grid>
                            }
                        </Grid>

                        <Grid container spacing={3}>
                            <Grid item xs={col3} style={{ marginTop: 16 }}>
                                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                    <KeyboardDatePicker fullWidth format="dd/MM/yyyy"
                                        id="dateUpdated" label="Ordered Date"
                                        value={this.state.orderedDate}
                                        onChange={this.onDateChanged}
                                        KeyboardButtonProps={{
                                            'aria-label': 'change date',
                                        }}
                                    />
                                </MuiPickersUtilsProvider>
                            </Grid>
                            <Grid item xs={col3}>
                                <Autocomplete debug id="debug" options={vendors} getOptionLabel={(option) => option.ShopName}                                  
                                    onChange={(event, value) => {
                                        if(value){
                                            let shopId = value.ShopId;
                                            this.setState({ shopId: shopId });
                                            this.loadOrders(shopId, this.state.orderedFormatDate, this.state.status);
                                        } else {
                                            this.setState({ shopId: 0 });
                                            this.loadOrders(0, this.state.orderedFormatDate, this.state.status);
                                        }
                                    }}
                                    renderInput={ params => (
                                        <TextField {...params} label="Choose Shop Name" margin="normal" fullWidth />
                                    )}
                                />
                            </Grid>
                            <Grid item xs={col3}>
                                <Select fullWidth id="ddlStatus" value={this.state.status} style={{ marginTop: 32 }}
                                    onChange={ this.onStatusChanged }>
                                    <MenuItem value="0">Choose Payment Status</MenuItem>
                                    <MenuItem value="Pending">Pending</MenuItem>
                                    <MenuItem value="Partial">Partial</MenuItem>
                                    <MenuItem value="Received">Received</MenuItem>
                                </Select>
                            </Grid>                            
                        </Grid>

                        <Grid container spacing={0}>
                            <Grid item xs={12}>
                                <div className="ag-theme-alpine" style={{ width: "100%", height: 520, marginTop: 10 }}>
                                    <AgGridReact
                                        columnDefs={this.state.columnDefs} rowData={this.state.rowData}
                                        onGridReady={this.onGridReady} defaultColDef={this.state.defaultColDef}
                                        frameworkComponents={this.state.frameworkComponents} context={this.state.context}
                                        pagination={true} gridOptions={this.gridOptions} paginationPageSize={100}
                                        components={this.state.components} rowClassRules={this.state.rowClassRules} 
                                        suppressClickEdit={true}
                                    />
                                </div>
                            </Grid>                        
                        </Grid>
                    </div>
                    )}
            </div>
        );
    }
}

export default withRouter(withStyles(useStyles)(withMediaQuery('(min-width:600px)')(ManagePayments)))