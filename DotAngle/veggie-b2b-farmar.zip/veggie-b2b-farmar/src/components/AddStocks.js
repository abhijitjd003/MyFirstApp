import React, { Component } from 'react';
import './common/Common.css';
import { Button, TextField, Grid, withStyles, FormControlLabel, Checkbox, useMediaQuery, MenuItem, Select } from '@material-ui/core';
import './common/CommonModal.css';
import { withRouter } from 'react-router-dom';
import Loader from './loader/Loader';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import EditRenderer from './common/EditRenderer';
import ConfirmModal from './modal/ConfirmModal';
import ErrorModal from './modal/ErrorModal';
import api from './common/APIValues';
import CreateIcon from '@material-ui/icons/Create';
import RestoreFromTrashIcon from '@material-ui/icons/RestoreFromTrash';
import { useStyles } from './common/useStyles';

// const useStyles = theme => ({
//     leftIcon: {
//         marginRight: theme.spacing.unit,
//     },
//     topMargin: {
//         marginTop: 16,
//     },
//     root: {
//         fontSize: 12, height: '2.1rem', marginTop: 20,
//         backgroundColor: "#2b494b",
//         "&:hover": {
//             backgroundColor: "#2b494b"
//         },
//         "&:disabled": {
//             backgroundColor: "rgba(0, 0, 0, 0.12)"
//         },
//     },
// });

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);    
    return <Component mediaQuery={mediaQuery} {...props} />;
};

const validateForm = (errors) => {
    let valid = true;
    Object.keys(errors).map(function (e) {
        if (errors[e].length > 0) {
            valid = false;
        }        
    });
    return valid;
}

class AddStocks extends Component {
    constructor(props) {
        super(props);
        this.state = {
            vendorId: 0, productId: 0, totalWeight: null, gradeAWeight: null, gradeBWeight: null, dumpWeight: null,
            errorMessage: null, loading: false, actionName: 'CREATE', userId: null, vendors: [], products: [], stockId: 0,
            errors: {
                vendorId: '',
                productId: '',
                totalWeight: '',
                gradeAWeight: '',
            },
            columnDefs: [                
                { headerName: 'Vendor Name', field: 'VendorName', cellStyle: { 'text-align': "center" }, width: 145 },
                { headerName: 'Product Name', field: 'ProductName', cellStyle: { 'text-align': "center" }, width: 250 },
                { headerName: 'Total Weight', field: 'TotalWeight', cellStyle: { 'text-align': "center" }, width: 140 },
                { headerName: 'Grade A Weight', field: 'GradeAWeight', cellStyle: { 'text-align': "center" }, width: 160 },
                { headerName: 'Grade B Weight', field: 'GradeBWeight', cellStyle: { 'text-align': "center" }, width: 160 },
                { headerName: 'Dump Weight', field: 'DumpWeight', cellStyle: { 'text-align': "center" }, width: 145 },
                { headerName: 'Created Date', field: 'CreatedDateTime', cellStyle: { 'text-align': "center" }, width: 145 },
                { headerName: 'Created User', field: 'CreatedUserId', cellStyle: { 'text-align': "center" }, width: 145 },
                { headerName: 'Action', field: 'Action', sorting: false, filter: false, cellRenderer: 'editRenderer', 
                    cellStyle: { 'text-align': "center" }, width: 85 },
            ],
            context: { componentParent: this },
            frameworkComponents: { editRenderer: EditRenderer },
            rowData: [],
            defaultColDef: { width: 110, sortable: true, resizable: true, filter: true },
            rowClassRules: {
                'grid-row-even': function (params) { return params.node.rowIndex % 2 === 0; },
                'grid-row-odd': function (params) { return params.node.rowIndex % 2 !== 0; }
            },
        };

        this.onVendorChanged = this.onVendorChanged.bind(this);
        this.onProductChanged = this.onProductChanged.bind(this);
    }

    validateAllInputs(){
        if(!this.state.totalWeight || this.state.vendorId === 0 || !this.state.gradeAWeight || this.state.productId === 0){
            return false;
        }
        else{
            return true;
        }
    }

    create = (event) => {
        event.preventDefault();
        if (validateForm(this.state.errors) && this.validateAllInputs()) {
            let totalGradeWeight =  Number(this.state.gradeAWeight) + Number(this.state.gradeBWeight) + Number(this.state.dumpWeight);
            if(Math.round(totalGradeWeight * 100) / 100 === Number(this.state.totalWeight)) {
                this.setState({ loading: true });
                let newStock = {};
                newStock.StockId = this.state.stockId;
                newStock.VendorId = this.state.vendorId;
                newStock.ProductId = this.state.productId;
                newStock.TotalWeight = this.state.totalWeight;
                newStock.GradeAWeight = this.state.gradeAWeight;
                newStock.GradeBWeight = this.state.gradeBWeight;
                newStock.DumpWeight = this.state.dumpWeight;
                newStock.CreatedUserId = this.state.userId;
                this.createStock(newStock);
            } else {
                var errorMsg = 'Sum of Grade A Weight, Grade B Weight and Dump Weight should be equal to Total Weight.';
                this.refs.errModalComp.openModal(errorMsg);
            }
        } else {
            let errors = this.state.errors;
            if (this.state.vendorId === 0) {
                errors.vendorId = 'Select vendor name';
            }
            if (this.state.productId === 0) {
                errors.productId = 'Select product name';
            }
            if (!this.state.totalWeight) {
                errors.totalWeight = 'Total weight is required';
            }
            if (!this.state.gradeAWeight) {
                errors.gradeAWeight = 'Grade A weight is required';
            }
            this.setState({ errors, errorMessage: null });
        }
    }

    loadStocks(){
        let partialUrl = api.URL;
        fetch(partialUrl + 'Stock/GetStocks')
            .then(res => res.json())
            .then(result => this.setState({ rowData: result, loading: false }))
            .catch(err => console.log(err));
    }

    DeleteRecord(){
        this.setState({ loading: true })
        let StockId = this.state.stockId;
        let partialUrl = api.URL;
        fetch(partialUrl + 'Stock/RemoveStock?StockId=' + StockId, {
            method: 'POST',
            mode: 'cors'
        }).then(data => {
            this.loadStocks();
            this.setState({ loading: false })
        });
    }

    loadVendors(){
        let partialUrl = api.URL;
        fetch(partialUrl + 'Vendor/GetValidVendors')
            .then(res => res.json())
            .then(result => this.setState({ vendors: result, loading: false }))
            .catch(err => console.log(err));
    }

    loadProducts(){
        let partialUrl = api.URL;
        fetch(partialUrl + 'Product/GetValidProducts')
            .then(res => res.json())
            .then(result => this.setState({ products: result, loading: false }))
            .catch(err => console.log(err));
    }

    componentDidMount() {
        let loggedInUser = sessionStorage.getItem('loggedInUser');

        if(loggedInUser) {
            this.setState({ userId: loggedInUser, loading: true });
            this.loadVendors();
            this.loadProducts();
            this.loadStocks();
        } else {
            const { history } = this.props;
            if (history) history.push('/Home');
        }
    }

    editGridRow = row => {
        this.setState({
            stockId: row.StockId,
            vendorId: row.VendorId,
            productId: row.ProductId,
            totalWeight: row.TotalWeight,
            gradeAWeight: row.GradeAWeight,
            gradeBWeight: row.GradeBWeight,
            dumpWeight: row.DumpWeight,
            actionName: 'UPDATE'
        })
    };

    showConfirmPopup = row => {
        this.setState({ stockId: row.StockId })
        this.refs.cnfrmModalComp.openModal();
    }

    createStock(newStock) {
        let partialUrl = api.URL;
        fetch(partialUrl + 'Stock/CreateStock', {
            method: 'POST',
            mode: 'cors',
            body: JSON.stringify(newStock),
            headers: { 'Content-Type': 'application/json' }
        }).then((response) => response.json())
            .then((responseJson) => {
                if (responseJson) {
                    this.loadStocks();
                    this.setState({ 
                        loading: false, actionName: 'CREATE', vendorId: 0, productId: 0, totalWeight: null, gradeAWeight: null, 
                        gradeBWeight: null, stockId: null, dumpWeight: null,
                    });
                } else {
                    this.setState({ 
                        loading: false, actionName: 'CREATE', vendorId: 0, productId: 0, totalWeight: null, gradeAWeight: null, 
                        gradeBWeight: null, stockId: null, dumpWeight: null,
                    });
                    var errorMsg = 'Duplicate stocks found.';
                    this.refs.errModalComp.openModal(errorMsg);
                }
            })
    }

    handleChange = (event) => {
        event.preventDefault();
        const { name, value } = event.target;
        let errors = this.state.errors;

        switch (name) {
            case 'totalWeight':
                this.state.totalWeight = value;
                errors.totalWeight = value.length <= 0 ? 'Total weight is required' : !Number(value) ? 'Total weight is not valid' : '';
                break;
            case 'gradeAWeight':
                this.state.gradeAWeight = value;
                errors.gradeAWeight = value.length <= 0 ? 'Grade A weight is required' : !Number(value) ? 'Grade A weight is not valid' : '';
                break;            
            default:
                break;
        }
        this.setState({ errors, [name]: value });
    }

    onVendorChanged(e) {
        let vendorId = e.target.value; 
        this.setState({ vendorId: vendorId });
        if(vendorId === 0){
            this.state.errors.vendorId = 'Select vendor name';
        }else{
            this.state.errors.vendorId = '';
        }
    };

    onProductChanged(e) {
        let productId = e.target.value; 
        this.setState({ productId: productId });
        if(productId === 0){
            this.state.errors.productId = 'Select product name';
        }else{
            this.state.errors.productId = '';
        }
    };

    render() {
        const { classes, mediaQuery } = this.props;        
        const col3 = mediaQuery ? 4 : 12;
        const col2 = mediaQuery ? 2 : 12;
        const col0 = mediaQuery ? 10 : 0;

        let vendors = this.state.vendors.map((vendor) =>
            <MenuItem value={vendor.VendorId}>{vendor.ContactName}</MenuItem>
        );

        let products = this.state.products.map((product) =>
            <MenuItem value={product.ProductId}>{product.ProductName}</MenuItem>
        );
        
        return (
            <div>
                {this.state.loading ? (
                    <Loader />
                ) : (
                    <div>
                        <ErrorModal ref="errModalComp" />
                        <ConfirmModal ref="cnfrmModalComp" onClick={(e) => this.DeleteRecord(e)} />

                        <form onSubmit={this.loginToDashboard} noValidate>
                            <h2 className="header-text-color">Add Stocks</h2>
                            <Grid container spacing={3}>
                                <Grid item xs={col3}>
                                    <Select fullWidth id="ddlVendor" value={this.state.vendorId} className="selectTopMargin"
                                        onChange={ this.onVendorChanged }>
                                        <MenuItem value={0}>Choose Vendor</MenuItem>
                                        {vendors}
                                    </Select>
                                    {this.state.errors.vendorId.length > 0 &&
                                        <span className='error'>{this.state.errors.vendorId}</span>}
                                </Grid>
                                <Grid item xs={col3}>
                                    <Select fullWidth id="ddlProduct" value={this.state.productId} className="selectTopMargin"
                                        onChange={ this.onProductChanged }>
                                        <MenuItem value={0}>Choose Product</MenuItem>
                                        {products}
                                    </Select>
                                    {this.state.errors.productId.length > 0 &&
                                        <span className='error'>{this.state.errors.productId}</span>}                                   
                                </Grid>
                                <Grid item xs={col3}>
                                    <TextField fullWidth required="true" name="totalWeight" id="txtTotalWeight" 
                                        label="Total Weight" InputLabelProps={{ shrink: true, style: { fontSize: 18 } }}
                                        onChange={this.handleChange} noValidate value={this.state.totalWeight} />
                                        {this.state.errors.totalWeight.length > 0 &&
                                            <span className='error'>{this.state.errors.totalWeight}</span>}                                   
                                </Grid>                                
                            </Grid>
                            <Grid container spacing={3}>
                                <Grid item xs={col3}>
                                    <TextField fullWidth required="true" name="gradeAWeight" id="txtGradeAWeight" 
                                        label="Grade A Weight" InputLabelProps={{ shrink: true, style: { fontSize: 18 } }}
                                        onChange={this.handleChange} noValidate value={this.state.gradeAWeight} />
                                        {this.state.errors.gradeAWeight.length > 0 &&
                                            <span className='error'>{this.state.errors.gradeAWeight}</span>}
                                </Grid>
                                <Grid item xs={col3}>
                                    <TextField fullWidth name="gradeBWeight" id="txtTotalWeight" 
                                        label="Grade B Weight" InputLabelProps={{ shrink: true, style: { fontSize: 18 } }}
                                        onChange={this.handleChange} noValidate value={this.state.gradeBWeight} />                                                                     
                                </Grid>
                                <Grid item xs={col3}>
                                    <TextField fullWidth name="dumpWeight" id="txtDumpWeight" 
                                        label="Dump Weight" InputLabelProps={{ shrink: true, style: { fontSize: 18 } }}
                                        onChange={this.handleChange} noValidate value={this.state.dumpWeight} />                            
                                </Grid>                                
                            </Grid>
                            <Grid container spacing={1}>
                                <Grid item xs={col0}>                                    
                                </Grid>
                                <Grid item xs={col2}>
                                    <Button fullWidth className={classes.root} variant="contained"
                                        color="primary" onClick={this.create}>
                                        <CreateIcon className={classes.leftIcon} />{ this.state.actionName }</Button>
                                </Grid>
                            </Grid>
                        </form>

                        <Grid container spacing={0}>
                            <Grid item xs={12}>
                                <div className="ag-theme-alpine" style={{ width: "100%", height: 425, marginTop: 10 }}>
                                    <AgGridReact
                                        columnDefs={this.state.columnDefs} rowData={this.state.rowData}
                                        onGridReady={this.onGridReady} defaultColDef={this.state.defaultColDef}
                                        frameworkComponents={this.state.frameworkComponents} context={this.state.context}
                                        pagination={true} gridOptions={this.gridOptions} paginationPageSize={50}
                                        components={this.state.components} rowClassRules={this.state.rowClassRules} suppressClickEdit={true}
                                    />
                                </div>
                            </Grid>                        
                        </Grid>
                    </div>
                    )}
            </div>
        );
    }
}

export default withRouter(withStyles(useStyles)(withMediaQuery('(min-width:600px)')(AddStocks)))