import React from "react";
import ViewOrder from './ViewOrder';
import ReactToPrint from "react-to-print";
import { Grid, withStyles, Button, useMediaQuery } from '@material-ui/core';
import { withRouter } from 'react-router-dom';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import PrintIcon from '@material-ui/icons/Print';
import { useStyles } from './common/useStyles';

class ViewOrderReport extends React.Component {
  render() {
    return (
      <div style={{ marginRight: 10, marginLeft: 10, marginTop: 10 }}>
          <ViewOrder />
      </div>
    );
  }
}

// const useStyles = theme => ({
//     leftIcon: {
//         marginRight: theme.spacing.unit,
//     },
//     topMargin: {
//         marginTop: 16,
//     },
//     root: {
//         fontSize: 12, height: '2.1rem', marginTop: 20,
//         backgroundColor: "#0079c2",
//         "&:hover": {
//             backgroundColor: "#0079c2"
//         },
//         "&:disabled": {
//             backgroundColor: "rgba(0, 0, 0, 0.12)"
//         },
//     },
// });

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);
    return <Component mediaQuery={mediaQuery} {...props} />;
};

class PrintViewOrder extends React.Component {

    goBack = () => {
        const { history } = this.props;
        if (history) history.push('/ManageOrders');
    };

    render() {
        const { classes, mediaQuery } = this.props;
        const col9 = mediaQuery ? 9 : 12;
        const col7 = mediaQuery ? 8 : 12;
        const col2 = mediaQuery ? 2 : 6;

        return (
            <div>
                <Grid container spacing={1}>
                    <Grid item xs={col7}>                        
                    </Grid>
                    <Grid item xs={col2}>
                        <ReactToPrint
                            trigger={() => 
                                <Button fullWidth variant="contained" className={classes.root}
                                color="primary" onClick={this.print}>
                                <PrintIcon className={classes.leftIcon} />Print Order</Button>
                            }
                            content={() => this.componentRef}
                        />
                    </Grid>
                    <Grid item xs={col2}>
                        <Button fullWidth className={classes.root} variant="contained"
                            color="primary" onClick={this.goBack}>
                            <ArrowBackIcon className={classes.leftIcon} />Go Back</Button>
                    </Grid>                    
                </Grid>                

                <ViewOrderReport ref={el => (this.componentRef = el)} />
            </div>
        );
    }
}
                          
export default withRouter(withStyles(useStyles)(withMediaQuery('(min-width:600px)')(PrintViewOrder)))