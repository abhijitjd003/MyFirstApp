import React, { Component } from 'react';
import './common/Common.css';
import { Button, TextField, Grid, withStyles, FormControlLabel, Checkbox, useMediaQuery } from '@material-ui/core';
import './common/CommonModal.css';
import { withRouter } from 'react-router-dom';
import Loader from './loader/Loader';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import ActionRenderer from './common/ActionRenderer';
import ConfirmModal from './modal/ConfirmModal';
import ErrorModal from './modal/ErrorModal';
import api from './common/APIValues';
import CreateIcon from '@material-ui/icons/Create';
import { useStyles } from './common/useStyles';

// const useStyles = theme => ({
//     leftIcon: {
//         marginRight: theme.spacing.unit,
//     },
//     topMargin: {
//         marginTop: 16,
//     },
//     root: {
//         fontSize: 12, height: '2.1rem', marginTop: 20,
//         backgroundColor: "#0079c2",
//         "&:hover": {
//             backgroundColor: "#0079c2"
//         },
//         "&:disabled": {
//             backgroundColor: "rgba(0, 0, 0, 0.12)"
//         },
//     },
// });

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);    
    return <Component mediaQuery={mediaQuery} {...props} />;
};

const validateForm = (errors) => {
    let valid = true;
    Object.keys(errors).map(function (e) {
        if (errors[e].length > 0) {
            valid = false;
        }        
    });
    return valid;
}

class VendorTypes extends Component {
    constructor(props) {
        super(props);
        this.state = {
            typeId: 0, typeName: null, disable: false, description: null,
            errorMessage: null, loading: false, actionName: 'CREATE', userId: null,
            errors: {
                typeName: ''
            },
            columnDefs: [                
                { headerName: 'Type Name', field: 'TypeName', cellStyle: { 'text-align': "center" }, flex: 1 },
                { headerName: 'Description', field: 'Description', cellStyle: { 'text-align': "center" }, flex: 2 },
                { headerName: 'Disable', field: 'IsDisable', cellStyle: { 'text-align': "center" }, width: 110 },
                { headerName: 'Created Date', field: 'CreatedDateTime', cellStyle: { 'text-align': "center" }, width: 150 },
                { headerName: 'Created User', field: 'CreatedUserId', cellStyle: { 'text-align': "center" }, width: 200 },
                { headerName: 'Actions', field: 'Actions', sorting: false, filter: false, cellRenderer: 'actionRenderer', 
                    cellStyle: { 'text-align': "center" }, width: 110 },
            ],
            context: { componentParent: this },
            frameworkComponents: { actionRenderer: ActionRenderer },
            rowData: [],
            defaultColDef: { width: 110, sortable: true, resizable: true, filter: true },
            rowClassRules: {
                'grid-row-even': function (params) { return params.node.rowIndex % 2 === 0; },
                'grid-row-odd': function (params) { return params.node.rowIndex % 2 !== 0; }
            },
        };
    }

    create = (event) => {
        event.preventDefault();
        if (validateForm(this.state.errors) && this.state.typeName) {
            this.setState({ loading: true });
            let newVendorType = {};            
            newVendorType.TypeId = this.state.typeId;
            newVendorType.TypeName = this.state.typeName;
            newVendorType.Description = this.state.description;
            newVendorType.Disable = this.state.disable;
            newVendorType.CreatedUserId = this.state.userId;
            this.createVendorType(newVendorType);
        } else {
            let errors = this.state.errors;
            if (!this.state.typeName) {
                errors.typeName = 'Vendor type name is required';
            }
            this.setState({ errors, errorMessage: null });
        }
    }

    loadVendorTypes(){
        let partialUrl = api.URL;
        fetch(partialUrl + 'VendorType/GetVendorTypes')
            .then(res => res.json())
            .then(result => this.setState({ rowData: result, loading: false }))
            .catch(err => console.log(err));
    }

    DeleteRecord(){
        this.setState({ loading: true })
        let TypeId = this.state.typeId;
        let partialUrl = api.URL;
        fetch(partialUrl + 'VendorType/RemoveVendorType?TypeId=' + TypeId, {
            method: 'POST',
            mode: 'cors'
        }).then(data => {
            this.loadVendorTypes();
            this.setState({ loading: false })
        });
    }

    componentDidMount() {
        let loggedInUser = sessionStorage.getItem('loggedInUser');

        if(loggedInUser) {
            this.setState({ userId: loggedInUser, loading: true });
            this.loadVendorTypes();
        } else {
            const { history } = this.props;
            if (history) history.push('/Home');
        }
    }

    editGridRow = row => {
        this.setState({
            typeId: row.TypeId,
            typeName: row.TypeName,
            description: row.Description,
            disable: row.IsDisable === 'YES' ? true : false,
            actionName: 'UPDATE'
        })
    };

    showConfirmPopup = row => {
        this.setState({ typeId: row.TypeId })
        this.refs.cnfrmModalComp.openModal();
    }

    createVendorType(newVendorType) {
        let partialUrl = api.URL;
        fetch(partialUrl + 'VendorType/CreateVendorType', {
            method: 'POST',
            mode: 'cors',
            body: JSON.stringify(newVendorType),
            headers: { 'Content-Type': 'application/json' }
        }).then((response) => response.json())
            .then((responseJson) => {
                if (responseJson) {
                    this.loadVendorTypes();
                    this.setState({ 
                        loading: false, actionName: 'CREATE', typeId: 0, typeName: null, description: null, disable: false
                    });
                } else {
                    this.setState({ 
                        loading: false, actionName: 'CREATE', typeId: 0, typeName: null, description: null, disable: false
                    });
                    var errorMsg = 'Duplicate vendor type found.';
                    this.refs.errModalComp.openModal(errorMsg);
                }
            })
    }

    handleChange = (event) => {
        event.preventDefault();
        const { name, value } = event.target;
        let errors = this.state.errors;

        switch (name) {
            case 'typeName':
                this.state.typeName = value;
                errors.typeName = value.length <= 0
                    ? 'Vendor type name is required' : '';
                break;            
            default:
                break;
        }
        this.setState({ errors, [name]: value });
    }

    _chkDeactivateChange = event => { this.setState({ disable: event.target.checked }); };

    render() {
        const { classes, mediaQuery } = this.props;
        const cols = mediaQuery ? 3 : 12;
        const colsBtnL = mediaQuery ? 10 : 8;
        const colsBtnM = mediaQuery ? 2 : 4;
        
        return (
            <div>
                {this.state.loading ? (
                    <Loader />
                ) : (
                    <div>
                        <ErrorModal ref="errModalComp" />
                        <ConfirmModal ref="cnfrmModalComp" onClick={(e) => this.DeleteRecord(e)} />

                        <form onSubmit={this.loginToDashboard} noValidate>
                            <h2 className="header-text-color">Add Vendor Types</h2>
                            <Grid container spacing={1}>
                                <Grid item xs={12}>
                                    <TextField fullWidth required="true" name="typeName" id="txtTypeName" 
                                        label="Vendor Type Name" InputLabelProps={{ shrink: true, style: { fontSize: 18 } }}
                                        onChange={this.handleChange} noValidate value={this.state.typeName} />
                                    {this.state.errors.typeName.length > 0 &&
                                        <span className='error'>{this.state.errors.typeName}</span>}
                                </Grid>
                                <Grid item xs={12}>
                                    <TextField fullWidth name="description" id="txtDescription" 
                                        label="Description" InputLabelProps={{ shrink: true, style: { fontSize: 18 } }}
                                        onChange={this.handleChange} noValidate value={this.state.description} />                                    
                                </Grid>
                                <Grid item xs={colsBtnL}>
                                    <FormControlLabel className={ classes.topMargin } control={
                                        <Checkbox id="chkDeactivate" value={true} name="chkDeactivate" color="primary" 
                                            checked={this.state.disable} onChange={ this._chkDeactivateChange } />
                                    } label="Disable" />
                                </Grid>
                                <Grid item xs={colsBtnM}>
                                    <Button fullWidth className={classes.root} variant="contained"
                                        color="primary" onClick={this.create}>
                                        <CreateIcon className={classes.leftIcon} />{ this.state.actionName }</Button>
                                </Grid>
                            </Grid>
                        </form>

                        <Grid container spacing={0}>
                            <Grid item xs={12}>
                                <div className="ag-theme-alpine" style={{ width: "100%", height: 425, marginTop: 5 }}>
                                    <AgGridReact
                                        columnDefs={this.state.columnDefs} rowData={this.state.rowData}
                                        onGridReady={this.onGridReady} defaultColDef={this.state.defaultColDef}
                                        frameworkComponents={this.state.frameworkComponents} context={this.state.context}
                                        pagination={true} gridOptions={this.gridOptions} paginationAutoPageSize={true}
                                        components={this.state.components} rowClassRules={this.state.rowClassRules} suppressClickEdit={true}
                                    />
                                </div>
                            </Grid>                        
                        </Grid>
                    </div>
                    )}
            </div>
        );
    }
}

export default withRouter(withStyles(useStyles)(withMediaQuery('(min-width:600px)')(VendorTypes)))