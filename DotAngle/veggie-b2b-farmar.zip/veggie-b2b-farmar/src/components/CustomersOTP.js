import React, { Component } from 'react';
import './common/Common.css';
import { Button, TextField, Grid, withStyles, useMediaQuery, Select, MenuItem } from '@material-ui/core';
import './common/CommonModal.css';
import { withRouter } from 'react-router-dom';
import Loader from './loader/Loader';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import api from './common/APIValues';
import { useStyles } from './common/useStyles';

// const useStyles = theme => ({
//     leftIcon: {
//         marginRight: theme.spacing.unit,
//     },
//     topMargin: {
//         marginTop: 16,
//     },
//     root: {
//         fontSize: 12, height: '2.1rem', marginTop: 20,
//         backgroundColor: "#0079c2",
//         "&:hover": {
//             backgroundColor: "#0079c2"
//         },
//         "&:disabled": {
//             backgroundColor: "rgba(0, 0, 0, 0.12)"
//         },
//     },
// });

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);    
    return <Component mediaQuery={mediaQuery} {...props} />;
};

class CustomersOTP extends Component {
    constructor(props) {
        super(props);
        this.state = {
            columnDefs: [                
                { headerName: 'Mobile Number', field: 'MobileNo', cellStyle: { 'text-align': "center" } },
                { headerName: 'OTP', field: 'OTP', cellStyle: { 'text-align': "center" } },
                { headerName: 'Requested Date', field: 'RequestedDateTime', cellStyle: { 'text-align': "center" } },
            ],
            context: { componentParent: this },
            frameworkComponents: { },
            rowData: [],
            defaultColDef: { flex: window.innerWidth <= 600 ? 0 : 1, width: 110, sortable: true, resizable: true, filter: true },
            rowClassRules: {
                'grid-row-even': function (params) { return params.node.rowIndex % 2 === 0; },
                'grid-row-odd': function (params) { return params.node.rowIndex % 2 !== 0; }
            },
        };
    }

    loadCustomersOTP() {
        let partialUrl = api.URL;
        fetch(partialUrl + 'Login/GetCustomersOTP')
            .then(res => res.json())
            .then(result => this.setState({ rowData: result, loading: false }))
            .catch(err => console.log(err));
    }

    componentDidMount() {
        let loggedInUser = sessionStorage.getItem('loggedInUser');

        if(loggedInUser) {
            this.setState({ userId: loggedInUser, loading: true });
            this.loadCustomersOTP();
        } else {
            const { history } = this.props;
            if (history) history.push('/Home');
        }
    }

    render() {
        const { classes, mediaQuery } = this.props;
        
        return (
            <div>
                {this.state.loading ? (
                    <Loader />
                ) : (
                    <div>
                        <Grid container spacing={0}>
                            <Grid item xs={12}>
                                <h2 className="header-text-color">New Customers OTP</h2>
                            </Grid>
                        </Grid>

                        <Grid container spacing={0}>
                            <Grid item xs={12}>
                                <div className="ag-theme-alpine" style={{ width: "100%", height: 600, marginTop: 0 }}>
                                    <AgGridReact
                                        columnDefs={this.state.columnDefs} rowData={this.state.rowData}
                                        onGridReady={this.onGridReady} defaultColDef={this.state.defaultColDef}
                                        frameworkComponents={this.state.frameworkComponents} context={this.state.context}
                                        pagination={true} gridOptions={this.gridOptions} paginationPageSize={100}
                                        components={this.state.components} rowClassRules={this.state.rowClassRules} suppressClickEdit={true}
                                    />
                                </div>
                            </Grid>                        
                        </Grid>
                    </div>
                    )}
            </div>
        );
    }
}

export default withRouter(withStyles(useStyles)(withMediaQuery('(min-width:600px)')(CustomersOTP)))