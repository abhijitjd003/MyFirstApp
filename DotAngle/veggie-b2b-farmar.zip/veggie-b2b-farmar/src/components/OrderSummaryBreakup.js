import React, { Component } from 'react';
import { 
    Grid, withStyles, Table, TableBody, TableContainer, TableCell, TableHead, TableRow,
    Paper, useMediaQuery
} from '@material-ui/core';
import api from './common/APIValues';
import Loader from './loader/Loader';
import { useStyles } from './common/useStyles';

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);    
    return <Component mediaQuery={mediaQuery} {...props} />;
};

class OrderSummaryBreakup extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            open: false, breakUpData: [], loading: false, orderedDate: null, OrderSummaryDetails: {}, cratesCount: [],
            overallWeight: null,
        };
    }

    loadProducts(orderedDate){
        let partialUrl = api.URL;       
        fetch(partialUrl + 'OrderSummary/GetCratesDetails?OrderedDate='+ orderedDate + '&ProductId='+ 0)
            .then(res => res.json())
            .then(result => {                
                this.setState({ 
                    breakUpData: result.orderSummaries, cratesCount: result.orderBreakups, 
                    overallWeight: result.OverallWeight, loading: false
                })
            })
            .catch(err => console.log(err));
    }

    componentDidMount() {
        let loggedInUser = sessionStorage.getItem('loggedInUser');

        if(loggedInUser) {
            let orderedDateRef = sessionStorage.getItem('OrderedDateRef');
            if(orderedDateRef) {
                this.setState({ loading: true });
                this.loadProducts(orderedDateRef);
            }
        } else {
            const { history } = this.props;
            if (history) history.push('/Home');
        }
    }

    render() {
        const { classes, mediaQuery } = this.props;
        const height = mediaQuery ? '50%' : '20%';

        return (
            <div>
                {this.state.loading ? (
                    <Loader />
                ) : (
                    <div>
                        <h2 className="header-text-color">Order Summary Breakup</h2>

                        <Grid container spacing={0}>
                            <Grid item xs={12}>
                                <TableContainer component={Paper}>                                    
                                    <Table className={classes.table} size="small" aria-label="simple table">
                                        <TableHead className="table-header-custom">
                                            <TableRow>
                                                <TableCell align="center"></TableCell>                                                
                                                <TableCell style={{ color: 'white', fontSize: 16 }} align="center">Product Name</TableCell>                                             
                                                <TableCell style={{ color: 'white', fontSize: 16 }} align="center">Weight</TableCell>
                                                <TableCell style={{ color: 'white', fontSize: 16 }} align="center">Breakup</TableCell>
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                        {this.state.breakUpData.map((data, index) => (
                                            <TableRow>
                                                <TableCell align="center">
                                                    <img className={classes.img} height={height} alt="complex" src={ data.ProductImagePath } />
                                                </TableCell>                                                
                                                <TableCell align="center">{ data.ProductName }</TableCell>                                            
                                                <TableCell align="center">{ data.TotalWeight } { data.UnitType }</TableCell>
                                                <TableCell align="center">
                                                    {this.state.cratesCount.map((data1, index) => (
                                                        data1.ProductId === data.ProductId &&
                                                            data1.Weight + 'X' + data1.OrderCount + ' , '
                                                    ))}
                                                </TableCell>
                                            </TableRow>
                                        ))}
                                        </TableBody>
                                    </Table>
                                </TableContainer>
                            </Grid>                        
                        </Grid>
                    </div>
                    )}
            </div>
        );
    }
}

export default withStyles(useStyles)(withMediaQuery('(min-width:600px)')(OrderSummaryBreakup))