import React, { Component } from 'react';
import './common/Common.css';
import { Grid, withStyles, Button, Tab, Tabs, Typography, Box, AppBar, Select, MenuItem, useMediaQuery } from '@material-ui/core';
import './common/CommonModal.css';
import { withRouter } from 'react-router-dom';
import Loader from './loader/Loader';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import EditRenderer from './common/EditRenderer';
import RejectModal from './modal/RejectModal';
import SalesOfficerModal from './modal/SalesOfficerModal';
import ViewCustomerImagesModal from './modal/ViewCustomerImagesModal';
import ErrorModal from './modal/ErrorModal';
import api from './common/APIValues';
import PropTypes from 'prop-types';
import ViewRenderer from './common/ViewRenderer';
import { useStyles } from './common/useStyles';

// const useStyles = theme => ({
//     leftIcon: {
//         marginRight: theme.spacing.unit,
//     },
//     topMargin: {
//         marginTop: 16,
//     },
//     topMarginTab: {
//         marginTop: 10,
//     },
//     topMarginSm: {
//         marginTop: 5,
//     },
//     root: {
//         fontSize: 12, height: '2.1rem', marginTop: 20,
//         backgroundColor: "#0079c2",
//         "&:hover": {
//             backgroundColor: "#0079c2"
//         },
//         "&:disabled": {
//             backgroundColor: "rgba(0, 0, 0, 0.12)"
//         },
//     },
//     tabBar: {
//         backgroundColor: "white", color: '#ff9800'
//     },
//     tabLinks: {
//         fontSize: 12, "&:hover": {
//             textDecoration: 'none',
//         },
//     },
//     tabLinksActive: {
//         fontSize: 12, backgroundColor: "#03A9F4", color: 'white',
//         "&:hover": {
//             textDecoration: 'none',
//         },
//     },
// });

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);    
    return <Component mediaQuery={mediaQuery} {...props} />;
};

class ManageCustomers extends Component {
    constructor(props) {
        super(props);
        this.state = {
            shopId: 0, userId: null, disableApprove: false, disableReject: false, disable: false,
            tabIndex: 0, activeTab: 'tabInProgress', actionDisable: 'Disable', loading: false,
            columnDefs: [
                { 
                    headerName: '', field: 'Action', width: 100, sorting: false, filter: false, 
                    cellRenderer: 'actionRenderer', headerCheckboxSelection: true, checkboxSelection: true, headerCheckboxSelectionFilteredOnly: true,
                },                
                { headerName: 'Shop Name', field: 'ShopName', width: 160 },
                { headerName: 'Name', field: 'ContactPerson', width: 160 },
                { headerName: 'Location', field: 'Location' },
                { headerName: 'Ref Code', field: 'ReferralCode', width: 120, cellStyle: { 'text-align': "center" } },
                { headerName: 'Sales Officer', field: 'SalesOfficer', width: 160, cellStyle: { 'text-align': "center" } },
                { headerName: 'Mobile No', field: 'MobileNo', width: 130, cellStyle: { 'text-align': "center" } },
                { headerName: 'Email', field: 'Email', width: 190 },
                { headerName: 'Address', field: 'Address' },
                { headerName: 'Pin Code', field: 'PinCode', width: 120, cellStyle: { 'text-align': "center" } },
                { headerName: 'GST No', field: 'GSTNo', width: 120 },
                { headerName: 'Reject Reason', field: 'RejectedReason', width: 150 },
                { headerName: 'Updated Date', field: 'UpdatedDate', width: 150, cellStyle: { 'text-align': "center" } },
                { headerName: 'Updated User', field: 'UserId', width: 150 },
                { 
                    headerName: 'Action', field: 'Action', width: 110, sorting: false, filter: false, 
                    cellRenderer: 'viewRenderer'
                },
            ],
            context: { componentParent: this },
            frameworkComponents: { viewRenderer: ViewRenderer, actionRenderer: EditRenderer },
            rowData: [],
            defaultColDef: { sortable: true, resizable: true, filter: true },
            rowClassRules: {
                'grid-row-even': function (params) { return params.node.rowIndex % 2 === 0; },
                'grid-row-odd': function (params) { return params.node.rowIndex % 2 !== 0; }
            },
            suppressRowClickSelection: true,
            rowSelection: 'multiple',
        };
    }

    handleOnChangeTab = (event, newValue) => {
        this.setState({ tabIndex: newValue, loading: true })
        switch (newValue) {
            case 0:
                this.setState({ activeTab: 'tabInProgress', disableApprove: false, disableReject: false, actionDisable: 'Disable' })
                this.loadVendors('InProgress');
                break;
            case 1:
                this.setState({ activeTab: 'tabApproved', disableApprove: true, disableReject: true, actionDisable: 'Disable' })
                this.loadVendors('Approved');
                break;
            case 2:
                this.setState({ activeTab: 'tabRejected', disableApprove: true, disableReject: true, actionDisable: 'Disable' })
                this.loadVendors('Rejected');
                break;
            case 3:
                this.setState({ activeTab: 'tabDisabled', disableApprove: true, disableReject: true, actionDisable: 'Enable' })
                this.loadVendors('Disabled');
                break;            
        }
    };

    onGridReady = params => { this.gridApi = params.api; this.gridColumnApi = params.columnApi; };

    loadVendors(status){
        let partialUrl = api.URL;
        fetch(partialUrl + 'Customer/GetCustomers?Status=' + status)
            .then(res => res.json())
            .then(result => this.setState({ rowData: result, loading: false }))
            .catch(err => console.log(err));
    }

    editGridRow = row => {        
        const { history } = this.props;
        if (history) history.push({ pathname: '/AddCustomers', shopIdRef: row.ShopId });
    };

    approveRejectDisableVendor = (status, rejectReason) => {        
        let vendorData = {}; let isValid = true;
        let selectedNodes = this.gridApi.getSelectedNodes();
        let Vendors = selectedNodes.map(node => node.data);

        if(Vendors.length > 0) {            
            Vendors.map((vendor, index) => {
                switch(status) {
                    case 'Approved':
                    case 'Rejected':
                        if(vendor.Status === 'Rejected' || vendor.Status === 'Approved'){
                            isValid = false;
                        }
                        break;
                    case 'Disabled':
                        if(this.state.activeTab === 'tabDisabled'){
                            status = 'InProgress';
                        }
                        break;
                }
            });

            if(isValid) {
                this.setState({ loading: true });
                vendorData.Status = status;
                vendorData.ShopIds = selectedNodes.map(node => node.data.ShopId);
                vendorData.UserId = this.state.userId;
                vendorData.RejectReason = rejectReason;
                let partialUrl = api.URL;
                fetch(partialUrl + 'Customer/ApproveRejectDisableCustomer', {
                    method: 'POST',
                    mode: 'cors',
                    body: JSON.stringify(vendorData),
                    headers: { 'Content-Type': 'application/json' }
                }).then((response) => response.json())
                    .then((responseJson) => {
                        if (responseJson) {
                            this.loadVendors('Approved');
                            this.setState({ loading: false });
                            var successMsg = '';
                            if(this.state.activeTab === 'tabDisabled'){
                                successMsg = 'Request(s) Enabled successfully.';
                            } else {
                                successMsg = 'Request(s) '+ status +' successfully.';
                            }
                            this.refs.errModalComp.openModal(successMsg, 'Informations');
                        }
                    })
            } else {                
                var errorMsg = '';
                switch(status) {
                    case 'Approved':
                        errorMsg = 'Cannot approve already Approved/Rejected vendors.';
                        break;
                    case 'Rejected':
                        errorMsg = 'Cannot reject already Approved/Rejected vendors.';
                        break;
                }
                this.refs.errModalComp.openModal(errorMsg);
            }
        } else {
            var errorMsg = '';
            switch(status) {
                case 'Approved':
                    errorMsg = 'Select at least one vendor to Approve.';
                    break;
                case 'Rejected':
                    errorMsg = 'Select at least one vendor to Reject.';
                    break;
                case 'Disabled':
                    if(this.state.activeTab === 'tabDisabled'){
                        errorMsg = 'Select at least one vendor to Enable.';
                    } else {
                        errorMsg = 'Select at least one vendor to Disable.';
                    }
                    break;
            }
            this.refs.errModalComp.openModal(errorMsg);
        }
    }

    RejectRequestPopup() {
        let selectedNodes = this.gridApi.getSelectedNodes();
        let Vendors = selectedNodes.map(node => node.data);
        if(Vendors.length > 0) {
            this.refs.rejectModalComp.openModal();
        } else {
            var errorMsg = 'Select at least one vendor to Reject.';
            this.refs.errModalComp.openModal(errorMsg);
        }
    }

    showSalesOfficerPopup() {
        let selectedNodes = this.gridApi.getSelectedNodes();
        let Customers = selectedNodes.map(node => node.data);
        if(Customers.length > 0) {
            this.refs.salesOfficerModalComp.openModal();
        } else {
            var errorMsg = 'Select at least one customer to assign sales officer.';
            this.refs.errModalComp.openModal(errorMsg);
        }
    }

    viewRowData = (row, status) => {
        const { history } = this.props;
        if(status === 'view'){            
            if (history) history.push({ pathname: '/ManageOrders', customerIdRef: row.ShopId });
        } else if(status === 'edit') {
            if (history) history.push({ pathname: '/CreateOrders', orderNoRef: row.OrderNo, shopIdRef: row.ShopId });
        } else {
            this.loadShopImages(row.ShopId)            
        }
    };

    loadShopImages(shopId){
        let partialUrl = api.URL;
        fetch(partialUrl + 'Customer/GetShopImages?ShopId=' + shopId)
            .then(res => res.json())
            .then(result => {
                this.refs.viewModalComp.openModal(result);
            })
            .catch(err => console.log(err));
    }

    assignSalesOfficer = (salesOfficer) => {        
        let customerData = {};
        let selectedNodes = this.gridApi.getSelectedNodes();
        let Customers = selectedNodes.map(node => node.data);

        if(Customers.length > 0) {
            this.setState({ loading: true });
            customerData.FullName = salesOfficer;
            customerData.ShopIds = selectedNodes.map(node => node.data.ShopId);
            let partialUrl = api.URL;
            fetch(partialUrl + 'Customer/AssignSalesOfficer', {
                method: 'POST',
                mode: 'cors',
                body: JSON.stringify(customerData),
                headers: { 'Content-Type': 'application/json' }
            }).then((response) => response.json())
                .then((responseJson) => {
                    if (responseJson) {
                        this.loadVendors('Approved');
                        this.setState({ loading: false });
                        var successMsg = 'Sales officer assigned successfully.';
                        this.refs.errModalComp.openModal(successMsg, 'Informations');
                    }
                })
        }
    }

    componentDidMount() {
        let loggedInUser = sessionStorage.getItem('loggedInUser');

        if(loggedInUser) {
            this.setState({ userId: loggedInUser, loading: true });
            this.loadVendors('InProgress');
        } else {
            const { history } = this.props;
            if (history) history.push('/Home');
        }
    }

    render() {
        const { classes, mediaQuery } = this.props;
        const col1 = mediaQuery ? 1 : 4;
        const col12 = mediaQuery ? 1 : 4;
        const col2 = mediaQuery ? 2 : 6;
        const col7 = mediaQuery ? 7 : 6;
        
        return (
            <div>
                {this.state.loading ? (
                    <Loader />
                ) : (
                    <div>
                        <ErrorModal ref="errModalComp" />
                        <ViewCustomerImagesModal ref="viewModalComp" />                        
                        <RejectModal ref="rejectModalComp" onClick={(status, rejectReason) => this.approveRejectDisableVendor(status, rejectReason)} />
                        <SalesOfficerModal ref="salesOfficerModalComp" onClick={(salesOfficer) => this.assignSalesOfficer(salesOfficer)} />

                        <Grid container spacing={1}>
                            <Grid item xs={col7}>
                                <h2 className="header-text-color">Manage Customers</h2>
                            </Grid>
                            <Grid item xs={col2}>                                
                                    <Button fullWidth className={classes.root} variant="contained"
                                        color="primary" onClick={() => this.showSalesOfficerPopup()}>Assign Sales Officer</Button>
                            </Grid>
                            <Grid item xs={col1}>
                                    <Button fullWidth className={classes.root} variant="contained" disabled={this.state.disableApprove}
                                        color="primary" onClick={() => this.approveRejectDisableVendor('Approved')}>APPROVE</Button>
                            </Grid>
                            <Grid item xs={col12}>
                                    <Button fullWidth className={classes.root} variant="contained" disabled={this.state.disableReject}
                                        color="primary" onClick={() => this.RejectRequestPopup()}>REJECT</Button>
                            </Grid>
                            <Grid item xs={col12}>                                
                                    <Button fullWidth className={classes.root} variant="contained" disabled={this.state.disable}
                                        color="primary" onClick={() => this.approveRejectDisableVendor('Disabled')}>{this.state.actionDisable}</Button>
                            </Grid>                                                        
                        </Grid>
                        
                        <div className={classes.topMarginSm}>
                                <AppBar position="static" className={classes.tabBar}>
                                    <Tabs variant="fullWidth" value={this.state.tabIndex} onChange={this.handleOnChangeTab}
                                        TabIndicatorProps={{ style: { background: '#2b494b' } }}>
                                        <LinkTab className={this.state.activeTab === 'tabInProgress' ? classes.tabLinksActive : classes.tabLinks}
                                            label="In Progress" {...a11yProps(0)} />
                                        <LinkTab className={this.state.activeTab === 'tabApproved' ? classes.tabLinksActive : classes.tabLinks}
                                            label="Approved" {...a11yProps(1)} />
                                        <LinkTab className={this.state.activeTab === 'tabRejected' ? classes.tabLinksActive : classes.tabLinks}
                                            label="Rejected" {...a11yProps(2)} />
                                        <LinkTab className={this.state.activeTab === 'tabDisabled' ? classes.tabLinksActive : classes.tabLinks}
                                            label="Disabled" {...a11yProps(3)} />                                        
                                    </Tabs>
                                </AppBar>
                                <TabPanel value={this.state.tabIndex} index={0}>
                                    <div className="ag-theme-alpine" style={{ width: "100%", height: 510 }}>
                                        <AgGridReact
                                            columnDefs={this.state.columnDefs} rowData={this.state.rowData}
                                            onGridReady={this.onGridReady} defaultColDef={this.state.defaultColDef}
                                            frameworkComponents={this.state.frameworkComponents} context={this.state.context}
                                            pagination={true} gridOptions={this.gridOptions} paginationPageSize={50}
                                            components={this.state.components} rowClassRules={this.state.rowClassRules} 
                                            suppressClickEdit={true} rowSelection={this.state.rowSelection}
                                            suppressRowClickSelection={true}/>
                                    </div>
                                </TabPanel>
                                <TabPanel value={this.state.tabIndex} index={1}>
                                    <div className="ag-theme-alpine" style={{ width: "100%", height: 510 }}>
                                        <AgGridReact
                                            columnDefs={this.state.columnDefs} rowData={this.state.rowData}
                                            onGridReady={this.onGridReady} defaultColDef={this.state.defaultColDef}
                                            frameworkComponents={this.state.frameworkComponents} context={this.state.context}
                                            pagination={true} gridOptions={this.gridOptions} paginationPageSize={50}
                                            components={this.state.components} rowClassRules={this.state.rowClassRules} 
                                            suppressClickEdit={true} rowSelection={this.state.rowSelection}
                                            suppressRowClickSelection={true}/>
                                    </div>
                                </TabPanel>
                                <TabPanel value={this.state.tabIndex} index={2}>
                                    <div className="ag-theme-alpine" style={{ width: "100%", height: 510 }}>
                                        <AgGridReact
                                            columnDefs={this.state.columnDefs} rowData={this.state.rowData}
                                            onGridReady={this.onGridReady} defaultColDef={this.state.defaultColDef}
                                            frameworkComponents={this.state.frameworkComponents} context={this.state.context}
                                            pagination={true} gridOptions={this.gridOptions} paginationPageSize={50}
                                            components={this.state.components} rowClassRules={this.state.rowClassRules} 
                                            suppressClickEdit={true} rowSelection={this.state.rowSelection}
                                            suppressRowClickSelection={true}/>
                                    </div>
                                </TabPanel>
                                <TabPanel value={this.state.tabIndex} index={3}>
                                    <div className="ag-theme-alpine" style={{ width: "100%", height: 510 }}>
                                        <AgGridReact
                                            columnDefs={this.state.columnDefs} rowData={this.state.rowData}
                                            onGridReady={this.onGridReady} defaultColDef={this.state.defaultColDef}
                                            frameworkComponents={this.state.frameworkComponents} context={this.state.context}
                                            pagination={true} gridOptions={this.gridOptions} paginationPageSize={50}
                                            components={this.state.components} rowClassRules={this.state.rowClassRules} 
                                            suppressClickEdit={true} rowSelection={this.state.rowSelection}
                                            suppressRowClickSelection={true}/>
                                    </div>
                                </TabPanel>                                
                            </div>
                    </div>
                    )}
            </div>
        );
    }
}

function TabPanel(props) {
    const { children, value, index, ...other } = props;

    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`nav-tabpanel-${index}`}
            aria-labelledby={`nav-tab-${index}`}
            {...other}
        >
            {value === index && (
                <Box p={5}>
                    <Typography>{children}</Typography>
                </Box>
            )}
        </div>
    );
}

TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.any.isRequired,
    value: PropTypes.any.isRequired,
};

function a11yProps(index) {
    return {
        id: `nav-tab-${index}`,
        'aria-controls': `nav-tabpanel-${index}`,
    };
}

function LinkTab(props) {
    return (
        <Tab
            component="a"
            onClick={(event) => {
                event.preventDefault();
            }}
            {...props}
        />
    );
}

export default withRouter(withStyles(useStyles)(withMediaQuery('(min-width:600px)')(ManageCustomers)))