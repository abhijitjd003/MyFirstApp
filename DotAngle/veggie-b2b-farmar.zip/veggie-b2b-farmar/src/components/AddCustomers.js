import React, { Component } from 'react';
import './common/Common.css';
import { Button, TextField, Grid, withStyles, useMediaQuery } from '@material-ui/core';
import './common/CommonModal.css';
import { withRouter } from 'react-router-dom';
import Loader from './loader/Loader';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import ErrorModal from './modal/ErrorModal';
import CheckIcon from '@material-ui/icons/Check';
import api from './common/APIValues';
import { useStyles } from './common/useStyles';

// const useStyles = theme => ({
//     leftIcon: {
//         marginRight: theme.spacing.unit,
//     },
//     topMargin: {
//         marginTop: 16,
//     },
//     root: {
//         fontSize: 12, height: '2.1rem', marginTop: 5,
//         backgroundColor: "#2b494b",
//         "&:hover": {
//             backgroundColor: "#2b494b"
//         },
//         "&:disabled": {
//             backgroundColor: "rgba(0, 0, 0, 0.12)"
//         },
//     },
// });

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);    
    return <Component mediaQuery={mediaQuery} {...props} />;
};

const validateForm = (errors) => {
    let valid = true;
    Object.keys(errors).map(function (e) {
        if (errors[e].length > 0) {
            valid = false;
        }        
    });
    return valid;
}

const validEmailRegex = RegExp(/^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i);

class AddCustomers extends Component {
    constructor(props) {
        super(props);
        this.state = {
            shopName: null, contactPersonName: null, mobileNo: null, email: null, altContactNo: null, address: null, 
            location: null, gstNo: null, referralCode: null, shopId: 0, shopImages: [], userId: null,
            errorMessage: null, loading: false, rowData: {}, pinCode: null,
            errors: {
                shopName: '',
                contactPersonName: '',
                email: '',
                mobileNo: '',
                address: '',
                location: '',
                altContactNo: '',
                shopImages: '',
                pinCode: '',
            },            
        };
    }

    validateAllInputs(){
        if(!this.state.shopName || !this.state.contactPersonName || !this.state.mobileNo ||
            !this.state.address || !this.state.location || !this.state.pinCode){
                return false;
        }
        else{
            return true;
        }
    }

    save = (event) => {
        event.preventDefault();
        if (validateForm(this.state.errors) && this.validateAllInputs()) {
            this.setState({ loading: true });
            let vendorDetails = {};
            vendorDetails.ShopId = this.state.shopId;
            vendorDetails.ShopName = this.state.shopName;
            vendorDetails.PinCode = this.state.pinCode;
            vendorDetails.ContactPerson = this.state.contactPersonName;
            vendorDetails.Email = this.state.email;
            vendorDetails.MobileNo = this.state.mobileNo;
            vendorDetails.Address = this.state.address;
            vendorDetails.Location = this.state.location;
            vendorDetails.AlternateContactNo = this.state.altContactNo;
            vendorDetails.GSTNo = this.state.gstNo;
            vendorDetails.ReferralCode = this.state.referralCode;
            vendorDetails.ShopImages = this.state.shopImages;
            vendorDetails.UserId = this.state.userId;
            this.saveVendorDetails(vendorDetails);
        } else {
            let errors = this.state.errors;
            if (!this.state.shopName) {
                errors.shopName = 'Shop name is required';
            }
            if (!this.state.mobileNo) {
                errors.mobileNo = 'Mobile number is required';
            }
            // if (!this.state.email) {
            //     errors.email = 'Email address is required';
            // }
            if (!this.state.contactPersonName) {
                errors.contactPersonName = 'Contact person name is required';
            }
            if (!this.state.address) {
                errors.address = 'Address is required';
            }
            if (!this.state.location) {
                errors.location = 'Location is required';
            }
            if (!this.state.pinCode) {
                errors.pinCode = 'Pin Code is required';
            }
            // if (this.state.shopImages.length !== 3 && this.state.shopId === 0) {
            //     errors.shopImages = 'Upload 3 shop images';
            // } else {
            //     errors.shopImages = '';
            // }
            this.setState({ errors, errorMessage: null });
        }
    }

    loadVendor(shopId){
        console.log(shopId);
        let partialUrl = api.URL;
        fetch(partialUrl + 'Customer/GetCustomer?ShopId=' + shopId)
            .then(res => res.json())
            .then(result => { 
                this.setState({ 
                    shopId: result.ShopId,
                    shopName: result.ShopName,
                    address: result.Address,
                    gstNo: result.GSTNo,
                    referralCode: result.ReferralCode,
                    mobileNo: result.MobileNo,
                    location: result.Location,
                    email: result.Email,
                    contactPersonName: result.ContactPerson,
                    altContactNo: result.AlternateContactNo === 0 ? null : result.AlternateContactNo,
                    pinCode: result.PinCode === 0 ? null : result.PinCode
            })
        })
            .catch(err => console.log(err));
    }

    componentDidMount() {
        let loggedInUser = sessionStorage.getItem('loggedInUser');

        if(loggedInUser) {
            this.setState({ userId: loggedInUser });
            let shopId = this.props.location.shopIdRef;
            if(shopId > 0) {
                this.loadVendor(shopId);
            }
        } else {
            const { history } = this.props;
            if (history) history.push('/Home');
        }
    }

    saveVendorDetails(vendorDetails) {
        let partialUrl = api.URL;
        fetch(partialUrl + 'Customer/AddCustomer', {
            method: 'POST',
            mode: 'cors',
            body: JSON.stringify(vendorDetails),
            headers: { 'Content-Type': 'application/json' }
        }).then((response) => response.json())
            .then((responseJson) => {
                if (responseJson) {                    
                    this.setState({ loading: false, shopImages: [] });
                    const { history } = this.props;
                    if (history) history.push('/ManageCustomers');
                } else {
                    this.setState({ loading: false });
                    var errorMsg = 'Duplicate customer found.';
                    this.refs.errModalComp.openModal(errorMsg);
                }
            })
    }

    handleChange = (event) => {
        event.preventDefault();
        const { name, value } = event.target;
        let errors = this.state.errors;

        switch (name) {
            case 'shopName':
                this.state.shopName = value;
                errors.shopName = value.length <= 0 ? 'Shop name is required' : '';
                break;
            case 'mobileNo':
                this.state.mobileNo = value;
                errors.mobileNo = value.length <= 0 ? 'Mobile number is required' : !Number(value) ? 'Mobile number is not valid' : '';
                break;
            case 'email':
                this.state.email = value;
                errors.email = !validEmailRegex.test(value) && value.length > 0 ? 'Email address is not valid' : '';
                break;
            case 'contactPersonName':
                this.state.contactPersonName = value;
                errors.contactPersonName = value.length <= 0 ? 'Contact person name is required' : '';
                break;
            case 'address':
                this.state.address = value;
                errors.address = value.length <= 0 ? 'Address is required' : '';
                break;
            case 'location':
                this.state.location = value;
                errors.location = value.length <= 0 ? 'Location is required' : '';
                break;
            case 'altContactNo':
                this.state.altContactNo = value;
                errors.altContactNo = !Number(value) && value.length > 0 ? 'Alternate contact number is not valid' : '';
                break;
            case 'pinCode':
                this.state.pinCode = value;
                errors.pinCode = value.length <= 0 ? 'Pin Code is required' : !Number(value) ? 'Pin Code is not valid' : '';
                break;            
            default:
                break;
        }
        this.setState({ errors, [name]: value });
    }

    onFileUploadChange = (event) => {
        var files = Array.from(event.target.files)

        files.map((file) =>
        {
            var blob = file.slice();
            var reader = new FileReader();

            reader.onloadend = function (evt) {
                if (evt.target.readyState == FileReader.DONE) {
                    var cont = evt.target.result
                    var base64String = getB64Str(cont);

                    let shopImage = {};
                    shopImage.FileType = file.type;
                    shopImage.FileName = file.name;
                    shopImage.FileBase64String = base64String;
                    this.state.shopImages.push(shopImage);
                }
            }.bind(this);

            reader.readAsArrayBuffer(blob);
        });

        let errors = this.state.errors;        
        errors.shopImages = '';
        this.setState({ errors, errorMessage: null });
    }

    render() {
        const { classes, mediaQuery } = this.props;
        const col2 = mediaQuery ? 2 : 12;
        const col3 = mediaQuery ? 3 : 12;
        const col4 = mediaQuery ? 4 : 12;
        const col5 = mediaQuery ? 5 : 12;
        const col8 = mediaQuery ? 8 : 12;
        const col6 = mediaQuery ? 6 : 12;
        
        return (
            <div>
                {this.state.loading ? (
                    <Loader />
                ) : (
                    <div>
                        <ErrorModal ref="errModalComp" />

                        <form onSubmit={this.loginToDashboard} noValidate>
                            <h2 className="header-text-color">Add Customers</h2>

                            <Grid container spacing={3}>                                                            
                                <Grid item xs={col6}>
                                    <TextField fullWidth required="true" name="shopName" id="txtShopName" label="Shop Name"
                                        onChange={this.handleChange} noValidate value={this.state.shopName} 
                                        InputLabelProps={{ shrink: true, style: { fontSize: 18 } }}/>
                                    {this.state.errors.shopName.length > 0 &&
                                        <span className='error'>{this.state.errors.shopName}</span>}
                                </Grid>                            
                                <Grid item xs={col6}>
                                    <TextField fullWidth required="true" name="contactPersonName" id="txtContactPersonName" label="Contact Person Name"
                                        onChange={this.handleChange} noValidate value={this.state.contactPersonName} 
                                        InputLabelProps={{ shrink: true, style: { fontSize: 18 } }}/>
                                    {this.state.errors.contactPersonName.length > 0 &&
                                        <span className='error'>{this.state.errors.contactPersonName}</span>}
                                </Grid>                                
                            </Grid>
                            <Grid container spacing={3}>
                                <Grid item xs={col4}>                                
                                    <TextField fullWidth required="true" name="mobileNo" id="txtMobileNo" label="Mobile Number"
                                        onChange={this.handleChange} noValidate value={this.state.mobileNo} 
                                        InputLabelProps={{ shrink: true, style: { fontSize: 18 } }}/>
                                    {this.state.errors.mobileNo.length > 0 &&
                                        <span className='error'>{this.state.errors.mobileNo}</span>}
                                </Grid>
                                <Grid item xs={col4}>                                
                                    <TextField fullWidth name="email" id="txtEmail" label="Email Address"
                                        onChange={this.handleChange} noValidate value={this.state.email} 
                                        InputLabelProps={{ shrink: true, style: { fontSize: 18 } }}/>
                                    {this.state.errors.email.length > 0 &&
                                        <span className='error'>{this.state.errors.email}</span>}
                                </Grid>
                                <Grid item xs={col4}>                                
                                    <TextField fullWidth name="altContactNo" id="txtAltContactNo" label="Alternate Contact Number"
                                        onChange={this.handleChange} noValidate value={this.state.altContactNo} 
                                        InputLabelProps={{ shrink: true, style: { fontSize: 18 } }}/>
                                    {this.state.errors.altContactNo.length > 0 &&
                                        <span className='error'>{this.state.errors.altContactNo}</span>}                                    
                                </Grid>
                            </Grid>
                            <Grid container spacing={3}>
                                <Grid item xs={12}>                                
                                    <TextField fullWidth required="true" name="address" id="txtAddress" label="Address" multiline rowsMax={4}
                                        onChange={this.handleChange} noValidate value={this.state.address} 
                                        InputLabelProps={{ shrink: true, style: { fontSize: 18 } }}/>
                                    {this.state.errors.address.length > 0 &&
                                        <span className='error'>{this.state.errors.address}</span>}
                                </Grid>                            
                            </Grid>
                            <Grid container spacing={3}>                                
                                <Grid item xs={col8}>                                
                                    <TextField fullWidth required="true" name="location" id="txtLocation" label="Location"
                                        onChange={this.handleChange} noValidate value={this.state.location} 
                                        InputLabelProps={{ shrink: true, style: { fontSize: 18 } }}/>
                                    {this.state.errors.location.length > 0 &&
                                        <span className='error'>{this.state.errors.location}</span>}
                                </Grid>
                                <Grid item xs={col4}>                                
                                    <TextField fullWidth required="true" name="pinCode" id="txtPinCode" label="Pin Code"
                                        onChange={this.handleChange} noValidate value={this.state.pinCode} 
                                        InputLabelProps={{ shrink: true, style: { fontSize: 18 } }}/>
                                    {this.state.errors.pinCode.length > 0 &&
                                        <span className='error'>{this.state.errors.pinCode}</span>}
                                </Grid>          
                            </Grid>
                            <Grid container spacing={3}>
                                <Grid item xs={col4}>
                                    <TextField fullWidth name="shopImages" type="file" onChange={ e => {this.onFileUploadChange(e)}}
                                        label="Upload Shop Images" InputLabelProps={{ shrink: true, style: { fontSize: 18 } }} 
                                        inputProps={{ multiple: true }}/>
                                    {/* {this.state.errors.shopImages.length > 0 &&
                                        <span className='error'>{this.state.errors.shopImages}</span>} */}
                                </Grid>                                                            
                                <Grid item xs={col4}>
                                    <TextField fullWidth name="gstNo" id="txtGSTNo" label="GST Number"
                                        onChange={this.handleChange} noValidate value={this.state.gstNo} 
                                        InputLabelProps={{ shrink: true, style: { fontSize: 18 } }}/>
                                </Grid>                            
                                <Grid item xs={col4}>
                                    <TextField fullWidth name="referralCode" id="txtState" label="Referral Code"
                                        onChange={this.handleChange} noValidate value={this.state.referralCode} 
                                        InputLabelProps={{ shrink: true, style: { fontSize: 18 } }}/>
                                </Grid>                                
                            </Grid>                           
                            <Grid container spacing={0}>
                                <Grid item xs={10}>
                                </Grid>
                                <Grid item xs={col2}>                                
                                    <Button fullWidth className={classes.root} variant="contained"
                                        color="primary" onClick={this.save}>
                                        <CheckIcon className={classes.leftIcon} />SAVE</Button>
                                </Grid>
                                {this.state.errorMessage &&
                                    <Grid item xs={12} className='error-main'>{this.state.errorMessage}</Grid>}
                            </Grid>
                        </form>
                    </div>
                    )}
            </div>
        );
    }
}

function getB64Str (buffer) {
    var binary = '';
    var bytes = new Uint8Array(buffer);
    var len = bytes.byteLength;
    for (var i = 0; i < len; i++) {
        binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
}

export default withRouter(withStyles(useStyles)(withMediaQuery('(min-width:600px)')(AddCustomers)))