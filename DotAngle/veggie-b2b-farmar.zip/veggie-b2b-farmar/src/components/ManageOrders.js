import React, { Component } from 'react';
import './common/Common.css';
import { Grid, withStyles, Button, useMediaQuery, InputLabel } from '@material-ui/core';
import './common/CommonModal.css';
import { withRouter, Link } from 'react-router-dom';
import Loader from './loader/Loader';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import LinkRenderer from './common/LinkRenderer';
import EditRenderer from './common/EditRenderer';
import OrderModal from './modal/OrderModal';
import api from './common/APIValues';
import BuildIcon from '@material-ui/icons/Build';
import 'date-fns';
import DateFnsUtils from '@date-io/date-fns';
import { MuiPickersUtilsProvider, KeyboardDatePicker } from '@material-ui/pickers';
import ConfirmModal from './modal/ConfirmModal';
import ErrorModal from './modal/ErrorModal';
import CloseIcon from '@material-ui/icons/Close';
import Popup from "reactjs-popup";
import { useStyles } from './common/useStyles';

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);    
    return <Component mediaQuery={mediaQuery} {...props} />;
};

class ManageOrders extends Component {
    constructor(props) {
        super(props);
        this.state = {
            orderNo: 0, userId: null, loading: false, orderedDate: new Date(), totalPrice: null, totalOutstanding: null,
            showDetails: false, orderedFormatDate: '', shopId: 0, open: false, errorTypeMsg: '', header: '',
            columnDefs: [
                { 
                    headerName: '', field: 'Action', width: 60, sorting: false, filter: false, 
                    cellRenderer: 'editRenderer',
                },
                { 
                    headerName: 'Action', field: 'Action', width: 130, sorting: false, filter: false, 
                    cellRenderer: 'linkRenderer',
                }, 
                { headerName: 'Ref Code', field: 'ReferralCode', width: 120 },
                { headerName: 'Order Status', field: 'Status', width: 140 },
                { headerName: 'Shop Name', field: 'ShopName', width: 250 },
                { headerName: 'Total Weight', field: 'TotalWeight', width: 140 },
                { headerName: 'Total Pieces', field: 'TotalPiece', width: 140 },
                { headerName: 'Order Mode', field: 'OrderMode', width: 135 },
                { headerName: 'Order No', field: 'OrderNo', width: 125 },          
                { headerName: 'Total Price', field: 'TotalPrice', width: 130 },                                                              
                { headerName: 'Order DateTime', field: 'OrderedDateTime', width: 180 },               
                { headerName: 'Delivery Date', field: 'DeliveryDate', width: 150 },
                { headerName: 'Delivery Time', field: 'DeliveryTime', width: 170 },
                { headerName: 'Delivery Person', field: 'DeliveryUser' },
                { headerName: 'Created User', field: 'UserId' },                
            ],
            context: { componentParent: this },
            frameworkComponents: { linkRenderer: LinkRenderer, editRenderer: EditRenderer },
            rowData: [],
            defaultColDef: { sortable: true, resizable: true, filter: true },
            rowClassRules: {
                'grid-row-even': function (params) { return params.node.rowIndex % 2 === 0; },
                'grid-row-odd': function (params) { return params.node.rowIndex % 2 !== 0; }
            },
            suppressRowClickSelection: true,
            rowSelection: 'multiple',
        };

        this.openModal = this.openModal.bind(this);
        this.closeModal = this.closeModal.bind(this);
        this.popupOnClose = this.popupOnClose.bind(this);
    }

    onGridReady = params => { this.gridApi = params.api; this.gridColumnApi = params.columnApi; };
    openModal(errorTypeMsg, header) {        
        this.setState({ open: true, errorTypeMsg: errorTypeMsg, header: header ? header : 'Errors' });
    }
    closeModal() { this.setState({ open: false }); }
    popupOnClose() { }

    onDateChanged = (date) => { 
        this.setState({ orderedDate: date });
        let shopId = this.props.location.customerIdRef;
        let orderedDate = '';
        if(date){
            var dd = String(date.getDate()).padStart(2, '0');
            var mm = String(date.getMonth() + 1).padStart(2, '0');
            var yyyy = date.getFullYear();
            orderedDate = dd + "/" + mm + "/" + yyyy;
        }
        this.setState({ orderedFormatDate: orderedDate });
        this.loadOrders(shopId, orderedDate);
    };

    loadOrders(shopId, orderedDate){
        let partialUrl = api.URL;
        let customerId = 0; if (shopId) {
            customerId = shopId;
        }

        fetch(partialUrl + 'Order/GetOrders?ShopId=' + customerId + '&OrderedDate=' + orderedDate)
            .then(res => res.json())
            .then(result => {                
                this.setState({ rowData: result.orders, totalPrice: result.TotalPrice, 
                    totalOutstanding: result.TotalOutstanding, loading: false })
                if(customerId > 0) {
                    this.setState({ showDetails: true });
                }
            })
            .catch(err => console.log(err));
    }

    viewRowData = (row, status) => {        
        const { history } = this.props;
        if(status === 'view'){            
            if (history) history.push({ pathname: '/ViewOrderReport', orderNoRef: row.OrderNo });
        } else if(status === 'edit') {
            if (history) history.push({ pathname: '/CreateOrders', orderNoRef: row.OrderNo, shopIdRef: row.ShopId });
        }
    };

    editGridRow = row => {
        let orderNo = row.OrderNo;
        this.setState({ orderNo: orderNo });
        this.refs.orderModalComp.openModal();
    };

    showConfirmPopup = row => {
        this.setState({ orderNo: row.OrderNo })
        this.refs.cnfrmModalComp.openModal();
    }

    DeleteRecord = () => {
        this.setState({ loading: true });
        let OrderNo = this.state.orderNo;
        let partialUrl = api.URL;
        fetch(partialUrl + 'Order/RemoveCreatedOrder?OrderNo=' + OrderNo, {
            method: 'POST',
            mode: 'cors'
        }).then((response) => response.json())
            .then((responseJson) => {
                if (responseJson) {
                    this.loadOrders(this.state.shopId, this.state.orderedFormatDate);
                    this.setState({ orderNo: 0 });
                } else {
                    this.setState({ loading: false });
                    var errorMsg = 'Cannot delete Dispatched/Delivered order.';
                    this.openModal(errorMsg);
                }
        });
    }

    updateOrder = (status, deliveryDate, deliveryTime, deliveryUserId, orderMode) => {
        this.setState({ loading: true });
        let orderData = {};
        orderData.Status = status !== '0' ? status : '';
        orderData.DeliveredDate = deliveryDate;
        orderData.DeliveryTime = deliveryTime !== ' - ' ? deliveryTime : '';
        orderData.OrderNo = this.state.orderNo;
        orderData.DeliveryUserId = deliveryUserId;
        orderData.OrderMode = orderMode;
        let partialUrl = api.URL;
        fetch(partialUrl + 'Order/UpdateOrder', {
             method: 'POST',
            mode: 'cors',
            body: JSON.stringify(orderData),
            headers: { 'Content-Type': 'application/json' }
        }).then((response) => response.json())
            .then((responseJson) => {
                if (responseJson) {
                    this.loadOrders(this.state.shopId, this.state.orderedFormatDate);
                    this.setState({ loading: false });                    
                }
            })
    }

    componentDidMount() {
        let loggedInUser = sessionStorage.getItem('loggedInUser');
        let shopId = this.props.location.customerIdRef;
        
        if(loggedInUser) {
            this.setState({ userId: loggedInUser, loading: true, shopId: shopId });
            let orderedDate = '';
            if(this.state.orderedDate){
                var dd = String(this.state.orderedDate.getDate()).padStart(2, '0');
                var mm = String(this.state.orderedDate.getMonth() + 1).padStart(2, '0');
                var yyyy = this.state.orderedDate.getFullYear();
                orderedDate = dd + "/" + mm + "/" + yyyy;
            }
            this.setState({ orderedFormatDate: orderedDate });
            this.loadOrders(shopId, orderedDate);
        } else {
            const { history } = this.props;
            if (history) history.push('/Home');
        }
    }

    redirectToOrderSummary = (event) => {
        const { history } = this.props;
        if (history) history.push({ 
            pathname: '/OrderSummary', orderedDateFormatRef: this.state.orderedFormatDate, 
            orderedDateTimeRef: this.state.orderedDate 
        });
    }

    render() {
        const { classes, mediaQuery } = this.props;
        const col2 = mediaQuery ? 2 : 12;
        const col10 = mediaQuery ? 10 : 5;
        const col3 = mediaQuery ? 3 : 12;
        const col5 = mediaQuery ? 7 : 0;
        const col23 = mediaQuery ? 2 : 3;
        
        return (
            <div>
                <Popup contentStyle={{ width: "600px", height: "220px", borderRadius: "5px" }} open={this.state.open}
                    className="popup-modal-container-box" modal onOpen={e => this.popupOnClose(e)}
                    onClose={this.popupOnClose} lockScroll={true} closeOnDocumentClick={false}>
                    <div className="modal-custom">
                        <div className="header">{ this.state.header }</div>
                        <div className="content-confirm">
                            <InputLabel>{ this.state.errorTypeMsg }</InputLabel>
                        </div>
                        <Grid className="actions" container spacing={1}>
                            <Grid item xs={9}>
                            </Grid>
                            <Grid item xs={3}>
                                <Button className={classes.root} color="primary" variant="contained" onClick={this.closeModal}>
                                    <CloseIcon className={classes.leftIcon} /> Close </Button>
                            </Grid>
                        </Grid>
                    </div>
                </Popup>

                {this.state.loading ? (
                    <Loader />
                ) : (
                    <div>                        
                        <ConfirmModal ref="cnfrmModalComp" onClick={(e) => this.DeleteRecord(e)} />                        
                        <OrderModal ref="orderModalComp" onClick={(status, deliveryDate, deliveryTime, deliveryUserId, orderMode) => 
                            this.updateOrder(status, deliveryDate, deliveryTime, deliveryUserId, orderMode)} />

                        <Grid container spacing={1}>
                            <Grid item xs={col10}>
                                <h2 className="header-text-color">Manage Orders</h2>
                            </Grid>                     
                        </Grid>

                        <Grid container spacing={0}>
                            <Grid item xs={col3}>
                                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                    <KeyboardDatePicker fullWidth format="dd/MM/yyyy"
                                        id="dateUpdated" label="Ordered Date"
                                        value={this.state.orderedDate}
                                        onChange={this.onDateChanged}
                                        KeyboardButtonProps={{
                                            'aria-label': 'change date',
                                        }}
                                    />
                                </MuiPickersUtilsProvider>
                            </Grid>
                            <Grid item xs={col5}></Grid>
                            { this.state.showDetails &&
                                <Grid item xs={col23}>                                
                                    <div style={{ marginTop: 30 }}>
                                        Total Price: { this.state.totalPrice }
                                    </div>                               
                                </Grid>
                            }
                            { this.state.showDetails &&
                                <Grid item xs={col23}>
                                    <div style={{ marginTop: 30 }}>                                                                            
                                        Total Outstanding: { this.state.totalOutstanding }
                                    </div>
                                </Grid>
                            }
                            <Grid item xs={col2}>                                
                                <Button fullWidth className={classes.root} variant="contained"
                                    color="primary" onClick={() => this.redirectToOrderSummary()}>
                                    <BuildIcon className={classes.leftIcon} />Order Summary</Button>
                            </Grid>
                        </Grid>

                        <Grid container spacing={0}>
                            <Grid item xs={12}>
                                <div className="ag-theme-alpine" style={{ width: "100%", height: 550, marginTop: 10 }}>
                                    <AgGridReact
                                        columnDefs={this.state.columnDefs} rowData={this.state.rowData}
                                        onGridReady={this.onGridReady} defaultColDef={this.state.defaultColDef}
                                        frameworkComponents={this.state.frameworkComponents} context={this.state.context}
                                        pagination={true} gridOptions={this.gridOptions} paginationPageSize={100}
                                        components={this.state.components} rowClassRules={this.state.rowClassRules} 
                                        suppressClickEdit={true}
                                    />
                                </div>
                            </Grid>                        
                        </Grid>
                    </div>
                    )}
            </div>
        );
    }
}

export default withRouter(withStyles(useStyles)(withMediaQuery('(min-width:600px)')(ManageOrders)))