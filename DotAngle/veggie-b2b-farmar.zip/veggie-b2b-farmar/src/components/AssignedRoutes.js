import React, { Component } from 'react';
import { 
    Grid, withStyles, Table, TableBody, TableContainer, TableCell, TableHead, TableRow,
    Paper, useMediaQuery, Select, MenuItem
} from '@material-ui/core';
import api from './common/APIValues';
import Loader from './loader/Loader';
import { useStyles } from './common/useStyles';

// const useStyles = theme => ({
//     leftIcon: {
//         marginRight: theme.spacing.unit,
//     },
//     topMargin: {
//         marginTop: 10,
//     },
//     root: {
//         fontSize: 12, height: '2.1rem', marginTop: 20,
//         backgroundColor: "#2b494b",
//         "&:hover": {
//             backgroundColor: "#2b494b"
//         },
//         "&:disabled": {
//             backgroundColor: "rgba(0, 0, 0, 0.12)"
//         },
//     },
// });

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);    
    return <Component mediaQuery={mediaQuery} {...props} />;
};

class AssignedRoutes extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            open: false, rowData: [], loading: false, orderedDate: null, rowData: [], routes: [], route: '0'
        };

        this.onRouteChanged = this.onRouteChanged.bind(this);
    }

    loadOrders(orderedDateRef, route){
        let partialUrl = api.URL;
        fetch(partialUrl + 'Customer/GetAssignedRoutes?&OrderedDate=' + orderedDateRef + '&CondOper=2&RouteCategory=' + route)
            .then(res => res.json())
            .then(result => {
                this.setState({ rowData: result, loading: false })
            })
            .catch(err => console.log(err));
    }

    loadRoutes(){
        let partialUrl = api.URL;
        fetch(partialUrl + 'Customer/GetRoutes')
            .then(res => res.json())
            .then(result => this.setState({ routes: result, }))
            .catch(err => console.log(err));
    }

    onRouteChanged(e) {
        let route = e.target.value;
        this.setState({ route: route });
        let orderedDateRef = sessionStorage.getItem('OrderedDateFormatRef');
        this.loadOrders(orderedDateRef, route);
    };

    componentDidMount() {
        let loggedInUser = sessionStorage.getItem('loggedInUser');
        if(loggedInUser) {
            let orderedDateRef = sessionStorage.getItem('OrderedDateFormatRef');
            if(orderedDateRef) {
                this.setState({ loading: true });
                this.loadRoutes();
                this.loadOrders(orderedDateRef, '');
            }
        } else {
            const { history } = this.props;
            if (history) history.push('/Home');
        }
    }

    render() {
        const { classes, mediaQuery } = this.props;
        const col10 = mediaQuery ? 10 : 8;
        const col2 = mediaQuery ? 2 : 4;
        let _routes = this.state.routes;
        let routes = _routes.map((route) =>
                <MenuItem value={route.RouteCategory}>{route.RouteName}</MenuItem>
            );

        return (
            <div>
                {this.state.loading ? (
                    <Loader />
                ) : (
                    <div>
                        <Grid container spacing={4}>                            
                            <Grid item xs={col10}>
                                <h2 className="header-text-color">Customer Order Routes</h2>
                            </Grid>
                            <Grid item xs={col2}>
                                <Select fullWidth id="ddRoute" value={this.state.route} onChange={ this.onRouteChanged }
                                    className="selectTopMargin">
                                    {routes}
                                </Select>
                            </Grid>
                        </Grid>

                        <Grid container spacing={0}>
                            <Grid item xs={12}>
                                <TableContainer component={Paper}>                                    
                                    <Table className={classes.table} aria-label="simple table">
                                        <TableHead className="table-header-custom">
                                            <TableRow>                                                
                                                <TableCell style={{ color: 'white', fontSize: 16 }} align="center">Shop Name</TableCell>                                             
                                                <TableCell style={{ color: 'white', fontSize: 16 }} align="center">Total Weight</TableCell>
                                                <TableCell style={{ color: 'white', fontSize: 16 }} align="center">Location</TableCell>
                                                <TableCell style={{ color: 'white', fontSize: 16 }} align="center">Pin Code</TableCell>
                                                <TableCell style={{ color: 'white', fontSize: 16 }} align="center">Route</TableCell>
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                        {this.state.rowData.map((data, index) => (
                                            <TableRow key={data.OrderNo}>
                                                <TableCell align="center">{data.ShopName}</TableCell>                                            
                                                <TableCell align="center">{data.TotalWeight}</TableCell>
                                                <TableCell align="center">{data.Location}</TableCell>                                            
                                                <TableCell align="center">{data.PinCode}</TableCell>
                                                <TableCell align="center">{data.Route}</TableCell>
                                            </TableRow>
                                        ))}
                                        </TableBody>
                                    </Table>
                                </TableContainer>
                            </Grid>                        
                        </Grid>
                    </div>
                    )}
            </div>
        );
    }
}

export default withStyles(useStyles)(withMediaQuery('(min-width:600px)')(AssignedRoutes))