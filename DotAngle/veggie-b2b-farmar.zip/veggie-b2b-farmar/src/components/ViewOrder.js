import React, { Component } from 'react';
import './common/Common.css';
import { 
    Grid, withStyles, Table, TableBody, TableContainer, TableCell, TableHead, TableRow,
    Paper, useMediaQuery, Card, CardContent
} from '@material-ui/core';
import './common/CommonModal.css';
import { withRouter } from 'react-router-dom';
import Loader from './loader/Loader';
import api from './common/APIValues';
import { useStyles } from './common/useStyles';

// const useStyles = theme => ({
//     leftIcon: {
//         marginRight: theme.spacing.unit,
//     },
//     topMargin: {
//         marginTop: 10,
//     },
//     root: {
//         fontSize: 12, height: '2.1rem', marginTop: 20,
//         backgroundColor: "#0079c2",
//         "&:hover": {
//             backgroundColor: "#0079c2"
//         },
//         "&:disabled": {
//             backgroundColor: "rgba(0, 0, 0, 0.12)"
//         },
//     },
// });

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);
    return <Component mediaQuery={mediaQuery} {...props} />;
};

class ViewOrder extends Component {
    constructor(props) {
        super(props);
        this.state = {
            orderNo: 0, userId: null, shopName: null, status: null, orderDateTime: null, deliveryDate: null, deliveryTime: null,
            totalPrice: null, totalWeight: null, loading: false, paymentStatus: null, contactName: null, mobileNo: null,            
            rowData: [], deliveryCharges: null,
        };
    }

    loadOrderProducts(orderNo){
        let partialUrl = api.URL;
        fetch(partialUrl + 'Order/GetOrderProducts?OrderNo='+ orderNo)
            .then(res => res.json())
            .then(result => {
                console.log(result);
                this.setState({
                    rowData: result.orders,
                    orderNo: result.orderProduct.OrderNo,
                    shopName: result.orderProduct.ShopName,
                    contactName: result.orderProduct.ContactName,
                    orderDateTime: result.orderProduct.OrderedDateTime,
                    mobileNo: result.orderProduct.MobileNo,
                    totalPrice: result.orderProduct.OverallTotalPrice,
                    totalWeight: result.orderProduct.OverallTotalWeight,
                    totalPieces: result.orderProduct.TotalPiece,
                    deliveryCharges: result.orderProduct.DeliveryCharges,
                    loading: false
                });
            })
            .catch(err => console.log(err));
    }

    componentDidMount() {
        let loggedInUser = sessionStorage.getItem('loggedInUser');
        let orderNo = this.props.location.orderNoRef;
        this.setState({ userId: loggedInUser, loading: true });
        this.loadOrderProducts(orderNo);
    }

    render() {
        const { classes, mediaQuery } = this.props;

        return (
            <div>
                {this.state.loading ? (
                    <Loader />
                ) : (
                    <div>
                        <h2 className="header-text-color">View Order</h2>
                        
                        <Grid container spacing={0}>
                            <Grid item xs={12}>
                                <Card style={{ border: '1px solid #f16623' }}>
                                    <CardContent>
                                        <Grid container spacing={3}>
                                            <Grid item xs={2}>
                                                <b>Ordered Date</b>
                                            </Grid>
                                            <Grid item xs={2}>
                                                <b>Order No</b>
                                            </Grid>
                                            <Grid item xs={3}>
                                                <b>Shop Name</b>
                                            </Grid>
                                            <Grid item xs={3}>
                                                <b>Contact Name</b>
                                            </Grid>
                                            <Grid item xs={2}>
                                                <b>Mobile No</b>
                                            </Grid>
                                        </Grid>
                                        <Grid container spacing={3}>
                                            <Grid item xs={2}>
                                                { this.state.orderDateTime }
                                            </Grid>
                                            <Grid item xs={2}>
                                                { this.state.orderNo }
                                            </Grid>
                                            <Grid item xs={3}>
                                                { this.state.shopName }
                                            </Grid>
                                            <Grid item xs={3}>
                                                { this.state.contactName }
                                            </Grid>
                                            <Grid item xs={2}>
                                                { this.state.mobileNo }
                                            </Grid>
                                        </Grid>
                                    </CardContent>
                                </Card>
                            </Grid>
                        </Grid>

                        <Grid container spacing={0}>
                            <Grid item xs={12}>
                                <TableContainer component={Paper} className={classes.topMargin}>                                    
                                    <Table className={classes.table} aria-label="simple table">
                                        <TableHead className="table-header-custom">
                                            <TableRow>                                                
                                                <TableCell style={{ color: 'white', fontSize: 16 }} align="left">Product Name</TableCell>
                                                <TableCell style={{ color: 'white', fontSize: 16 }} align="center">Quantity / Pieces</TableCell>
                                                <TableCell style={{ color: 'white', fontSize: 16 }} align="center">Price Per Kg / Pc</TableCell>
                                                <TableCell style={{ color: 'white', fontSize: 16 }} align="center">Total Price</TableCell>
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                        {this.state.rowData.map((data, index) => (
                                            <TableRow key={data.ProductId}>                                                
                                                <TableCell align="left">{data.ProductName}</TableCell>
                                                <TableCell align="center">{data.TotalWeight}</TableCell>                                                      
                                                <TableCell align="center">{data.RatePerKg}</TableCell>                                                
                                                <TableCell align="center">{data.TotalPrice}</TableCell>                                             
                                            </TableRow>
                                        ))}
                                            <TableRow>
                                                <TableCell rowSpan={3} />
                                                <TableCell align="left">Total Quantity: <b>{ Number(this.state.totalWeight) }</b></TableCell>
                                                <TableCell colSpan={1} />
                                                <TableCell align="left">Total Amount: <b>{ this.state.totalPrice } INR</b></TableCell>
                                            </TableRow>
                                            <TableRow>
                                                <TableCell align="left">Total Pieces: <b>{ Number(this.state.totalPieces) }</b></TableCell>
                                                <TableCell colSpan={1} />
                                                <TableCell align="left">Delivery Charges: <b>{ this.state.deliveryCharges } INR</b></TableCell>
                                            </TableRow>
                                            <TableRow>
                                                <TableCell align="left">Order Mode: <b>{ Number(this.state.deliveryCharges) === 0 ? 'Pickup' : 'Delivery' }</b></TableCell>
                                                <TableCell colSpan={1} />
                                                <TableCell align="left">Grand Total: <b>{ Number(this.state.totalPrice) + Number(this.state.deliveryCharges) } INR</b></TableCell>
                                            </TableRow>
                                        </TableBody>
                                    </Table>
                                </TableContainer>
                            </Grid>
                        </Grid>
                    </div>
                    )}
            </div>
        );
    }
}

export default withRouter(withStyles(useStyles)(withMediaQuery('(min-width:600px)')(ViewOrder)))