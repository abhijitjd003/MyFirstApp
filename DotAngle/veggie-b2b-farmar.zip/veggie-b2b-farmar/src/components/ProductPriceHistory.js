import React, { Component } from 'react';
import './common/Common.css';
import { Grid, withStyles, Button, useMediaQuery } from '@material-ui/core';
import './common/CommonModal.css';
import { withRouter } from 'react-router-dom';
import Loader from './loader/Loader';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import api from './common/APIValues';
import 'date-fns';
import DateFnsUtils from '@date-io/date-fns';
import { MuiPickersUtilsProvider, KeyboardDatePicker } from '@material-ui/pickers';
import { useStyles } from './common/useStyles';
import GetAppIcon from '@material-ui/icons/GetApp';

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);    
    return <Component mediaQuery={mediaQuery} {...props} />;
};

class ProductPriceHistory extends Component {
    constructor(props) {
        super(props);
        this.state = {
            fromDate: null, loading: false, toDate: null, fromDateFormat: null, toDateFormat: null,
            columnDefs: [                
                { headerName: 'Product Name', field: 'ProductName', cellStyle: { textAlign: 'center' } },
                { headerName: 'Price Kg / Piece', field: 'RatePerKg', cellStyle: { textAlign: 'center' } },
                { headerName: 'Updated Date', field: 'UpdatedDate', cellStyle: { textAlign: 'center' } },                
            ],
            context: { componentParent: this },
            rowData: [],
            defaultColDef: { flex: 1, sortable: true, resizable: true, filter: true },
            rowClassRules: {
                'grid-row-even': function (params) { return params.node.rowIndex % 2 === 0; },
                'grid-row-odd': function (params) { return params.node.rowIndex % 2 !== 0; }
            },            
            rowSelection: 'multiple',
        };
    }

    onGridReady = params => { this.gridApi = params.api; this.gridColumnApi = params.columnApi; };

    onFromDateChanged = (date) => { 
        this.setState({ fromDate: date });
        let updatedDate = '';
        if(date){
            var dd = String(date.getDate()).padStart(2, '0');
            var mm = String(date.getMonth() + 1).padStart(2, '0');
            var yyyy = date.getFullYear();
            updatedDate = yyyy + "-" + mm + "-" + dd;
        }
        this.setState({ fromDateFormat: updatedDate});
        this.loadProductsHistory(updatedDate, this.state.toDateFormat);
    };

    onToDateChanged = (date) => { 
        this.setState({ toDate: date });
        let updatedDate = '';
        if(date){
            var dd = String(date.getDate()).padStart(2, '0');
            var mm = String(date.getMonth() + 1).padStart(2, '0');
            var yyyy = date.getFullYear();
            updatedDate = yyyy + "-" + mm + "-" + dd;
        }
        this.setState({ toDateFormat: updatedDate});
        this.loadProductsHistory(this.state.fromDateFormat, updatedDate);
    };

    loadProductsHistory(fromDate, toDate){
        let partialUrl = api.URL;
        fetch(partialUrl + 'Product/GetProductsHistory?FromDate='+ fromDate + '&ToDate='+ toDate)
            .then(res => res.json())
            .then(result => {
                this.setState({ rowData: result, loading: false });
            })
            .catch(err => console.log(err));
    }

    componentDidMount() {
        let loggedInUser = sessionStorage.getItem('loggedInUser');

        if(loggedInUser) {
            this.setState({ loading: true });
            this.loadProductsHistory('', '');
        } else {
            const { history } = this.props;
            if (history) history.push('/Home');
        }
    }

    exportToExcel = () => {
        var params = { fileName: 'SSAV PG Cap', sheetName: 'SSAV PG Cap', };
        this.gridApi.exportDataAsExcel(params);
    };

    render() {
        const { classes, mediaQuery } = this.props;
        const col3 = mediaQuery ? 3 : 6;
        const col03 = mediaQuery ? 3 : 12;
        
        return (
            <div>
                {this.state.loading ? (
                    <Loader />
                ) : (
                    <div>                        
                        <h2 className="header-text-color">Product Price History</h2>

                        <Grid container spacing={2}>
                            <Grid item xs={col3}>
                                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                    <KeyboardDatePicker fullWidth format="dd/MM/yyyy"
                                        id="dateUpdated" label="From Date"
                                        value={this.state.fromDate}
                                        onChange={this.onFromDateChanged}
                                        KeyboardButtonProps={{
                                            'aria-label': 'change date',
                                        }}
                                    />
                                </MuiPickersUtilsProvider>
                            </Grid>
                            <Grid item xs={col3}>
                                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                    <KeyboardDatePicker fullWidth format="dd/MM/yyyy"
                                        id="dateUpdated" label="To Date"
                                        value={this.state.toDate}
                                        onChange={this.onToDateChanged}
                                        KeyboardButtonProps={{
                                            'aria-label': 'change date',
                                        }}
                                    />
                                </MuiPickersUtilsProvider>
                            </Grid>
                            <Grid item xs={col03}></Grid>
                            <Grid item xs={col03}>                                
                                <Button fullWidth className={classes.root} variant="contained"
                                    color="primary" onClick={ this.exportToExcel }>
                                    <GetAppIcon className={classes.leftIcon} />Export To Excel</Button>
                            </Grid>
                        </Grid>
                        
                        <Grid container spacing={0}>
                            <Grid item xs={12}>
                                <div className="ag-theme-alpine" style={{ width: "100%", height: 550, marginTop: 10 }}>
                                    <AgGridReact
                                        columnDefs={this.state.columnDefs} rowData={this.state.rowData}
                                        onGridReady={this.onGridReady} defaultColDef={this.state.defaultColDef}
                                        frameworkComponents={this.state.frameworkComponents} context={this.state.context}
                                        pagination={true} gridOptions={this.gridOptions} paginationPageSize={50}
                                        components={this.state.components} rowClassRules={this.state.rowClassRules} 
                                        singleClickEdit={true}
                                    />
                                </div>
                            </Grid>                        
                        </Grid>
                    </div>
                    )}
            </div>
        );
    }
}

export default withRouter(withStyles(useStyles)(withMediaQuery('(min-width:600px)')(ProductPriceHistory)))