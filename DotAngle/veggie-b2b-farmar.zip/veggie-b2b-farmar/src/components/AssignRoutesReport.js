import React from "react";
import AssignedRoutes from './AssignedRoutes';
import ReactToPrint from "react-to-print";
import { Grid, withStyles, Button, useMediaQuery } from '@material-ui/core';
import { withRouter } from 'react-router-dom';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import PrintIcon from '@material-ui/icons/Print';
import { useStyles } from './common/useStyles';

class AssignRoutesReport extends React.Component {
  render() {
    return (
      <div style={{ marginRight: 10, marginLeft: 10, marginTop: 10 }}>
          <AssignedRoutes />
      </div>
    );
  }
}

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);
    return <Component mediaQuery={mediaQuery} {...props} />;
};

class PrintRoutes extends React.Component {

    goBack = () => {
        const { history } = this.props;
        if (history) history.push('/AssignRoutes');
    };

    render() {
        const { classes, mediaQuery } = this.props;
        const col7 = mediaQuery ? 8 : 0;
        const col2 = mediaQuery ? 2 : 6;

        return (
            <div>
                <Grid container spacing={ mediaQuery ? 1 : 0 }>
                    <Grid item xs={col7}>                        
                    </Grid>
                    <Grid item xs={col2}>
                        <ReactToPrint
                            trigger={() => 
                                <Button fullWidth variant="contained" className={classes.root}
                                color="primary" onClick={this.print}>
                                <PrintIcon className={classes.leftIcon} />Print Routes</Button>
                            }
                            content={() => this.componentRef}
                        />
                    </Grid>
                    <Grid item xs={col2}>
                        <Button fullWidth className={classes.root} variant="contained"
                            color="primary" onClick={this.goBack}>
                            <ArrowBackIcon className={classes.leftIcon} />Go Back</Button>
                    </Grid>                    
                </Grid>                

                <AssignRoutesReport ref={el => (this.componentRef = el)} />
            </div>
        );
    }
}
                          
export default withRouter(withStyles(useStyles)(withMediaQuery('(min-width:600px)')(PrintRoutes)))