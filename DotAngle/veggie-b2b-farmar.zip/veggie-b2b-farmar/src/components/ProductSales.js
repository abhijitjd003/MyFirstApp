import React, { Component } from 'react';
import './common/Common.css';
import {  Grid, withStyles, CardContent, Card, useMediaQuery, Select, MenuItem, } from '@material-ui/core';
import './common/CommonModal.css';
import { withRouter } from 'react-router-dom';
import Loader from './loader/Loader';
import api from './common/APIValues';
import 'date-fns';
import DateFnsUtils from '@date-io/date-fns';
import { MuiPickersUtilsProvider, KeyboardDatePicker } from '@material-ui/pickers';
import {
    PieChart, Pie, Cell, ComposedChart, Line, Area, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
    ResponsiveContainer, AreaChart, LineChart
} from 'recharts';
import { useStyles } from './common/useStyles';

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);    
    return <Component mediaQuery={mediaQuery} {...props} />;
};

class ProductSales extends Component {
    constructor(props) {
        super(props);
        this.state = {
            fromDate: null, toDate: null, fromDateFormat: null, toDateFormat: null, rowData: [], productId: 7,
            header: null, products: [], avgQuantity: null, unitType: '30D', avgCost: null, productPriceHistory: [],
            avgRatePerKg: null,
        };

        this.onProductChanged = this.onProductChanged.bind(this);
        this.onUnitChanged = this.onUnitChanged.bind(this);
    }

    onFromDateChanged = (date) => { 
        this.setState({ fromDate: date, loading: true });        
        let fromDate = '';
        if(date){
            var dd = String(date.getDate()).padStart(2, '0');
            var mm = String(date.getMonth() + 1).padStart(2, '0');
            var yyyy = date.getFullYear();
            fromDate = yyyy + "-" + mm + "-" + dd;
        }
        this.setState({ fromDateFormat: fromDate });
        this.loadProductSales(fromDate, this.state.toDateFormat, this.state.productId);
    };

    onToDateChanged = (date) => { 
        this.setState({ toDate: date, loading: true });
        let toDate = '';
        if(date){
            var dd = String(date.getDate()).padStart(2, '0');
            var mm = String(date.getMonth() + 1).padStart(2, '0');
            var yyyy = date.getFullYear();
            toDate = yyyy + "-" + mm + "-" + dd;
        }
        this.setState({ toDateFormat: toDate });
        this.loadProductSales(this.state.fromDateFormat, toDate, this.state.productId);
    };

    loadProductSales(fromDate, toDate, productId) {
        let partialUrl = api.URL;
        fetch(partialUrl + 'Report/GetProductSales?FromDate='+ fromDate + '&ToDate='+ toDate + '&ProductId='+ productId)
            .then(res => res.json())
            .then(result => {
                this.setState({ 
                    rowData: result.orders, avgCost: result.AvgCost, avgQuantity: result.AvgQuantity, 
                    loading: false, productPriceHistory: result.productPriceHistory, avgRatePerKg: result.AvgRatePerKg,
                });
            })
            .catch(err => console.log(err));
    }

    loadOrderStartEndDates() {
        let partialUrl = api.URL;
        fetch(partialUrl + 'SalesOfficer/GetOrderStartEndDates/')
            .then(res => res.json())
            .then(result => {
                this.setState({ 
                    fromDate: result.MonthDate, toDate: result.ToDate,
                    fromDateFormat: result.MonthDateFormat, toDateFormat: result.ToDateYearFormat,
                });

                this.loadProductSales(result.MonthDateFormat, result.ToDateYearFormat, this.state.productId);
            })
            .catch(err => console.log(err));
    }

    componentDidMount() {
        let loggedInUser = sessionStorage.getItem('loggedInUser');
        
        if(loggedInUser) {
            this.setState({ loading: true });
            this.loadOrderStartEndDates();
            this.loadProducts();
        } else {
            const { history } = this.props;
            if (history) history.push('/Home');
        }
    }

    loadProducts(){
        let partialUrl = api.URL;
        fetch(partialUrl + 'Product/GetProducts')
            .then(res => res.json())
            .then(result => this.setState({ products: result, loading: false }))
            .catch(err => console.log(err));
    }

    onProductChanged(e) {
        let productId = e.target.value;
        this.setState({ productId: productId, loading: true });
        this.loadProductSales(this.state.fromDateFormat, this.state.toDateFormat, productId);
    };

    onUnitChanged(e) {
        let unitType = e.target.value;
        var currentDate = new Date();

        switch(unitType){
            case '30D':
                currentDate.setDate(currentDate.getDate() - 30);
                this.setState({ 
                    fromDate: currentDate,
                    toDate: new Date(),
                });
                break;
            case '21D':
                currentDate.setDate(currentDate.getDate() - 21);
                this.setState({ 
                    fromDate: currentDate,
                    toDate: new Date(),
                });
                break;
            case '14D':
                currentDate.setDate(currentDate.getDate() - 14);
                this.setState({ 
                    fromDate: currentDate,
                    toDate: new Date(),
                });
                break;
            case '7D':
                currentDate.setDate(currentDate.getDate() - 7);
                this.setState({ 
                    fromDate: currentDate,
                    toDate: new Date(),
                });
                break;
        }
        
        let fromDate = ''; let toDate = '';        
        if(currentDate){
            var dd = String(currentDate.getDate()).padStart(2, '0');
            var mm = String(currentDate.getMonth() + 1).padStart(2, '0');
            var yyyy = currentDate.getFullYear();
            fromDate = yyyy + "-" + mm + "-" + dd;
        }        
        if(new Date()){
            var dd = String(new Date().getDate()).padStart(2, '0');
            var mm = String(new Date().getMonth() + 1).padStart(2, '0');
            var yyyy = new Date().getFullYear();
            toDate = yyyy + "-" + mm + "-" + dd;
        }

        this.setState({ unitType: unitType, loading: true });
        this.loadProductSales(fromDate, toDate, this.state.productId);
    };

    render() {
        const { classes, mediaQuery } = this.props;
        const col4 = mediaQuery ? 3 : 12;
        const col6 = mediaQuery ? 6 : 12;

        let productItems = this.state.products;
        let products = productItems.map((product) =>
            <MenuItem value={product.ProductId}>{product.ProductName}</MenuItem>
        );
        
        return (
            <div>
                {this.state.loading ? (
                    <Loader />
                ) : (
                    <div>
                        <Grid container spacing={0}>
                            <Grid item xs={12}>                     
                                <h2 className="header-text-color">Product Sales Report</h2>
                            </Grid>
                        </Grid>

                        <Grid container spacing={4}>
                            <Grid item xs={col4}>
                                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                    <KeyboardDatePicker fullWidth format="dd/MM/yyyy"
                                        id="dateOrder" label="From Date"
                                        value={this.state.fromDate}
                                        onChange={this.onFromDateChanged}
                                        KeyboardButtonProps={{
                                            'aria-label': 'change date',
                                        }}
                                    />
                                </MuiPickersUtilsProvider>
                            </Grid>
                            <Grid item xs={col4}>
                                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                    <KeyboardDatePicker fullWidth format="dd/MM/yyyy"
                                        id="dateOrder" label="To Date"
                                        value={this.state.toDate}
                                        onChange={this.onToDateChanged}
                                        KeyboardButtonProps={{
                                            'aria-label': 'change date',
                                        }}
                                    />
                                </MuiPickersUtilsProvider>
                            </Grid>
                            <Grid item xs={col4}>
                                <Select fullWidth id="ddlProduct" value={this.state.productId} className="selectTopMargin"
                                    onChange={ this.onProductChanged }>
                                    {products}
                                </Select>
                            </Grid>
                            <Grid item xs={col4}>
                                <Select fullWidth id="ddlUnitType" value={this.state.unitType} className="selectTopMargin"
                                    onChange={ this.onUnitChanged }>
                                    <MenuItem value="7D">Last 7 days</MenuItem>
                                    <MenuItem value="14D">Last 14 days</MenuItem>
                                    <MenuItem value="21D">Last 21 days</MenuItem>
                                    <MenuItem value="30D">Last 30 days</MenuItem>                                     
                                </Select>
                            </Grid>  
                        </Grid>
                        
                        <Grid container spacing={0}>
                            <Grid item xs={12}>
                                <Card className={classes.rootCard}>
                                    <CardContent>
                                        <Grid container spacing={0}>
                                            <Grid item xs={10}>
                                                <span className="dashboard-text-color">
                                                    PRODUCT ORDER QUANTITY
                                                </span>
                                            </Grid>
                                            <Grid item xs={2}>
                                                <span className="graph-sub-text">
                                                    AVERAGE QUANTITY: { Math.round(this.state.avgQuantity) }
                                                </span>
                                            </Grid>
                                        </Grid>

                                        <ResponsiveContainer className={classes.chart} height={300} width='100%'>                            
                                            <ComposedChart data={this.state.rowData}
                                                margin={{ top: 30 }}>
                                                <YAxis type="number" />
                                                <XAxis dataKey="OrderedDateTime" type="category" />
                                                <Tooltip/>
                                                <Legend/>
                                                <Bar dataKey='Quantity' barSize={15} fill='#347f58' label={{ position: 'top' }}/>
                                            </ComposedChart>
                                        </ResponsiveContainer>
                                    </CardContent>
                                </Card>
                            </Grid>
                        </Grid>
                        <Grid container spacing={ mediaQuery ? 2 : 0 }>
                            <Grid item xs={col6}>
                                <Card className={classes.rootCard}>
                                    <CardContent>
                                        <Grid container spacing={0}>
                                            <Grid item xs={9}>
                                                <span className="dashboard-text-color">
                                                    PRODUCT ORDER COST
                                                </span>
                                            </Grid>
                                            <Grid item xs={3}>
                                                <span className="graph-sub-text">
                                                    AVERAGE COST: { Math.round(this.state.avgCost) }
                                                </span>
                                            </Grid>
                                        </Grid>

                                        <ResponsiveContainer className={classes.chart} height={300} width='100%'>                            
                                            <AreaChart data={this.state.rowData}
                                                margin={{ top: 30 }}>
                                                <YAxis type="number" />
                                                <XAxis dataKey="OrderedDateTime" type="category" />
                                                <Tooltip/>
                                                <Legend/>
                                                <Area type='monotone' dataKey='Cost' stroke='#347f58' fill='#347f58' 
                                                    />
                                            </AreaChart>
                                        </ResponsiveContainer>
                                    </CardContent>
                                </Card>
                            </Grid>
                            <Grid item xs={col6}>
                                <Card className={classes.rootCard}>
                                    <CardContent>
                                        <Grid container spacing={0}>
                                            <Grid item xs={9}>
                                                <span className="dashboard-text-color">
                                                    PRODUCT RATE HISTORY
                                                </span>
                                            </Grid>
                                            <Grid item xs={3}>
                                                <span className="graph-sub-text">
                                                    AVERAGE RATE: { Math.round(this.state.avgRatePerKg) }
                                                </span>
                                            </Grid>
                                        </Grid>

                                        <ResponsiveContainer className={classes.chart} height={300} width='100%'>                            
                                            <LineChart data={this.state.productPriceHistory}
                                                margin={{ top: 30 }}>
                                                <YAxis type="number" />
                                                <XAxis dataKey="OrderedDateTime" type="category" />
                                                <Tooltip/>
                                                <Legend/>
                                                <Line type='monotone' dataKey='RatePerKg' stroke='#347f58' fill='#347f58' 
                                                    label={{ position: 'top' }} />
                                            </LineChart>
                                        </ResponsiveContainer>
                                    </CardContent>
                                </Card>
                            </Grid>                    
                        </Grid>
                    </div>
                    )}
            </div>
        );
    }
}

export default withRouter(withStyles(useStyles)(withMediaQuery('(min-width:600px)')(ProductSales)))