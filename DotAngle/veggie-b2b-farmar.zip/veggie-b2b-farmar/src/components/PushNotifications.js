import React, { Component } from 'react';
import './common/Common.css';
import { Button, TextField, Grid, withStyles, InputLabel, Input, useMediaQuery, Select, MenuItem } from '@material-ui/core';
import './common/CommonModal.css';
import { withRouter } from 'react-router-dom';
import Loader from './loader/Loader';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import DeleteRenderer from './common/DeleteRenderer';
import ConfirmModal from './modal/ConfirmModal';
import ErrorModal from './modal/ErrorModal';
import api from './common/APIValues';
import NotificationsIcon from '@material-ui/icons/Notifications';
import { useStyles } from './common/useStyles';

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);    
    return <Component mediaQuery={mediaQuery} {...props} />;
};

const validateForm = (errors) => {
    let valid = true;
    Object.keys(errors).map(function (e) {
        if (errors[e].length > 0) {
            valid = false;
        }        
    });
    return valid;
}

class PushNotifications extends Component {
    constructor(props) {
        super(props);
        this.state = {
            message: null,
            errorMessage: null, loading: false, notificationId: null, shopIds: [], customerNames: [], title: null,
            errors: {
                message: '',
                title: '',
            },
            columnDefs: [
                { headerName: 'Title', field: 'Title', cellStyle: { 'text-align': "center" }, width: 140 },                
                { headerName: 'Notification Message', field: 'Message', flex: 1 },
                { headerName: 'Created Date', field: 'CreatedDateTime', cellStyle: { 'text-align': "center" }, width: 145 },
                { headerName: 'Action', field: 'Action', sorting: false, filter: false, cellRenderer: 'deleteRenderer', cellStyle: { 'text-align': "center" }, width: 90 },
            ],
            context: { componentParent: this },
            frameworkComponents: { deleteRenderer: DeleteRenderer },
            rowData: [],
            defaultColDef: { width: 110, sortable: true, resizable: true, filter: true },
            rowClassRules: {
                'grid-row-even': function (params) { return params.node.rowIndex % 2 === 0; },
                'grid-row-odd': function (params) { return params.node.rowIndex % 2 !== 0; }
            },
        };
    }

    create = (event) => {
        event.preventDefault();
        if (validateForm(this.state.errors) && this.state.message && this.state.title) {
            this.setState({ loading: true });
            let notification = {};
            notification.Title = this.state.title;
            notification.Message = this.state.message;
            notification.ShopIds = this.state.shopIds;
            this.pushNotification(notification);
        } else {
            let errors = this.state.errors;
            if (!this.state.message) {
                errors.message = 'Notification message is required';
            }
            if (!this.state.title) {
                errors.title = 'Title is required';
            }
            this.setState({ errors, errorMessage: null });
        }
    }

    loadNotifications(){
        let partialUrl = api.URL;
        fetch(partialUrl + 'Notification/GetNotifications/')
            .then(res => res.json())
            .then(result => this.setState({ rowData: result, loading: false }))
            .catch(err => console.log(err));
    }

    DeleteRecord(){
        this.setState({ loading: true })
        let NotificationId = this.state.notificationId;
        let partialUrl = api.URL;
        fetch(partialUrl + 'Notification/RemoveNotification?NotificationId=' + NotificationId, {
            method: 'POST',
            mode: 'cors'
        }).then(data => {
            this.loadNotifications();
            this.setState({ loading: false })
        });
    }

    componentDidMount() {
        let loggedInUser = sessionStorage.getItem('loggedInUser');

        if(loggedInUser) {
            this.setState({ userId: loggedInUser, loading: true });
            this.loadCustomers();
            this.loadNotifications();
        } else {
            const { history } = this.props;
            if (history) history.push('/Home');
        }
    }

    showConfirmPopup = row => {
        this.setState({ notificationId: row.NotificationId })
        this.refs.cnfrmModalComp.openModal();
    }

    pushNotification(notification) {
        let partialUrl = api.URL;
        fetch(partialUrl + 'Notification/PushNotification', {
            method: 'POST',
            mode: 'cors',
            body: JSON.stringify(notification),
            headers: { 'Content-Type': 'application/json' }
        }).then((response) => response.json())
            .then((responseJson) => {
                if (responseJson) {
                    this.loadNotifications();
                    this.setState({ 
                        loading: false, message: null, shopIds: [], title: null,
                    });
                } else {
                    this.setState({ 
                        loading: false, message: null, shopIds: [], title: null,
                    });
                    var errorMsg = 'Duplicate notification message found.';
                    this.refs.errModalComp.openModal(errorMsg);
                }
            })
    }

    handleChange = (event) => {
        event.preventDefault();
        const { name, value } = event.target;
        let errors = this.state.errors;

        switch (name) {
            case 'message':
                this.state.message = value;
                errors.message = value.length <= 0
                    ? 'Notification message is required' : '';
                break; 
            case 'title':
                this.state.title = value;
                errors.title = value.length <= 0
                    ? 'Title is required' : '';
                break;            
            default:
                break;
        }
        this.setState({ errors, [name]: value });
    }

    handleSelectChange = (event) => {
        this.setState({ shopIds: event.target.value });
    };

    loadCustomers(){
        let status = 'Approved';
        let partialUrl = api.URL;
        fetch(partialUrl + 'Customer/GetCustomers?Status=' + status)
            .then(res => res.json())
            .then(result => {
                this.setState({ customerNames: result, })
            })
            .catch(err => console.log(err));
    }

    render() {
        const { classes, mediaQuery } = this.props;
        const col2 = mediaQuery ? 2 : 12;
        const col0 = mediaQuery ? 10 : 0;

        return (
            <div>
                {this.state.loading ? (
                    <Loader />
                ) : (
                    <div>
                        <ErrorModal ref="errModalComp" />
                        <ConfirmModal ref="cnfrmModalComp" onClick={(e) => this.DeleteRecord(e)} />

                        <form onSubmit={this.loginToDashboard} noValidate>
                            <h2 className="header-text-color">Push Notification</h2>
                            <Grid container spacing={2}>
                                <Grid item xs={12}>
                                    <TextField fullWidth required="true" name="title" id="txtTitle" multiline rowsMax={4} 
                                        label="Title"
                                        onChange={this.handleChange} noValidate value={this.state.title} />
                                    {this.state.errors.title.length > 0 &&
                                        <span className='error'>{this.state.errors.title}</span>}
                                </Grid>
                                <Grid item xs={12}>
                                    <TextField fullWidth required="true" name="message" id="txtMessage" multiline rowsMax={4} 
                                        label="Notification Message"
                                        onChange={this.handleChange} noValidate value={this.state.message} />
                                    {this.state.errors.message.length > 0 &&
                                        <span className='error'>{this.state.errors.message}</span>}
                                </Grid>
                                <Grid item xs={12}>
                                    <InputLabel id="demo-mutiple-name-label">Customer Name</InputLabel>
                                    <Select fullWidth labelId="demo-mutiple-name-label" id="demo-mutiple-name" multiple
                                    value={this.state.shopIds} onChange={this.handleSelectChange} input={<Input />}>
                                    {this.state.customerNames.map((customer) => (
                                        <MenuItem key={customer.ShopId} value={customer.ShopId}>
                                            {customer.ShopName}
                                        </MenuItem>
                                    ))}
                                    </Select>
                                </Grid>                                
                            </Grid>
                            <Grid container spacing={0}>
                                <Grid item xs={col0}></Grid>
                                <Grid item xs={col2}>
                                    <Button fullWidth className={classes.root} variant="contained"
                                        color="primary" onClick={this.create}>
                                    <NotificationsIcon className={classes.leftIcon} />Push Notification</Button>
                                </Grid>
                            </Grid>
                        </form>

                        <Grid container spacing={0}>
                            <Grid item xs={12}>
                                <div className="ag-theme-alpine" style={{ width: "100%", height: 500, marginTop: 10 }}>
                                    <AgGridReact
                                        columnDefs={this.state.columnDefs} rowData={this.state.rowData}
                                        onGridReady={this.onGridReady} defaultColDef={this.state.defaultColDef}
                                        frameworkComponents={this.state.frameworkComponents} context={this.state.context}
                                        pagination={true} gridOptions={this.gridOptions} paginationPageSize={30}
                                        components={this.state.components} rowClassRules={this.state.rowClassRules} suppressClickEdit={true}
                                    />
                                </div>
                            </Grid>                        
                        </Grid>
                    </div>
                    )}
            </div>
        );
    }
}

export default withRouter(withStyles(useStyles)(withMediaQuery('(min-width:600px)')(PushNotifications)))