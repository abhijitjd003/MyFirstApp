import React, { Component } from 'react';
import './common/Common.css';
import { Grid, withStyles, Button, useMediaQuery } from '@material-ui/core';
import './common/CommonModal.css';
import { withRouter } from 'react-router-dom';
import Loader from './loader/Loader';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import ViewRenderer from './common/ViewRenderer';
import api from './common/APIValues';
import SearchIcon from '@material-ui/icons/Search';
import 'date-fns';
import DateFnsUtils from '@date-io/date-fns';
import { MuiPickersUtilsProvider, KeyboardDatePicker } from '@material-ui/pickers';
import { useStyles } from './common/useStyles';

// const useStyles = theme => ({
//     leftIcon: {
//         marginRight: theme.spacing.unit,
//     },
//     topMargin: {
//         marginTop: 16,
//     },
//     root: {
//         fontSize: 12, height: '2.1rem', marginTop: 20,
//         backgroundColor: "#0079c2",
//         "&:hover": {
//             backgroundColor: "#0079c2"
//         },
//         "&:disabled": {
//             backgroundColor: "rgba(0, 0, 0, 0.12)"
//         },
//     },
// });

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);    
    return <Component mediaQuery={mediaQuery} {...props} />;
};

class OrderSummary extends Component {
    constructor(props) {
        super(props);
        this.state = {
            orderedDate: null, seconds: 0, interval: 0,
            columnDefs: [
                { 
                    headerName: 'Action', field: 'Action', sorting: false, filter: false, 
                    cellRenderer: 'viewRenderer', cellStyle: { textAlign: 'center' }, width: 115
                },
                { headerName: 'Ordered Date', field: 'OrderedDate', cellStyle: { textAlign: 'center' }, width: 150 },
                { headerName: 'Total Customers Ordered', field: 'TotalVendorsOrdered', cellStyle: { textAlign: 'center' }, flex: 1 },
                { headerName: 'Total Orders', field: 'TotalOrders', cellStyle: { textAlign: 'center' }, width: 140 },
                { headerName: 'Total Weight', field: 'TotalWeight', cellStyle: { textAlign: 'center' }, width: 140 },
                { headerName: 'Total Pieces', field: 'TotalPieces', cellStyle: { textAlign: 'center' }, width: 135 },
                { headerName: 'Total Price', field: 'TotalPrice', cellStyle: { textAlign: 'center' }, width: 125 },
                { headerName: 'Delivery Charges', field: 'DeliveryCharges', cellStyle: { textAlign: 'center' }, width: 170 },
            ],
            context: { componentParent: this },
            frameworkComponents: { viewRenderer: ViewRenderer },
            rowData: [],
            defaultColDef: { sortable: true, resizable: true, filter: true },
            rowClassRules: {
                'grid-row-even': function (params) { return params.node.rowIndex % 2 === 0; },
                'grid-row-odd': function (params) { return params.node.rowIndex % 2 !== 0; }
            },            
            rowSelection: 'multiple',
        };
    }

    onGridReady = params => { this.gridApi = params.api; this.gridColumnApi = params.columnApi; };

    onDateChanged = (date) => { 
        this.setState({ orderedDate: date });
        let orderDate = '';
        if(date){
            var dd = String(date.getDate()).padStart(2, '0');
            var mm = String(date.getMonth() + 1).padStart(2, '0');
            var yyyy = date.getFullYear();
            orderDate = dd + "/" + mm + "/" + yyyy;
        }
        this.loadOrderSummary(orderDate);
    };

    viewRowData = (row) => {
        sessionStorage.setItem('OrderedDateRef', row.OrderedDate);
        sessionStorage.setItem('TotalWeightRef', row.TotalWeight);
        sessionStorage.setItem('TotalOrdersRef', row.TotalOrders);
        sessionStorage.setItem('TotalVegetablesRef', row.TotalVegetables);
        sessionStorage.setItem('TotalPriceRef', row.TotalPrice);
        sessionStorage.setItem('TotalVendorsOrderedRef', row.TotalVendorsOrdered);
        sessionStorage.setItem('TotalPiecesRef', row.TotalPieces);
        sessionStorage.setItem('DeliveryChargesRef', row.DeliveryCharges);
        sessionStorage.setItem('IntervalCount', this.state.interval);
        const { history } = this.props;        
        if (history) history.push({ pathname: '/OrderSummaryReport' });
    };

    loadOrderSummary(orderedDate) {
        let partialUrl = api.URL;
        fetch(partialUrl + 'OrderSummary/GetOrderSummary?OrderedDate='+ orderedDate)
            .then(res => res.json())
            .then(result => {
                this.setState({ rowData: result, loading: false });
            })
            .catch(err => console.log(err));
    }

    loadInterval() {
        let partialUrl = api.URL;
        fetch(partialUrl + 'OrderSummary/GetDisplayInterval/')
            .then(res => res.json())
            .then(result => {
                this.setState({ interval: Number(result + '000') });
            })
            .catch(err => console.log(err));
    }

    componentDidMount() {
        let loggedInUser = sessionStorage.getItem('loggedInUser');
        
        if(loggedInUser) {
            let orderedDateFormatRef = this.props.location.orderedDateFormatRef;
            let orderedDateTimeRef = this.props.location.orderedDateTimeRef;
            console.log(orderedDateTimeRef);
            this.setState({ loading: true, orderedDate: orderedDateTimeRef ? orderedDateTimeRef : null });
            this.loadOrderSummary(orderedDateFormatRef ? orderedDateFormatRef : '');
            this.loadInterval();
        } else {
            const { history } = this.props;
            if (history) history.push('/Home');
        }
    }

    render() {
        const { classes, mediaQuery } = this.props;
        const col3 = mediaQuery ? 3 : 12;
        
        return (
            <div>
                {this.state.loading ? (
                    <Loader />
                ) : (
                    <div>                        
                        <h2 className="header-text-color">Order Summary</h2>                        

                        <Grid container spacing={0}>
                            <Grid item xs={col3}>
                                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                    <KeyboardDatePicker fullWidth format="dd/MM/yyyy"
                                        id="dateOrder" label="Ordered Date"
                                        value={this.state.orderedDate}
                                        onChange={this.onDateChanged}
                                        KeyboardButtonProps={{
                                            'aria-label': 'change date',
                                        }}
                                    />
                                </MuiPickersUtilsProvider>
                            </Grid>
                        </Grid>
                        
                        <Grid container spacing={0}>
                            <Grid item xs={12}>
                                <div className="ag-theme-alpine" style={{ width: "100%", height: 550, marginTop: 10 }}>
                                    <AgGridReact
                                        columnDefs={this.state.columnDefs} rowData={this.state.rowData}
                                        onGridReady={this.onGridReady} defaultColDef={this.state.defaultColDef}
                                        frameworkComponents={this.state.frameworkComponents} context={this.state.context}
                                        pagination={true} gridOptions={this.gridOptions} paginationAutoPageSize={true}
                                        components={this.state.components} rowClassRules={this.state.rowClassRules} 
                                        singleClickEdit={true}
                                    />
                                </div>
                            </Grid>                        
                        </Grid>
                    </div>
                    )}
            </div>
        );
    }
}

export default withRouter(withStyles(useStyles)(withMediaQuery('(min-width:600px)')(OrderSummary)))