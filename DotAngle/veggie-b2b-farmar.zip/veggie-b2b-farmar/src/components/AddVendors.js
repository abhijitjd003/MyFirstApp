import React, { Component } from 'react';
import './common/Common.css';
import { Button, TextField, Grid, withStyles, FormControlLabel, Checkbox, useMediaQuery, MenuItem, Select } from '@material-ui/core';
import './common/CommonModal.css';
import { withRouter } from 'react-router-dom';
import Loader from './loader/Loader';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import ActionRenderer from './common/ActionRenderer';
import ConfirmModal from './modal/ConfirmModal';
import ErrorModal from './modal/ErrorModal';
import api from './common/APIValues';
import CreateIcon from '@material-ui/icons/Create';
import { useStyles } from './common/useStyles';

// const useStyles = theme => ({
//     leftIcon: {
//         marginRight: theme.spacing.unit,
//     },
//     topMargin: {
//         marginTop: 16,
//     },
//     root: {
//         fontSize: 12, height: '2.1rem', marginTop: 20,
//         backgroundColor: "#2b494b",
//         "&:hover": {
//             backgroundColor: "#2b494b"
//         },
//         "&:disabled": {
//             backgroundColor: "rgba(0, 0, 0, 0.12)"
//         },
//     },
// });

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);    
    return <Component mediaQuery={mediaQuery} {...props} />;
};

const validateForm = (errors) => {
    let valid = true;
    Object.keys(errors).map(function (e) {
        if (errors[e].length > 0) {
            valid = false;
        }        
    });
    return valid;
}

class AddVendors extends Component {
    constructor(props) {
        super(props);
        this.state = {
            typeId: 0, typeName: null, disable: false, address: null, contactName: null, mobileNo: null,
            errorMessage: null, loading: false, actionName: 'CREATE', userId: null, vendorId: 0, vendorTypes: [],
            errors: {
                typeId: '',
                contactName: '',
                mobileNo: '',
                address: '',
            },
            columnDefs: [                
                { headerName: 'Vendor Type', field: 'TypeName', cellStyle: { 'text-align': "center" }, flex: 2 },
                { headerName: 'Contact Name', field: 'ContactName', cellStyle: { 'text-align': "center" }, flex: 2 },
                { headerName: 'Mobile No', field: 'MobileNo', cellStyle: { 'text-align': "center" }, width: 130 },
                { headerName: 'Address', field: 'Address', cellStyle: { 'text-align': "center" }, flex: 2 },
                { headerName: 'Disable', field: 'IsDisable', cellStyle: { 'text-align': "center" }, width: 110 },
                { headerName: 'Created Date', field: 'CreatedDateTime', cellStyle: { 'text-align': "center" }, width: 145 },
                { headerName: 'Created User', field: 'CreatedUserId', cellStyle: { 'text-align': "center" }, width: 145 },
                { headerName: 'Actions', field: 'Actions', sorting: false, filter: false, cellRenderer: 'actionRenderer', 
                    cellStyle: { 'text-align': "center" }, width: 110 },
            ],
            context: { componentParent: this },
            frameworkComponents: { actionRenderer: ActionRenderer },
            rowData: [],
            defaultColDef: { width: 110, sortable: true, resizable: true, filter: true },
            rowClassRules: {
                'grid-row-even': function (params) { return params.node.rowIndex % 2 === 0; },
                'grid-row-odd': function (params) { return params.node.rowIndex % 2 !== 0; }
            },
        };

        this.onVendorTypeChanged = this.onVendorTypeChanged.bind(this);
    }

    validateAllInputs(){
        if(!this.state.contactName || this.state.typeId === 0 || !this.state.mobileNo || !this.state.address){
            return false;
        }
        else{
            return true;
        }
    }

    create = (event) => {
        event.preventDefault();
        if (validateForm(this.state.errors) && this.validateAllInputs()) {
            this.setState({ loading: true });
            let newVendor = {};
            newVendor.VendorId = this.state.vendorId;
            newVendor.TypeId = this.state.typeId;
            newVendor.ContactName = this.state.contactName;
            newVendor.MobileNo = this.state.mobileNo;
            newVendor.Address = this.state.address;
            newVendor.Disable = this.state.disable;
            newVendor.CreatedUserId = this.state.userId;
            this.createVendor(newVendor);
        } else {
            let errors = this.state.errors;
            if (this.state.typeId === 0) {
                errors.typeId = 'Select vendor type';
            }
            if (!this.state.contactName) {
                errors.contactName = 'Contact name is required';
            }
            if (!this.state.mobileNo) {
                errors.mobileNo = 'Mobile number is required';
            }
            if (!this.state.address) {
                errors.address = 'Address is required';
            }
            this.setState({ errors, errorMessage: null });
        }
    }

    loadVendors(){
        let partialUrl = api.URL;
        fetch(partialUrl + 'Vendor/GetVendors')
            .then(res => res.json())
            .then(result => this.setState({ rowData: result, loading: false }))
            .catch(err => console.log(err));
    }

    DeleteRecord(){
        this.setState({ loading: true })
        let VendorId = this.state.vendorId;
        let partialUrl = api.URL;
        fetch(partialUrl + 'Vendor/RemoveVendor?VendorId=' + VendorId, {
            method: 'POST',
            mode: 'cors'
        }).then(data => {
            this.loadVendors();
            this.setState({ loading: false })
        });
    }

    loadVendorTypes(){
        let partialUrl = api.URL;
        fetch(partialUrl + 'VendorType/GetValidVendorTypes')
            .then(res => res.json())
            .then(result => this.setState({ vendorTypes: result, loading: false }))
            .catch(err => console.log(err));
    }

    componentDidMount() {
        let loggedInUser = sessionStorage.getItem('loggedInUser');

        if(loggedInUser) {
            this.setState({ userId: loggedInUser, loading: true });
            this.loadVendorTypes();
            this.loadVendors();
        } else {
            const { history } = this.props;
            if (history) history.push('/Home');
        }
    }

    editGridRow = row => {
        this.setState({
            vendorId: row.VendorId,
            typeId: row.TypeId,
            contactName: row.ContactName,
            mobileNo: row.MobileNo,
            address: row.Address,
            disable: row.IsDisable === 'YES' ? true : false,
            actionName: 'UPDATE'
        })
    };

    showConfirmPopup = row => {
        this.setState({ vendorId: row.VendorId })
        this.refs.cnfrmModalComp.openModal();
    }

    createVendor(newVendor) {
        let partialUrl = api.URL;
        fetch(partialUrl + 'Vendor/CreateVendor', {
            method: 'POST',
            mode: 'cors',
            body: JSON.stringify(newVendor),
            headers: { 'Content-Type': 'application/json' }
        }).then((response) => response.json())
            .then((responseJson) => {
                if (responseJson) {
                    this.loadVendors();
                    this.setState({ 
                        loading: false, actionName: 'CREATE', typeId: 0, typeName: null, address: null, mobileNo: null, 
                        vendorId: null, contactName: null, disable: false
                    });
                } else {
                    this.setState({ 
                        loading: false, actionName: 'CREATE', typeId: 0, typeName: null, address: null, mobileNo: null, 
                        vendorId: null, contactName: null, disable: false
                    });
                    var errorMsg = 'Duplicate vendor found.';
                    this.refs.errModalComp.openModal(errorMsg);
                }
            })
    }

    handleChange = (event) => {
        event.preventDefault();
        const { name, value } = event.target;
        let errors = this.state.errors;

        switch (name) {
            case 'contactName':
                this.state.contactName = value;
                errors.contactName = value.length <= 0 ? 'Contact name is required' : '';
                break;
            case 'mobileNo':
                this.state.mobileNo = value;
                errors.mobileNo = value.length <= 0 ? 'Mobile number is required' : !Number(value) ? 'Mobile number is not valid' : '';
                break;
            case 'address':
                this.state.address = value;
                errors.address = value.length <= 0 ? 'Address is required' : '';
                break;            
            default:
                break;
        }
        this.setState({ errors, [name]: value });
    }

    _chkDeactivateChange = event => { this.setState({ disable: event.target.checked }); };

    onVendorTypeChanged(e) {
        let typeId = e.target.value; 
        this.setState({ typeId: typeId });
        if(typeId === 0){
            this.state.errors.typeId = 'Select vendor type';
        }else{
            this.state.errors.typeId = '';
        }
    };

    render() {
        const { classes, mediaQuery } = this.props;        
        const col3 = mediaQuery ? 3 : 12;
        const col6 = mediaQuery ? 6 : 12;
        const colsBtnL = mediaQuery ? 10 : 8;
        const colsBtnM = mediaQuery ? 2 : 4;

        let vendorTypes = this.state.vendorTypes.map((vendorType) =>
            <MenuItem value={vendorType.TypeId}>{vendorType.TypeName}</MenuItem>
        );
        
        return (
            <div>
                {this.state.loading ? (
                    <Loader />
                ) : (
                    <div>
                        <ErrorModal ref="errModalComp" />
                        <ConfirmModal ref="cnfrmModalComp" onClick={(e) => this.DeleteRecord(e)} />

                        <form onSubmit={this.loginToDashboard} noValidate>
                            <h2 className="header-text-color">Add Vendors</h2>
                            <Grid container spacing={3}>
                                <Grid item xs={col3}>
                                    <Select fullWidth id="ddlVendorType" value={this.state.typeId} className="selectTopMargin"
                                        onChange={ this.onVendorTypeChanged }>
                                        <MenuItem value={0}>Choose Vendor Type</MenuItem>
                                        {vendorTypes}
                                    </Select>
                                    {this.state.errors.typeId.length > 0 &&
                                        <span className='error'>{this.state.errors.typeId}</span>}
                                </Grid>                                
                                <Grid item xs={col3}>
                                    <TextField fullWidth required="true" name="mobileNo" id="txtMobileNo" 
                                        label="Mobile Number" InputLabelProps={{ shrink: true, style: { fontSize: 18 } }}
                                        onChange={this.handleChange} noValidate value={this.state.mobileNo} />
                                        {this.state.errors.mobileNo.length > 0 &&
                                            <span className='error'>{this.state.errors.mobileNo}</span>}                                   
                                </Grid>
                                <Grid item xs={col6}>
                                    <TextField fullWidth required="true" name="contactName" id="txtContactName" 
                                        label="Contact Name" InputLabelProps={{ shrink: true, style: { fontSize: 18 } }}
                                        onChange={this.handleChange} noValidate value={this.state.contactName} />
                                        {this.state.errors.contactName.length > 0 &&
                                            <span className='error'>{this.state.errors.contactName}</span>}                                   
                                </Grid>
                                <Grid item xs={12}>
                                    <TextField fullWidth required="true" name="address" id="txtAddress" 
                                        label="Address" InputLabelProps={{ shrink: true, style: { fontSize: 18 } }}
                                        onChange={this.handleChange} noValidate value={this.state.address} />
                                        {this.state.errors.address.length > 0 &&
                                            <span className='error'>{this.state.errors.address}</span>}                                   
                                </Grid>
                            </Grid>
                            <Grid container spacing={0}>
                                <Grid item xs={colsBtnL}>
                                    <FormControlLabel className={ classes.topMargin } control={
                                        <Checkbox id="chkDeactivate" value={true} name="chkDeactivate" color="primary" 
                                            checked={this.state.disable} onChange={ this._chkDeactivateChange } />
                                    } label="Disable" />
                                </Grid>
                                <Grid item xs={colsBtnM}>
                                    <Button fullWidth className={classes.root} variant="contained"
                                        color="primary" onClick={this.create}>
                                        <CreateIcon className={classes.leftIcon} />{ this.state.actionName }</Button>
                                </Grid>
                            </Grid>
                        </form>

                        <Grid container spacing={0}>
                            <Grid item xs={12}>
                                <div className="ag-theme-alpine" style={{ width: "100%", height: 425, marginTop: 5 }}>
                                    <AgGridReact
                                        columnDefs={this.state.columnDefs} rowData={this.state.rowData}
                                        onGridReady={this.onGridReady} defaultColDef={this.state.defaultColDef}
                                        frameworkComponents={this.state.frameworkComponents} context={this.state.context}
                                        pagination={true} gridOptions={this.gridOptions} paginationAutoPageSize={true}
                                        components={this.state.components} rowClassRules={this.state.rowClassRules} suppressClickEdit={true}
                                    />
                                </div>
                            </Grid>                        
                        </Grid>
                    </div>
                    )}
            </div>
        );
    }
}

export default withRouter(withStyles(useStyles)(withMediaQuery('(min-width:600px)')(AddVendors)))