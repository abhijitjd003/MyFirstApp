import React, { Component } from 'react';
import { Route } from 'react-router';
import Layout from './components/Layout';
import Products from './components/Products';
import Categories from './components/Categories';
import AddCustomers from './components/AddCustomers';
import ManageCustomers from './components/ManageCustomers';
import ManageOrders from './components/ManageOrders';
import UserManagement from './components/UserManagement';
import CreateOrders from './components/CreateOrders';
import OrderSummary from './components/OrderSummary';
import OrderSummaryByDate from './components/OrderSummaryByDate';
import ProductPriceHistory from './components/ProductPriceHistory';
import VendorTypes from './components/VendorTypes';
import AddVendors from './components/AddVendors';
import AddStocks from './components/AddStocks';
import GradeAStock from './components/GradeAStock';
import GradeBStock from './components/GradeBStock';
import Settings from './components/Settings';
import CratesDetails from './components/CratesDetails';
import GradeBStockOutstanding from './components/GradeBStockOutstanding';
import ViewOrderReport from './components/ViewOrderReport';
import OrderSummaryReport from './components/OrderSummaryReport';
import AssignRoutes from './components/AssignRoutes';
import ManagePayments from './components/ManagePayments';
import AssignRoutesReport from './components/AssignRoutesReport';
import OrderSummaryBreakup from './components/OrderSummaryBreakup';
import OrderProductSummary from './components/OrderProductSummary';
import SalesOfficerBoard from './components/SalesOfficerBoard';
import PushNotifications from './components/PushNotifications';
import CustomersOTP from './components/CustomersOTP';
import ProductSales from './components/ProductSales';
import CustomerOrders from './components/CustomerOrders';
import Orders from './components/Orders';
import Dashboard from './components/Dashboard';

export default class DefaultApp extends Component {
    static displayName = DefaultApp.name;

    render() {
        return (
            <Layout>
                <Route path='/Products' component={Products} />
                <Route path='/Categories' component={Categories} />
                <Route path='/AddCustomers' component={AddCustomers} />
                <Route path='/ManageCustomers' component={ManageCustomers} />
                <Route path='/CreateOrders' component={CreateOrders} />
                <Route path='/ManageOrders' component={ManageOrders} />
                <Route path='/OrderSummary' component={OrderSummary} />
                <Route path='/OrderSummaryByDate' component={OrderSummaryByDate} />                
                <Route path='/UserManagement' component={UserManagement} />
                <Route path='/ProductPriceHistory' component={ProductPriceHistory} />
                <Route path='/VendorTypes' component={VendorTypes} />
                <Route path='/AddVendors' component={AddVendors} />
                <Route path='/AddStocks' component={AddStocks} />
                <Route path='/GradeAStock' component={GradeAStock} />
                <Route path='/GradeBStock' component={GradeBStock} />
                <Route path='/Settings' component={Settings} />
                <Route path='/CratesDetails' component={CratesDetails} />
                <Route path='/GradeBStockOutstanding' component={GradeBStockOutstanding} />
                <Route path='/ViewOrderReport' component={ViewOrderReport} />
                <Route path='/OrderSummaryReport' component={OrderSummaryReport} />
                <Route path='/AssignRoutes' component={AssignRoutes} />
                <Route path='/ManagePayments' component={ManagePayments} />
                <Route path='/AssignRoutesReport' component={AssignRoutesReport} />
                <Route path='/OrderSummaryBreakup' component={OrderSummaryBreakup} />
                <Route path='/OrderProductSummary' component={OrderProductSummary} />
                <Route path='/SalesOfficerBoard' component={SalesOfficerBoard} />
                <Route path='/PushNotifications' component={PushNotifications} />
                <Route path='/CustomersOTP' component={CustomersOTP} />
                <Route path='/ProductSales' component={ProductSales} />
                <Route path='/CustomerOrders' component={CustomerOrders} />
                <Route path='/Orders' component={Orders} />
                <Route path='/Dashboard' component={Dashboard} />
            </Layout>
        );
    }
}
