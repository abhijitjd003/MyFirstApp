const express = require('express');
const crypto = require('crypto-js');
const router = express.Router();

router.get('/hyvorTalkSignon/:isLoggedIn/:userId/:name/:email', (req, res) => {
    inputParams = {
        userId: req.params.userId,
        name: req.params.name,
        email: req.params.email,
        isLoggedIn: req.params.isLoggedIn,
    }
    console.log(inputParams);
    const installationCode = hyvorTalkSignon(inputParams);
    res.json(installationCode);
})

module.exports = router;

function hyvorTalkSignon(inputParams) {
    const HYVOR_TALK_SSO_PRIVATE_KEY = '69eb5a765e4eef2df08eaab8e2f04b8c';
    const user = {};

    if(inputParams.isLoggedIn === 'true') {
        user.id = inputParams.userId;
        user.name = inputParams.name;
        user.email = inputParams.email;
        user.picture = '';
        user.url = '';
    };


    const userData = Buffer.from(JSON.stringify(user)).toString('base64');
    const hash = crypto.HmacSHA1(userData, HYVOR_TALK_SSO_PRIVATE_KEY).toString();

    return {
        userData,
        hash
    }
}