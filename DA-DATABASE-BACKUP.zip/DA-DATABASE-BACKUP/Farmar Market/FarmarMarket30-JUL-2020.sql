-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 182.50.133.79:3306
-- Generation Time: Jul 29, 2020 at 09:35 PM
-- Server version: 5.5.51-38.1-log
-- PHP Version: 7.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `FarmarMarket`
--
CREATE DATABASE IF NOT EXISTS `FarmarMarket` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `FarmarMarket`;

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `UspAddCustomer`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspAddCustomer` (IN `p_ShopId` INT, IN `p_ShopName` VARCHAR(50), IN `p_ContactPerson` VARCHAR(50), IN `p_MobileNo` BIGINT, IN `p_Email` VARCHAR(30), IN `p_Address` VARCHAR(100), IN `p_Location` VARCHAR(400), IN `p_GSTNo` VARCHAR(30), IN `p_ReferralCode` VARCHAR(20), IN `p_AlternateContactNo` BIGINT, IN `p_CreatedDateTime` DATETIME, IN `p_UpdatedDateTime` DATETIME, IN `p_UserId` VARCHAR(50), IN `p_ShopImage1` VARCHAR(200), IN `p_ShopImage2` VARCHAR(200), IN `p_ShopImage3` VARCHAR(200))  BEGIN
	IF p_ShopId = 0 THEN
    BEGIN
		SET @DuplicateShop := 0;
		SELECT @DuplicateShop := ShopId FROM ShopDetails
		WHERE MobileNo = p_MobileNo;
        
        IF @DuplicateShop = 0 THEN
        BEGIN
			INSERT INTO ShopDetails
			(				
				ShopName,
				Address,
                GSTNo,
                ReferralCode,
                MobileNo,
                Status,
                Location,
				CreatedDateTime,
				UpdatedDateTime,
                UpdatedUserId,
				CreatedUserId,				
                AlternateContactNo,
                Email,
                ContactPerson
			)
			SELECT
				p_ShopName,
				p_Address,
                p_GSTNo,
                p_ReferralCode,
                p_MobileNo,
                'InProgress',
                p_Location,
				p_CreatedDateTime,
				p_UpdatedDateTime,
                p_UserId,
				p_UserId,				
                p_AlternateContactNo,
                p_Email,
                p_ContactPerson;
			
            INSERT INTO ShopImages
            (
				Image1, 
                Image2, 
                Image3,
                ShopId
            )
            SELECT 
				p_ShopImage1,
                p_ShopImage2,
                p_ShopImage3,
                last_insert_id();
            
            UPDATE ShopImages
            SET Image1 = replace(Image1, 'shop_id', last_insert_id()),
				Image2 = replace(Image2, 'shop_id', last_insert_id()),
                Image3 = replace(Image3, 'shop_id', last_insert_id())
            WHERE ShopId = last_insert_id();
            
			SELECT 'success' Message, last_insert_id() ShopId;
		END;
        ELSE
        BEGIN
			SELECT 'error' Message;
        END;
        END IF;
	END;
    ELSE
    BEGIN		
        UPDATE ShopDetails
		SET ShopName = p_ShopName,
			Address = p_Address,
			GSTNo = p_GSTNo,
			ReferralCode = p_ReferralCode,
			MobileNo = p_MobileNo,			
			Location = p_Location,			
			UpdatedDateTime = p_UpdatedDateTime,
			UpdatedUserId = p_UserId,			
			AlternateContactNo = p_AlternateContactNo,
			Email = p_Email,
			ContactPerson = p_ContactPerson,
            Status = 'InProgress'
		WHERE ShopId = p_ShopId;
        
        UPDATE ShopImages
		SET Image1 = CASE WHEN p_ShopImage1 IS NULL OR p_ShopImage1 = '' 
				THEN Image1 ELSE p_ShopImage1 END,
			Image2 = CASE WHEN p_ShopImage2 IS NULL OR p_ShopImage2 = '' 
				THEN Image2 ELSE p_ShopImage2 END,
			Image3 =  CASE WHEN p_ShopImage3 IS NULL OR p_ShopImage3 = '' 
				THEN Image3 ELSE p_ShopImage3 END
		WHERE ShopId = p_ShopId;
        
        UPDATE ShopImages
		SET Image1 = replace(Image1, 'shop_id', p_ShopId),
			Image2 = replace(Image2, 'shop_id', p_ShopId),
			Image3 = replace(Image3, 'shop_id', p_ShopId)
		WHERE ShopId = p_ShopId;
        
        SELECT * FROM ShopImages
        WHERE ShopId = p_ShopId;
        
        SELECT 'success' Message;
    END;
    END IF;
END$$

DROP PROCEDURE IF EXISTS `UspApproveRejectDisableCustomer`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspApproveRejectDisableCustomer` (IN `p_ShopId` INT, IN `p_Status` VARCHAR(30), IN `p_UpdatedDateTime` DATETIME, IN `p_UserId` VARCHAR(50), IN `p_RejectReason` VARCHAR(100))  BEGIN
	UPDATE ShopDetails
    SET Status = p_Status,
		RejectedReason = p_RejectReason,
        UpdatedDateTime = p_UpdatedDateTime,
        UpdatedUserId = p_UserId
	WHERE ShopId = p_ShopId;
END$$

DROP PROCEDURE IF EXISTS `UspAssignRouteToCustomer`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspAssignRouteToCustomer` (IN `p_ShopId` INT, IN `p_RouteCategory` VARCHAR(30), IN `p_UpdatedDateTime` DATETIME, IN `p_UserId` VARCHAR(50))  BEGIN
	UPDATE ShopDetails
    SET Route = p_RouteCategory,
        UpdatedDateTime = p_UpdatedDateTime,
        UpdatedUserId = p_UserId
	WHERE ShopId = p_ShopId;
END$$

DROP PROCEDURE IF EXISTS `UspCreateOrders`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspCreateOrders` (IN `p_OrderNo` BIGINT, IN `p_PassCode` INT, IN `p_OrderedDateTime` DATETIME, IN `p_ShopId` INT, IN `p_UserId` VARCHAR(50))  BEGIN
	INSERT INTO Orders
    (
		OrderNo,
        PassCode,
        OrderedDateTime,
        ShopId,
        Status,
        CreatedUserId,
        UpdatedUserId,
        UpdatedDateTime,
        DeliveryDate,
        DeliveryTime
    )
	SELECT
		p_OrderNo,
        p_PassCode,
        p_OrderedDateTime,
        p_ShopId,
        'Initiated',
        p_UserId,
        p_UserId,
        p_OrderedDateTime,
        DATE_ADD(now(), INTERVAL 2190 MINUTE),
        '07:00 AM - 10:00 AM';
END$$

DROP PROCEDURE IF EXISTS `UspCreateProduct`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspCreateProduct` (IN `p_ProductId` INT, IN `p_CategoryId` INT, IN `p_ProductName` VARCHAR(100), IN `p_RatePerKg` DECIMAL(10,2), IN `p_MinPurchaseQuantity` DECIMAL(10,2), IN `p_CreatedDateTime` DATETIME, IN `p_UpdatedDateTime` DATETIME, IN `p_UserId` VARCHAR(50), IN `p_ProductImagePath` VARCHAR(100), IN `p_UnitType` VARCHAR(10))  BEGIN
	SET @ProductId := 0;
    SELECT @ProductId := ProductId FROM Products
    WHERE ProductId = p_ProductId AND RatePerKg = p_RatePerKg;
    
	IF p_ProductId = 0 THEN
    BEGIN
		SET @DuplicateProduct := 0;
		SELECT @DuplicateProduct := ProductId FROM Products
		WHERE CategoryId = p_CategoryId AND Name = p_ProductName;
        
        IF @DuplicateProduct = 0 THEN
        BEGIN
			INSERT INTO Products
			(
				CategoryId,
				Name,
				RatePerKG,
				MinPurchaseQuantity,
				CreatedDateTime,
				UpdatedDateTime,
				CreatedUserId,
				UpdateduserId,
                Deactivate,                
                ProductImagePath,
                UnitType
			)
			SELECT
				p_CategoryId,
				p_ProductName,
				p_RatePerKg,
				p_MinPurchaseQuantity,
				p_CreatedDateTime,
				p_UpdatedDateTime,
				p_UserId,
				p_UserId,
                'NO',
                p_ProductImagePath,
                p_UnitType;
                
			SELECT 'success' Message;
		END;
        ELSE
        BEGIN
			SELECT 'error' Message;
        END;
        END IF;
	END;
    ELSE
    BEGIN
		IF @ProductId = 0 THEN
        BEGIN
			INSERT INTO ProductHistory
			(
				ProductId,
				CategoryId,
				Name,
				RatePerKG,
				MinPurchaseQuantity,
				CreatedDateTime,
				UpdatedDateTime,
				CreatedUserId,
				UpdatedUserId,
                StatusCode
			)
			SELECT
				ProductId,
				CategoryId,
				Name,
				RatePerKg,
				MinPurchaseQuantity,
				CreatedDateTime,
				p_UpdatedDateTime,
				CreatedUserId,
				p_UserId,
                'U'
			FROM Products
            WHERE ProductId = p_ProductId;
        END;        
        END IF;
        UPDATE Products
		SET CategoryId = p_CategoryId,
			Name = p_ProductName,
			RatePerKg = p_RatePerKg,
			MinPurchaseQuantity = p_MinPurchaseQuantity,
			UpdatedDateTime = p_UpdatedDateTime,
			UpdateduserId = p_UserId,            
            UnitType = p_UnitType,
            ProductImagePath = CASE WHEN p_ProductImagePath IS NULL OR p_ProductImagePath = '' 
				THEN ProductImagePath ELSE p_ProductImagePath END
		WHERE ProductId = p_ProductId;
        
        SELECT 'success' Message, ProductImagePath
        FROM Products
        WHERE ProductId = p_ProductId;
    END;
    END IF;
END$$

DROP PROCEDURE IF EXISTS `UspCreateProductCategory`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspCreateProductCategory` (IN `p_CategoryId` INT, IN `p_CategoryName` VARCHAR(50), IN `p_CreatedDateTime` DATETIME, IN `p_Deactivate` TINYINT, IN `p_UserId` VARCHAR(50))  BEGIN
	IF p_CategoryId = 0 THEN
    BEGIN
		SET @DuplicateCategory := 0;
		SELECT @DuplicateCategory := CategoryId FROM ProductCategories
		WHERE Name = p_CategoryName;
        
        IF @DuplicateCategory = 0 THEN
        BEGIN
			INSERT INTO ProductCategories
			(				
				Name,				
				CreatedDateTime,				
				CreatedUserId,				
                Deactivate
			)
			SELECT
				p_CategoryName,				
				p_CreatedDateTime,				
				p_UserId,
                p_Deactivate;
                
			SELECT 'success' Message;
		END;
        ELSE
        BEGIN
			SELECT 'error' Message;
        END;
        END IF;
	END;
    ELSE
    BEGIN		
        UPDATE ProductCategories
		SET Name = p_CategoryName,			
            Deactivate = p_Deactivate,
            CreatedDateTime = p_CreatedDateTime,
            CreatedUserId = p_UserId
		WHERE CategoryId = p_CategoryId;
        
        SELECT 'success' Message;
    END;
    END IF;
END$$

DROP PROCEDURE IF EXISTS `UspCreateStock`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspCreateStock` (IN `p_VendorId` INT, IN `p_StockId` INT, IN `p_ProductId` INT, IN `p_TotalWeight` DECIMAL(10,2), IN `p_GradeAWeight` DECIMAL(10,2), IN `p_GradeBWeight` DECIMAL(10,2), IN `p_CreatedDateTime` DATETIME, IN `p_DumpWeight` DECIMAL(10,2), IN `p_CreatedUserId` VARCHAR(50))  BEGIN
	IF p_StockId = 0 THEN
    BEGIN
		SET @DuplicateStock := 0;
		SELECT @DuplicateStock := StockId FROM Stocks
		WHERE VendorId = p_VendorId AND ProductId = p_ProductId 
			AND DATE(CreatedDateTime) = DATE(p_CreatedDateTime);
        
        IF @DuplicateStock = 0 THEN
        BEGIN
			INSERT INTO Stocks
			(				
				VendorId,
                ProductId,
                TotalWeight,
                GradeAWeight,
                GradeBWeight,
				CreatedDateTime,
				CreatedUserId,				
                DumpWeight
			)
			SELECT
				p_VendorId,	
                p_ProductId,
                p_TotalWeight,
                p_GradeAWeight,	
                p_GradeBWeight,
				p_CreatedDateTime,				
				p_CreatedUserId,
                p_DumpWeight;
                
			SELECT 'success' Message;
            		
			UPDATE Products
			SET TotalStock = TotalStock + p_GradeAWeight,
				GradeBStock = GradeBStock + p_GradeBWeight
			WHERE ProductId = p_ProductId;
		END;
        ELSE
        BEGIN
			SELECT 'error' Message;
        END;
        END IF;
	END;
    ELSE
    BEGIN
		SET @PrevGradeAWeight := 0, @PrevGradeBWeight := 0;
        SELECT @PrevGradeAWeight := GradeAWeight, @PrevGradeBWeight := GradeBWeight
        FROM Stocks
        WHERE StockId = p_StockId;
        
        UPDATE Stocks
		SET VendorId = p_VendorId,
			ProductId = p_ProductId,
			TotalWeight = p_TotalWeight,
            GradeAWeight = p_GradeAWeight,
            GradeBWeight = p_GradeBWeight,
            DumpWeight = p_DumpWeight,
            CreatedDateTime = p_CreatedDateTime,
            CreatedUserId = p_CreatedUserId
		WHERE StockId = p_StockId;
        
        SELECT 'success' Message;
        
        UPDATE Products
		SET TotalStock = TotalStock + (p_GradeAWeight - @PrevGradeAWeight),
			GradeBStock = GradeBStock + (p_GradeBWeight - @PrevGradeBWeight)
		WHERE ProductId = p_ProductId;
    END;
    END IF;
END$$

DROP PROCEDURE IF EXISTS `UspCreateUser`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspCreateUser` (IN `p_UserId` INT, IN `p_FullName` VARCHAR(50), IN `p_Email` VARCHAR(30), IN `p_MobileNo` BIGINT, IN `p_Role` VARCHAR(20), IN `p_Password` VARCHAR(20))  BEGIN
	IF p_UserId = 0 THEN
    BEGIN
		SET @DuplicateUser := 0;
		SELECT @DuplicateUser := UserId FROM Users
		WHERE MobileNo = p_MobileNo AND Role = p_Role;
        
        IF @DuplicateUser = 0 THEN
        BEGIN
			INSERT INTO Users
			(				
				FullName,				
				MobileNo,				
				Email,				
                Password,
                Role
			)
			SELECT
				p_FullName,				
				p_MobileNo,				
				p_Email,
                p_Password,
                p_Role;
                
			SELECT 'success' Message;
		END;
        ELSE
        BEGIN
			SELECT 'error' Message;
        END;
        END IF;
	END;
    ELSE
    BEGIN		
        UPDATE Users
		SET FullName = p_FullName,			
            MobileNo = p_MobileNo,
            Email = p_Email,
            Password = p_Password,
            Role = p_Role
		WHERE UserId = p_UserId;
        
        SELECT 'success' Message;
    END;
    END IF;
END$$

DROP PROCEDURE IF EXISTS `UspCreateVendor`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspCreateVendor` (IN `p_VendorId` INT, IN `p_TypeId` INT, IN `p_ContactName` VARCHAR(50), IN `p_MobileNo` BIGINT, IN `p_Address` VARCHAR(200), IN `p_CreatedDateTime` DATETIME, IN `p_Disable` TINYINT, IN `p_CreatedUserId` VARCHAR(50))  BEGIN
	IF p_VendorId = 0 THEN
    BEGIN
		SET @DuplicateVendor := 0;
		SELECT @DuplicateVendor := VendorId FROM Vendors
		WHERE MobileNo = p_MobileNo AND TypeId = p_TypeId;
        
        IF @DuplicateVendor = 0 THEN
        BEGIN
			INSERT INTO Vendors
			(				
				TypeId,
                ContactName,
                MobileNo,
                Address,
				CreatedDateTime,				
				CreatedUserId,				
                Disable
			)
			SELECT
				p_TypeId,	
                p_ContactName,
                p_MobileNo,	
                p_Address,
				p_CreatedDateTime,				
				p_CreatedUserId,
                p_Disable;
                
			SELECT 'success' Message;
		END;
        ELSE
        BEGIN
			SELECT 'error' Message;
        END;
        END IF;
	END;
    ELSE
    BEGIN		
        UPDATE Vendors
		SET TypeId = p_TypeId,
			ContactName = p_ContactName,
            MobileNo = p_MobileNo,
            Address = p_Address,
            Disable = p_Disable,
            CreatedDateTime = p_CreatedDateTime,
            CreatedUserId = p_CreatedUserId
		WHERE VendorId = p_VendorId;
        
        SELECT 'success' Message;
    END;
    END IF;
END$$

DROP PROCEDURE IF EXISTS `UspCreateVendorType`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspCreateVendorType` (IN `p_TypeId` INT, IN `p_TypeName` VARCHAR(50), IN `p_Description` VARCHAR(1024), IN `p_CreatedDateTime` DATETIME, IN `p_Disable` TINYINT, IN `p_CreatedUserId` VARCHAR(50))  BEGIN
	IF p_TypeId = 0 THEN
    BEGIN
		SET @DuplicateType := 0;
		SELECT @DuplicateType := TypeId FROM VendorTypes
		WHERE TypeName = p_TypeName;
        
        IF @DuplicateType = 0 THEN
        BEGIN
			INSERT INTO VendorTypes
			(				
				TypeName,
                Description,
				CreatedDateTime,				
				CreatedUserId,				
                Disable
			)
			SELECT
				p_TypeName,	
                p_Description,
				p_CreatedDateTime,				
				p_CreatedUserId,
                p_Disable;
                
			SELECT 'success' Message;
		END;
        ELSE
        BEGIN
			SELECT 'error' Message;
        END;
        END IF;
	END;
    ELSE
    BEGIN		
        UPDATE VendorTypes
		SET TypeName = p_TypeName,			
            Disable = p_Disable,
            Description = p_Description,
            CreatedDateTime = p_CreatedDateTime,
            CreatedUserId = p_CreatedUserId
		WHERE TypeId = p_TypeId;
        
        SELECT 'success' Message;
    END;
    END IF;
END$$

DROP PROCEDURE IF EXISTS `UspDeleteProduct`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspDeleteProduct` (IN `p_ProductId` INT, IN `p_UpdatedDateTime` DATETIME, IN `p_UserId` VARCHAR(50))  BEGIN
	INSERT INTO ProductHistory
	(
		ProductId,
		CategoryId,
		Name,
		RatePerKG,
		MinPurchaseQuantity,
		CreatedDateTime,
		UpdatedDateTime,
		CreatedUserId,
		UpdateduserId,
		StatusCode,
        TotalStock
	)
	SELECT
		ProductId,
		CategoryId,
		Name,
		RatePerKg,
		MinPurchaseQuantity,
		CreatedDateTime,
		p_UpdatedDateTime,
		CreatedUserId,
		p_UserId,
		'D',
        TotalStock
	FROM Products
	WHERE ProductId = p_ProductId;
    
    DELETE FROM Products WHERE ProductId = p_ProductId;
END$$

DROP PROCEDURE IF EXISTS `UspDeleteProductCategory`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspDeleteProductCategory` (IN `p_CategoryId` INT)  BEGIN
	DELETE FROM ProductCategories WHERE CategoryId = p_CategoryId;
END$$

DROP PROCEDURE IF EXISTS `UspDeleteStock`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspDeleteStock` (IN `p_StockId` INT)  BEGIN
	DELETE FROM Stocks
    WHERE StockId = p_StockId;
END$$

DROP PROCEDURE IF EXISTS `UspDeleteUser`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspDeleteUser` (IN `p_UserId` INT)  BEGIN
	DELETE FROM Users WHERE UserId = p_UserId;
END$$

DROP PROCEDURE IF EXISTS `UspDeleteVendor`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspDeleteVendor` (IN `p_VendorId` INT)  BEGIN
	DELETE FROM Vendors
    WHERE VendorId = p_VendorId;
END$$

DROP PROCEDURE IF EXISTS `UspDeleteVendorType`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspDeleteVendorType` (IN `p_TypeId` INT)  BEGIN
	DELETE FROM VendorTypes
    WHERE TypeId = p_TypeId;
END$$

DROP PROCEDURE IF EXISTS `UspGetCategories`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetCategories` ()  BEGIN
	SELECT CategoryId, Name, Deactivate, DATE_FORMAT(CreatedDateTime, "%d/%m/%Y") CreatedDateTime,
		CreatedUserId
    FROM ProductCategories;
END$$

DROP PROCEDURE IF EXISTS `UspGetCratesDetails`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetCratesDetails` (IN `p_OrderedDate` VARCHAR(20), IN `p_ProductId` INT)  BEGIN
	SELECT SUM(Weight) TotalWeight, P.Name ProductName, P.ProductImagePath,
		CASE WHEN FLOOR(SUM(Weight)/20) >= 1 THEN FLOOR(SUM(Weight)/20) ELSE 0 END Crates20, 
        CASE WHEN FLOOR((SUM(Weight)%20)/10) >= 1 THEN FLOOR((SUM(Weight)%20)/10) ELSE 0 END Crates10,         
		CASE WHEN ((SUM(Weight)%20)%10) < 6 AND ((SUM(Weight)%20)%10) > 0 THEN 1
			 WHEN ((SUM(Weight)%20)%10) < 10 AND ((SUM(Weight)%20)%10) > 5 THEN 2
        ELSE 0 END Crates5
	FROM OrderProducts OP
    INNER JOIN Products P ON P.ProductId = OP.ProductId
	INNER JOIN Orders O ON OP.OrderNo = O.OrderNo
    WHERE DATE_FORMAT(OrderedDateTime, "%d/%m/%Y") = p_OrderedDate
		AND OP.ProductId = p_ProductId
	GROUP BY OP.ProductId, DATE(OrderedDateTime);
END$$

DROP PROCEDURE IF EXISTS `UspGetCustomer`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetCustomer` (IN `p_ShopId` INT)  BEGIN
	SET @OrderedDate := '';
    SET @Outstanding := 0;
    
	SELECT @OrderedDate := DATE_FORMAT(MAX(OrderedDateTime), "%d/%m/%Y") OrderedDate
	FROM Orders
    WHERE ShopId = p_ShopId;
    
    SELECT @Outstanding := SUM(OP.PricePerKg) Outstanding
	FROM Orders O
    INNER JOIN OrderProducts OP ON OP.OrderNo = O.OrderNo
    WHERE ShopId = p_ShopId AND PaymentStatus = 'Pending';
    
	SELECT *, IFNULL(@OrderedDate,'') LastOrderedDate, IFNULL(@Outstanding,0) Outstanding 
    FROM ShopDetails
    WHERE ShopId = p_ShopId;
END$$

DROP PROCEDURE IF EXISTS `UspGetCustomers`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetCustomers` (IN `p_Status` VARCHAR(30))  BEGIN
	SELECT ShopId, ShopName, Address, GSTNo, ReferralCode, MobileNo, Status, RejectedReason,
		Location, DATE_FORMAT(UpdatedDateTime, "%d/%m/%Y") UpdatedDateTime, UpdatedUserId, 
        AlternateContactNo, Email, ContactPerson, Route
    FROM ShopDetails
    WHERE Status = p_Status
    ORDER BY UpdatedDateTime DESC;
END$$

DROP PROCEDURE IF EXISTS `UspGetDeliveryUsers`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetDeliveryUsers` ()  BEGIN
	SELECT 0 UserId, 'Choose Delivery Person' FullName
    UNION
	SELECT UserId, FullName FROM Users
    WHERE Role = 'Delivery';
END$$

DROP PROCEDURE IF EXISTS `UspGetGradeBStocks`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetGradeBStocks` ()  BEGIN
	SELECT Name ProductName, GradeBStock, Deactivate FROM Products
    ORDER BY Name;
END$$

DROP PROCEDURE IF EXISTS `UspGetOrderPickupDetails`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetOrderPickupDetails` ()  BEGIN
	SELECT * FROM OrderPickupDetails;
END$$

DROP PROCEDURE IF EXISTS `UspGetOrderProducts`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetOrderProducts` (IN `p_OrderNo` BIGINT)  BEGIN
	SELECT PricePerKg * Weight TotalPrice, Weight TotalWeight, Name ProductName, OP.ProductId
		, PricePerKg
	FROM OrderProducts OP
    INNER JOIN Products P ON P.ProductId = OP.ProductId
    WHERE OrderNo = p_OrderNo;
    
    SELECT O.OrderNo, SD.ShopName, O.Status, OrderedDateTime, DATE_FORMAT(DeliveryDate, "%d/%m/%Y") DeliveryDate
		, DeliveryTime, OverallTotalPrice, OverallTotalWeight, O.PaymentStatus
    FROM Orders O
    INNER JOIN ShopDetails SD ON SD.ShopId = O.ShopId
    INNER JOIN (
		SELECT SUM(PricePerKg * Weight) OverallTotalPrice, SUM(Weight) OverallTotalWeight, OrderNo
        FROM OrderProducts
        GROUP BY OrderNo
    ) OP ON OP.OrderNo = O.OrderNo    
    WHERE O.OrderNo = p_OrderNo;
    
    SELECT * FROM OrderPickupDetails;
END$$

DROP PROCEDURE IF EXISTS `UspGetOrders`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetOrders` (IN `p_ShopId` INT)  BEGIN
	SELECT O.OrderNo, SD.ShopName, PassCode, O.Status, SD.ShopId,
		DATE_FORMAT(OrderedDateTime, "%d/%m/%Y %h:%i:%s %p") OrderedDateTime,
		DATE_FORMAT(DeliveryDate, "%d/%m/%Y") DeliveryDate, DeliveryTime,
		OP.TotalPrice, OP.TotalWeight, U.FullName DeliveryUser, O.PaymentStatus, 
        DATE_FORMAT(OrderedDateTime, "%d/%m/%Y") OrderedDate, O.UpdatedUserId
    FROM Orders O
    INNER JOIN ShopDetails SD ON SD.ShopId = O.ShopId
    INNER JOIN (
		SELECT SUM(PricePerKg * Weight) TotalPrice, SUM(Weight) TotalWeight, OrderNo
        FROM OrderProducts
        GROUP BY OrderNo
    ) OP ON OP.OrderNo = O.OrderNo
    LEFT JOIN Users U ON U.UserId = O.DeliveryUserId
    WHERE SD.ShopId = CASE WHEN p_ShopId = 0 THEN SD.ShopId ELSE p_ShopId END
    ORDER BY OrderedDateTime DESC;
    
    SELECT IFNULL(SUM(PricePerKg * Weight), 0) TotalPrice
    FROM Orders O 
    INNER JOIN OrderProducts OP ON OP.OrderNo = O.OrderNo
    WHERE ShopId = p_ShopId AND PaymentStatus = 'Completed';
    
    SELECT IFNULL(SUM(PricePerKg * Weight), 0) TotalOutstanding
    FROM Orders O
    INNER JOIN OrderProducts OP ON OP.OrderNo = O.OrderNo
    WHERE ShopId = p_ShopId AND PaymentStatus = 'Pending';
END$$

DROP PROCEDURE IF EXISTS `UspGetOrderSummary`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetOrderSummary` ()  BEGIN
	CREATE TEMPORARY TABLE OrderSummary
    (
		OrderedDate DATE NULL,
		TotalVendorsOrdered INT NULL,
        TotalOrders INT NULL,
        TotalVegetables INT NULL,
        TotalWeight DECIMAL(10,2) NULL,
        TotalPieces INT NULL,
        TotalPrice DECIMAL(10.2) NULL
	);
	
    INSERT INTO OrderSummary (OrderedDate)
	SELECT DISTINCT DATE(OrderedDateTime) OrderedDate
    FROM Orders;
    
    UPDATE OrderSummary OS
    LEFT JOIN (
		SELECT DISTINCT COUNT(ShopId) TotalVendorsOrdered, DATE(OrderedDateTime) OrderedDate
        FROM Orders
		GROUP BY DATE(OrderedDateTime)
    ) O ON O.OrderedDate = OS.OrderedDate
    SET OS.TotalVendorsOrdered = O.TotalVendorsOrdered;
    
    UPDATE OrderSummary OS
    LEFT JOIN (
		SELECT DISTINCT COUNT(OrderNo) TotalOrders, DATE(OrderedDateTime) OrderedDate
        FROM Orders
		GROUP BY DATE(OrderedDateTime)
    ) O ON O.OrderedDate = OS.OrderedDate
    SET OS.TotalOrders = O.TotalOrders;
    
    UPDATE OrderSummary OS
    LEFT JOIN (
		SELECT DISTINCT COUNT(ProductId) TotalVegetables, DATE(OrderedDateTime) OrderedDate
        FROM Orders O
        INNER JOIN OrderProducts OP ON OP.OrderNo = O.OrderNo
		GROUP BY DATE(OrderedDateTime)
    ) O ON O.OrderedDate = OS.OrderedDate
    SET OS.TotalVegetables = O.TotalVegetables;
    
    UPDATE OrderSummary OS
    LEFT JOIN (
		SELECT DISTINCT SUM(Weight) TotalWeight, DATE(OrderedDateTime) OrderedDate
        FROM Orders O
        INNER JOIN OrderProducts OP ON OP.OrderNo = O.OrderNo
        INNER JOIN Products P ON P.ProductId = OP.ProductId AND P.UnitType = 'KG'
        WHERE P.UnitType = 'KG'
		GROUP BY DATE(OrderedDateTime)
    ) O ON O.OrderedDate = OS.OrderedDate
    SET OS.TotalWeight = O.TotalWeight;
    
	UPDATE OrderSummary OS
    LEFT JOIN (
		SELECT DISTINCT SUM(Weight) TotalPieces, DATE(OrderedDateTime) OrderedDate
        FROM Orders O
        INNER JOIN OrderProducts OP ON OP.OrderNo = O.OrderNo
        INNER JOIN Products P ON P.ProductId = OP.ProductId AND P.UnitType = 'Piece'
        WHERE P.UnitType = 'Piece'
		GROUP BY DATE(OrderedDateTime)
    ) O ON O.OrderedDate = OS.OrderedDate
    SET OS.TotalPieces = O.TotalPieces;
    
    UPDATE OrderSummary OS
    LEFT JOIN (
		SELECT DISTINCT SUM(PricePerKg * Weight) TotalPrice, DATE(OrderedDateTime) OrderedDate
        FROM Orders O
        INNER JOIN OrderProducts OP ON OP.OrderNo = O.OrderNo
		GROUP BY DATE(OrderedDateTime)
    ) O ON O.OrderedDate = OS.OrderedDate
    SET OS.TotalPrice = O.TotalPrice;
    
    SELECT DATE_FORMAT(OrderedDate, "%d/%m/%Y") OrderedDate, 
		CASE WHEN TotalVendorsOrdered IS NULL THEN 0 ELSE TotalVendorsOrdered END TotalVendorsOrdered, 
        CASE WHEN TotalOrders IS NULL THEN 0 ELSE TotalOrders END TotalOrders,
		CASE WHEN TotalPrice IS NULL THEN 0 ELSE TotalPrice END TotalPrice, 
        CASE WHEN TotalWeight IS NULL THEN 0 ELSE TotalWeight END TotalWeight, 
        CASE WHEN TotalVegetables IS NULL THEN 0 ELSE TotalVegetables END TotalVegetables, 
        CASE WHEN TotalPieces IS NULL THEN 0 ELSE TotalPieces END TotalPieces
    FROM OrderSummary
    ORDER BY OrderedDate DESC;
    
    DROP TABLE OrderSummary;
END$$

DROP PROCEDURE IF EXISTS `UspGetOrderTime`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetOrderTime` ()  BEGIN
	SELECT * FROM OrderTime;
END$$

DROP PROCEDURE IF EXISTS `UspGetProductCategories`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetProductCategories` ()  BEGIN
	SELECT 0 CategoryId, 'Choose Category' Name
    UNION
	SELECT CategoryId, Name 
    FROM ProductCategories
    WHERE Deactivate = 0 OR Deactivate IS NULL;
END$$

DROP PROCEDURE IF EXISTS `UspGetProducts`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetProducts` ()  BEGIN
	SELECT P.CategoryId, PC.Name CategoryName, P.Name ProductName, RatePerKg, MinPurchaseQuantity, 
		DATE_FORMAT(UpdatedDateTime, "%d/%m/%Y %h:%i:%s %p") UpdatedDateTime, P.ProductId, UpdatedUserId, 
        P.Deactivate, TotalStock, ProductImagePath, UnitType
    FROM Products P
    INNER JOIN ProductCategories PC ON P.CategoryId = PC.CategoryId
    ORDER BY P.Name;
END$$

DROP PROCEDURE IF EXISTS `UspGetProductsHistory`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetProductsHistory` (IN `p_UpdatedDate` VARCHAR(20))  BEGIN
	SELECT H1.Name ProductName, H1.RatePerKg, DATE_FORMAT(UpdatedDateTime, "%d/%m/%Y") UpdatedDate 
	FROM ProductHistory H1
	INNER JOIN (
		SELECT Name, MAX(UpdatedDateTime) UpdatedDate
		FROM ProductHistory
		GROUP BY Name, DATE(UpdatedDateTime)
	) H2 ON H1.Name = H2.Name AND H2.UpdatedDate = H1.UpdatedDateTime
    WHERE DATE_FORMAT(UpdatedDateTime, "%d/%m/%Y") = CASE WHEN p_UpdatedDate IS NULL OR p_UpdatedDate = ''
		THEN DATE_FORMAT(UpdatedDateTime, "%d/%m/%Y") ELSE p_UpdatedDate END
	ORDER BY DATE(UpdatedDateTime) DESC;
END$$

DROP PROCEDURE IF EXISTS `UspGetRemovedGradeAStocks`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetRemovedGradeAStocks` ()  BEGIN
	SELECT ProductName, Weight, ReasonType, RemovedUserId, 
		DATE_FORMAT(RemovedDateTime, "%d/%m/%Y") RemovedDateTime
    FROM RemovedGradeAStock;
END$$

DROP PROCEDURE IF EXISTS `UspGetRemovedGradeBStocks`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetRemovedGradeBStocks` ()  BEGIN
	SELECT ProductName, Weight, BuyerName, RemovedUserId, 
		DATE_FORMAT(RemovedDateTime, "%d/%m/%Y") RemovedDateTime
    FROM RemovedGradeBStock;
END$$

DROP PROCEDURE IF EXISTS `UspGetRoutes`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetRoutes` ()  BEGIN
	SELECT '0' RouteCategory, 'Choose Route' Route
    UNION
	SELECT RouteCategory, RouteCategory Route FROM Routes;
END$$

DROP PROCEDURE IF EXISTS `UspGetStocks`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetStocks` ()  BEGIN
	SELECT StockId, S.VendorId, ContactName VendorName, S.ProductId, Name ProductName, TotalWeight,
		GradeAWeight, GradeBWeight, DumpWeight, DATE_FORMAT(S.CreatedDateTime, "%d/%m/%Y") CreatedDateTime,
		S.CreatedUserId
    FROM Stocks S
    INNER JOIN Vendors V ON V.VendorId = S.VendorId
    INNER JOIN Products P ON P.ProductId = S.ProductId
    ORDER BY S.CreatedDateTime DESC;
END$$

DROP PROCEDURE IF EXISTS `UspGetTotalWeightPerProduct`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetTotalWeightPerProduct` (IN `p_OrderedDate` VARCHAR(20))  BEGIN
    SELECT SUM(Weight) TotalWeight, P.Name ProductName, P.TotalStock, 
		(P.TotalStock - SUM(Weight)) Indent, OP.ProductId,
		DATE_FORMAT(OrderedDateTime, "%d/%m/%Y") OrderedDateTime
	FROM OrderProducts OP
    INNER JOIN Products P ON P.ProductId = OP.ProductId
	INNER JOIN Orders O ON OP.OrderNo = O.OrderNo
    WHERE DATE_FORMAT(OrderedDateTime, "%d/%m/%Y") = p_OrderedDate
	GROUP BY OP.ProductId, DATE(OrderedDateTime);
END$$

DROP PROCEDURE IF EXISTS `UspGetUsers`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetUsers` ()  BEGIN
	SELECT * FROM Users;
END$$

DROP PROCEDURE IF EXISTS `UspGetVendors`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetVendors` ()  BEGIN
	SELECT VendorId, V.TypeId, TypeName, V.Disable, DATE_FORMAT(V.CreatedDateTime, "%d/%m/%Y") CreatedDateTime,
		V.CreatedUserId, Address, ContactName, MobileNo
    FROM Vendors V
    INNER JOIN VendorTypes VT ON V.TypeId = VT.TypeId
    ORDER BY ContactName;
END$$

DROP PROCEDURE IF EXISTS `UspGetVendorTypes`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspGetVendorTypes` ()  BEGIN
	SELECT TypeId, TypeName, Disable, DATE_FORMAT(CreatedDateTime, "%d/%m/%Y") CreatedDateTime,
		CreatedUserId, Description
    FROM VendorTypes
    ORDER BY TypeName;
END$$

DROP PROCEDURE IF EXISTS `UspRemoveGradeAStock`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspRemoveGradeAStock` (IN `p_ProductId` INT, IN `p_TotalWeight` DECIMAL(10,2), IN `p_ReasonType` VARCHAR(50), IN `p_CreatedDateTime` DATETIME, IN `p_CreatedUserId` VARCHAR(50))  BEGIN
	SET @AvaialableStock := 0;
	SELECT @AvaialableStock := ProductId FROM Products
	WHERE ProductId = p_ProductId;
	
    IF @AvaialableStock >= p_TotalWeight THEN
    BEGIN
		INSERT INTO RemovedGradeAStock
		(
			ProductName,
			Weight,
			ReasonType,
			RemovedDateTime,
			RemovedUserId
		)
		SELECT
			(SELECT Name FROM Products WHERE ProductId = p_ProductId),
			p_TotalWeight,
			p_ReasonType,
			p_CreatedDateTime,
			p_CreatedUserId;
            
		UPDATE Products
		SET TotalStock = TotalStock - p_TotalWeight
		WHERE ProductId = p_ProductId;
		
        SELECT 'success' Message;
	END;
    ELSE
    BEGIN
		SELECT 'error' Message;
    END;
    END IF;
END$$

DROP PROCEDURE IF EXISTS `UspRemoveGradeBStock`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspRemoveGradeBStock` (IN `p_ProductId` INT, IN `p_TotalWeight` DECIMAL(10,2), IN `p_BuyerName` VARCHAR(50), IN `p_CreatedDateTime` DATETIME, IN `p_CreatedUserId` VARCHAR(50))  BEGIN
		INSERT INTO RemovedGradeBStock
		(
			ProductName,
			Weight,
			BuyerName,
			RemovedDateTime,
			RemovedUserId
		)
		SELECT
			(SELECT Name FROM Products WHERE ProductId = p_ProductId),
			p_TotalWeight,
			p_BuyerName,
			p_CreatedDateTime,
			p_CreatedUserId;
            
		UPDATE Products
		SET GradeBStock = GradeBStock - p_TotalWeight
		WHERE ProductId = p_ProductId;
		
        SELECT 'success' Message;
END$$

DROP PROCEDURE IF EXISTS `UspSetupOrderTime`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspSetupOrderTime` (IN `p_FromTime` VARCHAR(20), IN `p_ToTime` VARCHAR(20))  BEGIN
	UPDATE OrderTime
    SET FromTime = p_FromTime,
		ToTime = p_ToTime;
END$$

DROP PROCEDURE IF EXISTS `UspUpdateCreatedOrders`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspUpdateCreatedOrders` (IN `p_OrderNo` BIGINT, IN `p_UserId` VARCHAR(50), IN `p_UpdatedDateTime` DATETIME)  BEGIN
	INSERT INTO OrderProductsTemp
    (
		OrderNo,
        PricePerKg,
        Weight,
        ProductId
    )
    SELECT 
		OrderNo,
        PricePerKg,
        Weight,
        ProductId
	FROM OrderProducts
    WHERE OrderNo = p_OrderNo;
    
	DELETE FROM OrderProducts
    WHERE OrderNo = p_OrderNo;
    
    UPDATE Orders
    SET UpdatedUserId = p_UserId,
        UpdatedDateTime = p_UpdatedDateTime
	WHERE OrderNo = p_OrderNo;
END$$

DROP PROCEDURE IF EXISTS `UspUpdateOrder`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspUpdateOrder` (IN `p_OrderNo` BIGINT, IN `p_Status` VARCHAR(20), IN `p_DeliveredDate` DATE, IN `p_DeliveryTime` VARCHAR(30), IN `p_DeliveryUserId` INT)  BEGIN
	UPDATE Orders
    SET Status = CASE WHEN p_Status IS NULL OR p_Status = '' THEN Status ELSE p_Status END,
		DeliveryDate = CASE WHEN p_DeliveredDate IS NULL OR p_DeliveredDate = '' OR p_DeliveredDate like '%0001%'
			THEN DeliveryDate ELSE p_DeliveredDate END,
        DeliveryTime = CASE WHEN p_DeliveryTime IS NULL OR p_DeliveryTime = '' THEN DeliveryTime 
			ELSE p_DeliveryTime END,
		DeliveryUserId = CASE WHEN p_DeliveryUserId IS NULL OR p_DeliveryUserId = 0 
			THEN DeliveryUserId ELSE p_DeliveryUserId END
	WHERE OrderNo = p_OrderNo;
END$$

DROP PROCEDURE IF EXISTS `UspUpdateOrderPickupDetails`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspUpdateOrderPickupDetails` (IN `p_PickupAddress` VARCHAR(200), IN `p_ContactNo1` BIGINT, IN `p_ContactNo2` BIGINT, IN `p_DeliveryCharges` DECIMAL(10,2))  BEGIN
	UPDATE OrderPickupDetails
    SET PickupAddress = p_PickupAddress,
		ContactNo1 = p_ContactNo1,
        ContactNo2 = p_ContactNo2,
        DeliveryCharges = p_DeliveryCharges;
END$$

DROP PROCEDURE IF EXISTS `UspUpdateProducts`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspUpdateProducts` (IN `p_ProductId` INT, IN `p_RatePerKg` DECIMAL(10,2), IN `p_UpdatedDateTime` DATETIME, IN `p_Deactivate` VARCHAR(4), IN `p_UserId` VARCHAR(50))  BEGIN
	SET @ProductId := 0;
    SELECT @ProductId := ProductId FROM Products
    WHERE ProductId = p_ProductId AND RatePerKg = p_RatePerKg;
    
	IF @ProductId = 0 THEN
        BEGIN
			INSERT INTO ProductHistory
			(
				ProductId,
				CategoryId,
				Name,
				RatePerKG,
				MinPurchaseQuantity,
				CreatedDateTime,
				UpdatedDateTime,
				CreatedUserId,
				UpdatedUserId,
                StatusCode,
                TotalStock
			)
			SELECT
				ProductId,
				CategoryId,
				Name,
				RatePerKg,
				MinPurchaseQuantity,
				CreatedDateTime,
				p_UpdatedDateTime,
				CreatedUserId,
				p_UserId,
                'U',
                TotalStock
			FROM Products
            WHERE ProductId = p_ProductId;
        END;        
        END IF;
        UPDATE Products
		SET RatePerKg = p_RatePerKg,			
			UpdatedDateTime = p_UpdatedDateTime,
			UpdateduserId = p_UserId,
            Deactivate = p_Deactivate
		WHERE ProductId = p_ProductId;
END$$

DROP PROCEDURE IF EXISTS `UspUpdateProductsStock`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspUpdateProductsStock` (IN `p_CondOper` INT, IN `p_OrderNo` BIGINT)  BEGIN
	IF p_CondOper = 1 THEN
    BEGIN
		UPDATE Products P
		INNER JOIN OrderProducts OP ON OP.ProductId = P.ProductId
		INNER JOIN OrderProductsTemp T ON T.ProductId = OP.ProductId AND T.OrderNo = OP.OrderNo
		SET P.TotalStock = P.TotalStock - (OP.Weight - T.Weight)
		WHERE OP.OrderNo = p_OrderNo AND T.OrderNo = p_OrderNo;
	END;
    ELSE
    BEGIN
		UPDATE Products P
		INNER JOIN OrderProducts OP ON OP.ProductId = P.ProductId
		SET P.TotalStock = P.TotalStock - OP.Weight
		WHERE OP.OrderNo = p_OrderNo;
    END;
    END IF;
END$$

DROP PROCEDURE IF EXISTS `UspValidateLoginCustomer`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspValidateLoginCustomer` (IN `p_MobileNo` BIGINT)  BEGIN
	SELECT * FROM ShopDetails S1
    INNER JOIN ShopImages S2 ON S1.ShopId = S2.ShopId
    WHERE MobileNo = p_MobileNo;
END$$

DROP PROCEDURE IF EXISTS `UspValidateLoginUser`$$
CREATE DEFINER=`farmar_market`@`%` PROCEDURE `UspValidateLoginUser` (IN `p_Email` VARCHAR(30), IN `p_Password` VARCHAR(20))  BEGIN
	SET @IsUserValid := '';
    
    SELECT @IsUserValid := Email FROM Users
    WHERE Email = p_Email AND Password = p_Password;
    
    IF @IsUserValid = '' THEN
		SELECT 0 IsValid;
	ELSE
		SELECT 1 IsValid;
	END IF;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `Languages`
--

DROP TABLE IF EXISTS `Languages`;
CREATE TABLE IF NOT EXISTS `Languages` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Language` varchar(20) NOT NULL,
  `IsRequired` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `OrderPickupDetails`
--

DROP TABLE IF EXISTS `OrderPickupDetails`;
CREATE TABLE IF NOT EXISTS `OrderPickupDetails` (
  `PickupAddress` varchar(200) NOT NULL,
  `ContactNo1` bigint(20) NOT NULL,
  `ContactNo2` bigint(20) DEFAULT NULL,
  `DeliveryCharges` decimal(10,2) DEFAULT '0.00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `OrderPickupDetails`
--

INSERT INTO `OrderPickupDetails` (`PickupAddress`, `ContactNo1`, `ContactNo2`, `DeliveryCharges`) VALUES
('Mysore', 1234567890, 9876543210, '1.00');

-- --------------------------------------------------------

--
-- Table structure for table `OrderProducts`
--

DROP TABLE IF EXISTS `OrderProducts`;
CREATE TABLE IF NOT EXISTS `OrderProducts` (
  `OrderNo` bigint(20) NOT NULL,
  `PricePerKg` decimal(10,2) NOT NULL,
  `Weight` decimal(10,2) NOT NULL,
  `ProductId` int(11) NOT NULL,
  KEY `FK_OrderNo` (`OrderNo`),
  KEY `FK_ProductId` (`ProductId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `OrderProducts`
--

INSERT INTO `OrderProducts` (`OrderNo`, `PricePerKg`, `Weight`, `ProductId`) VALUES
(987654321, '25.00', '10.00', 7),
(987654321, '28.00', '10.00', 8),
(251956947, '75.00', '12.00', 19),
(251956947, '80.00', '10.00', 18),
(251956947, '2.00', '5.00', 70),
(453291935, '29.00', '7.00', 11),
(453291935, '62.00', '8.00', 10),
(870021823, '29.00', '7.00', 11),
(870021823, '20.00', '5.00', 7),
(870021823, '25.00', '3.00', 8),
(870021823, '28.00', '3.00', 61),
(870021823, '15.00', '20.00', 34),
(870021823, '16.00', '8.00', 25),
(870021823, '16.00', '5.00', 27),
(870021823, '16.00', '4.00', 26),
(870021823, '12.00', '8.00', 30),
(870021823, '65.00', '8.00', 10),
(870021823, '33.00', '10.00', 9),
(870021823, '18.00', '15.00', 31),
(870021823, '15.00', '10.00', 28),
(870021823, '75.00', '5.00', 18),
(870021823, '60.00', '6.00', 19),
(870021823, '35.00', '5.00', 20),
(870021823, '36.00', '3.00', 64),
(870021823, '26.00', '3.00', 45),
(870021823, '18.00', '5.00', 63),
(870021823, '11.00', '3.00', 65),
(870021823, '49.00', '10.00', 21),
(870021823, '9.00', '15.00', 29),
(870021823, '16.00', '20.00', 35),
(870021823, '45.00', '3.00', 44),
(870021823, '13.00', '20.00', 15),
(870021823, '18.00', '3.00', 46),
(870021823, '18.00', '10.00', 62),
(870021823, '45.00', '25.00', 16),
(870021823, '15.00', '3.00', 47),
(870021823, '32.00', '100.00', 13),
(870021823, '33.00', '25.00', 14),
(870021823, '15.00', '10.00', 36),
(870021823, '30.00', '10.00', 42),
(870021823, '4.00', '3.00', 68),
(870021823, '3.00', '3.00', 69),
(870021823, '3.00', '3.00', 67),
(870021823, '3.00', '3.00', 70),
(870021823, '2.50', '3.00', 71),
(870021823, '3.00', '1.00', 73),
(870021823, '10.00', '1.00', 72),
(347701245, '29.00', '1.00', 11),
(347701245, '20.00', '1.00', 7),
(347701245, '25.00', '2.00', 8),
(347701245, '28.00', '3.00', 61),
(347701245, '15.00', '3.00', 34),
(347701245, '16.00', '3.00', 25),
(347701245, '16.00', '3.00', 27),
(347701245, '16.00', '3.00', 26),
(347701245, '12.00', '3.00', 30),
(347701245, '65.00', '3.00', 10),
(347701245, '33.00', '3.00', 9),
(347701245, '18.00', '4.00', 31),
(347701245, '15.00', '4.00', 28),
(347701245, '75.00', '4.00', 18),
(347701245, '60.00', '5.00', 19),
(537135941, '29.00', '15.00', 11),
(537135941, '20.00', '25.00', 7),
(537135941, '28.00', '8.00', 61),
(537135941, '16.00', '5.00', 26),
(537135941, '33.00', '20.00', 9),
(916088913, '29.00', '4.00', 11),
(916088913, '20.00', '3.00', 7),
(916088913, '60.00', '3.00', 19),
(885406872, '8.00', '8.00', 72),
(929742553, '40.00', '2.00', 75),
(929742553, '12.00', '2.00', 72),
(456532865, '40.00', '7.00', 75),
(456532865, '12.00', '7.00', 72),
(865816401, '50.00', '3.00', 75),
(865816401, '12.00', '3.00', 72),
(865816401, '25.00', '3.00', 80),
(865816401, '55.00', '1.00', 79),
(865816401, '20.00', '3.00', 47),
(466603786, '27.00', '1.00', 75),
(466603786, '8.00', '1.00', 72),
(466603786, '33.00', '1.00', 8),
(300163571, '27.00', '1.00', 75),
(809804125, '27.00', '2.00', 75),
(329592287, '8.00', '1.00', 72),
(329592287, '35.00', '2.00', 8),
(329592287, '34.00', '1.00', 14),
(401648359, '8.00', '1.00', 72),
(401648359, '35.00', '1.00', 8),
(878845433, '8.00', '1.00', 72),
(878845433, '25.00', '2.00', 7),
(723432040, '30.00', '25.00', 7),
(463599447, '98.00', '20.00', 75),
(594037741, '36.00', '3.00', 8),
(432542241, '36.00', '3.00', 8),
(640905238, '8.00', '1.00', 72),
(640905238, '36.00', '3.00', 8),
(307404182, '8.00', '2.00', 72),
(307404182, '36.00', '6.00', 8),
(424763040, '8.00', '7.00', 72),
(424763040, '26.00', '9.00', 61),
(424763040, '29.00', '15.00', 20),
(563105971, '8.00', '7.00', 72),
(563105971, '26.00', '9.00', 61),
(563105971, '29.00', '15.00', 20),
(356718397, '22.00', '200.00', 13),
(242592254, '22.00', '200.00', 13),
(679312493, '8.00', '1.00', 72),
(383631602, '8.00', '2.00', 72),
(383631602, '31.00', '15.00', 7),
(661649633, '8.00', '3.00', 72),
(661649633, '68.00', '16.00', 10),
(661649633, '36.00', '10.00', 9),
(359506762, '8.00', '1.00', 72),
(684901433, '8.00', '1.00', 72),
(149189603, '36.00', '3.00', 8),
(149189603, '31.00', '5.00', 7),
(190421409, '36.00', '3.00', 8),
(190421409, '31.00', '5.00', 7),
(202183560, '8.00', '3.00', 72),
(202183560, '36.00', '18.00', 8),
(202183560, '14.50', '5.00', 27),
(202183560, '24.00', '10.00', 62),
(869064109, '36.00', '3.00', 8),
(506186774, '36.00', '3.00', 8),
(505432732, '8.00', '1.00', 72),
(505432732, '36.00', '6.00', 8),
(651868976, '36.00', '3.00', 8),
(420704570, '36.00', '3.00', 8),
(299420884, '36.00', '3.00', 8),
(345344296, '36.00', '3.00', 8),
(130264486, '36.00', '3.00', 8),
(412806267, '36.00', '3.00', 8),
(140181512, '38.00', '3.00', 64),
(125098617, '36.00', '3.00', 8),
(488208600, '36.00', '3.00', 8),
(244573493, '8.00', '1.00', 72),
(437462782, '8.00', '2.00', 72),
(437462782, '38.00', '6.00', 8),
(437462782, '35.00', '5.00', 7),
(935356328, '8.00', '3.00', 72),
(931350246, '45.00', '3.00', 8),
(787166615, '25.00', '3.00', 61),
(693615285, '18.00', '6.00', 25),
(669641210, '8.00', '12.00', 72),
(669641210, '38.00', '6.00', 7),
(787827429, '8.00', '9.00', 72),
(787827429, '43.00', '30.00', 8),
(787827429, '38.00', '9.00', 7),
(787827429, '25.00', '9.00', 61),
(787827429, '11.00', '3.00', 30),
(787827429, '12.00', '10.00', 65),
(787827429, '32.00', '6.00', 14),
(787827429, '20.00', '10.00', 13),
(731349187, '8.00', '30.00', 72),
(731349187, '43.00', '33.00', 8),
(731349187, '38.00', '18.00', 7),
(731349187, '25.00', '15.00', 61),
(731349187, '38.00', '15.00', 64),
(558845287, '38.00', '3.00', 7);

-- --------------------------------------------------------

--
-- Table structure for table `OrderProductsTemp`
--

DROP TABLE IF EXISTS `OrderProductsTemp`;
CREATE TABLE IF NOT EXISTS `OrderProductsTemp` (
  `OrderNo` bigint(20) NOT NULL,
  `PricePerKg` decimal(10,2) NOT NULL,
  `Weight` decimal(10,2) NOT NULL,
  `ProductId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `Orders`
--

DROP TABLE IF EXISTS `Orders`;
CREATE TABLE IF NOT EXISTS `Orders` (
  `OrderNo` bigint(20) NOT NULL,
  `PassCode` bigint(20) NOT NULL,
  `OrderedDateTime` datetime NOT NULL,
  `DeliveryDate` datetime DEFAULT NULL,
  `DeliveryTime` varchar(30) DEFAULT NULL,
  `Status` varchar(20) NOT NULL,
  `ShopId` int(11) NOT NULL,
  `DeliveryUserId` int(11) DEFAULT NULL,
  `PaymentStatus` varchar(10) NOT NULL,
  `UpdatedDateTime` datetime NOT NULL,
  `CreatedUserId` varchar(50) NOT NULL,
  `UpdatedUserId` varchar(50) NOT NULL,
  PRIMARY KEY (`OrderNo`),
  KEY `FK_ShopId` (`ShopId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Orders`
--

INSERT INTO `Orders` (`OrderNo`, `PassCode`, `OrderedDateTime`, `DeliveryDate`, `DeliveryTime`, `Status`, `ShopId`, `DeliveryUserId`, `PaymentStatus`, `UpdatedDateTime`, `CreatedUserId`, `UpdatedUserId`) VALUES
(125098617, 217916, '2020-07-27 01:20:56', NULL, NULL, 'Initiated', 4, NULL, '', '2020-07-27 01:20:56', '8123506123', '8123506123'),
(130264486, 744926, '2020-07-27 01:14:57', NULL, NULL, 'Initiated', 4, NULL, '', '2020-07-27 01:14:57', '8123506123', '8123506123'),
(140181512, 178082, '2020-07-27 01:20:07', NULL, NULL, 'Initiated', 4, NULL, '', '2020-07-27 01:20:07', '8123506123', '8123506123'),
(149189603, 284629, '2020-07-26 02:17:18', NULL, NULL, 'Initiated', 4, NULL, '', '2020-07-26 02:17:18', 'Shamnoon', 'Shamnoon'),
(190421409, 224520, '2020-07-26 02:17:20', NULL, NULL, 'Initiated', 4, NULL, '', '2020-07-26 02:17:20', 'Shamnoon', 'Shamnoon'),
(202183560, 509694, '2020-07-26 12:35:08', '2020-07-31 00:00:00', '10:58 PM - 12:58 PM', 'Initiated', 4, NULL, '', '2020-07-26 12:35:08', 'Shamnoon', 'Shamnoon'),
(242592254, 896993, '2020-07-25 20:33:01', NULL, NULL, 'Initiated', 4, NULL, '', '2020-07-25 20:33:01', 'Shamnoon', 'Shamnoon'),
(244573493, 161903, '2020-07-27 02:30:31', NULL, NULL, 'Initiated', 4, NULL, '', '2020-07-27 02:30:31', '8123506123', '8123506123'),
(251956947, 489904, '2020-07-08 05:13:41', '2020-07-10 00:00:00', '06:16 PM - 09:16 PM', 'Initiated', 4, NULL, 'Pending', '2020-07-22 06:01:30', '', ''),
(299420884, 471349, '2020-07-27 01:09:03', NULL, NULL, 'Initiated', 4, NULL, '', '2020-07-27 01:09:03', '8123506123', '8123506123'),
(300163571, 456327, '2020-07-21 23:28:44', NULL, NULL, 'Initiated', 6, NULL, '', '2020-07-22 06:01:30', '', ''),
(307404182, 535766, '2020-07-25 20:14:00', NULL, NULL, 'Initiated', 4, NULL, '', '2020-07-25 20:14:00', 'Shamnoon', 'Shamnoon'),
(329592287, 570787, '2020-07-22 17:25:44', NULL, NULL, 'Initiated', 4, NULL, '', '2020-07-22 06:01:30', '', ''),
(345344296, 668103, '2020-07-27 01:10:00', NULL, NULL, 'Initiated', 4, NULL, '', '2020-07-27 01:10:00', '8123506123', '8123506123'),
(347701245, 564654, '2020-07-10 11:30:09', NULL, NULL, 'Initiated', 5, NULL, 'Pending', '2020-07-22 06:01:30', '', ''),
(356718397, 107024, '2020-07-25 20:29:33', NULL, NULL, 'Initiated', 4, NULL, '', '2020-07-25 20:29:33', 'Shamnoon', 'Shamnoon'),
(359506762, 978338, '2020-07-25 22:59:22', NULL, NULL, 'Initiated', 4, NULL, '', '2020-07-25 22:59:22', 'Shamnoon', 'Shamnoon'),
(383631602, 295780, '2020-07-25 22:33:27', NULL, NULL, 'Initiated', 4, NULL, '', '2020-07-25 22:33:27', 'Shamnoon', 'Shamnoon'),
(401648359, 435055, '2020-07-22 17:26:15', NULL, NULL, 'Initiated', 6, NULL, '', '2020-07-22 06:01:30', '', ''),
(412806267, 348780, '2020-07-27 01:17:17', NULL, NULL, 'Initiated', 4, NULL, '', '2020-07-27 01:17:17', '8123506123', '8123506123'),
(420704570, 532733, '2020-07-27 01:07:11', NULL, NULL, 'Initiated', 4, NULL, '', '2020-07-27 01:07:11', '8123506123', '8123506123'),
(424763040, 830249, '2020-07-25 20:27:25', NULL, NULL, 'Initiated', 4, NULL, '', '2020-07-25 20:27:25', 'Shamnoon', 'Shamnoon'),
(432542241, 115638, '2020-07-25 19:56:51', NULL, NULL, 'Initiated', 4, NULL, '', '2020-07-25 19:56:51', 'Shamnoon', 'Shamnoon'),
(437462782, 660568, '2020-07-28 11:03:44', '2020-07-29 11:03:47', '07:00 AM - 10:00 AM', 'Initiated', 4, NULL, '', '2020-07-28 11:03:44', '8123506123', '8123506123'),
(453291935, 447030, '2020-07-09 08:00:20', NULL, NULL, 'Initiated', 4, NULL, 'Pending', '2020-07-22 06:01:30', '', ''),
(456532865, 176175, '2020-07-18 13:05:31', NULL, NULL, 'Delivered', 4, NULL, 'Pending', '2020-07-22 06:01:30', '', ''),
(463599447, 113511, '2020-07-25 10:43:25', NULL, NULL, 'Initiated', 5, NULL, '', '2020-07-25 10:43:25', 'test@gmail.com', 'test@gmail.com'),
(466603786, 838018, '2020-07-21 23:28:14', NULL, NULL, 'Initiated', 6, NULL, '', '2020-07-22 06:01:30', '', ''),
(488208600, 210014, '2020-07-27 02:16:52', NULL, NULL, 'Initiated', 4, NULL, '', '2020-07-27 02:16:52', '8123506123', '8123506123'),
(505432732, 779887, '2020-07-27 01:01:18', NULL, NULL, 'Initiated', 4, NULL, '', '2020-07-27 01:01:18', '8123506123', '8123506123'),
(506186774, 806062, '2020-07-26 23:09:06', NULL, NULL, 'Initiated', 4, NULL, '', '2020-07-26 23:09:06', '8123506123', '8123506123'),
(537135941, 884042, '2020-07-10 09:38:16', NULL, NULL, 'Initiated', 5, NULL, 'Pending', '2020-07-22 06:01:30', '', ''),
(558845287, 926483, '2020-07-30 02:28:59', '2020-07-31 02:29:02', '07:00 AM - 10:00 AM', 'Initiated', 4, NULL, '', '2020-07-30 02:28:59', '8123506123', '8123506123'),
(563105971, 144942, '2020-07-25 20:27:26', NULL, NULL, 'Initiated', 4, NULL, '', '2020-07-25 20:27:26', 'Shamnoon', 'Shamnoon'),
(594037741, 358075, '2020-07-25 18:03:10', '2020-07-25 00:00:00', '06:43 PM - 08:43 PM', 'Initiated', 4, NULL, '', '2020-07-25 18:03:10', 'Shamnoon', 'Shamnoon'),
(640905238, 165689, '2020-07-25 20:01:03', NULL, NULL, 'Initiated', 4, NULL, '', '2020-07-25 20:01:03', 'Shamnoon', 'Shamnoon'),
(651868976, 425077, '2020-07-27 01:06:36', NULL, NULL, 'Initiated', 4, NULL, '', '2020-07-27 01:06:36', '8123506123', '8123506123'),
(661649633, 577970, '2020-07-25 22:59:12', NULL, NULL, 'Initiated', 4, NULL, '', '2020-07-25 22:59:12', 'Shamnoon', 'Shamnoon'),
(669641210, 778787, '2020-07-30 02:00:56', '2020-07-31 02:00:59', '07:00 AM - 10:00 AM', 'Initiated', 4, NULL, '', '2020-07-30 02:00:56', '8123506123', '8123506123'),
(679312493, 583222, '2020-07-26 09:42:02', NULL, NULL, 'Initiated', 5, NULL, '', '2020-07-26 09:42:02', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com'),
(684901433, 157158, '2020-07-25 23:48:24', NULL, NULL, 'Initiated', 4, NULL, '', '2020-07-25 23:48:24', 'Shamnoon', 'Shamnoon'),
(693615285, 865448, '2020-07-29 11:06:31', '2020-07-30 11:06:35', '07:00 AM - 10:00 AM', 'Initiated', 4, NULL, '', '2020-07-29 11:06:31', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com'),
(723432040, 627402, '2020-07-25 21:53:56', NULL, NULL, 'Initiated', 6, NULL, '', '2020-07-25 21:53:56', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com'),
(731349187, 790337, '2020-07-30 02:28:43', '2020-07-31 02:28:47', '07:00 AM - 10:00 AM', 'Initiated', 4, NULL, '', '2020-07-30 02:28:43', '8123506123', '8123506123'),
(787166615, 976566, '2020-07-29 11:04:25', '2020-07-30 11:04:29', '07:00 AM - 10:00 AM', 'Initiated', 4, NULL, '', '2020-07-29 11:04:25', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com'),
(787827429, 680010, '2020-07-30 02:20:32', '2020-07-31 02:20:36', '07:00 AM - 10:00 AM', 'Initiated', 22, NULL, '', '2020-07-30 02:20:32', '9886168703', '9886168703'),
(809804125, 875280, '2020-07-21 23:29:07', NULL, NULL, 'Initiated', 6, NULL, '', '2020-07-22 06:01:30', '', ''),
(865816401, 628783, '2020-07-18 14:12:55', NULL, NULL, 'Initiated', 6, NULL, 'Pending', '2020-07-22 06:01:30', '', ''),
(869064109, 987083, '2020-07-26 23:02:23', NULL, NULL, 'Initiated', 4, NULL, '', '2020-07-26 23:02:23', 'Shamnoon', 'Shamnoon'),
(870021823, 646991, '2020-07-10 09:32:09', NULL, NULL, 'Initiated', 5, NULL, 'Pending', '2020-07-22 06:01:30', '', ''),
(878845433, 454260, '2020-07-24 14:38:28', NULL, NULL, 'Initiated', 6, NULL, '', '0000-00-00 00:00:00', '', ''),
(885406872, 788763, '2020-07-12 14:59:38', NULL, NULL, 'Initiated', 5, NULL, 'Pending', '2020-07-22 06:01:30', '', ''),
(916088913, 985053, '2020-07-10 23:40:39', NULL, NULL, 'Initiated', 4, NULL, 'Pending', '2020-07-22 06:01:30', '', ''),
(929742553, 965514, '2020-07-18 13:00:38', NULL, NULL, 'Initiated', 6, NULL, 'Pending', '2020-07-22 06:01:30', '', ''),
(931350246, 521011, '2020-07-29 10:45:14', '2020-07-30 10:45:18', '07:00 AM - 10:00 AM', 'Initiated', 4, NULL, '', '2020-07-29 10:45:14', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com'),
(935356328, 948972, '2020-07-29 10:36:22', '2020-07-30 10:36:26', '07:00 AM - 10:00 AM', 'Initiated', 4, NULL, '', '2020-07-29 10:36:22', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com'),
(987654321, 123456, '2020-07-05 02:51:47', '2020-07-31 00:00:00', NULL, 'InProgress', 4, 4, 'Pending', '2020-07-22 06:01:30', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `OrderTime`
--

DROP TABLE IF EXISTS `OrderTime`;
CREATE TABLE IF NOT EXISTS `OrderTime` (
  `FromTime` datetime NOT NULL,
  `ToTime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `OrderTime`
--

INSERT INTO `OrderTime` (`FromTime`, `ToTime`) VALUES
('2020-07-05 21:05:39', '2020-07-05 23:55:39');

-- --------------------------------------------------------

--
-- Table structure for table `ProductCategories`
--

DROP TABLE IF EXISTS `ProductCategories`;
CREATE TABLE IF NOT EXISTS `ProductCategories` (
  `CategoryId` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) NOT NULL,
  `Deactivate` tinyint(4) DEFAULT NULL,
  `CreatedDateTime` datetime NOT NULL,
  `CreatedUserId` varchar(50) NOT NULL,
  PRIMARY KEY (`CategoryId`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ProductCategories`
--

INSERT INTO `ProductCategories` (`CategoryId`, `Name`, `Deactivate`, `CreatedDateTime`, `CreatedUserId`) VALUES
(26, 'Vegetables', 0, '2020-06-25 10:40:16', ''),
(27, 'Fruits', 0, '2020-06-25 10:40:35', '');

-- --------------------------------------------------------

--
-- Table structure for table `ProductHistory`
--

DROP TABLE IF EXISTS `ProductHistory`;
CREATE TABLE IF NOT EXISTS `ProductHistory` (
  `ProductHistId` int(11) NOT NULL AUTO_INCREMENT,
  `ProductId` int(11) NOT NULL,
  `CategoryId` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `RatePerKG` decimal(10,2) NOT NULL,
  `MinPurchaseQuantity` decimal(10,2) NOT NULL,
  `CreatedDateTime` datetime NOT NULL,
  `UpdatedDateTime` datetime NOT NULL,
  `CreatedUserId` varchar(50) NOT NULL,
  `UpdatedUserId` varchar(50) NOT NULL,
  `StatusCode` char(1) NOT NULL,
  `TotalStock` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`ProductHistId`)
) ENGINE=InnoDB AUTO_INCREMENT=962 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ProductHistory`
--

INSERT INTO `ProductHistory` (`ProductHistId`, `ProductId`, `CategoryId`, `Name`, `RatePerKG`, `MinPurchaseQuantity`, `CreatedDateTime`, `UpdatedDateTime`, `CreatedUserId`, `UpdatedUserId`, `StatusCode`, `TotalStock`) VALUES
(22, 6, 26, 'BEANS (LOCAL)', '35.00', '5.00', '2020-06-29 14:21:30', '2020-06-29 18:21:13', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(23, 6, 26, 'BEANS (LOCAL)', '35.00', '12.00', '2020-06-29 14:21:30', '2020-06-29 18:21:33', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(24, 5, 26, 'ALOO', '25.00', '5.00', '2020-06-29 14:20:48', '2020-06-29 18:21:41', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(25, 6, 26, 'BEANS (LOCAL)', '35.00', '15.00', '2020-06-29 14:21:30', '2020-06-29 05:52:07', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(26, 5, 26, 'ALOO', '25.00', '10.00', '2020-06-29 14:20:48', '2020-06-30 11:21:58', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(27, 5, 26, 'ALOO', '25.00', '10.00', '2020-06-29 14:20:48', '2020-07-02 01:51:26', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(28, 5, 26, 'ALOO', '25.00', '10.00', '2020-06-29 14:20:48', '2020-07-02 02:00:15', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'U', '99.00'),
(29, 5, 26, 'ALOO', '25.00', '10.00', '2020-06-29 14:20:48', '2020-07-02 14:31:36', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'D', NULL),
(30, 6, 26, 'BEANS (LOCAL)', '35.00', '12.00', '2020-06-29 14:21:30', '2020-07-02 02:06:19', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(31, 6, 26, 'ALOO', '25.00', '10.00', '2020-06-29 14:21:30', '2020-07-02 02:38:17', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'U', '50.00'),
(32, 6, 26, 'ALOO', '25.00', '10.00', '2020-06-29 14:21:30', '2020-07-03 07:09:16', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'D', NULL),
(33, 37, 26, 'ALOO', '10.00', '10.00', '2020-07-02 06:11:16', '2020-07-03 07:12:01', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'D', NULL),
(34, 38, 26, 'ALOO', '10.00', '10.00', '2020-07-02 06:13:43', '2020-07-03 07:15:16', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'D', NULL),
(35, 39, 26, 'ALOO', '10.00', '10.00', '2020-07-02 06:17:45', '2020-07-03 07:19:41', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'D', NULL),
(36, 40, 26, 'ALOO', '10.00', '10.00', '2020-07-02 06:21:13', '2020-07-02 06:50:33', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'U', '10.00'),
(37, 40, 26, 'ALOO', '10.00', '10.00', '2020-07-02 06:21:13', '2020-07-03 07:51:07', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'U', '10.00'),
(38, 40, 26, 'ALOO', '10.00', '10.00', '2020-07-02 06:21:13', '2020-07-03 07:32:41', 'abhijitjd003@gmail.com', '', 'U', '10.00'),
(39, 40, 26, 'ALOO', '10.00', '10.00', '2020-07-02 06:21:13', '2020-07-03 07:33:04', 'abhijitjd003@gmail.com', '', 'U', '10.00'),
(40, 40, 26, 'ALOO', '10.00', '10.00', '2020-07-02 06:21:13', '2020-07-03 07:33:08', 'abhijitjd003@gmail.com', '', 'U', '20.00'),
(41, 40, 26, 'ALOO', '10.00', '10.00', '2020-07-02 06:21:13', '2020-07-03 07:33:34', 'abhijitjd003@gmail.com', 'null', 'D', NULL),
(42, 41, 26, 'ALOO', '10.00', '10.00', '2020-07-03 07:35:40', '2020-07-03 08:13:40', '', '', 'U', '10.00'),
(43, 41, 26, 'ALOO', '10.00', '10.00', '2020-07-03 07:35:40', '2020-07-03 08:13:59', '', '', 'U', '10.00'),
(44, 41, 26, 'ALOO', '10.00', '10.00', '2020-07-03 07:35:40', '2020-07-03 08:28:43', '', '', 'U', '10.00'),
(45, 41, 26, 'ALOO', '10.00', '10.00', '2020-07-03 07:35:40', '2020-07-03 08:29:00', '', 'null', 'D', NULL),
(46, 42, 26, 'ALOO', '10.00', '10.00', '2020-07-03 08:31:50', '2020-07-03 12:44:51', '', '', 'U', '10.00'),
(47, 11, 26, 'BRINJAL (ROUND)', '9.00', '7.00', '2020-06-29 14:23:51', '2020-07-03 12:47:56', 'abhijitjd003@gmail.com', '', 'U', '65.00'),
(48, 7, 26, 'BEANS (OOTY)', '60.00', '5.00', '2020-06-29 14:21:54', '2020-07-03 12:48:21', 'abhijitjd003@gmail.com', '', 'U', '60.00'),
(49, 8, 26, 'BEETROOT', '30.00', '3.00', '2020-06-29 14:22:19', '2020-07-03 12:48:32', 'abhijitjd003@gmail.com', '', 'U', '30.00'),
(50, 9, 26, 'BHENDI', '15.00', '10.00', '2020-06-29 14:22:41', '2020-07-03 12:48:48', 'abhijitjd003@gmail.com', '', 'U', '100.00'),
(51, 10, 26, 'BRINJAL (LONG)', '10.00', '8.00', '2020-06-29 14:22:59', '2020-07-03 12:48:57', 'abhijitjd003@gmail.com', '', 'U', '75.00'),
(52, 11, 26, 'BRINJAL (ROUND)', '14.00', '7.00', '2020-06-29 14:23:51', '2020-07-03 12:49:11', 'abhijitjd003@gmail.com', '', 'U', '65.00'),
(53, 12, 26, 'CABBAGE', '11.00', '11.00', '2020-06-29 14:24:18', '2020-07-03 12:49:22', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(54, 13, 26, 'CAPSICUM', '65.00', '100.00', '2020-06-29 14:25:12', '2020-07-03 12:49:38', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(55, 14, 26, 'CARROT', '30.00', '25.00', '2020-06-29 14:25:39', '2020-07-03 12:49:59', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(56, 16, 26, 'CUCUMBER', '8.00', '25.00', '2020-06-29 14:26:10', '2020-07-03 12:50:29', 'abhijitjd003@gmail.com', '', 'U', '65.00'),
(57, 17, 26, 'DRUMSTICK', '54.00', '10.00', '2020-06-29 14:26:27', '2020-07-03 12:50:55', 'abhijitjd003@gmail.com', '', 'U', '20.00'),
(58, 18, 26, 'GARLIC', '80.00', '5.00', '2020-06-29 14:26:45', '2020-07-03 12:51:53', 'abhijitjd003@gmail.com', '', 'U', '25.00'),
(59, 19, 26, 'GINGER', '70.00', '5.00', '2020-06-29 14:27:04', '2020-07-03 12:52:25', 'abhijitjd003@gmail.com', '', 'U', '30.00'),
(60, 20, 26, 'GREEN CHILLIES', '30.00', '5.00', '2020-06-29 14:27:20', '2020-07-03 12:52:48', 'abhijitjd003@gmail.com', '', 'U', '30.00'),
(61, 21, 26, 'HAGALA KAI', '44.00', '10.00', '2020-06-29 14:27:39', '2020-07-03 12:53:12', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(62, 22, 26, 'HALASANDE', '1.00', '1.00', '2020-06-29 14:27:57', '2020-07-03 12:53:41', 'abhijitjd003@gmail.com', '', 'U', '1.00'),
(63, 23, 26, 'HIREKAI', '30.00', '10.00', '2020-06-29 14:28:11', '2020-07-03 12:54:02', 'abhijitjd003@gmail.com', '', 'U', '35.00'),
(64, 24, 26, 'KNOL KHOL', '24.00', '4.00', '2020-06-29 14:28:32', '2020-07-03 12:54:29', 'abhijitjd003@gmail.com', '', 'U', '25.00'),
(65, 25, 26, 'KUMBALA', '80.00', '8.00', '2020-06-29 14:28:47', '2020-07-03 12:54:53', 'abhijitjd003@gmail.com', '', 'U', '80.00'),
(66, 26, 26, 'LEMON', '40.00', '4.00', '2020-06-29 14:29:04', '2020-07-03 12:55:07', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(67, 27, 26, 'MC', '5.00', '5.00', '2020-06-29 14:29:17', '2020-07-03 12:55:40', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(68, 28, 26, 'MULANGI', '15.00', '10.00', '2020-06-29 14:29:29', '2020-07-03 12:56:07', 'abhijitjd003@gmail.com', '', 'U', '25.00'),
(69, 29, 26, 'ONION', '18.00', '15.00', '2020-06-29 14:30:03', '2020-07-03 12:56:39', 'abhijitjd003@gmail.com', '', 'U', '200.00'),
(70, 30, 26, 'PADUVALAKAI', '18.00', '8.00', '2020-06-29 14:30:17', '2020-07-03 12:57:02', 'abhijitjd003@gmail.com', '', 'U', '80.00'),
(71, 31, 26, 'SIMEBADNE KAI', '20.00', '15.00', '2020-06-29 14:30:35', '2020-07-03 12:57:21', 'abhijitjd003@gmail.com', '', 'U', '70.00'),
(72, 32, 26, 'SMALL ONION', '65.00', '6.00', '2020-06-29 14:30:54', '2020-07-03 12:57:44', 'abhijitjd003@gmail.com', '', 'U', '65.00'),
(73, 33, 26, 'SOREKAI', '18.00', '10.00', '2020-06-29 14:31:10', '2020-07-03 12:58:06', 'abhijitjd003@gmail.com', '', 'U', '20.00'),
(74, 36, 26, 'THONDEKAI', '20.00', '10.00', '2020-06-29 14:32:02', '2020-07-03 12:58:38', 'abhijitjd003@gmail.com', '', 'U', '25.00'),
(75, 34, 26, 'TOMATO (HULI)', '15.00', '20.00', '2020-06-29 14:31:27', '2020-07-03 12:58:56', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(76, 35, 26, 'TOMATO (JAMUN)', '18.00', '20.00', '2020-06-29 14:31:43', '2020-07-03 12:59:17', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(77, 58, 26, 'Apple', '200.00', '10.00', '2020-07-05 06:17:51', '2020-07-04 17:49:59', '', 'null', 'D', '50.00'),
(78, 59, 26, 'Apple', '200.00', '10.00', '2020-07-05 06:20:18', '2020-07-04 19:17:00', '', 'null', 'D', '50.00'),
(79, 42, 26, 'ALOO', '10.00', '10.00', '2020-07-03 08:31:50', '2020-07-05 08:08:59', '', '', 'U', '10.00'),
(80, 7, 26, 'BEANS (OOTY)', '26.00', '5.00', '2020-06-29 14:21:54', '2020-07-05 08:10:00', 'abhijitjd003@gmail.com', '', 'U', '60.00'),
(81, 8, 26, 'BEETROOT', '28.00', '3.00', '2020-06-29 14:22:19', '2020-07-05 08:12:04', 'abhijitjd003@gmail.com', '', 'U', '30.00'),
(82, 8, 26, 'BEETROOT', '28.00', '3.00', '2020-06-29 14:22:19', '2020-07-05 08:14:58', 'abhijitjd003@gmail.com', '', 'U', '30.00'),
(83, 7, 26, 'BEANS (OOTY)', '26.00', '5.00', '2020-06-29 14:21:54', '2020-07-05 08:20:03', 'abhijitjd003@gmail.com', '', 'U', '60.00'),
(84, 60, 26, 'Apple', '200.00', '10.00', '2020-07-05 08:21:58', '2020-07-05 08:22:55', '', '', 'U', '10.00'),
(85, 9, 26, 'BHENDI', '12.00', '10.00', '2020-06-29 14:22:41', '2020-07-04 22:59:36', 'abhijitjd003@gmail.com', '', 'U', '100.00'),
(86, 60, 26, 'Apple', '200.00', '10.00', '2020-07-05 08:21:58', '2020-07-04 23:00:11', '', '', 'U', '10.00'),
(87, 10, 26, 'BRINJAL (LONG)', '16.00', '8.00', '2020-06-29 14:22:59', '2020-07-05 01:16:09', 'abhijitjd003@gmail.com', '', 'U', '75.00'),
(88, 10, 26, 'BRINJAL (LONG)', '16.00', '8.00', '2020-06-29 14:22:59', '2020-07-05 01:16:22', 'abhijitjd003@gmail.com', '', 'U', '75.00'),
(89, 10, 26, 'BRINJAL (LONG)', '16.00', '8.00', '2020-06-29 14:22:59', '2020-07-05 01:16:46', 'abhijitjd003@gmail.com', '', 'U', '75.00'),
(90, 7, 26, 'BEANS (OOTY)', '26.00', '5.00', '2020-06-29 14:21:54', '2020-07-05 14:41:25', 'abhijitjd003@gmail.com', '', 'U', '60.00'),
(91, 9, 26, 'BHENDI', '12.00', '10.00', '2020-06-29 14:22:41', '2020-07-05 14:42:41', 'abhijitjd003@gmail.com', '', 'U', '100.00'),
(92, 12, 26, 'CABBAGE', '10.00', '11.00', '2020-06-29 14:24:18', '2020-07-05 14:43:18', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(93, 13, 26, 'CAPSICUM', '65.00', '100.00', '2020-06-29 14:25:12', '2020-07-05 14:43:34', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(94, 14, 26, 'CARROT', '30.00', '25.00', '2020-06-29 14:25:39', '2020-07-05 14:43:50', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(95, 15, 26, 'CAULIFLOWER', '20.00', '20.00', '2020-06-29 14:25:53', '2020-07-05 14:44:13', 'abhijitjd003@gmail.com', '', 'U', '30.00'),
(96, 16, 26, 'CUCUMBER', '9.00', '25.00', '2020-06-29 14:26:10', '2020-07-05 14:44:35', 'abhijitjd003@gmail.com', '', 'U', '65.00'),
(97, 17, 26, 'DRUMSTICK', '40.00', '10.00', '2020-06-29 14:26:27', '2020-07-05 14:44:51', 'abhijitjd003@gmail.com', '', 'U', '20.00'),
(98, 20, 26, 'GREEN CHILLIES', '26.00', '5.00', '2020-06-29 14:27:20', '2020-07-05 14:46:58', 'abhijitjd003@gmail.com', '', 'U', '30.00'),
(99, 20, 26, 'GREEN CHILLIES', '30.00', '5.00', '2020-06-29 14:27:20', '2020-07-05 14:47:20', 'abhijitjd003@gmail.com', '', 'U', '30.00'),
(100, 23, 26, 'HIREKAI', '18.00', '10.00', '2020-06-29 14:28:11', '2020-07-05 14:47:41', 'abhijitjd003@gmail.com', '', 'U', '35.00'),
(101, 25, 26, 'KUMBALA', '10.00', '8.00', '2020-06-29 14:28:47', '2020-07-05 14:48:01', 'abhijitjd003@gmail.com', '', 'U', '80.00'),
(102, 26, 26, 'LEMON', '40.00', '4.00', '2020-06-29 14:29:04', '2020-07-05 14:48:30', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(103, 27, 26, 'MC', '5.00', '5.00', '2020-06-29 14:29:17', '2020-07-05 14:48:41', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(104, 28, 26, 'MULANGI', '14.00', '10.00', '2020-06-29 14:29:29', '2020-07-05 14:48:51', 'abhijitjd003@gmail.com', '', 'U', '25.00'),
(105, 28, 26, 'MULANGI', '14.00', '10.00', '2020-06-29 14:29:29', '2020-07-05 14:49:00', 'abhijitjd003@gmail.com', '', 'U', '25.00'),
(106, 29, 26, 'ONION', '13.00', '15.00', '2020-06-29 14:30:03', '2020-07-05 14:49:32', 'abhijitjd003@gmail.com', '', 'U', '200.00'),
(107, 33, 26, 'SOREKAI', '11.00', '10.00', '2020-06-29 14:31:10', '2020-07-05 14:50:01', 'abhijitjd003@gmail.com', '', 'U', '20.00'),
(108, 34, 26, 'TOMATO (HULI)', '28.00', '20.00', '2020-06-29 14:31:27', '2020-07-05 14:50:21', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(109, 35, 26, 'TOMATO (JAMUN)', '28.00', '20.00', '2020-06-29 14:31:43', '2020-07-05 14:50:37', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(110, 46, 26, 'Pudina', '2.00', '3.00', '2020-07-03 13:08:54', '2020-07-05 14:51:10', '', '', 'U', '10.00'),
(111, 60, 26, 'Apple', '200.00', '10.00', '2020-07-05 08:21:58', '2020-07-05 14:54:32', '', 'null', 'D', '10.00'),
(112, 61, 26, 'Sapsige', '12.00', '10.00', '2020-07-05 14:55:16', '2020-07-05 14:55:33', '', '', 'U', '5.00'),
(113, 61, 26, 'Sapsige', '12.00', '10.00', '2020-07-05 14:55:16', '2020-07-05 14:56:13', '', '', 'U', '5.00'),
(114, 42, 26, 'ALOO', '10.00', '10.00', '2020-07-03 08:31:50', '2020-07-05 15:02:32', '', '', 'U', '10.00'),
(115, 18, 26, 'GARLIC', '80.00', '5.00', '2020-06-29 14:26:45', '2020-07-05 15:05:07', 'abhijitjd003@gmail.com', '', 'U', '25.00'),
(116, 10, 26, 'BRINJAL (LONG)', '16.00', '8.00', '2020-06-29 14:22:59', '2020-07-05 15:10:31', 'abhijitjd003@gmail.com', '', 'U', '75.00'),
(117, 12, 26, 'CABBAGE', '12.00', '11.00', '2020-06-29 14:24:18', '2020-07-05 15:10:54', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(118, 13, 26, 'CAPSICUM', '60.00', '100.00', '2020-06-29 14:25:12', '2020-07-05 15:11:30', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(119, 14, 26, 'CARROT', '32.00', '25.00', '2020-06-29 14:25:39', '2020-07-05 15:11:47', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(120, 16, 26, 'CUCUMBER', '10.00', '25.00', '2020-06-29 14:26:10', '2020-07-05 15:12:29', 'abhijitjd003@gmail.com', '', 'U', '65.00'),
(121, 17, 26, 'DRUMSTICK', '40.00', '10.00', '2020-06-29 14:26:27', '2020-07-05 15:12:44', 'abhijitjd003@gmail.com', '', 'U', '20.00'),
(122, 18, 26, 'GARLIC', '80.00', '5.00', '2020-06-29 14:26:45', '2020-07-05 15:13:00', 'abhijitjd003@gmail.com', '', 'U', '25.00'),
(123, 19, 26, 'GINGER', '60.00', '5.00', '2020-06-29 14:27:04', '2020-07-05 15:13:15', 'abhijitjd003@gmail.com', '', 'U', '30.00'),
(124, 20, 26, 'GREEN CHILLIES', '35.00', '5.00', '2020-06-29 14:27:20', '2020-07-05 15:13:32', 'abhijitjd003@gmail.com', '', 'U', '30.00'),
(125, 21, 26, 'HAGALA KAI', '36.00', '10.00', '2020-06-29 14:27:39', '2020-07-05 15:13:46', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(126, 22, 26, 'HALASANDE', '30.00', '1.00', '2020-06-29 14:27:57', '2020-07-05 15:14:01', 'abhijitjd003@gmail.com', '', 'U', '1.00'),
(127, 17, 26, 'DRUMSTICK', '40.00', '10.00', '2020-06-29 14:26:27', '2020-07-05 15:14:14', 'abhijitjd003@gmail.com', '', 'U', '20.00'),
(128, 23, 26, 'HIREKAI', '25.00', '10.00', '2020-06-29 14:28:11', '2020-07-05 15:14:34', 'abhijitjd003@gmail.com', '', 'U', '35.00'),
(129, 24, 26, 'KNOL KHOL', '18.00', '4.00', '2020-06-29 14:28:32', '2020-07-05 15:15:00', 'abhijitjd003@gmail.com', '', 'U', '25.00'),
(130, 25, 26, 'KUMBALA', '12.00', '8.00', '2020-06-29 14:28:47', '2020-07-05 15:15:14', 'abhijitjd003@gmail.com', '', 'U', '80.00'),
(131, 26, 26, 'LEMON', '45.00', '4.00', '2020-06-29 14:29:04', '2020-07-05 15:15:38', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(132, 27, 26, 'MC', '6.00', '5.00', '2020-06-29 14:29:17', '2020-07-05 15:16:49', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(133, 28, 26, 'MULANGI', '18.00', '10.00', '2020-06-29 14:29:29', '2020-07-05 15:17:45', 'abhijitjd003@gmail.com', '', 'U', '25.00'),
(134, 29, 26, 'ONION', '12.00', '15.00', '2020-06-29 14:30:03', '2020-07-05 15:18:13', 'abhijitjd003@gmail.com', '', 'U', '200.00'),
(135, 30, 26, 'PADUVALAKAI', '12.00', '8.00', '2020-06-29 14:30:17', '2020-07-05 15:18:33', 'abhijitjd003@gmail.com', '', 'U', '80.00'),
(136, 31, 26, 'SIMEBADNE KAI', '20.00', '15.00', '2020-06-29 14:30:35', '2020-07-05 15:18:52', 'abhijitjd003@gmail.com', '', 'U', '70.00'),
(137, 33, 26, 'SOREKAI', '12.00', '10.00', '2020-06-29 14:31:10', '2020-07-05 15:19:30', 'abhijitjd003@gmail.com', '', 'U', '20.00'),
(138, 34, 26, 'TOMATO (HULI)', '25.00', '20.00', '2020-06-29 14:31:27', '2020-07-05 15:20:02', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(139, 35, 26, 'TOMATO (JAMUN)', '26.00', '20.00', '2020-06-29 14:31:43', '2020-07-05 15:20:17', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(140, 36, 26, 'THONDEKAI', '18.00', '10.00', '2020-06-29 14:32:02', '2020-07-05 15:20:35', 'abhijitjd003@gmail.com', '', 'U', '25.00'),
(141, 30, 26, 'PADUVALAKAI', '12.00', '8.00', '2020-06-29 14:30:17', '2020-07-05 15:20:54', 'abhijitjd003@gmail.com', '', 'U', '80.00'),
(142, 42, 26, 'ALOO', '10.00', '10.00', '2020-07-03 08:31:50', '2020-07-05 15:21:31', '', '', 'U', '10.00'),
(143, 43, 26, 'Beans', '18.00', '3.00', '2020-07-03 13:02:15', '2020-07-05 15:21:58', '', '', 'U', '0.00'),
(144, 44, 26, 'Karibevu', '1.50', '3.00', '2020-07-03 13:08:04', '2020-07-05 15:22:22', '', '', 'U', '10.00'),
(145, 45, 26, 'kothmiri', '3.00', '3.00', '2020-07-03 13:08:28', '2020-07-05 15:22:43', '', '', 'U', '10.00'),
(146, 46, 26, 'Pudina', '3.00', '3.00', '2020-07-03 13:08:54', '2020-07-05 15:22:57', '', '', 'U', '10.00'),
(147, 47, 26, 'Palak', '2.00', '3.00', '2020-07-03 13:09:17', '2020-07-05 15:23:26', '', '', 'U', '10.00'),
(148, 11, 26, 'BRINJAL (ROUND)', '14.00', '7.00', '2020-06-29 14:23:51', '2020-07-05 15:23:50', 'abhijitjd003@gmail.com', '', 'U', '65.00'),
(149, 15, 26, 'CAULIFLOWER', '18.00', '20.00', '2020-06-29 14:25:53', '2020-07-05 15:25:13', 'abhijitjd003@gmail.com', '', 'U', '30.00'),
(150, 15, 26, 'CAULIFLOWER', '18.00', '20.00', '2020-06-29 14:25:53', '2020-07-05 15:26:12', 'abhijitjd003@gmail.com', '', 'U', '30.00'),
(151, 61, 26, 'Sapsige', '2.00', '3.00', '2020-07-05 14:55:16', '2020-07-05 15:27:05', '', '', 'U', '10.00'),
(152, 42, 26, 'ALOO', '10.00', '10.00', '2020-07-03 08:31:50', '2020-07-05 15:28:35', '', '', 'U', '10.00'),
(153, 42, 26, 'Brinjal Black', '16.00', '10.00', '2020-07-03 08:31:50', '2020-07-05 15:28:58', '', '', 'U', '10.00'),
(154, 43, 26, 'Beans', '18.00', '3.00', '2020-07-03 13:02:15', '2020-07-05 15:29:52', '', '', 'U', '10.00'),
(155, 42, 26, 'Brinjal Black', '16.00', '10.00', '2020-07-03 08:31:50', '2020-07-05 15:31:29', '', '', 'U', '10.00'),
(156, 43, 26, 'Potato', '18.00', '3.00', '2020-07-03 13:02:15', '2020-07-05 15:32:46', '', '', 'U', '10.00'),
(157, 62, 26, 'Beans', '18.00', '10.00', '2020-07-05 15:30:20', '2020-07-05 15:33:07', '', '', 'U', '10.00'),
(158, 61, 26, 'Sapsige', '2.00', '3.00', '2020-07-05 14:55:16', '2020-07-05 15:33:51', '', '', 'U', '10.00'),
(159, 29, 26, 'ONION', '12.00', '15.00', '2020-06-29 14:30:03', '2020-07-05 15:48:19', 'abhijitjd003@gmail.com', '', 'U', '200.00'),
(160, 8, 26, 'BEETROOT', '28.00', '3.00', '2020-06-29 14:22:19', '2020-07-05 18:46:53', 'abhijitjd003@gmail.com', '', 'U', '30.00'),
(161, 7, 26, 'BEANS (OOTY)', '25.00', '5.00', '2020-06-29 14:21:54', '2020-07-05 18:47:21', 'abhijitjd003@gmail.com', '', 'U', '60.00'),
(162, 12, 26, 'CABBAGE', '12.00', '11.00', '2020-06-29 14:24:18', '2020-07-05 18:49:30', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(163, 43, 26, 'Beans', '18.00', '3.00', '2020-07-03 13:02:15', '2020-07-05 18:50:09', '', '', 'U', '10.00'),
(164, 16, 26, 'CUCUMBER', '10.00', '25.00', '2020-06-29 14:26:10', '2020-07-05 18:51:30', 'abhijitjd003@gmail.com', '', 'U', '65.00'),
(165, 26, 26, 'LEMON', '45.00', '4.00', '2020-06-29 14:29:04', '2020-07-05 18:52:07', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(166, 21, 26, 'HAGALA KAI', '36.00', '10.00', '2020-06-29 14:27:39', '2020-07-05 18:52:47', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(167, 9, 26, 'BHENDI', '13.00', '10.00', '2020-06-29 14:22:41', '2020-07-05 18:53:37', 'abhijitjd003@gmail.com', '', 'U', '100.00'),
(168, 10, 26, 'BRINJAL (LONG)', '16.00', '8.00', '2020-06-29 14:22:59', '2020-07-05 18:55:18', 'abhijitjd003@gmail.com', '', 'U', '75.00'),
(169, 13, 26, 'CAPSICUM', '60.00', '100.00', '2020-06-29 14:25:12', '2020-07-05 18:55:59', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(170, 13, 26, 'BRINJAL(Long)', '16.00', '100.00', '2020-06-29 14:25:12', '2020-07-05 18:56:41', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(171, 17, 26, 'DRUMSTICK', '40.00', '10.00', '2020-06-29 14:26:27', '2020-07-05 19:00:04', 'abhijitjd003@gmail.com', '', 'U', '20.00'),
(172, 22, 26, 'HALASANDE', '30.00', '1.00', '2020-06-29 14:27:57', '2020-07-05 19:01:20', 'abhijitjd003@gmail.com', '', 'U', '1.00'),
(173, 23, 26, 'HIREKAI', '25.00', '10.00', '2020-06-29 14:28:11', '2020-07-05 19:02:16', 'abhijitjd003@gmail.com', '', 'U', '35.00'),
(174, 11, 26, 'BRINJAL (ROUND)', '14.00', '7.00', '2020-06-29 14:23:51', '2020-07-05 19:05:55', 'abhijitjd003@gmail.com', '', 'U', '65.00'),
(175, 12, 26, 'BRINJAL (Black)', '16.00', '11.00', '2020-06-29 14:24:18', '2020-07-05 19:06:31', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(176, 13, 26, 'BRINJAL(Long)', '16.00', '100.00', '2020-06-29 14:25:12', '2020-07-05 19:07:37', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(177, 14, 26, 'CARROT', '32.00', '25.00', '2020-06-29 14:25:39', '2020-07-05 19:08:22', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(178, 13, 26, 'TOMATO(Sour)', '12.00', '100.00', '2020-06-29 14:25:12', '2020-07-05 19:08:37', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(179, 15, 26, 'CAULIFLOWER', '18.00', '20.00', '2020-06-29 14:25:53', '2020-07-05 19:08:59', 'abhijitjd003@gmail.com', '', 'U', '30.00'),
(180, 16, 26, 'CABBAGE', '12.00', '25.00', '2020-06-29 14:26:10', '2020-07-05 19:09:38', 'abhijitjd003@gmail.com', '', 'U', '65.00'),
(181, 17, 26, 'HALSANDE', '30.00', '10.00', '2020-06-29 14:26:27', '2020-07-05 19:09:45', 'abhijitjd003@gmail.com', 'null', 'D', '20.00'),
(182, 15, 26, 'ONION', '12.00', '20.00', '2020-06-29 14:25:53', '2020-07-05 19:10:25', 'abhijitjd003@gmail.com', '', 'U', '30.00'),
(183, 14, 26, 'TOMATO(Jamun)', '32.00', '25.00', '2020-06-29 14:25:39', '2020-07-05 19:10:49', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(184, 22, 26, 'ONION', '12.00', '1.00', '2020-06-29 14:27:57', '2020-07-05 19:11:45', 'abhijitjd003@gmail.com', '', 'U', '1.00'),
(185, 23, 26, 'SMALL ONION', '30.00', '10.00', '2020-06-29 14:28:11', '2020-07-05 19:12:22', 'abhijitjd003@gmail.com', '', 'U', '35.00'),
(186, 24, 26, 'KNOL KHOL', '18.00', '4.00', '2020-06-29 14:28:32', '2020-07-05 19:13:27', 'abhijitjd003@gmail.com', '', 'U', '25.00'),
(187, 25, 26, 'KUMBALA', '12.00', '8.00', '2020-06-29 14:28:47', '2020-07-05 19:13:57', 'abhijitjd003@gmail.com', '', 'U', '80.00'),
(188, 26, 26, 'CUCUMBER', '10.00', '4.00', '2020-06-29 14:29:04', '2020-07-05 19:14:22', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(189, 27, 26, 'MC', '6.00', '5.00', '2020-06-29 14:29:17', '2020-07-05 19:14:55', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(190, 23, 26, 'MC', '6.00', '10.00', '2020-06-29 14:28:11', '2020-07-05 19:15:48', 'abhijitjd003@gmail.com', '', 'U', '35.00'),
(191, 23, 26, 'MC', '6.00', '10.00', '2020-06-29 14:28:11', '2020-07-05 19:16:10', 'abhijitjd003@gmail.com', '', 'U', '35.00'),
(192, 23, 26, 'MC', '6.00', '10.00', '2020-06-29 14:28:11', '2020-07-05 19:16:23', 'abhijitjd003@gmail.com', '', 'U', '35.00'),
(193, 22, 26, 'CUCUMBER', '10.00', '1.00', '2020-06-29 14:27:57', '2020-07-05 19:17:27', 'abhijitjd003@gmail.com', '', 'U', '1.00'),
(194, 23, 26, 'MC', '6.00', '10.00', '2020-06-29 14:28:11', '2020-07-05 19:17:38', 'abhijitjd003@gmail.com', '', 'U', '35.00'),
(195, 28, 26, 'MULANGI', '18.00', '10.00', '2020-06-29 14:29:29', '2020-07-05 19:18:04', 'abhijitjd003@gmail.com', '', 'U', '25.00'),
(196, 29, 26, 'ONION', '13.00', '15.00', '2020-06-29 14:30:03', '2020-07-05 19:18:21', 'abhijitjd003@gmail.com', '', 'U', '200.00'),
(197, 34, 26, 'TOMATO (HULI)', '25.00', '20.00', '2020-06-29 14:31:27', '2020-07-05 19:20:10', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(198, 30, 26, 'PADUVALAKAI', '12.00', '8.00', '2020-06-29 14:30:17', '2020-07-05 19:21:33', 'abhijitjd003@gmail.com', '', 'U', '80.00'),
(199, 31, 26, 'SIMEBADNE KAI', '20.00', '15.00', '2020-06-29 14:30:35', '2020-07-05 19:22:06', 'abhijitjd003@gmail.com', '', 'U', '70.00'),
(200, 35, 26, 'TOMATO (JAMUN)', '26.00', '20.00', '2020-06-29 14:31:43', '2020-07-05 19:23:10', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(201, 33, 26, 'SOREKAI', '12.00', '10.00', '2020-06-29 14:31:10', '2020-07-05 19:23:52', 'abhijitjd003@gmail.com', '', 'U', '20.00'),
(202, 32, 26, 'SMALL ONION', '65.00', '6.00', '2020-06-29 14:30:54', '2020-07-05 19:24:34', 'abhijitjd003@gmail.com', '', 'U', '65.00'),
(203, 32, 26, 'EEE', '65.00', '6.00', '2020-06-29 14:30:54', '2020-07-05 19:25:02', 'abhijitjd003@gmail.com', '', 'U', '65.00'),
(204, 33, 26, 'TONDEKAI', '18.00', '10.00', '2020-06-29 14:31:10', '2020-07-05 19:26:08', 'abhijitjd003@gmail.com', '', 'U', '20.00'),
(205, 42, 26, 'Brinjal Black', '16.00', '10.00', '2020-07-03 08:31:50', '2020-07-05 19:27:08', '', '', 'U', '10.00'),
(206, 44, 26, 'Karibevu', '1.50', '3.00', '2020-07-03 13:08:04', '2020-07-05 19:27:54', '', '', 'U', '10.00'),
(207, 45, 26, 'kothmiri', '3.00', '3.00', '2020-07-03 13:08:28', '2020-07-05 19:30:41', '', '', 'U', '10.00'),
(208, 46, 26, 'Pudina', '3.00', '3.00', '2020-07-03 13:08:54', '2020-07-05 19:31:36', '', '', 'U', '10.00'),
(209, 47, 26, 'Palak', '2.00', '3.00', '2020-07-03 13:09:17', '2020-07-05 19:32:13', '', '', 'U', '10.00'),
(210, 12, 26, 'EEE', '16.00', '11.00', '2020-06-29 14:24:18', '2020-07-05 19:33:24', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(211, 22, 26, 'EEE', '10.00', '1.00', '2020-06-29 14:27:57', '2020-07-05 19:33:35', 'abhijitjd003@gmail.com', '', 'U', '1.00'),
(212, 23, 26, 'EEE', '6.00', '10.00', '2020-06-29 14:28:11', '2020-07-05 19:33:46', 'abhijitjd003@gmail.com', '', 'U', '35.00'),
(213, 32, 26, 'EEE', '65.00', '6.00', '2020-06-29 14:30:54', '2020-07-05 19:34:02', 'abhijitjd003@gmail.com', '', 'U', '65.00'),
(214, 33, 26, 'EEE', '18.00', '10.00', '2020-06-29 14:31:10', '2020-07-05 19:34:19', 'abhijitjd003@gmail.com', '', 'U', '20.00'),
(215, 42, 26, 'EEE', '16.00', '10.00', '2020-07-03 08:31:50', '2020-07-05 19:34:32', '', '', 'U', '10.00'),
(216, 43, 26, 'Beetroot', '28.00', '3.00', '2020-07-03 13:02:15', '2020-07-05 19:36:27', '', '', 'U', '10.00'),
(217, 61, 26, 'Sapsige', '2.00', '3.00', '2020-07-05 14:55:16', '2020-07-05 19:37:07', '', '', 'U', '10.00'),
(218, 62, 26, 'Potato', '18.00', '10.00', '2020-07-05 15:30:20', '2020-07-05 19:38:01', '', '', 'U', '10.00'),
(219, 64, 26, 'HAGALKAYI', '35.00', '3.00', '2020-07-05 19:39:44', '2020-07-05 19:41:26', '', '', 'U', '10.00'),
(220, 42, 26, 'EEE', '16.00', '10.00', '2020-07-03 08:31:50', '2020-07-05 19:42:46', '', '', 'U', '10.00'),
(221, 62, 26, 'SEEMEBADANE', '20.00', '10.00', '2020-07-05 15:30:20', '2020-07-05 19:44:37', '', '', 'U', '10.00'),
(222, 62, 26, 'SEEMEBADANE', '20.00', '10.00', '2020-07-05 15:30:20', '2020-07-05 19:45:04', '', '', 'U', '10.00'),
(223, 27, 26, 'BRINJAL(Round)', '6.00', '5.00', '2020-06-29 14:29:17', '2020-07-05 19:46:38', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(224, 27, 26, 'BRINJAL(Round)', '14.00', '5.00', '2020-06-29 14:29:17', '2020-07-05 19:47:05', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(225, 26, 26, 'BRINJAL (Black)', '10.00', '4.00', '2020-06-29 14:29:04', '2020-07-05 19:47:31', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(226, 26, 26, 'BRINJAL (Black)', '16.00', '4.00', '2020-06-29 14:29:04', '2020-07-05 19:47:53', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(227, 20, 26, 'GREEN CHILLIES', '35.00', '5.00', '2020-06-29 14:27:20', '2020-07-05 19:48:54', 'abhijitjd003@gmail.com', '', 'U', '30.00'),
(228, 29, 26, 'MC', '13.00', '15.00', '2020-06-29 14:30:03', '2020-07-05 19:50:13', 'abhijitjd003@gmail.com', '', 'U', '200.00'),
(229, 13, 26, 'TOMATO(Huli)', '12.00', '100.00', '2020-06-29 14:25:12', '2020-07-05 19:51:32', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(230, 14, 26, 'TOMATO(Jamun)', '32.00', '25.00', '2020-06-29 14:25:39', '2020-07-05 19:51:43', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(231, 12, 26, 'EEE', '16.00', '11.00', '2020-06-29 14:24:18', '2020-07-05 20:36:09', 'abhijitjd003@gmail.com', '', 'U', '40.00'),
(232, 22, 26, 'EEE', '10.00', '1.00', '2020-06-29 14:27:57', '2020-07-05 20:36:25', 'abhijitjd003@gmail.com', '', 'U', '1.00'),
(233, 22, 26, 'EEE', '10.00', '1.00', '2020-06-29 14:27:57', '2020-07-05 20:36:36', 'abhijitjd003@gmail.com', '', 'U', '1.00'),
(234, 23, 26, 'EEE', '6.00', '10.00', '2020-06-29 14:28:11', '2020-07-05 20:36:46', 'abhijitjd003@gmail.com', '', 'U', '35.00'),
(235, 32, 26, 'EEE', '65.00', '6.00', '2020-06-29 14:30:54', '2020-07-05 20:37:05', 'abhijitjd003@gmail.com', '', 'U', '65.00'),
(236, 33, 26, 'EEE', '18.00', '10.00', '2020-06-29 14:31:10', '2020-07-05 20:37:16', 'abhijitjd003@gmail.com', '', 'U', '20.00'),
(237, 43, 26, 'EEE', '28.00', '3.00', '2020-07-03 13:02:15', '2020-07-05 20:37:35', '', '', 'U', '10.00'),
(238, 66, 26, 'xyz', '200.00', '10.00', '2020-07-05 21:23:33', '2020-07-05 21:24:34', '', '', 'U', '50.00'),
(239, 13, 26, 'TOMATO(Huli)', '25.00', '100.00', '2020-06-29 14:25:12', '2020-07-06 12:37:42', 'abhijitjd003@gmail.com', '', 'U', '150.00'),
(240, 14, 26, 'TOMATO(Jamun)', '26.00', '25.00', '2020-06-29 14:25:39', '2020-07-06 12:38:02', 'abhijitjd003@gmail.com', '', 'U', '50.00'),
(241, 36, 26, 'THONDEKAI', '18.00', '10.00', '2020-06-29 14:32:02', '2020-07-06 12:47:05', 'abhijitjd003@gmail.com', '', 'U', '25.00'),
(242, 67, 26, 'kothmiri', '3.00', '3.00', '2020-07-06 12:39:51', '2020-07-06 12:47:34', '', '', 'U', '10.00'),
(243, 36, 26, 'THONDEKAI', '18.00', '10.00', '2020-06-29 14:32:02', '2020-07-06 12:48:00', 'abhijitjd003@gmail.com', '', 'U', '25.00'),
(244, 67, 26, 'kothmiri', '3.00', '3.00', '2020-07-06 12:39:51', '2020-07-06 12:48:30', '', '', 'U', '10.00'),
(245, 12, 26, 'EEE', '16.00', '11.00', '2020-06-29 14:24:18', '2020-07-06 12:49:04', 'abhijitjd003@gmail.com', 'null', 'D', '40.00'),
(246, 22, 26, 'EEE', '10.00', '1.00', '2020-06-29 14:27:57', '2020-07-06 12:49:13', 'abhijitjd003@gmail.com', 'null', 'D', '1.00'),
(247, 23, 26, 'EEE', '6.00', '10.00', '2020-06-29 14:28:11', '2020-07-06 12:49:19', 'abhijitjd003@gmail.com', 'null', 'D', '35.00'),
(248, 25, 26, 'BRINJAL (White)', '12.00', '8.00', '2020-06-29 14:28:47', '2020-07-06 12:53:52', 'abhijitjd003@gmail.com', '', 'U', '80.00'),
(249, 16, 26, 'SMALL ONION', '15.00', '25.00', '2020-06-29 14:26:10', '2020-07-06 12:54:01', 'abhijitjd003@gmail.com', '', 'U', '65.00'),
(250, 69, 26, 'Pudina', '3.00', '3.00', '2020-07-06 12:40:50', '2020-07-06 12:56:50', '', '', 'U', '10.00'),
(251, 67, 26, 'kothmiri', '3.00', '3.00', '2020-07-06 12:39:51', '2020-07-06 12:57:23', '', '', 'U', '10.00'),
(252, 68, 26, 'Karibevu', '1.50', '3.00', '2020-07-06 12:40:25', '2020-07-06 12:57:41', '', '', 'U', '10.00'),
(253, 69, 26, 'Pudina', '3.00', '3.00', '2020-07-06 12:40:50', '2020-07-06 12:58:09', '', '', 'U', '10.00'),
(254, 71, 26, 'sapsige', '2.00', '3.00', '2020-07-06 12:41:52', '2020-07-06 12:58:32', '', '', 'U', '10.00'),
(255, 70, 26, 'Palak', '2.00', '3.00', '2020-07-06 12:41:13', '2020-07-06 12:58:51', '', '', 'U', '10.00'),
(256, 66, 26, 'xyz', '200.00', '10.00', '2020-07-05 21:23:33', '2020-07-06 13:00:43', '', 'null', 'D', '50.00'),
(257, 33, 26, 'EEE', '18.00', '10.00', '2020-06-29 14:31:10', '2020-07-06 13:00:51', 'abhijitjd003@gmail.com', 'null', 'D', '20.00'),
(258, 32, 26, 'EEE', '65.00', '6.00', '2020-06-29 14:30:54', '2020-07-06 13:01:02', 'abhijitjd003@gmail.com', 'null', 'D', '65.00'),
(259, 43, 26, 'EEE', '28.00', '3.00', '2020-07-03 13:02:15', '2020-07-06 13:01:11', '', 'null', 'D', '10.00'),
(260, 18, 26, 'GARLIC', '80.00', '5.00', '2020-06-29 14:26:45', '2020-07-07 01:54:05', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'U', '25.00'),
(261, 19, 26, 'GINGER', '60.00', '5.00', '2020-06-29 14:27:04', '2020-07-07 01:55:31', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'U', '30.00'),
(262, 13, 26, 'TOMATO(Huli)', '28.00', '100.00', '2020-06-29 14:25:12', '2020-07-08 14:53:35', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(263, 47, 26, 'SOREKAI', '12.00', '3.00', '2020-07-03 13:09:17', '2020-07-08 14:54:09', '', 'test@gmail.com', 'U', '10.00'),
(264, 16, 26, 'SMALL ONION', '15.00', '25.00', '2020-06-29 14:26:10', '2020-07-08 14:54:45', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(265, 62, 26, 'SEEMEBADANE', '20.00', '10.00', '2020-07-05 15:30:20', '2020-07-08 14:55:21', '', 'test@gmail.com', 'U', '10.00'),
(266, 46, 26, 'PADUVALKAYI', '12.00', '3.00', '2020-07-03 13:08:54', '2020-07-08 14:55:30', '', 'test@gmail.com', 'U', '10.00'),
(267, 15, 26, 'ONION', '12.00', '20.00', '2020-06-29 14:25:53', '2020-07-08 14:55:43', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(268, 35, 26, 'MULANGI', '18.00', '20.00', '2020-06-29 14:31:43', '2020-07-08 14:57:05', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(269, 29, 26, 'MC', '6.00', '15.00', '2020-06-29 14:30:03', '2020-07-08 14:57:16', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(270, 21, 26, 'LEMON', '45.00', '10.00', '2020-06-29 14:27:39', '2020-07-08 14:57:27', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(271, 63, 26, 'KHOL KHOL', '18.00', '5.00', '2020-07-05 19:38:57', '2020-07-08 14:58:34', '', 'test@gmail.com', 'U', '10.00'),
(272, 45, 26, 'HEEREKAI', '25.00', '3.00', '2020-07-03 13:08:28', '2020-07-08 14:58:52', '', 'test@gmail.com', 'U', '10.00'),
(273, 64, 26, 'HAGALKAYI', '35.00', '3.00', '2020-07-05 19:39:44', '2020-07-08 14:59:21', '', 'test@gmail.com', 'U', '10.00'),
(274, 20, 26, 'GREEN CHILLIES', '30.00', '5.00', '2020-06-29 14:27:20', '2020-07-08 14:59:32', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(275, 19, 26, 'GINGER', '60.00', '6.00', '2020-06-29 14:27:04', '2020-07-08 14:59:44', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(276, 18, 26, 'GARLIC', '80.00', '5.00', '2020-06-29 14:26:45', '2020-07-08 14:59:55', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(277, 28, 26, 'CUCUMBER', '10.00', '10.00', '2020-06-29 14:29:29', '2020-07-08 15:00:08', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(278, 31, 26, 'CAULIFLOWER', '18.00', '15.00', '2020-06-29 14:30:35', '2020-07-08 15:00:17', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '70.00'),
(279, 9, 26, 'CARROT', '32.00', '10.00', '2020-06-29 14:22:41', '2020-07-08 15:00:26', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '100.00'),
(280, 10, 26, 'CAPSICUM', '60.00', '8.00', '2020-06-29 14:22:59', '2020-07-08 15:00:34', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '75.00'),
(281, 30, 26, 'CABBAGE', '12.00', '8.00', '2020-06-29 14:30:17', '2020-07-08 15:00:44', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(282, 26, 26, 'BRINJAL (Black)', '16.00', '4.00', '2020-06-29 14:29:04', '2020-07-08 15:01:29', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(283, 27, 26, 'BRINJAL(Round)', '14.00', '5.00', '2020-06-29 14:29:17', '2020-07-08 15:01:40', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(284, 25, 26, 'BRINJAL (White)', '12.00', '8.00', '2020-06-29 14:28:47', '2020-07-08 15:01:52', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(285, 34, 26, 'BENDI', '13.00', '20.00', '2020-06-29 14:31:27', '2020-07-08 15:02:10', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(286, 61, 26, 'BEETROOT', '28.00', '3.00', '2020-07-05 14:55:16', '2020-07-08 15:02:19', '', 'test@gmail.com', 'U', '10.00'),
(287, 8, 26, 'Beans(OOTY)', '25.00', '3.00', '2020-06-29 14:22:19', '2020-07-08 15:02:31', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(288, 7, 26, 'Beans', '18.00', '5.00', '2020-06-29 14:21:54', '2020-07-08 15:02:42', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(289, 70, 26, 'Palak', '2.00', '3.00', '2020-07-06 12:41:13', '2020-07-08 15:03:11', '', 'test@gmail.com', 'U', '10.00'),
(290, 69, 26, 'Pudina', '3.00', '3.00', '2020-07-06 12:40:50', '2020-07-08 15:03:20', '', 'test@gmail.com', 'U', '10.00'),
(291, 71, 26, 'sapsige', '2.00', '3.00', '2020-07-06 12:41:52', '2020-07-08 15:04:39', '', 'test@gmail.com', 'U', '10.00'),
(292, 68, 26, 'Karibevu', '1.50', '3.00', '2020-07-06 12:40:25', '2020-07-08 15:27:11', '', 'test@gmail.com', 'U', '10.00'),
(293, 36, 26, 'THONDEKAI', '18.00', '10.00', '2020-06-29 14:32:02', '2020-07-08 15:31:21', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(294, 44, 26, 'DRUMSTICK', '40.00', '3.00', '2020-07-03 13:08:04', '2020-07-08 15:31:59', '', 'test@gmail.com', 'U', '10.00'),
(295, 65, 26, 'PUMPKIN', '12.00', '3.00', '2020-07-05 19:44:05', '2020-07-08 15:33:08', '', 'test@gmail.com', 'U', '10.00'),
(296, 68, 26, 'Karibevu', '2.50', '3.00', '2020-07-06 12:40:25', '2020-07-08 15:34:49', '', 'test@gmail.com', 'U', '10.00'),
(297, 67, 26, 'kothmiri', '3.00', '3.00', '2020-07-06 12:39:51', '2020-07-08 15:34:58', '', 'test@gmail.com', 'U', '10.00'),
(298, 71, 26, 'sapsige', '2.50', '3.00', '2020-07-06 12:41:52', '2020-07-08 15:35:11', '', 'test@gmail.com', 'U', '10.00'),
(299, 69, 26, 'Pudina', '3.00', '3.00', '2020-07-06 12:40:50', '2020-07-08 15:35:18', '', 'test@gmail.com', 'U', '10.00'),
(300, 70, 26, 'Palak', '2.50', '3.00', '2020-07-06 12:41:13', '2020-07-08 15:35:25', '', 'test@gmail.com', 'U', '10.00'),
(301, 36, 26, 'THONDEKAI', '15.00', '10.00', '2020-06-29 14:32:02', '2020-07-08 15:35:33', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(302, 14, 26, 'TOMATO(Jamun)', '29.00', '25.00', '2020-06-29 14:25:39', '2020-07-08 15:35:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(303, 13, 26, 'TOMATO(Huli)', '29.00', '100.00', '2020-06-29 14:25:12', '2020-07-08 15:35:48', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(304, 47, 26, 'SOREKAI', '14.00', '3.00', '2020-07-03 13:09:17', '2020-07-08 15:35:54', '', 'test@gmail.com', 'U', '10.00'),
(305, 16, 26, 'SMALL ONION', '45.00', '25.00', '2020-06-29 14:26:10', '2020-07-08 15:36:03', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(306, 62, 26, 'SEEMEBADANE', '22.00', '10.00', '2020-07-05 15:30:20', '2020-07-08 15:36:08', '', 'test@gmail.com', 'U', '10.00'),
(307, 46, 26, 'PADUVALKAYI', '13.00', '3.00', '2020-07-03 13:08:54', '2020-07-08 15:36:16', '', 'test@gmail.com', 'U', '10.00'),
(308, 15, 26, 'ONION', '13.00', '20.00', '2020-06-29 14:25:53', '2020-07-08 15:36:24', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(309, 44, 26, 'DRUMSTICK', '43.00', '3.00', '2020-07-03 13:08:04', '2020-07-08 15:36:34', '', 'test@gmail.com', 'U', '10.00'),
(310, 35, 26, 'MULANGI', '14.00', '20.00', '2020-06-29 14:31:43', '2020-07-08 15:36:40', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(311, 29, 26, 'MC', '8.00', '15.00', '2020-06-29 14:30:03', '2020-07-08 15:37:04', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(312, 21, 26, 'LEMON', '49.00', '10.00', '2020-06-29 14:27:39', '2020-07-08 15:37:12', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(313, 65, 26, 'PUMPKIN', '11.00', '3.00', '2020-07-05 19:44:05', '2020-07-08 15:37:26', '', 'test@gmail.com', 'U', '10.00'),
(314, 63, 26, 'KHOL KHOL', '16.00', '5.00', '2020-07-05 19:38:57', '2020-07-08 15:37:34', '', 'test@gmail.com', 'U', '10.00'),
(315, 45, 26, 'HEEREKAI', '26.00', '3.00', '2020-07-03 13:08:28', '2020-07-08 15:37:49', '', 'test@gmail.com', 'U', '10.00'),
(316, 64, 26, 'HAGALKAYI', '26.00', '3.00', '2020-07-05 19:39:44', '2020-07-08 15:38:18', '', 'test@gmail.com', 'U', '10.00'),
(317, 20, 26, 'GREEN CHILLIES', '35.00', '5.00', '2020-06-29 14:27:20', '2020-07-08 15:38:29', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(318, 19, 26, 'GINGER', '60.00', '6.00', '2020-06-29 14:27:04', '2020-07-08 15:38:37', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(319, 28, 26, 'CUCUMBER', '12.00', '10.00', '2020-06-29 14:29:29', '2020-07-08 15:38:44', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(320, 31, 26, 'CAULIFLOWER', '18.00', '15.00', '2020-06-29 14:30:35', '2020-07-08 15:38:51', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '70.00'),
(321, 9, 26, 'CARROT', '33.00', '10.00', '2020-06-29 14:22:41', '2020-07-08 15:38:56', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '100.00'),
(322, 10, 26, 'CAPSICUM', '60.00', '8.00', '2020-06-29 14:22:59', '2020-07-08 15:39:03', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '75.00'),
(323, 30, 26, 'CABBAGE', '12.00', '8.00', '2020-06-29 14:30:17', '2020-07-08 15:39:09', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(324, 26, 26, 'BRINJAL (Black)', '18.00', '4.00', '2020-06-29 14:29:04', '2020-07-08 15:39:23', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(325, 27, 26, 'BRINJAL(Round)', '14.00', '5.00', '2020-06-29 14:29:17', '2020-07-08 15:39:31', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(326, 25, 26, 'BRINJAL (White)', '16.00', '8.00', '2020-06-29 14:28:47', '2020-07-08 15:39:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(327, 25, 26, 'BRINJAL (White)', '16.00', '8.00', '2020-06-29 14:28:47', '2020-07-08 15:39:56', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(328, 34, 26, 'BENDI', '14.00', '20.00', '2020-06-29 14:31:27', '2020-07-08 15:40:25', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(329, 61, 26, 'BEETROOT', '28.00', '3.00', '2020-07-05 14:55:16', '2020-07-08 15:40:55', '', 'test@gmail.com', 'U', '10.00'),
(330, 8, 26, 'Beans(OOTY)', '25.00', '3.00', '2020-06-29 14:22:19', '2020-07-08 15:41:11', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(331, 7, 26, 'Beans', '20.00', '5.00', '2020-06-29 14:21:54', '2020-07-08 15:41:36', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(332, 11, 26, 'POTATO', '14.00', '7.00', '2020-06-29 14:23:51', '2020-07-08 15:42:06', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(333, 24, 26, 'BRINJAL(Long)', '16.00', '4.00', '2020-06-29 14:28:32', '2020-07-08 15:47:18', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(334, 16, 26, 'SMALL ONION', '45.00', '25.00', '2020-06-29 14:26:10', '2020-07-08 15:50:55', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(335, 25, 26, 'BRINJAL (White)', '16.00', '8.00', '2020-06-29 14:28:47', '2020-07-08 15:52:59', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(336, 24, 26, 'BRINJAL(Long)', '16.00', '4.00', '2020-06-29 14:28:32', '2020-07-08 15:58:43', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(337, 24, 26, 'BRINJAL(Long)', '16.00', '4.00', '2020-06-29 14:28:32', '2020-07-08 15:59:35', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(338, 42, 26, 'HALSANDE', '30.00', '10.00', '2020-07-03 08:31:50', '2020-07-08 15:59:57', '', 'test@gmail.com', 'U', '10.00'),
(339, 25, 26, 'BRINJAL (White)', '16.00', '8.00', '2020-06-29 14:28:47', '2020-07-08 16:00:36', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(340, 68, 26, 'Karibevu', '2.50', '3.00', '2020-07-06 12:40:25', '2020-07-09 04:32:21', '', 'test@gmail.com', 'U', '10.00'),
(341, 67, 26, 'kothmiri', '3.00', '3.00', '2020-07-06 12:39:51', '2020-07-09 04:32:33', '', 'test@gmail.com', 'U', '10.00'),
(342, 71, 26, 'sapsige', '2.50', '3.00', '2020-07-06 12:41:52', '2020-07-09 04:32:38', '', 'test@gmail.com', 'U', '10.00'),
(343, 69, 26, 'Pudina', '3.00', '3.00', '2020-07-06 12:40:50', '2020-07-09 04:32:44', '', 'test@gmail.com', 'U', '10.00'),
(344, 70, 26, 'Palak', '2.50', '3.00', '2020-07-06 12:41:13', '2020-07-09 04:32:53', '', 'test@gmail.com', 'U', '10.00'),
(345, 36, 26, 'THONDEKAI', '15.00', '10.00', '2020-06-29 14:32:02', '2020-07-09 04:33:00', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(346, 14, 26, 'TOMATO(Jamun)', '29.00', '25.00', '2020-06-29 14:25:39', '2020-07-09 04:33:07', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(347, 13, 26, 'TOMATO(Huli)', '29.00', '100.00', '2020-06-29 14:25:12', '2020-07-09 04:33:17', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(348, 47, 26, 'SOREKAI', '14.00', '3.00', '2020-07-03 13:09:17', '2020-07-09 04:33:25', '', 'test@gmail.com', 'U', '10.00'),
(349, 16, 26, 'SMALL ONION', '45.00', '25.00', '2020-06-29 14:26:10', '2020-07-09 04:33:31', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(350, 62, 26, 'SEEMEBADANE', '22.00', '10.00', '2020-07-05 15:30:20', '2020-07-09 04:33:38', '', 'test@gmail.com', 'U', '10.00'),
(351, 46, 26, 'PADUVALKAYI', '13.00', '3.00', '2020-07-03 13:08:54', '2020-07-09 04:33:47', '', 'test@gmail.com', 'U', '10.00'),
(352, 15, 26, 'ONION', '13.00', '20.00', '2020-06-29 14:25:53', '2020-07-09 04:33:53', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(353, 44, 26, 'DRUMSTICK', '43.00', '3.00', '2020-07-03 13:08:04', '2020-07-09 04:33:59', '', 'test@gmail.com', 'U', '10.00'),
(354, 29, 26, 'MC', '8.00', '15.00', '2020-06-29 14:30:03', '2020-07-09 04:34:05', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(355, 21, 26, 'LEMON', '49.00', '10.00', '2020-06-29 14:27:39', '2020-07-09 04:34:14', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(356, 65, 26, 'PUMPKIN', '11.00', '3.00', '2020-07-05 19:44:05', '2020-07-09 04:34:22', '', 'test@gmail.com', 'U', '10.00'),
(357, 63, 26, 'KHOL KHOL', '16.00', '5.00', '2020-07-05 19:38:57', '2020-07-09 04:34:28', '', 'test@gmail.com', 'U', '10.00'),
(358, 45, 26, 'HEEREKAI', '26.00', '3.00', '2020-07-03 13:08:28', '2020-07-09 04:34:35', '', 'test@gmail.com', 'U', '10.00'),
(359, 64, 26, 'HAGALKAYI', '36.00', '3.00', '2020-07-05 19:39:44', '2020-07-09 04:34:54', '', 'test@gmail.com', 'U', '10.00'),
(360, 20, 26, 'GREEN CHILLIES', '35.00', '5.00', '2020-06-29 14:27:20', '2020-07-09 04:34:59', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(361, 19, 26, 'GINGER', '60.00', '6.00', '2020-06-29 14:27:04', '2020-07-09 04:35:08', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(362, 18, 26, 'GARLIC', '80.00', '5.00', '2020-06-29 14:26:45', '2020-07-09 04:35:15', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(363, 28, 26, 'CUCUMBER', '12.00', '10.00', '2020-06-29 14:29:29', '2020-07-09 04:35:22', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(364, 31, 26, 'CAULIFLOWER', '18.00', '15.00', '2020-06-29 14:30:35', '2020-07-09 04:35:29', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '70.00'),
(365, 9, 26, 'CARROT', '33.00', '10.00', '2020-06-29 14:22:41', '2020-07-09 04:35:35', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '100.00'),
(366, 10, 26, 'CAPSICUM', '60.00', '8.00', '2020-06-29 14:22:59', '2020-07-09 04:35:43', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '75.00'),
(367, 30, 26, 'CABBAGE', '12.00', '8.00', '2020-06-29 14:30:17', '2020-07-09 04:35:50', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(368, 26, 26, 'BRINJAL (Black)', '18.00', '4.00', '2020-06-29 14:29:04', '2020-07-09 04:36:03', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(369, 27, 26, 'BRINJAL(Round)', '14.00', '5.00', '2020-06-29 14:29:17', '2020-07-09 04:36:12', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(370, 25, 26, 'BRINJAL (White)', '16.00', '8.00', '2020-06-29 14:28:47', '2020-07-09 04:36:19', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(371, 34, 26, 'BENDI', '14.00', '20.00', '2020-06-29 14:31:27', '2020-07-09 04:36:25', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(372, 61, 26, 'BEETROOT', '28.00', '3.00', '2020-07-05 14:55:16', '2020-07-09 04:36:33', '', 'test@gmail.com', 'U', '10.00'),
(373, 8, 26, 'Beans(OOTY)', '25.00', '3.00', '2020-06-29 14:22:19', '2020-07-09 04:36:40', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(374, 7, 26, 'Beans', '20.00', '5.00', '2020-06-29 14:21:54', '2020-07-09 04:36:48', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(375, 11, 26, 'POTATO', '29.00', '7.00', '2020-06-29 14:23:51', '2020-07-09 04:36:56', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(376, 11, 26, 'POTATO', '29.00', '7.00', '2020-06-29 14:23:51', '2020-07-09 14:11:02', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(377, 7, 26, 'Beans', '20.00', '5.00', '2020-06-29 14:21:54', '2020-07-09 14:11:07', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(378, 8, 26, 'Beans(OOTY)', '25.00', '3.00', '2020-06-29 14:22:19', '2020-07-09 14:11:18', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(379, 61, 26, 'BEETROOT', '28.00', '3.00', '2020-07-05 14:55:16', '2020-07-09 14:11:25', '', 'test@gmail.com', 'U', '10.00'),
(380, 72, 26, 'Balekayi', '10.00', '1.00', '2020-07-09 14:18:36', '2020-07-09 14:19:33', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(381, 42, 26, 'HALSANDE', '30.00', '10.00', '2020-07-03 08:31:50', '2020-07-09 14:24:54', '', 'test@gmail.com', 'U', '10.00'),
(382, 73, 26, 'Methya Soppu', '3.00', '1.00', '2020-07-09 14:25:43', '2020-07-09 14:26:21', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(383, 24, 26, 'BRINJAL(Long)', '16.00', '4.00', '2020-06-29 14:28:32', '2020-07-09 14:33:50', 'abhijitjd003@gmail.com', 'test@gmail.com', 'D', '25.00'),
(384, 72, 26, 'Balekayi', '10.00', '1.00', '2020-07-09 14:18:36', '2020-07-09 14:34:00', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(385, 73, 26, 'Methya Soppu', '3.00', '1.00', '2020-07-09 14:25:43', '2020-07-09 14:34:08', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(386, 71, 26, 'sapsige', '2.50', '3.00', '2020-07-06 12:41:52', '2020-07-09 14:34:31', '', 'test@gmail.com', 'U', '10.00'),
(387, 70, 26, 'Palak', '2.50', '3.00', '2020-07-06 12:41:13', '2020-07-09 14:35:09', '', 'test@gmail.com', 'U', '10.00'),
(388, 67, 26, 'kothmiri', '3.00', '3.00', '2020-07-06 12:39:51', '2020-07-09 14:35:30', '', 'test@gmail.com', 'U', '10.00'),
(389, 69, 26, 'Pudina', '3.00', '3.00', '2020-07-06 12:40:50', '2020-07-09 14:35:40', '', 'test@gmail.com', 'U', '10.00'),
(390, 68, 26, 'Karibevu', '2.50', '3.00', '2020-07-06 12:40:25', '2020-07-09 14:35:53', '', 'test@gmail.com', 'U', '10.00'),
(391, 42, 26, 'HALSANDE', '30.00', '10.00', '2020-07-03 08:31:50', '2020-07-09 14:36:22', '', 'test@gmail.com', 'U', '10.00'),
(392, 36, 26, 'THONDEKAI', '15.00', '10.00', '2020-06-29 14:32:02', '2020-07-09 14:37:04', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(393, 14, 26, 'TOMATO(Jamun)', '32.00', '25.00', '2020-06-29 14:25:39', '2020-07-09 14:37:16', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(394, 13, 26, 'TOMATO(Huli)', '32.00', '100.00', '2020-06-29 14:25:12', '2020-07-09 14:37:35', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(395, 47, 26, 'SOREKAI', '14.00', '3.00', '2020-07-03 13:09:17', '2020-07-09 14:37:57', '', 'test@gmail.com', 'U', '10.00'),
(396, 16, 26, 'SMALL ONION', '45.00', '25.00', '2020-06-29 14:26:10', '2020-07-09 14:38:09', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(397, 62, 26, 'SEEMEBADANE', '22.00', '10.00', '2020-07-05 15:30:20', '2020-07-09 14:38:18', '', 'test@gmail.com', 'U', '10.00'),
(398, 46, 26, 'PADUVALKAYI', '13.00', '3.00', '2020-07-03 13:08:54', '2020-07-09 14:38:26', '', 'test@gmail.com', 'U', '10.00');
INSERT INTO `ProductHistory` (`ProductHistId`, `ProductId`, `CategoryId`, `Name`, `RatePerKG`, `MinPurchaseQuantity`, `CreatedDateTime`, `UpdatedDateTime`, `CreatedUserId`, `UpdatedUserId`, `StatusCode`, `TotalStock`) VALUES
(399, 15, 26, 'ONION', '13.00', '20.00', '2020-06-29 14:25:53', '2020-07-09 14:38:32', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(400, 44, 26, 'DRUMSTICK', '43.00', '3.00', '2020-07-03 13:08:04', '2020-07-09 14:38:43', '', 'test@gmail.com', 'U', '10.00'),
(401, 35, 26, 'MULANGI', '14.00', '20.00', '2020-06-29 14:31:43', '2020-07-09 14:38:56', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(402, 29, 26, 'MC', '9.00', '15.00', '2020-06-29 14:30:03', '2020-07-09 14:39:11', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(403, 21, 26, 'LEMON', '49.00', '10.00', '2020-06-29 14:27:39', '2020-07-09 14:39:19', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(404, 65, 26, 'PUMPKIN', '11.00', '3.00', '2020-07-05 19:44:05', '2020-07-09 14:39:33', '', 'test@gmail.com', 'U', '10.00'),
(405, 63, 26, 'KHOL KHOL', '16.00', '5.00', '2020-07-05 19:38:57', '2020-07-09 14:39:47', '', 'test@gmail.com', 'U', '10.00'),
(406, 45, 26, 'HEEREKAI', '26.00', '3.00', '2020-07-03 13:08:28', '2020-07-09 14:39:53', '', 'test@gmail.com', 'U', '10.00'),
(407, 64, 26, 'HAGALKAYI', '36.00', '3.00', '2020-07-05 19:39:44', '2020-07-09 14:39:59', '', 'test@gmail.com', 'U', '10.00'),
(408, 20, 26, 'GREEN CHILLIES', '35.00', '5.00', '2020-06-29 14:27:20', '2020-07-09 14:40:04', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(409, 19, 26, 'GINGER', '60.00', '6.00', '2020-06-29 14:27:04', '2020-07-09 14:40:10', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(410, 18, 26, 'GARLIC', '80.00', '5.00', '2020-06-29 14:26:45', '2020-07-09 14:40:21', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(411, 28, 26, 'CUCUMBER', '12.00', '10.00', '2020-06-29 14:29:29', '2020-07-09 14:40:30', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(412, 31, 26, 'CAULIFLOWER', '18.00', '15.00', '2020-06-29 14:30:35', '2020-07-09 14:40:36', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '70.00'),
(413, 9, 26, 'CARROT', '33.00', '10.00', '2020-06-29 14:22:41', '2020-07-09 14:40:49', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '100.00'),
(414, 10, 26, 'CAPSICUM', '62.00', '8.00', '2020-06-29 14:22:59', '2020-07-09 14:41:00', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '75.00'),
(415, 30, 26, 'CABBAGE', '12.00', '8.00', '2020-06-29 14:30:17', '2020-07-09 14:41:07', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(416, 26, 26, 'BRINJAL (Black)', '18.00', '4.00', '2020-06-29 14:29:04', '2020-07-09 14:41:20', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(417, 27, 26, 'BRINJAL(Round)', '14.00', '5.00', '2020-06-29 14:29:17', '2020-07-09 14:41:27', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(418, 25, 26, 'BRINJAL (White)', '16.00', '8.00', '2020-06-29 14:28:47', '2020-07-09 14:41:39', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(419, 34, 26, 'BENDI', '14.00', '20.00', '2020-06-29 14:31:27', '2020-07-09 14:41:54', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(420, 61, 26, 'BEETROOT', '28.00', '3.00', '2020-07-05 14:55:16', '2020-07-09 14:42:04', '', 'test@gmail.com', 'U', '10.00'),
(421, 8, 26, 'Beans(OOTY)', '25.00', '3.00', '2020-06-29 14:22:19', '2020-07-09 14:42:11', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(422, 7, 26, 'Beans', '20.00', '5.00', '2020-06-29 14:21:54', '2020-07-09 14:42:16', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(423, 11, 26, 'POTATO', '29.00', '7.00', '2020-06-29 14:23:51', '2020-07-09 14:42:22', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(424, 72, 26, 'Balekayi', '10.00', '1.00', '2020-07-09 14:18:36', '2020-07-10 15:00:27', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(425, 73, 26, 'Methya Soppu', '3.00', '1.00', '2020-07-09 14:25:43', '2020-07-10 15:01:09', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(426, 71, 26, 'Sabsige', '2.50', '3.00', '2020-07-06 12:41:52', '2020-07-10 15:01:33', '', 'test@gmail.com', 'U', '10.00'),
(427, 70, 26, 'Palak', '3.00', '3.00', '2020-07-06 12:41:13', '2020-07-10 15:01:53', '', 'test@gmail.com', 'U', '10.00'),
(428, 67, 26, 'Kothmiri', '3.00', '3.00', '2020-07-06 12:39:51', '2020-07-10 15:02:17', '', 'test@gmail.com', 'U', '10.00'),
(429, 69, 26, 'Pudina / Mint Leaves', '3.00', '3.00', '2020-07-06 12:40:50', '2020-07-10 15:02:31', '', 'test@gmail.com', 'U', '10.00'),
(430, 68, 26, 'Karibevu / Curry Leaves', '4.00', '3.00', '2020-07-06 12:40:25', '2020-07-10 15:02:57', '', 'test@gmail.com', 'U', '10.00'),
(431, 42, 26, 'HALSANDE', '30.00', '10.00', '2020-07-03 08:31:50', '2020-07-10 15:03:15', '', 'test@gmail.com', 'U', '10.00'),
(432, 36, 26, 'THONDEKAI / IVY GOURD', '15.00', '10.00', '2020-06-29 14:32:02', '2020-07-10 15:03:32', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(433, 14, 26, 'TOMATO(Jamun)', '33.00', '25.00', '2020-06-29 14:25:39', '2020-07-10 15:03:53', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(434, 13, 26, 'TOMATO(Huli)', '32.00', '100.00', '2020-06-29 14:25:12', '2020-07-10 15:04:16', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(435, 47, 26, 'SOREKAI / BOTTLE GOURD', '15.00', '3.00', '2020-07-03 13:09:17', '2020-07-10 15:04:35', '', 'test@gmail.com', 'U', '10.00'),
(436, 16, 26, 'SMALL ONION', '45.00', '25.00', '2020-06-29 14:26:10', '2020-07-10 15:04:59', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(437, 62, 26, 'SEEMEBADANE', '18.00', '10.00', '2020-07-05 15:30:20', '2020-07-10 15:05:18', '', 'test@gmail.com', 'U', '10.00'),
(438, 46, 26, 'PADUVALKAYI', '18.00', '3.00', '2020-07-03 13:08:54', '2020-07-10 15:05:39', '', 'test@gmail.com', 'U', '10.00'),
(439, 15, 26, 'ONION', '13.00', '20.00', '2020-06-29 14:25:53', '2020-07-10 15:05:51', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(440, 44, 26, 'DRUMSTICK', '45.00', '3.00', '2020-07-03 13:08:04', '2020-07-10 15:06:09', '', 'test@gmail.com', 'U', '10.00'),
(441, 35, 26, 'MULANGI / Raddish', '16.00', '20.00', '2020-06-29 14:31:43', '2020-07-10 15:06:25', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(442, 29, 26, 'Mangalore CUCUMBER', '9.00', '15.00', '2020-06-29 14:30:03', '2020-07-10 15:06:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(443, 21, 26, 'LEMON', '49.00', '10.00', '2020-06-29 14:27:39', '2020-07-10 15:06:56', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(444, 65, 26, 'PUMPKIN', '11.00', '3.00', '2020-07-05 19:44:05', '2020-07-10 15:07:17', '', 'test@gmail.com', 'U', '10.00'),
(445, 63, 26, 'KHOL KHOL', '18.00', '5.00', '2020-07-05 19:38:57', '2020-07-10 15:07:39', '', 'test@gmail.com', 'U', '10.00'),
(446, 45, 26, 'HEEREKAI', '26.00', '3.00', '2020-07-03 13:08:28', '2020-07-10 15:07:56', '', 'test@gmail.com', 'U', '10.00'),
(447, 64, 26, 'HAGALKAYI', '36.00', '3.00', '2020-07-05 19:39:44', '2020-07-10 15:08:16', '', 'test@gmail.com', 'U', '10.00'),
(448, 20, 26, 'GREEN CHILLIES', '35.00', '5.00', '2020-06-29 14:27:20', '2020-07-10 15:08:35', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(449, 19, 26, 'GINGER', '60.00', '6.00', '2020-06-29 14:27:04', '2020-07-10 15:08:58', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(450, 18, 26, 'GARLIC', '75.00', '5.00', '2020-06-29 14:26:45', '2020-07-10 15:09:08', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(451, 28, 26, 'CUCUMBER', '15.00', '10.00', '2020-06-29 14:29:29', '2020-07-10 15:09:24', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(452, 31, 26, 'CAULIFLOWER', '18.00', '15.00', '2020-06-29 14:30:35', '2020-07-10 15:09:47', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '70.00'),
(453, 9, 26, 'CARROT', '33.00', '10.00', '2020-06-29 14:22:41', '2020-07-10 15:09:59', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '100.00'),
(454, 10, 26, 'CAPSICUM', '65.00', '8.00', '2020-06-29 14:22:59', '2020-07-10 15:10:15', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '75.00'),
(455, 30, 26, 'CABBAGE', '12.00', '8.00', '2020-06-29 14:30:17', '2020-07-10 15:10:28', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(456, 26, 26, 'BRINJAL (Black)', '16.00', '4.00', '2020-06-29 14:29:04', '2020-07-10 15:11:58', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(457, 27, 26, 'BRINJAL(Round)', '16.00', '5.00', '2020-06-29 14:29:17', '2020-07-10 15:12:19', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(458, 25, 26, 'BRINJAL (Long)', '16.00', '8.00', '2020-06-29 14:28:47', '2020-07-10 15:12:38', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(459, 34, 26, 'BENDI / Ladies FINGER', '15.00', '20.00', '2020-06-29 14:31:27', '2020-07-10 15:13:04', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(460, 61, 26, 'BEETROOT', '28.00', '3.00', '2020-07-05 14:55:16', '2020-07-10 15:13:15', '', 'test@gmail.com', 'U', '10.00'),
(461, 8, 26, 'Beans(OOTY)', '25.00', '3.00', '2020-06-29 14:22:19', '2020-07-10 15:13:31', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(462, 7, 26, 'Beans', '20.00', '5.00', '2020-06-29 14:21:54', '2020-07-10 15:13:54', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(463, 11, 26, 'POTATO', '29.00', '7.00', '2020-06-29 14:23:51', '2020-07-10 15:14:12', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(464, 26, 26, 'BRINJAL (Black)', '16.00', '4.00', '2020-06-29 14:29:04', '2020-07-10 15:26:15', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(465, 27, 26, 'BRINJAL(Round)', '14.00', '5.00', '2020-06-29 14:29:17', '2020-07-10 15:26:51', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(466, 25, 26, 'BRINJAL (Long)', '16.00', '8.00', '2020-06-29 14:28:47', '2020-07-10 15:27:29', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(467, 34, 26, 'BENDI / Ladies FINGER', '13.00', '20.00', '2020-06-29 14:31:27', '2020-07-10 15:27:53', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(468, 61, 26, 'BEETROOT', '28.00', '3.00', '2020-07-05 14:55:16', '2020-07-10 15:28:04', '', 'test@gmail.com', 'U', '10.00'),
(469, 8, 26, 'Beans(OOTY)', '25.00', '3.00', '2020-06-29 14:22:19', '2020-07-10 15:28:12', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(470, 7, 26, 'Beans', '20.00', '5.00', '2020-06-29 14:21:54', '2020-07-10 15:28:23', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(471, 11, 26, 'POTATO', '39.00', '7.00', '2020-06-29 14:23:51', '2020-07-10 15:28:31', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(472, 11, 26, 'POTATO', '39.00', '7.00', '2020-06-29 14:23:51', '2020-07-10 15:44:15', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(473, 72, 26, 'Balekayi', '8.00', '1.00', '2020-07-09 14:18:36', '2020-07-11 13:47:52', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(474, 73, 26, 'Methya Soppu', '4.50', '1.00', '2020-07-09 14:25:43', '2020-07-11 13:48:11', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(475, 71, 26, 'Sabsige', '3.00', '3.00', '2020-07-06 12:41:52', '2020-07-11 13:48:25', '', 'test@gmail.com', 'U', '10.00'),
(476, 70, 26, 'Palak', '3.00', '3.00', '2020-07-06 12:41:13', '2020-07-11 13:48:35', '', 'test@gmail.com', 'U', '10.00'),
(477, 67, 26, 'Kothmiri', '4.00', '3.00', '2020-07-06 12:39:51', '2020-07-11 13:48:50', '', 'test@gmail.com', 'U', '10.00'),
(478, 69, 26, 'Pudina / Mint Leaves', '3.00', '3.00', '2020-07-06 12:40:50', '2020-07-11 13:49:22', '', 'test@gmail.com', 'U', '10.00'),
(479, 68, 26, 'Karibevu / Curry Leaves', '2.50', '3.00', '2020-07-06 12:40:25', '2020-07-11 13:49:39', '', 'test@gmail.com', 'U', '10.00'),
(480, 42, 26, 'HALSANDE', '30.00', '10.00', '2020-07-03 08:31:50', '2020-07-11 13:49:57', '', 'test@gmail.com', 'U', '10.00'),
(481, 36, 26, 'THONDEKAI / IVY GOURD', '15.00', '10.00', '2020-06-29 14:32:02', '2020-07-11 13:50:11', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(482, 14, 26, 'TOMATO(Jamun)', '33.00', '25.00', '2020-06-29 14:25:39', '2020-07-11 13:50:31', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(483, 13, 26, 'TOMATO(Huli)', '30.00', '100.00', '2020-06-29 14:25:12', '2020-07-11 13:50:48', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(484, 47, 26, 'SOREKAI / BOTTLE GOURD', '15.00', '3.00', '2020-07-03 13:09:17', '2020-07-11 13:51:09', '', 'test@gmail.com', 'U', '10.00'),
(485, 16, 26, 'SMALL ONION', '40.00', '25.00', '2020-06-29 14:26:10', '2020-07-11 13:51:30', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(486, 62, 26, 'SEEMEBADANE', '22.00', '10.00', '2020-07-05 15:30:20', '2020-07-11 13:51:46', '', 'test@gmail.com', 'U', '10.00'),
(487, 46, 26, 'PADUVALKAYI', '14.00', '3.00', '2020-07-03 13:08:54', '2020-07-11 13:52:00', '', 'test@gmail.com', 'U', '10.00'),
(488, 15, 26, 'ONION', '13.00', '20.00', '2020-06-29 14:25:53', '2020-07-11 13:52:16', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(489, 44, 26, 'DRUMSTICK', '45.00', '3.00', '2020-07-03 13:08:04', '2020-07-11 13:52:46', '', 'test@gmail.com', 'U', '10.00'),
(490, 35, 26, 'MULANGI / Raddish', '16.00', '20.00', '2020-06-29 14:31:43', '2020-07-11 13:53:09', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(491, 29, 26, 'Mangalore CUCUMBER', '9.00', '15.00', '2020-06-29 14:30:03', '2020-07-11 13:53:22', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(492, 21, 26, 'LEMON', '49.00', '10.00', '2020-06-29 14:27:39', '2020-07-11 13:53:40', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(493, 65, 26, 'PUMPKIN', '11.00', '3.00', '2020-07-05 19:44:05', '2020-07-11 13:54:00', '', 'test@gmail.com', 'U', '10.00'),
(494, 63, 26, 'KHOL KHOL', '28.00', '5.00', '2020-07-05 19:38:57', '2020-07-11 13:54:23', '', 'test@gmail.com', 'U', '10.00'),
(495, 45, 26, 'HEEREKAI', '26.00', '3.00', '2020-07-03 13:08:28', '2020-07-11 13:54:51', '', 'test@gmail.com', 'U', '10.00'),
(496, 64, 26, 'HAGALKAYI', '29.00', '3.00', '2020-07-05 19:39:44', '2020-07-11 13:55:09', '', 'test@gmail.com', 'U', '10.00'),
(497, 20, 26, 'GREEN CHILLIES', '30.00', '5.00', '2020-06-29 14:27:20', '2020-07-11 13:55:27', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(498, 19, 26, 'GINGER', '60.00', '6.00', '2020-06-29 14:27:04', '2020-07-11 13:55:39', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(499, 18, 26, 'GARLIC', '75.00', '5.00', '2020-06-29 14:26:45', '2020-07-11 13:55:53', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(500, 28, 26, 'CUCUMBER', '15.00', '10.00', '2020-06-29 14:29:29', '2020-07-11 13:56:04', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(501, 31, 26, 'CAULIFLOWER', '18.00', '15.00', '2020-06-29 14:30:35', '2020-07-11 13:56:23', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '70.00'),
(502, 9, 26, 'CARROT', '33.00', '10.00', '2020-06-29 14:22:41', '2020-07-11 13:56:35', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '100.00'),
(503, 10, 26, 'CAPSICUM', '68.00', '8.00', '2020-06-29 14:22:59', '2020-07-11 13:56:49', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '75.00'),
(504, 30, 26, 'CABBAGE', '12.00', '8.00', '2020-06-29 14:30:17', '2020-07-11 13:57:06', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(505, 26, 26, 'BRINJAL (Black)', '16.00', '4.00', '2020-06-29 14:29:04', '2020-07-11 13:57:32', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(506, 27, 26, 'BRINJAL(Round)', '14.00', '5.00', '2020-06-29 14:29:17', '2020-07-11 13:57:46', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(507, 25, 26, 'BRINJAL (Long)', '16.00', '8.00', '2020-06-29 14:28:47', '2020-07-11 13:58:06', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(508, 34, 26, 'BENDI / Ladies FINGER', '13.00', '20.00', '2020-06-29 14:31:27', '2020-07-11 13:58:24', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(509, 61, 26, 'BEETROOT', '28.00', '3.00', '2020-07-05 14:55:16', '2020-07-11 13:58:37', '', 'test@gmail.com', 'U', '10.00'),
(510, 8, 26, 'Beans(OOTY)', '25.00', '3.00', '2020-06-29 14:22:19', '2020-07-11 13:58:49', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(511, 7, 26, 'Beans', '20.00', '5.00', '2020-06-29 14:21:54', '2020-07-11 13:58:58', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(512, 11, 26, 'POTATO', '29.00', '7.00', '2020-06-29 14:23:51', '2020-07-11 13:59:10', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(513, 30, 26, 'CABBAGE', '12.00', '8.00', '2020-06-29 14:30:17', '2020-07-11 14:12:16', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(514, 26, 26, 'BRINJAL (Black)', '26.00', '4.00', '2020-06-29 14:29:04', '2020-07-11 14:13:02', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(515, 27, 26, 'BRINJAL(Round)', '14.00', '5.00', '2020-06-29 14:29:17', '2020-07-11 14:13:10', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(516, 26, 26, 'BRINJAL (Black)', '16.00', '4.00', '2020-06-29 14:29:04', '2020-07-11 14:13:33', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(517, 25, 26, 'BRINJAL (Long)', '14.00', '8.00', '2020-06-29 14:28:47', '2020-07-11 14:13:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(518, 34, 26, 'BENDI / Ladies FINGER', '16.00', '20.00', '2020-06-29 14:31:27', '2020-07-11 14:14:02', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(519, 61, 26, 'BEETROOT', '28.00', '3.00', '2020-07-05 14:55:16', '2020-07-11 14:14:17', '', 'test@gmail.com', 'U', '10.00'),
(520, 8, 26, 'Beans(OOTY)', '25.00', '3.00', '2020-06-29 14:22:19', '2020-07-11 14:14:29', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(521, 7, 26, 'Beans', '20.00', '5.00', '2020-06-29 14:21:54', '2020-07-11 14:14:53', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(522, 11, 26, 'POTATO', '29.00', '7.00', '2020-06-29 14:23:51', '2020-07-11 14:15:02', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(523, 15, 26, 'ONION', '13.00', '20.00', '2020-06-29 14:25:53', '2020-07-11 14:23:56', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(524, 44, 26, 'DRUMSTICK', '45.00', '3.00', '2020-07-03 13:08:04', '2020-07-11 14:24:12', '', 'test@gmail.com', 'U', '10.00'),
(525, 35, 26, 'MULANGI / Raddish', '16.00', '20.00', '2020-06-29 14:31:43', '2020-07-11 14:24:30', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(526, 29, 26, 'Mangalore CUCUMBER', '9.00', '15.00', '2020-06-29 14:30:03', '2020-07-11 14:24:56', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(527, 21, 26, 'LEMON', '49.00', '10.00', '2020-06-29 14:27:39', '2020-07-11 14:25:22', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(528, 65, 26, 'PUMPKIN', '11.00', '3.00', '2020-07-05 19:44:05', '2020-07-11 14:25:34', '', 'test@gmail.com', 'U', '10.00'),
(529, 63, 26, 'KHOL KHOL', '22.00', '5.00', '2020-07-05 19:38:57', '2020-07-11 14:26:34', '', 'test@gmail.com', 'U', '10.00'),
(530, 45, 26, 'HEEREKAI', '26.00', '3.00', '2020-07-03 13:08:28', '2020-07-11 14:27:08', '', 'test@gmail.com', 'U', '10.00'),
(531, 64, 26, 'HAGALKAYI', '30.00', '3.00', '2020-07-05 19:39:44', '2020-07-11 14:27:41', '', 'test@gmail.com', 'U', '10.00'),
(532, 20, 26, 'GREEN CHILLIES', '30.00', '5.00', '2020-06-29 14:27:20', '2020-07-11 14:28:32', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(533, 19, 26, 'GINGER', '60.00', '6.00', '2020-06-29 14:27:04', '2020-07-11 14:28:38', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(534, 18, 26, 'GARLIC', '75.00', '5.00', '2020-06-29 14:26:45', '2020-07-11 14:28:45', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(535, 28, 26, 'CUCUMBER', '15.00', '10.00', '2020-06-29 14:29:29', '2020-07-11 14:29:27', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(536, 31, 26, 'CAULIFLOWER', '16.00', '15.00', '2020-06-29 14:30:35', '2020-07-11 14:29:34', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '70.00'),
(537, 9, 26, 'CARROT', '33.00', '10.00', '2020-06-29 14:22:41', '2020-07-11 14:29:50', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '100.00'),
(538, 10, 26, 'CAPSICUM', '68.00', '8.00', '2020-06-29 14:22:59', '2020-07-11 14:30:01', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '75.00'),
(539, 30, 26, 'CABBAGE', '13.00', '8.00', '2020-06-29 14:30:17', '2020-07-11 14:30:59', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(540, 26, 26, 'BRINJAL (Black)', '16.00', '4.00', '2020-06-29 14:29:04', '2020-07-11 14:31:25', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(541, 27, 26, 'BRINJAL(Round)', '14.00', '5.00', '2020-06-29 14:29:17', '2020-07-11 14:31:35', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(542, 25, 26, 'BRINJAL (Long)', '14.00', '8.00', '2020-06-29 14:28:47', '2020-07-11 14:31:43', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(543, 34, 26, 'BENDI / Ladies FINGER', '16.00', '20.00', '2020-06-29 14:31:27', '2020-07-11 14:32:05', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(544, 61, 26, 'BEETROOT', '28.00', '3.00', '2020-07-05 14:55:16', '2020-07-11 14:32:12', '', 'test@gmail.com', 'U', '10.00'),
(545, 8, 26, 'Beans(OOTY)', '25.00', '3.00', '2020-06-29 14:22:19', '2020-07-11 14:32:42', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(546, 7, 26, 'Beans', '20.00', '5.00', '2020-06-29 14:21:54', '2020-07-11 14:32:50', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(547, 11, 26, 'POTATO', '29.00', '7.00', '2020-06-29 14:23:51', '2020-07-11 14:33:00', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(548, 74, 27, 'Apple', '200.00', '10.00', '2020-07-12 07:07:28', '2020-07-12 07:07:44', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'U', '50.00'),
(549, 74, 27, 'Apple', '200.00', '10.00', '2020-07-12 07:07:28', '2020-07-12 08:34:53', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'D', '50.00'),
(550, 72, 26, 'Balekayi', '8.00', '1.00', '2020-07-09 14:18:36', '2020-07-12 15:04:04', 'test@gmail.com', 'abhijitjd003@gmail.com', 'U', '10.00'),
(551, 72, 26, 'Balekayi', '8.00', '1.00', '2020-07-09 14:18:36', '2020-07-12 15:04:15', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(552, 72, 26, 'Balekayi', '8.00', '1.00', '2020-07-09 14:18:36', '2020-07-12 15:06:07', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(553, 7, 26, 'Beans', '20.00', '5.00', '2020-06-29 14:21:54', '2020-07-12 15:06:30', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(554, 8, 26, 'Beans(OOTY)', '25.00', '3.00', '2020-06-29 14:22:19', '2020-07-12 15:06:37', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(555, 61, 26, 'BEETROOT', '28.00', '3.00', '2020-07-05 14:55:16', '2020-07-12 15:06:41', '', 'test@gmail.com', 'U', '10.00'),
(556, 34, 26, 'BENDI / Ladies FINGER', '16.00', '20.00', '2020-06-29 14:31:27', '2020-07-12 15:07:17', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(557, 64, 26, 'HAGALKAYI', '30.00', '3.00', '2020-07-05 19:39:44', '2020-07-12 15:07:40', '', 'test@gmail.com', 'U', '10.00'),
(558, 26, 26, 'BRINJAL (Black)', '16.00', '4.00', '2020-06-29 14:29:04', '2020-07-12 15:08:10', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(559, 47, 26, 'SOREKAI / BOTTLE GOURD', '15.00', '3.00', '2020-07-03 13:09:17', '2020-07-12 15:08:43', '', 'test@gmail.com', 'U', '10.00'),
(560, 25, 26, 'BRINJAL (Long)', '14.00', '8.00', '2020-06-29 14:28:47', '2020-07-12 15:08:58', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(561, 28, 26, 'CUCUMBER', '15.00', '10.00', '2020-06-29 14:29:29', '2020-07-12 15:09:31', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(562, 30, 26, 'CABBAGE', '12.00', '8.00', '2020-06-29 14:30:17', '2020-07-12 15:09:43', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(563, 10, 26, 'CAPSICUM', '68.00', '8.00', '2020-06-29 14:22:59', '2020-07-12 15:09:53', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '75.00'),
(564, 9, 26, 'CARROT', '33.00', '10.00', '2020-06-29 14:22:41', '2020-07-12 15:10:02', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '100.00'),
(565, 31, 26, 'CAULIFLOWER', '16.00', '15.00', '2020-06-29 14:30:35', '2020-07-12 15:10:13', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '70.00'),
(566, 62, 26, 'SEEMEBADANE', '22.00', '10.00', '2020-07-05 15:30:20', '2020-07-12 15:10:57', '', 'test@gmail.com', 'U', '10.00'),
(567, 67, 26, 'Kothmiri', '4.00', '3.00', '2020-07-06 12:39:51', '2020-07-12 15:11:40', '', 'test@gmail.com', 'U', '10.00'),
(568, 28, 26, 'British Cucumber/ಬ್ರಿಟಿಷ್ ಸೌತೆಕಾಯಿ', '15.00', '10.00', '2020-06-29 14:29:29', '2020-07-12 15:12:19', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(569, 68, 26, 'Karibevu / Curry Leaves', '2.50', '3.00', '2020-07-06 12:40:25', '2020-07-12 15:12:34', '', 'test@gmail.com', 'U', '10.00'),
(570, 44, 26, 'DRUMSTICK', '45.00', '3.00', '2020-07-03 13:08:04', '2020-07-12 15:13:05', '', 'test@gmail.com', 'U', '10.00'),
(571, 18, 26, 'GARLIC', '75.00', '5.00', '2020-06-29 14:26:45', '2020-07-12 15:13:15', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(572, 19, 26, 'GINGER', '60.00', '6.00', '2020-06-29 14:27:04', '2020-07-12 15:13:33', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(573, 19, 26, 'Ginger/ಶುಂಠಿ', '60.00', '6.00', '2020-06-29 14:27:04', '2020-07-12 15:13:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(574, 20, 26, 'GREEN CHILLIES', '30.00', '5.00', '2020-06-29 14:27:20', '2020-07-12 15:14:02', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(575, 42, 26, 'HALSANDE', '30.00', '10.00', '2020-07-03 08:31:50', '2020-07-12 15:14:20', '', 'test@gmail.com', 'U', '10.00'),
(576, 36, 26, 'THONDEKAI / IVY GOURD', '15.00', '10.00', '2020-06-29 14:32:02', '2020-07-12 15:14:43', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(577, 63, 26, 'KHOL KHOL', '22.00', '5.00', '2020-07-05 19:38:57', '2020-07-12 15:15:17', '', 'test@gmail.com', 'U', '10.00'),
(578, 34, 26, 'Ladies FINGER/ BENDI / ', '15.00', '20.00', '2020-06-29 14:31:27', '2020-07-12 15:15:33', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(579, 21, 26, 'LEMON', '49.00', '10.00', '2020-06-29 14:27:39', '2020-07-12 15:15:44', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(580, 29, 26, 'Mangalore CUCUMBER', '9.00', '15.00', '2020-06-29 14:30:03', '2020-07-12 15:16:00', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(581, 73, 26, 'Methya Soppu', '4.50', '1.00', '2020-07-09 14:25:43', '2020-07-12 15:16:16', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(582, 69, 26, 'Pudina / Mint Leaves', '3.00', '3.00', '2020-07-06 12:40:50', '2020-07-12 15:16:35', '', 'test@gmail.com', 'U', '10.00'),
(583, 15, 26, 'ONION', '14.00', '20.00', '2020-06-29 14:25:53', '2020-07-12 15:16:57', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(584, 8, 26, 'Beans(OOTY)', '28.00', '3.00', '2020-06-29 14:22:19', '2020-07-12 15:17:18', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(585, 70, 26, 'Palak', '3.00', '3.00', '2020-07-06 12:41:13', '2020-07-12 15:17:37', '', 'test@gmail.com', 'U', '10.00'),
(586, 11, 26, 'POTATO', '29.00', '7.00', '2020-06-29 14:23:51', '2020-07-12 15:17:54', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(587, 65, 26, 'PUMPKIN', '11.00', '3.00', '2020-07-05 19:44:05', '2020-07-12 15:18:06', '', 'test@gmail.com', 'U', '10.00'),
(588, 35, 26, 'MULANGI / Raddish', '16.00', '20.00', '2020-06-29 14:31:43', '2020-07-12 15:18:39', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(589, 45, 26, 'HEEREKAI', '26.00', '3.00', '2020-07-03 13:08:28', '2020-07-12 15:18:50', '', 'test@gmail.com', 'U', '10.00'),
(590, 27, 26, 'BRINJAL(Round)', '14.00', '5.00', '2020-06-29 14:29:17', '2020-07-12 15:19:24', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(591, 71, 26, 'Sabsige', '3.00', '3.00', '2020-07-06 12:41:52', '2020-07-12 15:19:41', '', 'test@gmail.com', 'U', '10.00'),
(592, 16, 26, 'SMALL ONION', '40.00', '25.00', '2020-06-29 14:26:10', '2020-07-12 15:19:57', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(593, 46, 26, 'PADUVALKAYI', '14.00', '3.00', '2020-07-03 13:08:54', '2020-07-12 15:20:10', '', 'test@gmail.com', 'U', '10.00'),
(594, 14, 26, 'TOMATO(Jamun)', '34.00', '25.00', '2020-06-29 14:25:39', '2020-07-12 15:20:23', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(595, 13, 26, 'TOMATO(Huli)', '33.00', '100.00', '2020-06-29 14:25:12', '2020-07-12 15:20:34', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(596, 26, 26, 'Black Brinjal/ಬದನೇಕಾಯಿ', '16.00', '4.00', '2020-06-29 14:29:04', '2020-07-12 15:21:52', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(597, 61, 26, 'BEETROOT', '28.00', '3.00', '2020-07-05 14:55:16', '2020-07-12 15:22:22', '', 'test@gmail.com', 'U', '10.00'),
(598, 7, 26, 'Beans', '23.00', '5.00', '2020-06-29 14:21:54', '2020-07-12 15:22:39', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(599, 72, 26, 'Balekayi', '8.00', '1.00', '2020-07-09 14:18:36', '2020-07-12 15:22:55', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(600, 75, 26, 'Avarekai ', '25.00', '5.00', '2020-07-12 15:04:39', '2020-07-12 15:23:07', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(601, 76, 26, 'White Bitter Gourd / ಹಾಗಲಕಾಯಿ  ', '30.00', '3.00', '2020-07-12 15:27:22', '2020-07-12 15:27:40', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(602, 75, 26, 'Avare Kai/ಅವರೆ ಕೈ', '25.00', '5.00', '2020-07-12 15:04:39', '2020-07-12 15:32:40', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(603, 62, 26, 'Chayote gourd/ಸೇಮೆ ಬದನೆ', '22.00', '10.00', '2020-07-05 15:30:20', '2020-07-12 15:33:23', '', 'test@gmail.com', 'U', '10.00'),
(604, 73, 26, 'Menthya soppu/ಮೆಂಥ್ಯಾ ಸೋಪ್ಪು', '3.00', '1.00', '2020-07-09 14:25:43', '2020-07-12 15:34:25', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(605, 71, 26, 'Sabsige Soppu/ ಸಬ್ಸಿಜ್ ಸೊಪ್ಪ', '3.00', '3.00', '2020-07-06 12:41:52', '2020-07-12 15:35:02', '', 'test@gmail.com', 'U', '10.00'),
(606, 76, 26, 'Bitter Gourd- White  / ಹಾಗಲಕಾಯಿ  ', '30.00', '3.00', '2020-07-12 15:27:22', '2020-07-12 15:35:38', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(607, 19, 26, 'Ginger/ಶುಂಠಿ', '65.00', '6.00', '2020-06-29 14:27:04', '2020-07-12 15:36:44', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(608, 71, 26, 'ಸಬ್ಸಿಗೆ ಸೊಪ್ಪು ', '3.00', '3.00', '2020-07-06 12:41:52', '2020-07-12 15:38:59', '', 'test@gmail.com', 'U', '10.00'),
(609, 77, 26, 'Beans Cluster / ಗೋರಿಕಾಯಿ ', '18.00', '5.00', '2020-07-12 15:42:27', '2020-07-12 15:43:17', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(610, 75, 26, 'Avare Kai/ಅವರೆಕಾಯಿ', '25.00', '5.00', '2020-07-12 15:04:39', '2020-07-13 15:19:03', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(611, 11, 26, 'Potato/ಆಲೂ ಗೆಡ್ಡೆ ', '29.00', '7.00', '2020-06-29 14:23:51', '2020-07-13 15:21:28', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(612, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '23.00', '5.00', '2020-06-29 14:21:54', '2020-07-13 15:21:43', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(613, 34, 26, 'Lady\'s finger / Okra/ಬೆಂಡೇಕಾಯಿ  ', '15.00', '20.00', '2020-06-29 14:31:27', '2020-07-13 15:22:42', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(614, 30, 26, 'Cabbage/ಎಲೆ ಕೋಸು', '11.00', '8.00', '2020-06-29 14:30:17', '2020-07-13 15:23:14', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(615, 77, 26, 'Cluster Beans / ಗೋರಿಕಾಯಿ ', '18.00', '5.00', '2020-07-12 15:42:27', '2020-07-13 15:23:51', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(616, 20, 26, 'Green chilli/ಹಸಿರು ಮೆಣಸಿನಕಾಯಿ ', '32.00', '5.00', '2020-06-29 14:27:20', '2020-07-13 15:24:12', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(617, 62, 26, 'Chayote Gourd/ಸೀಮೆ ಬದನೆ ', '22.00', '10.00', '2020-07-05 15:30:20', '2020-07-13 15:24:30', '', 'test@gmail.com', 'U', '10.00'),
(618, 68, 26, 'Curry leaves/ಕರಿಬೇವು   ', '2.00', '3.00', '2020-07-06 12:40:25', '2020-07-13 15:24:52', '', 'test@gmail.com', 'U', '10.00'),
(619, 69, 26, 'Mint leaves/ಪುದಿನ ಸೊಪ್ಪು ', '2.00', '3.00', '2020-07-06 12:40:50', '2020-07-13 15:25:24', '', 'test@gmail.com', 'U', '10.00'),
(620, 67, 26, 'Coriander leaves/ಕೊತ್ತಂಬರಿ ಸೊಪ್ಪು', '3.00', '3.00', '2020-07-06 12:39:51', '2020-07-13 15:25:36', '', 'test@gmail.com', 'U', '10.00'),
(621, 73, 26, 'Menthya Soppu/ಮೆಂತ್ಯ ಸೊಪ್ಪು ', '3.00', '1.00', '2020-07-09 14:25:43', '2020-07-13 15:25:52', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(622, 78, 26, 'Avarekai - Chaparada', '32.00', '5.00', '2020-07-13 15:20:54', '2020-07-13 15:26:47', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(623, 78, 26, 'Avarekai - Chapparada / ಚಪ್ಪರದ ಅವರೆಕಾಯಿ', '32.00', '5.00', '2020-07-13 15:20:54', '2020-07-13 15:29:13', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(624, 67, 26, 'Coriander leaves/ಕೊತ್ತಂಬರಿ ಸೊಪ್ಪು', '4.00', '3.00', '2020-07-06 12:39:51', '2020-07-13 15:46:46', '', 'test@gmail.com', 'U', '10.00'),
(625, 68, 26, 'Curry leaves/ಕರಿಬೇವು   ', '2.50', '3.00', '2020-07-06 12:40:25', '2020-07-13 15:47:13', '', 'test@gmail.com', 'U', '10.00'),
(626, 69, 26, 'Mint leaves/ಪುದಿನ ಸೊಪ್ಪು ', '3.00', '3.00', '2020-07-06 12:40:50', '2020-07-13 15:47:42', '', 'test@gmail.com', 'U', '10.00'),
(627, 73, 26, 'Menthya Soppu/ಮೆಂತ್ಯ ಸೊಪ್ಪು ', '4.50', '1.00', '2020-07-09 14:25:43', '2020-07-13 15:48:38', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(628, 42, 26, 'Halasande/ಹಲಸಂದೆ (ಉದ್ದ ) ', '30.00', '10.00', '2020-07-03 08:31:50', '2020-07-13 16:02:27', '', 'test@gmail.com', 'U', '10.00'),
(629, 10, 26, 'Capsicum/ದಪ್ಪ ಮೆಣಸಿನಕಾಯಿ', '68.00', '8.00', '2020-06-29 14:22:59', '2020-07-14 15:11:36', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '75.00'),
(630, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '34.00', '25.00', '2020-06-29 14:25:39', '2020-07-14 15:12:13', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(631, 13, 26, 'Tomato(Sour)/ಟೊಮ್ಯಾಟೊ ', '33.00', '100.00', '2020-06-29 14:25:12', '2020-07-14 15:12:37', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(632, 34, 26, 'Lady\'s finger / Okra/ಬೆಂಡೇಕಾಯಿ  ', '14.00', '20.00', '2020-06-29 14:31:27', '2020-07-14 15:16:01', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(633, 78, 26, 'Avarekai - Chapparada / ಚಪ್ಪರದ ಅವರೆಕಾಯಿ', '32.00', '5.00', '2020-07-13 15:20:54', '2020-07-14 15:16:22', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(634, 42, 26, 'Halasande/ಹಲಸಂದೆ (ಉದ್ದ ) ', '30.00', '10.00', '2020-07-03 08:31:50', '2020-07-14 15:16:39', '', 'test@gmail.com', 'U', '10.00'),
(635, 18, 26, 'Garlic/ಬೆಳ್ಳುಳ್ಳಿ  ', '75.00', '5.00', '2020-06-29 14:26:45', '2020-07-14 15:39:21', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(636, 9, 26, 'Carrot/ಕ್ಯಾರೆಟ್ ', '33.00', '10.00', '2020-06-29 14:22:41', '2020-07-14 15:39:32', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '100.00'),
(637, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '28.00', '3.00', '2020-06-29 14:22:19', '2020-07-15 13:30:21', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(638, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '23.00', '5.00', '2020-06-29 14:21:54', '2020-07-15 13:30:34', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(639, 76, 26, 'Bitter Gourd- White  / ಬಿಳಿ ಹಾಗಲಕಾಯಿ  ', '30.00', '3.00', '2020-07-12 15:27:22', '2020-07-15 13:31:13', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(640, 76, 26, 'Bitter Gourd- White  / ಬಿಳಿ ಹಾಗಲಕಾಯಿ  ', '30.00', '3.00', '2020-07-12 15:27:22', '2020-07-15 13:32:28', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(641, 47, 26, 'Bottle gourd/ಸೋರೆಕಾಯಿ', '15.00', '3.00', '2020-07-03 13:09:17', '2020-07-15 13:33:07', '', 'test@gmail.com', 'U', '10.00'),
(642, 10, 26, 'Capsicum/ದಪ್ಪ ಮೆಣಸಿನಕಾಯಿ', '69.00', '8.00', '2020-06-29 14:22:59', '2020-07-15 13:34:47', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '75.00'),
(643, 62, 26, 'Chayote Gourd/ಸೀಮೆ ಬದನೆ ', '20.00', '10.00', '2020-07-05 15:30:20', '2020-07-15 13:35:47', '', 'test@gmail.com', 'U', '10.00'),
(644, 62, 26, 'Chayote Gourd/ಸೀಮೆ ಬದನೆ ', '22.00', '10.00', '2020-07-05 15:30:20', '2020-07-15 13:38:40', '', 'test@gmail.com', 'U', '10.00'),
(645, 62, 26, 'Chayote Gourd/ಸೀಮೆ ಬದನೆ ', '20.00', '10.00', '2020-07-05 15:30:20', '2020-07-15 13:40:09', '', 'test@gmail.com', 'U', '10.00'),
(646, 34, 26, 'Lady\'s finger / Okra/ಬೆಂಡೇಕಾಯಿ  ', '15.00', '20.00', '2020-06-29 14:31:27', '2020-07-15 13:40:51', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(647, 29, 26, 'Mangalore Cucumber/ಮಂಗಳೂರು ಸವತೆಕಾಯಿ ', '9.00', '15.00', '2020-06-29 14:30:03', '2020-07-15 13:42:37', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(648, 69, 26, 'Mint leaves/ಪುದಿನ ಸೊಪ್ಪು ', '2.00', '3.00', '2020-07-06 12:40:50', '2020-07-15 13:43:10', '', 'test@gmail.com', 'U', '10.00'),
(649, 13, 26, 'Tomato(Sour)/ಟೊಮ್ಯಾಟೊ ', '32.00', '100.00', '2020-06-29 14:25:12', '2020-07-15 13:44:33', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(650, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '33.00', '25.00', '2020-06-29 14:25:39', '2020-07-15 13:44:52', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(651, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '33.00', '25.00', '2020-06-29 14:25:39', '2020-07-15 13:45:14', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(652, 28, 26, 'Cucumber(Green)/ಸೌತೇಕಾಯಿ ', '15.00', '10.00', '2020-06-29 14:29:29', '2020-07-15 13:47:48', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(653, 61, 26, 'Beetroot/ಬೀಟ್ ರೂಟ್ ', '28.00', '3.00', '2020-07-05 14:55:16', '2020-07-15 14:09:35', '', 'test@gmail.com', 'U', '10.00'),
(654, 35, 26, 'Radish/ಮೂಲಂಗಿ ', '16.00', '20.00', '2020-06-29 14:31:43', '2020-07-15 14:54:52', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(655, 11, 26, 'Potato/ಆಲೂ ಗೆಡ್ಡೆ ', '29.00', '7.00', '2020-06-29 14:23:51', '2020-07-16 12:57:21', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(656, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '28.00', '5.00', '2020-06-29 14:21:54', '2020-07-16 12:57:44', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(657, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '32.00', '3.00', '2020-06-29 14:22:19', '2020-07-16 12:58:03', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(658, 30, 26, 'Cabbage/ಎಲೆ ಕೋಸು', '10.00', '8.00', '2020-06-29 14:30:17', '2020-07-16 12:58:41', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(659, 10, 26, 'Capsicum/ದಪ್ಪ ಮೆಣಸಿನಕಾಯಿ', '70.00', '8.00', '2020-06-29 14:22:59', '2020-07-16 12:58:55', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '75.00'),
(660, 31, 26, 'Cauliflower/ಹೂ ಕೋಸು', '18.00', '15.00', '2020-06-29 14:30:35', '2020-07-16 12:59:23', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '70.00'),
(661, 77, 26, 'Cluster Beans / ಗೋರಿಕಾಯಿ ', '22.00', '5.00', '2020-07-12 15:42:27', '2020-07-16 13:00:19', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(662, 20, 26, 'Green chilli/ಹಸಿರು ಮೆಣಸಿನಕಾಯಿ ', '30.00', '5.00', '2020-06-29 14:27:20', '2020-07-16 13:00:46', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(663, 65, 26, 'Pumpkin(Green)/ಕುಂಬಳಕಾಯಿ ', '11.00', '3.00', '2020-07-05 19:44:05', '2020-07-16 13:01:17', '', 'test@gmail.com', 'U', '10.00'),
(664, 29, 26, 'Mangalore Cucumber/ಮಂಗಳೂರು ಸವತೆಕಾಯಿ ', '11.00', '15.00', '2020-06-29 14:30:03', '2020-07-16 13:01:49', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(665, 35, 26, 'Raddish/ಮೂಲಂಗಿ ', '16.00', '20.00', '2020-06-29 14:31:43', '2020-07-16 13:02:06', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(666, 44, 26, 'Drum Stick/ನುಗ್ಗೆ ಕಾಯಿ ', '45.00', '3.00', '2020-07-03 13:08:04', '2020-07-16 13:02:25', '', 'test@gmail.com', 'U', '10.00'),
(667, 62, 26, 'Chayote Gourd/ಸೀಮೆ ಬದನೆ ', '22.00', '10.00', '2020-07-05 15:30:20', '2020-07-16 13:02:46', '', 'test@gmail.com', 'U', '10.00'),
(668, 36, 26, 'Ivy gourd/ತೊಂಡೆ ಕಾಯಿ ', '15.00', '10.00', '2020-06-29 14:32:02', '2020-07-16 13:03:07', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(669, 44, 26, 'Drum Stick/ನುಗ್ಗೆ ಕಾಯಿ ', '16.00', '3.00', '2020-07-03 13:08:04', '2020-07-16 13:15:58', '', 'test@gmail.com', 'U', '10.00'),
(670, 44, 26, 'Drum Stick/ನುಗ್ಗೆ ಕಾಯಿ ', '16.00', '3.00', '2020-07-03 13:08:04', '2020-07-16 13:16:39', '', 'test@gmail.com', 'U', '10.00'),
(671, 72, 26, 'Balekayi/ಬಾಲೆಕಾಯಿ', '8.00', '1.00', '2020-07-09 14:18:36', '2020-07-17 01:59:16', 'test@gmail.com', 'abhijitjd003@gmail.com', 'U', '10.00'),
(672, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '35.00', '3.00', '2020-06-29 14:22:19', '2020-07-17 01:59:27', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'U', '30.00'),
(673, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '30.00', '5.00', '2020-06-29 14:21:54', '2020-07-17 01:59:38', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'U', '60.00'),
(674, 11, 26, 'Potato/ಆಲೂ ಗೆಡ್ಡೆ ', '30.00', '7.00', '2020-06-29 14:23:51', '2020-07-16 15:21:28', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(675, 34, 26, 'Lady\'s finger / Okra/ಬೆಂಡೇಕಾಯಿ  ', '18.00', '20.00', '2020-06-29 14:31:27', '2020-07-16 15:22:15', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(676, 31, 26, 'Cauliflower/ಹೂ ಕೋಸು', '20.00', '15.00', '2020-06-29 14:30:35', '2020-07-16 15:22:48', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '70.00'),
(677, 45, 26, 'Ridge Gourd/ಹೀರೆಕಾಯಿ ', '26.00', '3.00', '2020-07-03 13:08:28', '2020-07-16 15:23:21', '', 'test@gmail.com', 'U', '10.00'),
(678, 63, 26, 'Knol Khol /ನವಿಲುಕೋಸು ', '18.00', '5.00', '2020-07-05 19:38:57', '2020-07-16 15:23:41', '', 'test@gmail.com', 'U', '10.00'),
(679, 29, 26, 'Mangalore Cucumber/ಮಂಗಳೂರು ಸವತೆಕಾಯಿ ', '14.00', '15.00', '2020-06-29 14:30:03', '2020-07-16 15:24:08', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(680, 29, 26, 'Mangalore Cucumber/ಮಂಗಳೂರು ಸವತೆಕಾಯಿ ', '14.00', '13.00', '2020-06-29 14:30:03', '2020-07-16 15:24:49', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(681, 36, 26, 'Ivy gourd/ತೊಂಡೆ ಕಾಯಿ ', '18.00', '10.00', '2020-06-29 14:32:02', '2020-07-16 15:25:52', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(682, 75, 26, 'Avare Kai/ಅವರೆಕಾಯಿ', '25.00', '5.00', '2020-07-12 15:04:39', '2020-07-16 21:56:59', 'test@gmail.com', 'abhijitjd003@gmail.com', 'U', '50.00'),
(683, 75, 26, 'Avare Kai/ಅವರೆಕಾಯಿ', '25.00', '5.00', '2020-07-12 15:04:39', '2020-07-17 12:32:03', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(684, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '35.00', '3.00', '2020-06-29 14:22:19', '2020-07-17 12:32:32', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(685, 34, 26, 'Lady\'s finger / Okra/ಬೆಂಡೇಕಾಯಿ  ', '20.00', '20.00', '2020-06-29 14:31:27', '2020-07-17 12:33:01', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(686, 30, 26, 'Cabbage/ಎಲೆ ಕೋಸು', '11.00', '8.00', '2020-06-29 14:30:17', '2020-07-17 12:33:20', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(687, 10, 26, 'Capsicum/ದಪ್ಪ ಮೆಣಸಿನಕಾಯಿ', '68.00', '8.00', '2020-06-29 14:22:59', '2020-07-17 12:34:24', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '75.00'),
(688, 10, 26, 'Capsicum/ದಪ್ಪ ಮೆಣಸಿನಕಾಯಿ', '65.00', '8.00', '2020-06-29 14:22:59', '2020-07-17 12:34:56', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '75.00'),
(689, 28, 26, 'Cucumber(Green)/ಸೌತೇಕಾಯಿ ', '20.00', '10.00', '2020-06-29 14:29:29', '2020-07-17 12:36:16', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(690, 20, 26, 'Green chilli/ಹಸಿರು ಮೆಣಸಿನಕಾಯಿ ', '32.00', '5.00', '2020-06-29 14:27:20', '2020-07-17 12:36:34', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(691, 63, 26, 'Knol Khol /ನವಿಲುಕೋಸು ', '17.00', '5.00', '2020-07-05 19:38:57', '2020-07-17 12:37:00', '', 'test@gmail.com', 'U', '10.00'),
(692, 65, 26, 'Pumpkin(Green)/ಕುಂಬಳಕಾಯಿ ', '10.00', '3.00', '2020-07-05 19:44:05', '2020-07-17 12:37:13', '', 'test@gmail.com', 'U', '10.00'),
(693, 29, 26, 'Mangalore Cucumber/ಮಂಗಳೂರು ಸವತೆಕಾಯಿ ', '13.00', '13.00', '2020-06-29 14:30:03', '2020-07-17 12:37:39', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(694, 46, 26, 'Snake gourd/ಪಡವಲಕಾಯಿ  ', '14.00', '3.00', '2020-07-03 13:08:54', '2020-07-17 12:38:00', '', 'test@gmail.com', 'U', '10.00'),
(695, 16, 26, 'Onion Small /ಸಣ್ಣ ಈರುಳ್ಳಿ  ', '40.00', '25.00', '2020-06-29 14:26:10', '2020-07-17 12:38:24', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(696, 47, 26, 'Bottle gourd/ಸೋರೆಕಾಯಿ', '11.00', '3.00', '2020-07-03 13:09:17', '2020-07-17 12:38:37', '', 'test@gmail.com', 'U', '10.00'),
(697, 13, 26, 'Tomato(Sour)/ಟೊಮ್ಯಾಟೊ ', '33.00', '100.00', '2020-06-29 14:25:12', '2020-07-17 12:38:59', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(698, 36, 26, 'Ivy gourd/ತೊಂಡೆ ಕಾಯಿ ', '17.00', '10.00', '2020-06-29 14:32:02', '2020-07-17 12:39:18', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(699, 68, 26, 'Curry leaves/ಕರಿಬೇವು   ', '2.00', '3.00', '2020-07-06 12:40:25', '2020-07-17 12:39:40', '', 'test@gmail.com', 'U', '10.00'),
(700, 69, 26, 'Mint leaves/ಪುದಿನ ಸೊಪ್ಪು ', '3.00', '3.00', '2020-07-06 12:40:50', '2020-07-17 12:40:03', '', 'test@gmail.com', 'U', '10.00'),
(701, 67, 26, 'Coriander leaves/ಕೊತ್ತಂಬರಿ ಸೊಪ್ಪು', '3.00', '3.00', '2020-07-06 12:39:51', '2020-07-17 12:40:28', '', 'test@gmail.com', 'U', '10.00'),
(702, 70, 26, 'Palak/ಪಾಲಾಕ್ ', '3.00', '3.00', '2020-07-06 12:41:13', '2020-07-17 12:40:47', '', 'test@gmail.com', 'U', '10.00'),
(703, 71, 26, 'Sabsige Soppu / ಸಬ್ಸಿಗೆ ಸೊಪ್ಪು ', '3.00', '3.00', '2020-07-06 12:41:52', '2020-07-17 12:41:05', '', 'test@gmail.com', 'U', '10.00'),
(704, 73, 26, 'Menthya Soppu/ಮೆಂತ್ಯ ಸೊಪ್ಪು ', '3.00', '1.00', '2020-07-09 14:25:43', '2020-07-17 12:41:25', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(705, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '30.00', '5.00', '2020-06-29 14:21:54', '2020-07-17 12:42:28', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(706, 75, 26, 'Avare Kai/ಅವರೆಕಾಯಿ', '30.00', '5.00', '2020-07-12 15:04:39', '2020-07-17 21:52:22', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(707, 72, 26, 'Balekayi/ಬಾಲೆಕಾಯಿ', '8.00', '1.00', '2020-07-09 14:18:36', '2020-07-17 21:52:47', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(708, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '35.00', '3.00', '2020-06-29 14:22:19', '2020-07-17 21:56:19', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(709, 61, 26, 'Beetroot/ಬೀಟ್ ರೂಟ್ ', '24.00', '3.00', '2020-07-05 14:55:16', '2020-07-17 21:56:35', '', 'test@gmail.com', 'U', '10.00'),
(710, 34, 26, 'Lady\'s finger / Okra/ಬೆಂಡೇಕಾಯಿ  ', '19.50', '20.00', '2020-06-29 14:31:27', '2020-07-17 21:57:00', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(711, 25, 26, 'Brinjal/ಬದನೇಕಾಯಿ (ಬಿಳಿ )', '14.00', '8.00', '2020-06-29 14:28:47', '2020-07-17 21:58:01', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(712, 27, 26, 'Brinjal Round /ಬದನೇಕಾಯಿ ', '14.00', '5.00', '2020-06-29 14:29:17', '2020-07-17 21:58:14', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(713, 30, 26, 'Cabbage/ಎಲೆ ಕೋಸು', '12.00', '8.00', '2020-06-29 14:30:17', '2020-07-17 21:58:30', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(714, 10, 26, 'Capsicum/ದಪ್ಪ ಮೆಣಸಿನಕಾಯಿ', '65.00', '8.00', '2020-06-29 14:22:59', '2020-07-17 21:59:08', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '75.00'),
(715, 9, 26, 'Carrot/ಕ್ಯಾರೆಟ್ ', '34.00', '10.00', '2020-06-29 14:22:41', '2020-07-17 21:59:19', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '100.00'),
(716, 31, 26, 'Cauliflower/ಹೂ ಕೋಸು', '19.00', '15.00', '2020-06-29 14:30:35', '2020-07-17 21:59:31', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '70.00'),
(717, 28, 26, 'Cucumber(Green)/ಸೌತೇಕಾಯಿ ', '16.00', '10.00', '2020-06-29 14:29:29', '2020-07-17 21:59:48', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(718, 44, 26, 'Drum Stick/ನುಗ್ಗೆ ಕಾಯಿ ', '45.00', '3.00', '2020-07-03 13:08:04', '2020-07-17 22:00:06', '', 'test@gmail.com', 'U', '10.00'),
(719, 18, 26, 'Garlic/ಬೆಳ್ಳುಳ್ಳಿ  ', '80.00', '5.00', '2020-06-29 14:26:45', '2020-07-17 22:00:24', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(720, 19, 26, 'Ginger/ಶುಂಠಿ', '60.00', '6.00', '2020-06-29 14:27:04', '2020-07-17 22:00:35', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(721, 20, 26, 'Green chilli/ಹಸಿರು ಮೆಣಸಿನಕಾಯಿ ', '32.00', '5.00', '2020-06-29 14:27:20', '2020-07-17 22:00:50', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(722, 76, 26, 'Bitter Gourd- White  / ಬಿಳಿ ಹಾಗಲಕಾಯಿ  ', '30.00', '3.00', '2020-07-12 15:27:22', '2020-07-17 22:01:12', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(723, 42, 26, 'Halasande/ಹಲಸಂದೆ (ಉದ್ದ ) ', '30.00', '10.00', '2020-07-03 08:31:50', '2020-07-17 22:01:35', '', 'test@gmail.com', 'U', '10.00'),
(724, 45, 26, 'Ridge Gourd/ಹೀರೆಕಾಯಿ ', '24.00', '3.00', '2020-07-03 13:08:28', '2020-07-17 22:01:51', '', 'test@gmail.com', 'U', '10.00'),
(725, 63, 26, 'Knol Khol /ನವಿಲುಕೋಸು ', '22.00', '5.00', '2020-07-05 19:38:57', '2020-07-17 22:02:12', '', 'test@gmail.com', 'U', '10.00'),
(726, 65, 26, 'Pumpkin(Green)/ಕುಂಬಳಕಾಯಿ ', '12.00', '3.00', '2020-07-05 19:44:05', '2020-07-17 22:02:33', '', 'test@gmail.com', 'U', '10.00'),
(727, 21, 26, 'Lemon/ನಿಂಬೆ ಹಣ್ಣು ', '49.00', '10.00', '2020-06-29 14:27:39', '2020-07-17 22:03:00', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(728, 29, 26, 'Mangalore Cucumber/ಮಂಗಳೂರು ಸವತೆಕಾಯಿ ', '14.00', '13.00', '2020-06-29 14:30:03', '2020-07-17 22:03:27', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(729, 35, 26, 'Raddish/ಮೂಲಂಗಿ ', '14.00', '20.00', '2020-06-29 14:31:43', '2020-07-17 22:03:47', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(730, 15, 26, 'Onion/ಈರುಳ್ಳಿ ', '14.00', '20.00', '2020-06-29 14:25:53', '2020-07-17 22:04:04', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(731, 46, 26, 'Snake gourd/ಪಡವಲಕಾಯಿ  ', '16.00', '3.00', '2020-07-03 13:08:54', '2020-07-17 22:04:30', '', 'test@gmail.com', 'U', '10.00'),
(732, 62, 26, 'Chayote Gourd/ಸೀಮೆ ಬದನೆ ', '20.00', '10.00', '2020-07-05 15:30:20', '2020-07-17 22:05:42', '', 'test@gmail.com', 'U', '10.00'),
(733, 16, 26, 'Onion Small /ಸಣ್ಣ ಈರುಳ್ಳಿ  ', '42.00', '25.00', '2020-06-29 14:26:10', '2020-07-17 22:06:00', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(734, 47, 26, 'Bottle gourd/ಸೋರೆಕಾಯಿ', '14.00', '3.00', '2020-07-03 13:09:17', '2020-07-17 22:06:18', '', 'test@gmail.com', 'U', '10.00'),
(735, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '34.00', '25.00', '2020-06-29 14:25:39', '2020-07-17 22:06:43', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(736, 13, 26, 'Tomato(Sour)/ಟೊಮ್ಯಾಟೊ ', '30.00', '100.00', '2020-06-29 14:25:12', '2020-07-17 22:06:54', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00');
INSERT INTO `ProductHistory` (`ProductHistId`, `ProductId`, `CategoryId`, `Name`, `RatePerKG`, `MinPurchaseQuantity`, `CreatedDateTime`, `UpdatedDateTime`, `CreatedUserId`, `UpdatedUserId`, `StatusCode`, `TotalStock`) VALUES
(737, 77, 26, 'Cluster Beans / ಗೋರಿಕಾಯಿ ', '22.00', '5.00', '2020-07-12 15:42:27', '2020-07-17 22:07:10', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(738, 68, 26, 'Curry leaves/ಕರಿಬೇವು   ', '3.00', '3.00', '2020-07-06 12:40:25', '2020-07-17 22:07:41', '', 'test@gmail.com', 'U', '10.00'),
(739, 69, 26, 'Mint leaves/ಪುದಿನ ಸೊಪ್ಪು ', '6.50', '3.00', '2020-07-06 12:40:50', '2020-07-17 22:08:18', '', 'test@gmail.com', 'U', '10.00'),
(740, 67, 26, 'Coriander leaves/ಕೊತ್ತಂಬರಿ ಸೊಪ್ಪು', '8.00', '3.00', '2020-07-06 12:39:51', '2020-07-17 22:08:34', '', 'test@gmail.com', 'U', '10.00'),
(741, 77, 26, 'Cluster Beans / ಗೋರಿಕಾಯಿ ', '25.00', '5.00', '2020-07-12 15:42:27', '2020-07-17 22:12:18', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(742, 70, 26, 'Palak/ಪಾಲಾಕ್ ', '3.50', '3.00', '2020-07-06 12:41:13', '2020-07-17 22:16:40', '', 'test@gmail.com', 'U', '10.00'),
(743, 80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '25.00', '3.00', '2020-07-17 22:21:11', '2020-07-17 23:07:43', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(744, 79, 27, 'Banana(Yellaki) / ಬಾಳೆಹಣ್ಣು', '55.00', '3.00', '2020-07-17 22:20:12', '2020-07-17 23:07:58', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(745, 80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '25.00', '3.00', '2020-07-17 22:21:11', '2020-07-17 23:08:39', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(746, 79, 27, 'Banana(Yellaki) / ಬಾಳೆಹಣ್ಣು', '55.00', '3.00', '2020-07-17 22:20:12', '2020-07-17 23:08:54', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(747, 11, 26, 'Potato/ಆಲೂ ಗೆಡ್ಡೆ ', '30.50', '7.00', '2020-06-29 14:23:51', '2020-07-17 23:10:05', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(748, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '45.00', '3.00', '2020-06-29 14:22:19', '2020-07-17 23:10:35', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(749, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '28.00', '5.00', '2020-06-29 14:21:54', '2020-07-17 23:10:46', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(750, 64, 26, 'Bitter gourd/ಹಾಗಲಕಾಯಿ ', '30.00', '3.00', '2020-07-05 19:39:44', '2020-07-17 23:12:38', '', 'test@gmail.com', 'U', '10.00'),
(751, 42, 26, 'Halasande/ಹಲಸಂದೆ (ಉದ್ದ ) ', '50.00', '10.00', '2020-07-03 08:31:50', '2020-07-17 23:13:17', '', 'test@gmail.com', 'U', '10.00'),
(752, 36, 26, 'Ivy gourd/ತೊಂಡೆ ಕಾಯಿ ', '18.00', '10.00', '2020-06-29 14:32:02', '2020-07-17 23:15:16', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(753, 77, 26, 'Cluster Beans / ಗೋರಿಕಾಯಿ ', '30.00', '5.00', '2020-07-12 15:42:27', '2020-07-17 23:16:31', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(754, 71, 26, 'Sabsige Soppu / ಸಬ್ಸಿಗೆ ಸೊಪ್ಪು ', '5.00', '3.00', '2020-07-06 12:41:52', '2020-07-17 23:17:07', '', 'test@gmail.com', 'U', '10.00'),
(755, 80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '25.00', '3.00', '2020-07-17 22:21:11', '2020-07-17 23:17:39', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(756, 80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '25.00', '3.00', '2020-07-17 22:21:11', '2020-07-17 23:18:00', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(757, 80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '25.00', '3.00', '2020-07-17 22:21:11', '2020-07-17 23:19:50', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(758, 80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '25.00', '3.00', '2020-07-17 22:21:11', '2020-07-17 23:20:37', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(759, 80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '25.00', '3.00', '2020-07-17 22:21:11', '2020-07-17 23:26:51', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(760, 80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '25.00', '3.00', '2020-07-17 22:21:11', '2020-07-17 23:27:17', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(761, 80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '25.00', '3.00', '2020-07-17 22:21:11', '2020-07-17 23:27:45', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(762, 80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '25.00', '3.00', '2020-07-17 22:21:11', '2020-07-17 23:28:24', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(763, 79, 27, 'Banana(Yellaki) / ಬಾಳೆಹಣ್ಣು', '55.00', '3.00', '2020-07-17 22:20:12', '2020-07-17 23:28:50', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(764, 80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '25.00', '3.00', '2020-07-17 22:21:11', '2020-07-17 23:30:11', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(765, 80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '25.00', '3.00', '2020-07-17 22:21:11', '2020-07-17 23:30:49', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(766, 79, 27, 'Banana(Yellaki) / ಬಾಳೆಹಣ್ಣು', '55.00', '3.00', '2020-07-17 22:20:12', '2020-07-17 23:30:57', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(767, 80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '25.00', '3.00', '2020-07-17 22:21:11', '2020-07-17 23:55:25', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(768, 80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '25.00', '3.00', '2020-07-17 22:21:11', '2020-07-17 23:55:57', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(769, 81, 27, 'Apple', '200.00', '10.00', '2020-07-18 08:00:15', '2020-07-18 08:03:24', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'U', '10.00'),
(770, 81, 27, 'Apple', '200.00', '10.00', '2020-07-18 08:00:15', '2020-07-18 20:43:41', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'U', '10.00'),
(771, 81, 27, 'Apple', '200.00', '10.00', '2020-07-18 08:00:15', '2020-07-18 20:45:54', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'U', '10.00'),
(772, 81, 27, 'Apple', '200.00', '10.00', '2020-07-18 08:00:15', '2020-07-18 08:36:19', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'U', '10.00'),
(773, 81, 27, 'Apple', '200.00', '10.00', '2020-07-18 08:00:15', '2020-07-18 09:49:30', 'abhijitjd003@gmail.com', 'test@gmail.com', 'D', '10.00'),
(774, 82, 26, 'ATest 1', '50.00', '5.00', '2020-07-18 14:01:54', '2020-07-18 14:02:22', 'md@spicetrip.com', 'md@spicetrip.com', 'D', '50.00'),
(775, 75, 26, 'Avare Kai/ಅವರೆಕಾಯಿ', '40.00', '5.00', '2020-07-12 15:04:39', '2020-07-18 14:04:11', 'test@gmail.com', 'md@spicetrip.com', 'U', '50.00'),
(776, 75, 26, 'Avare Kai/ಅವರೆಕಾಯಿ', '50.00', '5.00', '2020-07-12 15:04:39', '2020-07-18 15:22:29', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(777, 72, 26, 'Balekayi/ಬಾಲೆಕಾಯಿ', '12.00', '1.00', '2020-07-09 14:18:36', '2020-07-18 15:23:07', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(778, 80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '25.00', '3.00', '2020-07-17 22:21:11', '2020-07-18 15:23:38', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(779, 79, 27, 'Banana(Yellaki) / ಬಾಳೆಹಣ್ಣು', '55.00', '3.00', '2020-07-17 22:20:12', '2020-07-18 15:23:44', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(780, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '45.00', '3.00', '2020-06-29 14:22:19', '2020-07-18 15:23:52', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(781, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '40.00', '5.00', '2020-06-29 14:21:54', '2020-07-18 15:24:00', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(782, 61, 26, 'Beetroot/ಬೀಟ್ ರೂಟ್ ', '40.00', '3.00', '2020-07-05 14:55:16', '2020-07-18 15:24:08', '', 'test@gmail.com', 'U', '10.00'),
(783, 64, 26, 'Bitter gourd/ಹಾಗಲಕಾಯಿ ', '50.00', '3.00', '2020-07-05 19:39:44', '2020-07-18 15:24:20', '', 'test@gmail.com', 'U', '10.00'),
(784, 76, 26, 'Bitter Gourd- White  / ಬಿಳಿ ಹಾಗಲಕಾಯಿ  ', '50.00', '3.00', '2020-07-12 15:27:22', '2020-07-18 15:25:01', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(785, 47, 26, 'Bottle gourd/ಸೋರೆಕಾಯಿ', '20.00', '3.00', '2020-07-03 13:09:17', '2020-07-18 15:25:09', '', 'test@gmail.com', 'U', '10.00'),
(786, 26, 26, 'Brinjal Black /ಬದನೇಕಾಯಿ', '16.00', '4.00', '2020-06-29 14:29:04', '2020-07-18 15:25:19', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(787, 27, 26, 'Brinjal Round /ಬದನೇಕಾಯಿ ', '30.00', '5.00', '2020-06-29 14:29:17', '2020-07-18 15:25:29', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(788, 25, 26, 'Brinjal/ಬದನೇಕಾಯಿ (ಬಿಳಿ )', '30.00', '8.00', '2020-06-29 14:28:47', '2020-07-18 15:25:39', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(789, 30, 26, 'Cabbage/ಎಲೆ ಕೋಸು', '20.00', '8.00', '2020-06-29 14:30:17', '2020-07-18 15:25:47', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(790, 10, 26, 'Capsicum/ದಪ್ಪ ಮೆಣಸಿನಕಾಯಿ', '75.00', '8.00', '2020-06-29 14:22:59', '2020-07-18 15:25:55', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '75.00'),
(791, 9, 26, 'Carrot/ಕ್ಯಾರೆಟ್ ', '40.00', '10.00', '2020-06-29 14:22:41', '2020-07-18 15:26:03', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '100.00'),
(792, 31, 26, 'Cauliflower/ಹೂ ಕೋಸು', '25.00', '15.00', '2020-06-29 14:30:35', '2020-07-18 15:26:10', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '70.00'),
(793, 62, 26, 'Chayote Gourd/ಸೀಮೆ ಬದನೆ ', '30.00', '10.00', '2020-07-05 15:30:20', '2020-07-18 15:26:21', '', 'test@gmail.com', 'U', '10.00'),
(794, 77, 26, 'Cluster Beans / ಗೋರಿಕಾಯಿ ', '30.00', '5.00', '2020-07-12 15:42:27', '2020-07-18 15:26:29', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(795, 67, 26, 'Coriander leaves/ಕೊತ್ತಂಬರಿ ಸೊಪ್ಪು', '5.00', '3.00', '2020-07-06 12:39:51', '2020-07-18 15:26:40', '', 'test@gmail.com', 'U', '10.00'),
(796, 28, 26, 'Cucumber(Green)/ಸೌತೇಕಾಯಿ ', '25.00', '10.00', '2020-06-29 14:29:29', '2020-07-18 15:26:49', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(797, 68, 26, 'Curry leaves/ಕರಿಬೇವು   ', '4.00', '3.00', '2020-07-06 12:40:25', '2020-07-18 15:26:59', '', 'test@gmail.com', 'U', '10.00'),
(798, 44, 26, 'Drum Stick/ನುಗ್ಗೆ ಕಾಯಿ ', '55.00', '3.00', '2020-07-03 13:08:04', '2020-07-18 15:27:07', '', 'test@gmail.com', 'U', '10.00'),
(799, 18, 26, 'Garlic/ಬೆಳ್ಳುಳ್ಳಿ  ', '100.00', '5.00', '2020-06-29 14:26:45', '2020-07-18 15:27:20', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(800, 19, 26, 'Ginger/ಶುಂಠಿ', '100.00', '6.00', '2020-06-29 14:27:04', '2020-07-18 15:27:30', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(801, 20, 26, 'Green chilli/ಹಸಿರು ಮೆಣಸಿನಕಾಯಿ ', '45.00', '5.00', '2020-06-29 14:27:20', '2020-07-18 15:27:40', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(802, 36, 26, 'Ivy gourd/ತೊಂಡೆ ಕಾಯಿ ', '25.00', '10.00', '2020-06-29 14:32:02', '2020-07-18 15:27:50', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(803, 63, 26, 'Knol Khol /ನವಿಲುಕೋಸು ', '30.00', '5.00', '2020-07-05 19:38:57', '2020-07-18 15:28:05', '', 'test@gmail.com', 'U', '10.00'),
(804, 34, 26, 'Lady\'s finger / Okra/ಬೆಂಡೇಕಾಯಿ  ', '30.00', '20.00', '2020-06-29 14:31:27', '2020-07-18 15:28:19', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(805, 21, 26, 'Lemon/ನಿಂಬೆ ಹಣ್ಣು ', '10.00', '10.00', '2020-06-29 14:27:39', '2020-07-18 15:28:32', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(806, 29, 26, 'Mangalore Cucumber/ಮಂಗಳೂರು ಸವತೆಕಾಯಿ ', '15.00', '13.00', '2020-06-29 14:30:03', '2020-07-18 15:28:42', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(807, 73, 26, 'Menthya Soppu/ಮೆಂತ್ಯ ಸೊಪ್ಪು ', '3.50', '1.00', '2020-07-09 14:25:43', '2020-07-18 15:28:55', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(808, 69, 26, 'Mint leaves/ಪುದಿನ ಸೊಪ್ಪು ', '4.00', '3.00', '2020-07-06 12:40:50', '2020-07-18 15:29:05', '', 'test@gmail.com', 'U', '10.00'),
(809, 16, 26, 'Onion Small /ಸಣ್ಣ ಈರುಳ್ಳಿ  ', '60.00', '25.00', '2020-06-29 14:26:10', '2020-07-18 15:29:18', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(810, 15, 26, 'Onion/ಈರುಳ್ಳಿ ', '17.00', '20.00', '2020-06-29 14:25:53', '2020-07-18 15:29:28', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(811, 70, 26, 'Palak/ಪಾಲಾಕ್ ', '4.00', '3.00', '2020-07-06 12:41:13', '2020-07-18 15:29:42', '', 'test@gmail.com', 'U', '10.00'),
(812, 11, 26, 'Potato/ಆಲೂ ಗೆಡ್ಡೆ ', '40.00', '7.00', '2020-06-29 14:23:51', '2020-07-18 15:29:55', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(813, 65, 26, 'Pumpkin(Green)/ಕುಂಬಳಕಾಯಿ ', '20.00', '3.00', '2020-07-05 19:44:05', '2020-07-18 15:30:10', '', 'test@gmail.com', 'U', '10.00'),
(814, 35, 26, 'Raddish/ಮೂಲಂಗಿ ', '25.00', '20.00', '2020-06-29 14:31:43', '2020-07-18 15:30:25', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(815, 45, 26, 'Ridge Gourd/ಹೀರೆಕಾಯಿ ', '35.00', '3.00', '2020-07-03 13:08:28', '2020-07-18 15:30:36', '', 'test@gmail.com', 'U', '10.00'),
(816, 71, 26, 'Sabsige Soppu / ಸಬ್ಸಿಗೆ ಸೊಪ್ಪು ', '5.00', '3.00', '2020-07-06 12:41:52', '2020-07-18 15:30:45', '', 'test@gmail.com', 'U', '10.00'),
(817, 46, 26, 'Snake gourd/ಪಡವಲಕಾಯಿ  ', '20.00', '3.00', '2020-07-03 13:08:54', '2020-07-18 15:30:54', '', 'test@gmail.com', 'U', '10.00'),
(818, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '40.00', '25.00', '2020-06-29 14:25:39', '2020-07-18 15:31:03', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(819, 13, 26, 'Tomato(Sour)/ಟೊಮ್ಯಾಟೊ ', '40.00', '100.00', '2020-06-29 14:25:12', '2020-07-18 15:31:15', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(820, 42, 26, 'Halasande/ಹಲಸಂದೆ (ಉದ್ದ ) ', '50.00', '10.00', '2020-07-03 08:31:50', '2020-07-18 15:32:11', '', 'test@gmail.com', 'U', '10.00'),
(821, 42, 26, 'Halasande/ಹಲಸಂದೆ (ಉದ್ದ ) ', '50.00', '10.00', '2020-07-03 08:31:50', '2020-07-18 15:43:01', '', 'test@gmail.com', 'U', '10.00'),
(822, 42, 26, 'Halasande/ಹಲಸಂದೆ (ಉದ್ದ ) ', '38.00', '10.00', '2020-07-03 08:31:50', '2020-07-18 15:43:46', '', 'test@gmail.com', 'U', '10.00'),
(823, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '36.00', '3.00', '2020-06-29 14:22:19', '2020-07-19 14:19:00', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(824, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '28.00', '5.00', '2020-06-29 14:21:54', '2020-07-19 14:19:15', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(825, 31, 26, 'Cauliflower/ಹೂ ಕೋಸು', '20.00', '15.00', '2020-06-29 14:30:35', '2020-07-19 14:19:36', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '70.00'),
(826, 62, 26, 'Chayote Gourd/ಸೀಮೆ ಬದನೆ ', '26.00', '10.00', '2020-07-05 15:30:20', '2020-07-19 14:19:51', '', 'test@gmail.com', 'U', '10.00'),
(827, 28, 26, 'Cucumber(Green)/ಸೌತೇಕಾಯಿ ', '16.00', '10.00', '2020-06-29 14:29:29', '2020-07-19 14:20:13', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(828, 36, 26, 'Ivy gourd/ತೊಂಡೆ ಕಾಯಿ ', '22.00', '10.00', '2020-06-29 14:32:02', '2020-07-19 14:20:32', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(829, 29, 26, 'Mangalore Cucumber/ಮಂಗಳೂರು ಸವತೆಕಾಯಿ ', '14.00', '13.00', '2020-06-29 14:30:03', '2020-07-19 14:21:00', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(830, 16, 26, 'Onion Small /ಸಣ್ಣ ಈರುಳ್ಳಿ  ', '40.00', '25.00', '2020-06-29 14:26:10', '2020-07-19 14:21:22', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(831, 46, 26, 'Snake gourd/ಪಡವಲಕಾಯಿ  ', '18.00', '3.00', '2020-07-03 13:08:54', '2020-07-19 14:21:52', '', 'test@gmail.com', 'U', '10.00'),
(832, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '35.00', '25.00', '2020-06-29 14:25:39', '2020-07-19 14:22:10', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(833, 13, 26, 'Tomato(Sour)/ಟೊಮ್ಯಾಟೊ ', '32.00', '100.00', '2020-06-29 14:25:12', '2020-07-19 14:22:23', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(834, 30, 26, 'Cabbage/ಎಲೆ ಕೋಸು', '12.00', '8.00', '2020-06-29 14:30:17', '2020-07-19 14:33:39', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(835, 15, 26, 'Onion/ಈರುಳ್ಳಿ ', '14.00', '20.00', '2020-06-29 14:25:53', '2020-07-19 14:33:52', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(836, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '32.00', '3.00', '2020-06-29 14:22:19', '2020-07-19 14:34:30', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(837, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '25.00', '5.00', '2020-06-29 14:21:54', '2020-07-19 14:34:51', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(838, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '33.00', '25.00', '2020-06-29 14:25:39', '2020-07-19 15:05:39', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(839, 75, 26, 'Avare Kai/ಅವರೆಕಾಯಿ', '28.00', '5.00', '2020-07-12 15:04:39', '2020-07-20 14:30:33', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(840, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '30.00', '3.00', '2020-06-29 14:22:19', '2020-07-20 14:30:57', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(841, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '22.00', '5.00', '2020-06-29 14:21:54', '2020-07-20 14:31:10', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(842, 84, 26, 'British Cucumber/ ಬ್ರಿಟಿಷ್ ಸೌತೆಕಾಯಿ', '28.00', '3.00', '2020-07-20 14:35:58', '2020-07-20 14:37:19', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(843, 84, 26, 'British Cucumber/ ಬ್ರಿಟಿಷ್ ಸೌತೆಕಾಯಿ', '28.00', '3.00', '2020-07-20 14:35:58', '2020-07-20 14:37:56', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(844, 30, 26, 'Cabbage/ಎಲೆ ಕೋಸು', '11.00', '8.00', '2020-06-29 14:30:17', '2020-07-20 14:38:25', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(845, 10, 26, 'Capsicum/ದಪ್ಪ ಮೆಣಸಿನಕಾಯಿ', '68.00', '8.00', '2020-06-29 14:22:59', '2020-07-20 14:38:34', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '75.00'),
(846, 31, 26, 'Cauliflower/ಹೂ ಕೋಸು', '18.00', '15.00', '2020-06-29 14:30:35', '2020-07-20 14:38:47', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '70.00'),
(847, 42, 26, 'Halasande/ಹಲಸಂದೆ (ಉದ್ದ ) ', '38.00', '10.00', '2020-07-03 08:31:50', '2020-07-20 14:39:53', '', 'test@gmail.com', 'U', '10.00'),
(848, 21, 26, 'Lemon/ನಿಂಬೆ ಹಣ್ಣು ', '49.00', '10.00', '2020-06-29 14:27:39', '2020-07-20 14:40:13', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(849, 11, 26, 'Potato/ಆಲೂ ಗೆಡ್ಡೆ ', '30.50', '7.00', '2020-06-29 14:23:51', '2020-07-20 14:40:44', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '65.00'),
(850, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '30.00', '25.00', '2020-06-29 14:25:39', '2020-07-20 14:41:18', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(851, 13, 26, 'Tomato(Sour)/ಟೊಮ್ಯಾಟೊ ', '24.00', '100.00', '2020-06-29 14:25:12', '2020-07-20 14:41:27', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(852, 84, 26, 'British Cucumber/ ಬ್ರಿಟಿಷ್ ಸೌತೆಕಾಯಿ', '28.00', '3.00', '2020-07-20 14:35:58', '2020-07-20 14:41:51', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(853, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '30.00', '3.00', '2020-06-29 14:22:19', '2020-07-21 14:24:17', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(854, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '33.00', '3.00', '2020-06-29 14:22:19', '2020-07-21 14:25:21', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(855, 26, 26, 'Brinjal Black /ಬದನೇಕಾಯಿ', '26.00', '4.00', '2020-06-29 14:29:04', '2020-07-21 14:27:20', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '40.00'),
(856, 30, 26, 'Cabbage/ಎಲೆ ಕೋಸು', '10.00', '8.00', '2020-06-29 14:30:17', '2020-07-21 14:30:00', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(857, 28, 26, 'Cucumber(Green)/ಸೌತೇಕಾಯಿ ', '18.00', '10.00', '2020-06-29 14:29:29', '2020-07-21 14:31:12', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(858, 20, 26, 'Green chilli/ಹಸಿರು ಮೆಣಸಿನಕಾಯಿ ', '36.00', '5.00', '2020-06-29 14:27:20', '2020-07-21 14:32:28', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(859, 20, 26, 'Green chilli/ಹಸಿರು ಮೆಣಸಿನಕಾಯಿ ', '30.00', '5.00', '2020-06-29 14:27:20', '2020-07-21 14:33:42', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(860, 29, 26, 'Mangalore Cucumber/ಮಂಗಳೂರು ಸವತೆಕಾಯಿ ', '15.00', '13.00', '2020-06-29 14:30:03', '2020-07-21 14:35:21', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '200.00'),
(861, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '28.00', '25.00', '2020-06-29 14:25:39', '2020-07-21 14:37:10', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(862, 13, 26, 'Tomato(Sour)/ಟೊಮ್ಯಾಟೊ ', '22.00', '100.00', '2020-06-29 14:25:12', '2020-07-21 14:38:06', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(863, 85, 26, 'Apple', '100.00', '10.00', '2020-07-21 22:31:16', '2020-07-21 22:31:32', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'U', '0.00'),
(864, 85, 26, 'Apple', '101.00', '20.00', '2020-07-21 22:31:16', '2020-07-21 22:31:53', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'D', '0.00'),
(865, 78, 26, 'Avarekai - Chapparada / ಚಪ್ಪರದ ಅವರೆಕಾಯಿ', '32.00', '5.00', '2020-07-13 15:20:54', '2020-07-22 09:58:02', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(866, 75, 26, 'Avare Kai/ಅವರೆಕಾಯಿ', '27.00', '5.00', '2020-07-12 15:04:39', '2020-07-22 09:58:13', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(867, 80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '25.00', '3.00', '2020-07-17 22:21:11', '2020-07-22 14:02:23', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(868, 79, 27, 'Banana(Yellaki) / ಬಾಳೆಹಣ್ಣು', '55.00', '3.00', '2020-07-17 22:20:12', '2020-07-22 14:02:23', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(869, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '33.00', '3.00', '2020-06-29 14:22:19', '2020-07-22 14:02:23', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(870, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '23.00', '5.00', '2020-06-29 14:21:54', '2020-07-22 14:02:23', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(871, 25, 26, 'Brinjal/ಬದನೇಕಾಯಿ (ಬಿಳಿ )', '14.00', '8.00', '2020-06-29 14:28:47', '2020-07-22 14:02:23', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(872, 31, 26, 'Cauliflower/ಹೂ ಕೋಸು', '20.00', '15.00', '2020-06-29 14:30:35', '2020-07-22 14:02:23', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '70.00'),
(873, 44, 26, 'Drum Stick/ನುಗ್ಗೆ ಕಾಯಿ ', '45.00', '3.00', '2020-07-03 13:08:04', '2020-07-22 14:02:23', '', 'test@gmail.com', 'U', '10.00'),
(874, 36, 26, 'Ivy gourd/ತೊಂಡೆ ಕಾಯಿ ', '20.00', '10.00', '2020-06-29 14:32:02', '2020-07-22 14:02:23', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(875, 63, 26, 'Knol Khol /ನವಿಲುಕೋಸು ', '20.00', '5.00', '2020-07-05 19:38:57', '2020-07-22 14:02:23', '', 'test@gmail.com', 'U', '10.00'),
(876, 69, 26, 'Mint leaves/ಪುದಿನ ಸೊಪ್ಪು ', '2.50', '3.00', '2020-07-06 12:40:50', '2020-07-22 14:02:23', '', 'test@gmail.com', 'U', '10.00'),
(877, 70, 26, 'Palak/ಪಾಲಾಕ್ ', '2.00', '3.00', '2020-07-06 12:41:13', '2020-07-22 14:02:23', '', 'test@gmail.com', 'U', '10.00'),
(878, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '26.00', '25.00', '2020-06-29 14:25:39', '2020-07-22 14:02:23', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(879, 13, 26, 'Tomato(Sour)/ಟೊಮ್ಯಾಟೊ ', '20.00', '100.00', '2020-06-29 14:25:12', '2020-07-22 14:02:23', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(880, 75, 26, 'Avare Kai/ಅವರೆಕಾಯಿ', '28.00', '5.00', '2020-07-12 15:04:39', '2020-07-22 20:34:12', 'test@gmail.com', 'test@gmail.com', 'U', '50.00'),
(881, 36, 26, 'Ivy gourd/ತೊಂಡೆ ಕಾಯಿ ', '22.00', '10.00', '2020-06-29 14:32:02', '2020-07-23 11:58:57', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(882, 34, 26, 'Lady\'s finger / Okra/ಬೆಂಡೇಕಾಯಿ  ', '18.00', '20.00', '2020-06-29 14:31:27', '2020-07-23 11:58:57', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(883, 35, 26, 'Raddish/ಮೂಲಂಗಿ ', '16.00', '20.00', '2020-06-29 14:31:43', '2020-07-23 11:58:57', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(884, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '34.00', '25.00', '2020-06-29 14:25:39', '2020-07-23 11:58:57', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(885, 44, 26, 'Drum Stick/ನುಗ್ಗೆ ಕಾಯಿ ', '55.00', '3.00', '2020-07-03 13:08:04', '2020-07-23 20:01:11', '', 'test@gmail.com', 'U', '10.00'),
(886, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '25.00', '5.00', '2020-06-29 14:21:54', '2020-07-24 15:24:10', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '60.00'),
(887, 25, 26, 'Brinjal/ಬದನೇಕಾಯಿ (ಬಿಳಿ )', '18.00', '8.00', '2020-06-29 14:28:47', '2020-07-24 15:24:10', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '80.00'),
(888, 31, 26, 'Cauliflower/ಹೂ ಕೋಸು', '21.00', '15.00', '2020-06-29 14:30:35', '2020-07-24 15:24:10', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '70.00'),
(889, 84, 26, 'Cucumber - British/ ಬ್ರಿಟಿಷ್ ಸೌತೆಕಾಯಿ', '28.00', '3.00', '2020-07-20 14:35:58', '2020-07-24 15:24:10', 'test@gmail.com', 'test@gmail.com', 'U', '10.00'),
(890, 28, 26, 'Cucumber(Green)/ಸೌತೇಕಾಯಿ ', '20.00', '10.00', '2020-06-29 14:29:29', '2020-07-24 15:24:10', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(891, 18, 26, 'Garlic/ಬೆಳ್ಳುಳ್ಳಿ  ', '80.00', '5.00', '2020-06-29 14:26:45', '2020-07-24 15:24:10', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '25.00'),
(892, 20, 26, 'Green chilli/ಹಸಿರು ಮೆಣಸಿನಕಾಯಿ ', '30.00', '5.00', '2020-06-29 14:27:20', '2020-07-24 15:24:10', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(893, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '33.00', '25.00', '2020-06-29 14:25:39', '2020-07-24 15:24:10', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '50.00'),
(894, 20, 26, 'Green chilli/ಹಸಿರು ಮೆಣಸಿನಕಾಯಿ ', '28.00', '5.00', '2020-06-29 14:27:20', '2020-07-24 15:29:13', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '30.00'),
(895, 34, 26, 'Lady\'s finger / Okra/ಬೆಂಡೇಕಾಯಿ  ', '20.00', '20.00', '2020-06-29 14:31:27', '2020-07-24 15:29:13', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '150.00'),
(896, 75, 26, 'Avare Kai/ಅವರೆಕಾಯಿ', '98.00', '5.00', '2020-07-12 15:04:39', '2020-07-25 21:40:47', 'test@gmail.com', 'abhijitjd003@gmail.com', 'U', '50.00'),
(897, 75, 26, 'Avare Kai/ಅವರೆಕಾಯಿ', '99.00', '5.00', '2020-07-12 15:04:39', '2020-07-25 21:41:02', 'test@gmail.com', 'abhijitjd003@gmail.com', 'U', '50.00'),
(898, 86, 27, 'Apple', '100.00', '10.00', '2020-07-25 21:42:01', '2020-07-25 21:42:15', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'D', '0.00'),
(899, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '35.00', '3.00', '2020-06-29 14:22:19', '2020-07-25 16:02:01', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(900, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '30.00', '5.00', '2020-06-29 14:21:54', '2020-07-25 16:02:01', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '120.00'),
(901, 61, 26, 'Beetroot/ಬೀಟ್ ರೂಟ್ ', '24.00', '3.00', '2020-07-05 14:55:16', '2020-07-25 16:02:01', '', 'test@gmail.com', 'U', '0.00'),
(902, 64, 26, 'Bitter gourd/ಹಾಗಲಕಾಯಿ ', '42.00', '3.00', '2020-07-05 19:39:44', '2020-07-25 16:02:01', '', 'test@gmail.com', 'U', '0.00'),
(903, 27, 26, 'Brinjal Round /ಬದನೇಕಾಯಿ ', '14.00', '5.00', '2020-06-29 14:29:17', '2020-07-25 16:02:01', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(904, 10, 26, 'Capsicum/ದಪ್ಪ ಮೆಣಸಿನಕಾಯಿ', '65.00', '8.00', '2020-06-29 14:22:59', '2020-07-25 16:02:01', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(905, 9, 26, 'Carrot/ಕ್ಯಾರೆಟ್ ', '34.00', '10.00', '2020-06-29 14:22:41', '2020-07-25 16:02:01', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(906, 34, 26, 'Lady\'s finger / Okra/ಬೆಂಡೇಕಾಯಿ  ', '19.00', '20.00', '2020-06-29 14:31:27', '2020-07-25 16:02:01', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(907, 11, 26, 'Potato/ಆಲೂ ಗೆಡ್ಡೆ ', '31.00', '7.00', '2020-06-29 14:23:51', '2020-07-25 16:02:01', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(908, 45, 26, 'Ridge Gourd/ಹೀರೆಕಾಯಿ ', '26.00', '3.00', '2020-07-03 13:08:28', '2020-07-25 16:02:01', '', 'test@gmail.com', 'U', '0.00'),
(909, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '28.00', '25.00', '2020-06-29 14:25:39', '2020-07-25 16:02:01', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(910, 76, 26, 'Bitter Gourd- White  / ಬಿಳಿ ಹಾಗಲಕಾಯಿ  ', '42.00', '3.00', '2020-07-12 15:27:22', '2020-07-26 13:55:28', 'test@gmail.com', 'test@gmail.com', 'U', '0.00'),
(911, 64, 26, 'Bitter gourd/ಹಾಗಲಕಾಯಿ ', '40.00', '3.00', '2020-07-05 19:39:44', '2020-07-26 13:55:28', '', 'test@gmail.com', 'U', '0.00'),
(912, 31, 26, 'Cauliflower/ಹೂ ಕೋಸು', '18.00', '15.00', '2020-06-29 14:30:35', '2020-07-26 13:55:28', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(913, 20, 26, 'Green chilli/ಹಸಿರು ಮೆಣಸಿನಕಾಯಿ ', '29.00', '5.00', '2020-06-29 14:27:20', '2020-07-26 13:55:28', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-30.00'),
(914, 36, 26, 'Ivy gourd/ತೊಂಡೆ ಕಾಯಿ ', '23.00', '10.00', '2020-06-29 14:32:02', '2020-07-26 13:55:28', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(915, 63, 26, 'Knol Khol /ನವಿಲುಕೋಸು ', '23.00', '5.00', '2020-07-05 19:38:57', '2020-07-26 13:55:28', '', 'test@gmail.com', 'U', '0.00'),
(916, 29, 26, 'Mangalore Cucumber/ಮಂಗಳೂರು ಸವತೆಕಾಯಿ ', '16.00', '13.00', '2020-06-29 14:30:03', '2020-07-26 13:55:28', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(917, 45, 26, 'Ridge Gourd/ಹೀರೆಕಾಯಿ ', '28.00', '3.00', '2020-07-03 13:08:28', '2020-07-26 13:55:28', '', 'test@gmail.com', 'U', '0.00'),
(918, 13, 26, 'Tomato(Sour)/ಟೊಮ್ಯಾಟೊ ', '22.00', '100.00', '2020-06-29 14:25:12', '2020-07-26 13:55:28', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-400.00'),
(919, 25, 26, 'Brinjal/ಬದನೇಕಾಯಿ (ಬಿಳಿ )', '16.00', '8.00', '2020-06-29 14:28:47', '2020-07-26 13:56:25', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(920, 25, 26, 'Brinjal/ಬದನೇಕಾಯಿ (ಬಿಳಿ )', '19.00', '8.00', '2020-06-29 14:28:47', '2020-07-26 14:10:06', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(921, 9, 26, 'Carrot/ಕ್ಯಾರೆಟ್ ', '36.00', '10.00', '2020-06-29 14:22:41', '2020-07-26 14:10:06', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-10.00'),
(922, 45, 26, 'Ridge Gourd/ಹೀರೆಕಾಯಿ ', '32.00', '3.00', '2020-07-03 13:08:28', '2020-07-26 14:10:06', '', 'test@gmail.com', 'U', '0.00'),
(923, 44, 26, 'Drum Stick/ನುಗ್ಗೆ ಕಾಯಿ ', '50.00', '3.00', '2020-07-03 13:08:04', '2020-07-26 14:17:18', '', 'test@gmail.com', 'U', '0.00'),
(924, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '31.00', '5.00', '2020-06-29 14:21:54', '2020-07-27 12:38:51', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '95.00'),
(925, 64, 26, 'Bitter gourd/ಹಾಗಲಕಾಯಿ ', '38.00', '3.00', '2020-07-05 19:39:44', '2020-07-27 12:38:51', '', 'test@gmail.com', 'U', '-3.00'),
(926, 27, 26, 'Brinjal Round /ಬದನೇಕಾಯಿ ', '14.50', '5.00', '2020-06-29 14:29:17', '2020-07-27 12:38:51', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'U', '-5.00'),
(927, 62, 26, 'Chayote Gourd/ಸೀಮೆ ಬದನೆ ', '24.00', '10.00', '2020-07-05 15:30:20', '2020-07-27 12:38:51', '', 'abhijitjd003@gmail.com', 'U', '-10.00'),
(928, 63, 26, 'Knol Khol /ನವಿಲುಕೋಸು ', '24.00', '5.00', '2020-07-05 19:38:57', '2020-07-27 12:38:51', '', 'test@gmail.com', 'U', '0.00'),
(929, 11, 26, 'Potato/ಆಲೂ ಗೆಡ್ಡೆ ', '32.00', '7.00', '2020-06-29 14:23:51', '2020-07-27 12:38:51', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(930, 35, 26, 'Raddish/ಮೂಲಂಗಿ ', '15.00', '20.00', '2020-06-29 14:31:43', '2020-07-27 12:38:51', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(931, 45, 26, 'Ridge Gourd/ಹೀರೆಕಾಯಿ ', '30.00', '3.00', '2020-07-03 13:08:28', '2020-07-27 12:38:51', '', 'test@gmail.com', 'U', '0.00'),
(932, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '32.00', '25.00', '2020-06-29 14:25:39', '2020-07-27 12:38:51', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(933, 13, 26, 'Tomato(Sour)/ಟೊಮ್ಯಾಟೊ ', '24.00', '100.00', '2020-06-29 14:25:12', '2020-07-27 12:38:51', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-400.00'),
(934, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '36.00', '5.00', '2020-06-29 14:21:54', '2020-07-27 12:40:47', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '95.00'),
(935, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '36.00', '3.00', '2020-06-29 14:22:19', '2020-07-27 12:40:57', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-75.00'),
(936, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '38.00', '3.00', '2020-06-29 14:22:19', '2020-07-28 14:30:52', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '119.00'),
(937, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '35.00', '3.00', '2020-06-29 14:21:54', '2020-07-28 14:30:52', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '85.00'),
(938, 64, 26, 'Bitter gourd/ಹಾಗಲಕಾಯಿ ', '34.00', '3.00', '2020-07-05 19:39:44', '2020-07-28 14:30:52', '', 'test@gmail.com', 'U', '-3.00'),
(939, 10, 26, 'Capsicum/ದಪ್ಪ ಮೆಣಸಿನಕಾಯಿ', '68.00', '3.00', '2020-06-29 14:22:59', '2020-07-28 14:30:52', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-16.00'),
(940, 9, 26, 'Carrot/ಕ್ಯಾರೆಟ್ ', '35.00', '3.00', '2020-06-29 14:22:41', '2020-07-28 14:30:52', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-10.00'),
(941, 31, 26, 'Cauliflower/ಹೂ ಕೋಸು', '20.00', '3.00', '2020-06-29 14:30:35', '2020-07-28 14:30:52', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(942, 84, 26, 'Cucumber - British/ ಬ್ರಿಟಿಷ್ ಸೌತೆಕಾಯಿ', '18.00', '3.00', '2020-07-20 14:35:58', '2020-07-28 14:30:52', 'test@gmail.com', 'test@gmail.com', 'U', '0.00'),
(943, 36, 26, 'Ivy gourd/ತೊಂಡೆ ಕಾಯಿ ', '24.00', '3.00', '2020-06-29 14:32:02', '2020-07-28 14:30:52', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(944, 63, 26, 'Knol Khol /ನವಿಲುಕೋಸು ', '22.00', '3.00', '2020-07-05 19:38:57', '2020-07-28 14:30:52', '', 'test@gmail.com', 'U', '0.00'),
(945, 11, 26, 'Potato/ಆಲೂ ಗೆಡ್ಡೆ ', '31.50', '3.00', '2020-06-29 14:23:51', '2020-07-28 14:30:52', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(946, 45, 26, 'Ridge Gourd/ಹೀರೆಕಾಯಿ ', '27.00', '3.00', '2020-07-03 13:08:28', '2020-07-28 14:30:52', '', 'test@gmail.com', 'U', '0.00'),
(947, 14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '30.00', '3.00', '2020-06-29 14:25:39', '2020-07-28 14:30:52', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '135.00'),
(948, 13, 26, 'Tomato(Sour)/ಟೊಮ್ಯಾಟೊ ', '18.00', '5.00', '2020-06-29 14:25:12', '2020-07-28 14:30:52', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-400.00'),
(949, 13, 26, 'Tomato(Sour)/ಟೊಮ್ಯಾಟೊ ', '21.00', '5.00', '2020-06-29 14:25:12', '2020-07-28 14:38:00', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-400.00'),
(950, 61, 26, 'Beetroot/ಬೀಟ್ ರೂಟ್ ', '26.00', '3.00', '2020-07-05 14:55:16', '2020-07-28 14:44:19', '', 'test@gmail.com', 'U', '-18.00'),
(951, 8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '45.00', '3.00', '2020-06-29 14:22:19', '2020-07-29 14:42:38', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '116.00'),
(952, 7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '40.00', '3.00', '2020-06-29 14:21:54', '2020-07-29 14:42:38', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '85.00'),
(953, 10, 26, 'Capsicum/ದಪ್ಪ ಮೆಣಸಿನಕಾಯಿ', '69.00', '3.00', '2020-06-29 14:22:59', '2020-07-29 14:42:38', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '-16.00'),
(954, 31, 26, 'Cauliflower/ಹೂ ಕೋಸು', '21.00', '3.00', '2020-06-29 14:30:35', '2020-07-29 14:42:38', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(955, 84, 26, 'Cucumber - British/ ಬ್ರಿಟಿಷ್ ಸೌತೆಕಾಯಿ', '20.00', '3.00', '2020-07-20 14:35:58', '2020-07-29 14:42:38', 'test@gmail.com', 'test@gmail.com', 'U', '0.00'),
(956, 36, 26, 'Ivy gourd/ತೊಂಡೆ ಕಾಯಿ ', '26.00', '3.00', '2020-06-29 14:32:02', '2020-07-29 14:42:38', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(957, 73, 26, 'Menthya Soppu/ಮೆಂತ್ಯ ಸೊಪ್ಪು ', '4.00', '1.00', '2020-07-09 14:25:43', '2020-07-29 14:42:38', 'test@gmail.com', 'test@gmail.com', 'U', '0.00'),
(958, 11, 26, 'Potato/ಆಲೂ ಗೆಡ್ಡೆ ', '32.00', '3.00', '2020-06-29 14:23:51', '2020-07-29 14:42:38', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(959, 65, 26, 'Pumpkin(Green)/ಕುಂಬಳಕಾಯಿ ', '11.00', '5.00', '2020-07-05 19:44:05', '2020-07-29 14:42:38', '', 'test@gmail.com', 'U', '0.00'),
(960, 28, 26, 'Cucumber(Green)/ಸೌತೇಕಾಯಿ ', '18.00', '3.00', '2020-06-29 14:29:29', '2020-07-29 14:43:34', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00'),
(961, 11, 26, 'Potato/ಆಲೂ ಗೆಡ್ಡೆ ', '33.00', '3.00', '2020-06-29 14:23:51', '2020-07-29 14:51:05', 'abhijitjd003@gmail.com', 'test@gmail.com', 'U', '0.00');

-- --------------------------------------------------------

--
-- Table structure for table `Products`
--

DROP TABLE IF EXISTS `Products`;
CREATE TABLE IF NOT EXISTS `Products` (
  `ProductId` int(11) NOT NULL AUTO_INCREMENT,
  `CategoryId` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `RatePerKG` decimal(10,2) NOT NULL,
  `MinPurchaseQuantity` decimal(10,2) NOT NULL,
  `CreatedDateTime` datetime NOT NULL,
  `UpdatedDateTime` datetime NOT NULL,
  `CreatedUserId` varchar(50) NOT NULL,
  `UpdatedUserId` varchar(50) NOT NULL,
  `Deactivate` varchar(4) DEFAULT NULL,
  `TotalStock` decimal(10,2) NOT NULL,
  `ProductImagePath` varchar(200) NOT NULL,
  `UnitType` varchar(10) NOT NULL,
  `GradeBStock` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`ProductId`),
  KEY `FK_CategoryId` (`CategoryId`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Products`
--

INSERT INTO `Products` (`ProductId`, `CategoryId`, `Name`, `RatePerKG`, `MinPurchaseQuantity`, `CreatedDateTime`, `UpdatedDateTime`, `CreatedUserId`, `UpdatedUserId`, `Deactivate`, `TotalStock`, `ProductImagePath`, `UnitType`, `GradeBStock`) VALUES
(7, 26, 'Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '38.00', '3.00', '2020-06-29 14:21:54', '2020-07-29 14:51:05', 'abhijitjd003@gmail.com', 'test@gmail.com', 'NO', '49.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 15 copy.JPG', 'KG', '0.00'),
(8, 26, 'Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '43.00', '3.00', '2020-06-29 14:22:19', '2020-07-29 14:51:05', 'abhijitjd003@gmail.com', 'test@gmail.com', 'NO', '53.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 23 copy.JPG', 'KG', '0.00'),
(9, 26, 'Carrot/ಕ್ಯಾರೆಟ್ ', '36.00', '3.00', '2020-06-29 14:22:41', '2020-07-29 14:51:05', 'abhijitjd003@gmail.com', 'test@gmail.com', 'NO', '-10.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 16 copy.JPG', '', '0.00'),
(10, 26, 'Capsicum/ದಪ್ಪ ಮೆಣಸಿನಕಾಯಿ', '68.00', '3.00', '2020-06-29 14:22:59', '2020-07-29 14:51:05', 'abhijitjd003@gmail.com', 'test@gmail.com', 'NO', '-16.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 27 copy.JPG', '', '0.00'),
(11, 26, 'Potato/ಆಲೂ ಗೆಡ್ಡೆ ', '32.00', '3.00', '2020-06-29 14:23:51', '2020-07-29 14:51:05', 'abhijitjd003@gmail.com', 'test@gmail.com', 'NO', '0.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 21 copy.JPG', 'KG', '0.00'),
(13, 26, 'Tomato(Sour)/ಟೊಮ್ಯಾಟೊ ', '20.00', '5.00', '2020-06-29 14:25:12', '2020-07-29 14:51:05', 'abhijitjd003@gmail.com', 'test@gmail.com', 'NO', '-410.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 49 copy.JPG', '', '0.00'),
(14, 26, 'Tomato(Jamoon)/ಟೊಮ್ಯಾಟೊ', '32.00', '3.00', '2020-06-29 14:25:39', '2020-07-29 14:51:05', 'abhijitjd003@gmail.com', 'test@gmail.com', 'NO', '129.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 50 copy.JPG', '', '0.00'),
(15, 26, 'Onion/ಈರುಳ್ಳಿ ', '15.00', '5.00', '2020-06-29 14:25:53', '2020-07-29 14:51:05', 'abhijitjd003@gmail.com', 'test@gmail.com', 'NO', '0.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 44 copy.JPG', '', '0.00'),
(16, 26, 'Onion Small /ಸಣ್ಣ ಈರುಳ್ಳಿ  ', '42.00', '3.00', '2020-06-29 14:26:10', '2020-07-29 14:51:05', 'abhijitjd003@gmail.com', 'test@gmail.com', 'NO', '0.00', 'http://demo.farmar.in/UploadedFiles/Products/small-onion-310128419-t1ciq.jpg', '', '0.00'),
(18, 26, 'Garlic/ಬೆಳ್ಳುಳ್ಳಿ  ', '110.00', '2.00', '2020-06-29 14:26:45', '2020-07-29 14:51:05', 'abhijitjd003@gmail.com', 'test@gmail.com', 'NO', '0.00', 'http://demo.farmar.in/UploadedFiles/Products/garlic.jpg', '', '0.00'),
(19, 26, 'Ginger/ಶುಂಠಿ', '60.00', '2.00', '2020-06-29 14:27:04', '2020-07-29 14:51:05', 'abhijitjd003@gmail.com', 'test@gmail.com', 'NO', '0.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 32 copy.JPG', '', '0.00'),
(20, 26, 'Green chilli/ಹಸಿರು ಮೆಣಸಿನಕಾಯಿ ', '32.00', '1.00', '2020-06-29 14:27:20', '2020-07-29 14:51:05', 'abhijitjd003@gmail.com', 'test@gmail.com', 'NO', '-30.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 33 copy.JPG', '', '0.00'),
(21, 26, 'Lemon/ನಿಂಬೆ ಹಣ್ಣು ', '50.00', '2.00', '2020-06-29 14:27:39', '2020-07-29 14:51:05', 'abhijitjd003@gmail.com', 'test@gmail.com', 'YES', '0.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 39 copy.JPG', '', '0.00'),
(25, 26, 'Brinjal/ಬದನೇಕಾಯಿ (ಬಿಳಿ )', '18.00', '3.00', '2020-06-29 14:28:47', '2020-07-29 14:51:05', 'abhijitjd003@gmail.com', 'test@gmail.com', 'NO', '-6.00', 'http://demo.farmar.in/UploadedFiles/Products/brinjal (long).jpg', '', '0.00'),
(26, 26, 'Brinjal Black /ಬದನೇಕಾಯಿ', '32.00', '3.00', '2020-06-29 14:29:04', '2020-07-29 14:51:05', 'abhijitjd003@gmail.com', 'test@gmail.com', 'YES', '0.00', 'http://demo.farmar.in/UploadedFiles/Products/51GF3m4aeSL._SL1000_.jpg', '', '0.00'),
(27, 26, 'Brinjal Round /ಬದನೇಕಾಯಿ ', '14.00', '3.00', '2020-06-29 14:29:17', '2020-07-29 14:51:05', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 'NO', '-5.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 25 copy.JPG', 'KG', '0.00'),
(28, 26, 'Cucumber(Green)/ಸೌತೇಕಾಯಿ ', '25.00', '3.00', '2020-06-29 14:29:29', '2020-07-29 14:51:05', 'abhijitjd003@gmail.com', 'test@gmail.com', 'NO', '0.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 29 copy.JPG', '', '0.00'),
(29, 26, 'Mangalore Cucumber/ಮಂಗಳೂರು ಸವತೆಕಾಯಿ ', '19.00', '3.00', '2020-06-29 14:30:03', '2020-07-29 14:51:05', 'abhijitjd003@gmail.com', 'test@gmail.com', 'NO', '0.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 40 copy.JPG', '', '0.00'),
(30, 26, 'Cabbage/ಎಲೆ ಕೋಸು', '11.00', '3.00', '2020-06-29 14:30:17', '2020-07-29 14:51:05', 'abhijitjd003@gmail.com', 'test@gmail.com', 'NO', '85.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 26 copy.JPG', '', '10.00'),
(31, 26, 'Cauliflower/ಹೂ ಕೋಸು', '22.00', '3.00', '2020-06-29 14:30:35', '2020-07-29 14:51:05', 'abhijitjd003@gmail.com', 'test@gmail.com', 'NO', '0.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 281.jpg', '', '0.00'),
(34, 26, 'Lady\'s finger / Okra/ಬೆಂಡೇಕಾಯಿ  ', '20.00', '3.00', '2020-06-29 14:31:27', '2020-07-29 14:51:05', 'abhijitjd003@gmail.com', 'test@gmail.com', 'NO', '0.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 17 copy.JPG', '', '0.00'),
(35, 26, 'Raddish/ಮೂಲಂಗಿ ', '16.00', '3.00', '2020-06-29 14:31:43', '2020-07-29 14:51:05', 'abhijitjd003@gmail.com', 'test@gmail.com', 'NO', '0.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 43 copy.JPG', '', '0.00'),
(36, 26, 'Ivy gourd/ತೊಂಡೆ ಕಾಯಿ ', '25.00', '3.00', '2020-06-29 14:32:02', '2020-07-29 14:51:05', 'abhijitjd003@gmail.com', 'test@gmail.com', 'NO', '0.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 51 copy.JPG', '', '0.00'),
(42, 26, 'Halasande/ಹಲಸಂದೆ (ಉದ್ದ ) ', '27.00', '10.00', '2020-07-03 08:31:50', '2020-07-29 14:51:05', '', 'test@gmail.com', 'YES', '0.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 36 copy.JPG', '', '0.00'),
(44, 26, 'Drum Stick/ನುಗ್ಗೆ ಕಾಯಿ ', '46.00', '3.00', '2020-07-03 13:08:04', '2020-07-29 14:51:05', '', 'test@gmail.com', 'NO', '0.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 30 copy.JPG', '', '0.00'),
(45, 26, 'Ridge Gourd/ಹೀರೆಕಾಯಿ ', '28.00', '3.00', '2020-07-03 13:08:28', '2020-07-29 14:51:05', '', 'test@gmail.com', 'NO', '0.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 35 copy.JPG', '', '0.00'),
(46, 26, 'Snake gourd/ಪಡವಲಕಾಯಿ  ', '16.00', '3.00', '2020-07-03 13:08:54', '2020-07-29 14:51:05', '', 'test@gmail.com', 'YES', '0.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 45 copy.JPG', '', '0.00'),
(47, 26, 'Bottle gourd/ಸೋರೆಕಾಯಿ', '12.00', '3.00', '2020-07-03 13:09:17', '2020-07-29 14:51:05', '', 'test@gmail.com', 'YES', '0.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 48 copy.JPG', '', '0.00'),
(61, 26, 'Beetroot/ಬೀಟ್ ರೂಟ್ ', '25.00', '3.00', '2020-07-05 14:55:16', '2020-07-29 14:51:05', '', 'test@gmail.com', 'NO', '-45.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 22 copy.JPG', '', '0.00'),
(62, 26, 'Chayote Gourd/ಸೀಮೆ ಬದನೆ ', '26.00', '3.00', '2020-07-05 15:30:20', '2020-07-29 14:51:05', '', 'abhijitjd003@gmail.com', 'NO', '-10.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 46 copy.JPG', 'KG', '0.00'),
(63, 26, 'Knol Khol /ನವಿಲುಕೋಸು ', '24.00', '3.00', '2020-07-05 19:38:57', '2020-07-29 14:51:05', '', 'test@gmail.com', 'NO', '0.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 37 copy.JPG', '', '0.00'),
(64, 26, 'Bitter gourd/ಹಾಗಲಕಾಯಿ ', '38.00', '3.00', '2020-07-05 19:39:44', '2020-07-29 14:51:05', '', 'test@gmail.com', 'NO', '-18.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 34 copy.JPG', '', '0.00'),
(65, 26, 'Pumpkin(Green)/ಕುಂಬಳಕಾಯಿ ', '12.00', '5.00', '2020-07-05 19:44:05', '2020-07-29 14:51:05', '', 'test@gmail.com', 'NO', '-10.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 38 copy.JPG', '', '0.00'),
(67, 26, 'Coriander leaves/ಕೊತ್ತಂಬರಿ ಸೊಪ್ಪು', '4.00', '5.00', '2020-07-06 12:39:51', '2020-07-29 14:51:05', '', 'test@gmail.com', 'NO', '0.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 59 copy.JPG', '', '0.00'),
(68, 26, 'Curry leaves/ಕರಿಬೇವು   ', '2.00', '5.00', '2020-07-06 12:40:25', '2020-07-29 14:51:05', '', 'test@gmail.com', 'NO', '0.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 60 copy.JPG', '', '0.00'),
(69, 26, 'Mint leaves/ಪುದಿನ ಸೊಪ್ಪು ', '3.00', '5.00', '2020-07-06 12:40:50', '2020-07-29 14:51:05', '', 'test@gmail.com', 'NO', '0.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 58 copy.jpg', '', '0.00'),
(70, 26, 'Palak/ಪಾಲಾಕ್ ', '2.50', '5.00', '2020-07-06 12:41:13', '2020-07-29 14:51:05', '', 'test@gmail.com', 'NO', '0.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 571 copy.JPG', '', '0.00'),
(71, 26, 'Sabsige Soppu / ಸಬ್ಸಿಗೆ ಸೊಪ್ಪು ', '2.50', '5.00', '2020-07-06 12:41:52', '2020-07-29 14:51:05', '', 'test@gmail.com', 'NO', '0.00', 'http://demo.farmar.in/UploadedFiles/Products/sabsige.png', '', '0.00'),
(72, 26, 'Balekayi/ಬಾಲೆಕಾಯಿ', '8.00', '3.00', '2020-07-09 14:18:36', '2020-07-29 14:51:05', 'test@gmail.com', 'test@gmail.com', 'NO', '64.00', 'http://demo.farmar.in/UploadedFiles/Products/download (1).jpg', 'Piece', '0.00'),
(73, 26, 'Menthya Soppu/ಮೆಂತ್ಯ ಸೊಪ್ಪು ', '5.00', '1.00', '2020-07-09 14:25:43', '2020-07-29 14:51:05', 'test@gmail.com', 'test@gmail.com', 'NO', '0.00', 'http://demo.farmar.in/UploadedFiles/Products/menthya.jpg', '', '0.00'),
(75, 26, 'Avare Kai/ಅವರೆಕಾಯಿ', '98.00', '3.00', '2020-07-12 15:04:39', '2020-07-29 14:51:05', 'test@gmail.com', 'abhijitjd003@gmail.com', 'YES', '-20.00', 'http://demo.farmar.in/UploadedFiles/Products/37.jpg', 'KG', '0.00'),
(76, 26, 'Bitter Gourd- White  / ಬಿಳಿ ಹಾಗಲಕಾಯಿ  ', '0.00', '3.00', '2020-07-12 15:27:22', '2020-07-29 14:51:05', 'test@gmail.com', 'test@gmail.com', 'YES', '0.00', 'http://demo.farmar.in/UploadedFiles/Products/31ejn6doxEL.jpg', '', '0.00'),
(77, 26, 'Cluster Beans / ಗೋರಿಕಾಯಿ ', '22.00', '3.00', '2020-07-12 15:42:27', '2020-07-29 14:51:05', 'test@gmail.com', 'test@gmail.com', 'YES', '0.00', 'http://demo.farmar.in/UploadedFiles/Products/Gorikai.jpg', '', '0.00'),
(78, 26, 'Avarekai - Chapparada / ಚಪ್ಪರದ ಅವರೆಕಾಯಿ', '33.00', '3.00', '2020-07-13 15:20:54', '2020-07-29 14:51:05', 'test@gmail.com', 'abhijitjd003@gmail.com', 'YES', '0.00', 'http://demo.farmar.in/UploadedFiles/Products/lab-lab-long-bean-250x250.png', 'KG', '0.00'),
(79, 27, 'Banana(Yellaki) / ಬಾಳೆಹಣ್ಣು', '25.00', '3.00', '2020-07-17 22:20:12', '2020-07-29 14:51:05', 'test@gmail.com', 'test@gmail.com', 'YES', '0.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 17 copy.JPG', 'KG', '0.00'),
(80, 27, 'Banana(Pachbale)/ಬಾಳೆಹಣ್ಣು', '35.00', '3.00', '2020-07-17 22:21:11', '2020-07-29 14:51:05', 'test@gmail.com', 'test@gmail.com', 'YES', '0.00', 'http://demo.farmar.in/UploadedFiles/Products/Layer 17 copy.jpg', 'KG', '0.00'),
(83, 26, 'Chilli Bajji', '50.00', '3.00', '2020-07-19 14:23:45', '2020-07-29 14:51:05', 'test@gmail.com', 'test@gmail.com', 'YES', '0.00', 'http://demo.farmar.in/UploadedFiles/Products/s-l300.jpg', 'KG', '0.00'),
(84, 26, 'Cucumber - British/ ಬ್ರಿಟಿಷ್ ಸೌತೆಕಾಯಿ', '25.00', '3.00', '2020-07-20 14:35:58', '2020-07-29 14:51:05', 'test@gmail.com', 'test@gmail.com', 'YES', '0.00', 'http://demo.farmar.in/UploadedFiles/Products/british cucumber.jpg', 'KG', '0.00');

-- --------------------------------------------------------

--
-- Table structure for table `RemovedGradeAStock`
--

DROP TABLE IF EXISTS `RemovedGradeAStock`;
CREATE TABLE IF NOT EXISTS `RemovedGradeAStock` (
  `ProductName` varchar(50) NOT NULL,
  `Weight` decimal(10,2) DEFAULT NULL,
  `ReasonType` varchar(20) DEFAULT NULL,
  `RemovedDateTime` datetime NOT NULL,
  `RemovedUserId` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `RemovedGradeAStock`
--

INSERT INTO `RemovedGradeAStock` (`ProductName`, `Weight`, `ReasonType`, `RemovedDateTime`, `RemovedUserId`) VALUES
('Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '5.00', 'Expired', '2020-07-25 21:52:32', 'abhijitjd003@gmail.com'),
('Beans/ಬೀನ್ಸ್ (ಸ್ಥಳೀಯ ) ', '5.00', 'Rejected', '2020-07-27 16:41:17', 'test@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `RemovedGradeBStock`
--

DROP TABLE IF EXISTS `RemovedGradeBStock`;
CREATE TABLE IF NOT EXISTS `RemovedGradeBStock` (
  `ProductName` varchar(50) NOT NULL,
  `Weight` decimal(10,2) DEFAULT NULL,
  `BuyerName` varchar(50) NOT NULL,
  `RemovedDateTime` datetime NOT NULL,
  `RemovedUserId` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `RemovedGradeBStock`
--

INSERT INTO `RemovedGradeBStock` (`ProductName`, `Weight`, `BuyerName`, `RemovedDateTime`, `RemovedUserId`) VALUES
('Balekayi/ಬಾಲೆಕಾಯಿ', '20.00', 'Udupi Hotel', '2020-07-26 22:59:50', 'abhijitjd003@gmail.com'),
('Beans Ooty /ಬೀನ್ಸ್ (ಊಟಿ)', '10.00', 'XYZ', '2020-07-28 00:12:05', 'test@gmail.com'),
('Cabbage/ಎಲೆ ಕೋಸು', '7.00', 'Udupi Hotel', '2020-07-29 21:14:44', 'abhijitjd003@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `Routes`
--

DROP TABLE IF EXISTS `Routes`;
CREATE TABLE IF NOT EXISTS `Routes` (
  `RouteCategory` varchar(30) NOT NULL,
  `Route` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Routes`
--

INSERT INTO `Routes` (`RouteCategory`, `Route`) VALUES
('Route A', 'Kuvempu Nagar'),
('Route B', 'Vivekanand Nagar'),
('Route C', 'Hebbal');

-- --------------------------------------------------------

--
-- Table structure for table `ShopDetails`
--

DROP TABLE IF EXISTS `ShopDetails`;
CREATE TABLE IF NOT EXISTS `ShopDetails` (
  `ShopId` int(11) NOT NULL AUTO_INCREMENT,
  `ShopName` varchar(50) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `GSTNo` varchar(30) DEFAULT NULL,
  `ReferralCode` varchar(20) DEFAULT NULL,
  `MobileNo` bigint(20) NOT NULL,
  `Status` varchar(30) NOT NULL,
  `RejectedReason` varchar(100) DEFAULT NULL,
  `Location` varchar(400) NOT NULL,
  `CreatedDateTime` datetime NOT NULL,
  `UpdatedDateTime` datetime NOT NULL,
  `UpdatedUserId` varchar(50) NOT NULL,
  `CreatedUserId` varchar(50) NOT NULL,
  `AlternateContactNo` bigint(20) DEFAULT NULL,
  `Email` varchar(30) DEFAULT NULL,
  `ContactPerson` varchar(50) NOT NULL,
  `Route` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`ShopId`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ShopDetails`
--

INSERT INTO `ShopDetails` (`ShopId`, `ShopName`, `Address`, `GSTNo`, `ReferralCode`, `MobileNo`, `Status`, `RejectedReason`, `Location`, `CreatedDateTime`, `UpdatedDateTime`, `UpdatedUserId`, `CreatedUserId`, `AlternateContactNo`, `Email`, `ContactPerson`, `Route`) VALUES
(4, 'HOP COMS', 'Bangalore', '', '', 8123506123, 'Approved', NULL, 'Horamavu, Bangalore', '2020-07-06 01:59:24', '2020-07-27 20:22:50', 'abhijitjd003@gmail.com', '', 0, 'abhijitjd003@gmail.com', 'Abhijit Dharangutte', 'Route B'),
(5, 'HOP COMS BLR', 'test', NULL, NULL, 8123506123, 'Approved', NULL, 'test', '2020-07-08 04:18:14', '2020-07-20 18:35:23', 'md@spicetrip.com', '', 0, 'test@gmail.com', 'Abhijit', 'Route A'),
(6, 'Fresh Store', 'Dattagalli', NULL, NULL, 9999999999, 'Approved', NULL, 'Mysore', '2020-07-18 13:00:14', '2020-07-20 18:35:23', 'md@spicetrip.com', 'md@spicetrip.com', 9999999999, 'fresh@gmail.com', 'Kiran', 'Route A'),
(7, 'MTM Stores', 'Saraswathipuram', '', '', 9999999999, 'InProgress', NULL, 'Mysore', '2020-07-24 18:13:02', '2020-07-29 11:43:25', 'abhijitjd003@gmail.com', 'test@gmail.com', 0, '', 'Manjunath', NULL),
(8, 'xyz', 'test', '', '', 8123506123, 'Rejected', 'dummy data', 'test', '2020-07-29 11:45:04', '2020-07-29 11:52:52', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 0, '', 'xyz', NULL),
(9, 'xyz', 'dgfafg', NULL, NULL, 9876543211, 'Rejected', 'dummy data', 'dfg', '2020-07-29 11:52:28', '2020-07-29 11:52:52', 'abhijitjd003@gmail.com', 'abhijitjd003@gmail.com', 0, '', 'xyz', NULL),
(10, 'Chamundeshwari Vegetables', '# Tank road, Hootgalli', NULL, NULL, 7204909141, 'InProgress', NULL, 'Mysore', '2020-07-29 14:15:03', '2020-07-29 14:15:03', 'test@gmail.com', 'test@gmail.com', 0, NULL, 'Vasanth Kumar', NULL),
(11, 'Nandi Vegetables', '\"N\" Block, Kuvempunagar (Near to MRF wheel Alignment)', NULL, NULL, 7760375777, 'InProgress', NULL, 'Mysore', '2020-07-29 14:19:09', '2020-07-29 14:19:09', 'test@gmail.com', 'test@gmail.com', 0, NULL, 'Basavaraju', NULL),
(12, 'S.L.V. Vegetables', 'University Layout, Near R.T.Nagar', NULL, NULL, 7892797291, 'InProgress', NULL, 'Mysore', '2020-07-29 14:20:55', '2020-07-29 14:20:55', 'test@gmail.com', 'test@gmail.com', 0, NULL, 'Lakshmi NArayan', NULL),
(13, 'Hotel Akshaya Veg', 'Opposite to Appollo Hospital, Kuvempunagar', NULL, NULL, 9901793009, 'InProgress', NULL, 'Mysore', '2020-07-29 14:22:31', '2020-07-29 14:22:31', 'test@gmail.com', 'test@gmail.com', 0, NULL, 'M.K.VinayaBabu', NULL),
(14, 'Dosa Point ', 'Appollo Road, Kuvempunagar', NULL, NULL, 9916256503, 'InProgress', NULL, 'Mysore', '2020-07-29 14:24:06', '2020-07-29 14:24:06', 'test@gmail.com', 'test@gmail.com', 0, NULL, 'Mr. Rakshith', NULL),
(15, 'Vaishnavi Dosa Palace ', 'Ramaswamy Circle', NULL, NULL, 9686195178, 'InProgress', NULL, 'Mysore', '2020-07-29 14:25:25', '2020-07-29 14:25:25', 'test@gmail.com', 'test@gmail.com', 0, NULL, 'Renuka Raju', NULL),
(16, 'Raithana Thota', '#2024, Kanakadasanagar,Dattagalli', NULL, NULL, 9986678798, 'InProgress', NULL, 'Mysore', '2020-07-29 14:28:13', '2020-07-29 14:28:13', 'test@gmail.com', 'test@gmail.com', 0, NULL, 'Uday', NULL),
(21, 'Hbcbhd', 'Bbdbbd', '', '', 8050106577, 'InProgress', NULL, '12.8552105,74.8438975', '2020-07-30 01:20:39', '2020-07-30 01:27:23', '8050106577', '8050106577', 0, NULL, '', NULL),
(22, 'Test Mart', 'Mysuru', '', '', 9886168703, 'Approved', NULL, '12.2844928,76.6020156', '2020-07-30 01:52:41', '2020-07-30 02:16:49', 'test@gmail.com', '9886168703', 0, NULL, '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ShopImages`
--

DROP TABLE IF EXISTS `ShopImages`;
CREATE TABLE IF NOT EXISTS `ShopImages` (
  `ShopId` int(11) NOT NULL,
  `Image1` varchar(200) NOT NULL,
  `Image2` varchar(200) NOT NULL,
  `Image3` varchar(200) NOT NULL,
  KEY `ShopId` (`ShopId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ShopImages`
--

INSERT INTO `ShopImages` (`ShopId`, `Image1`, `Image2`, `Image3`) VALUES
(4, 'http://demo.farmar.in/UploadedFiles/Vendors/shop_id/1.png', 'http://demo.farmar.in/UploadedFiles/Vendors/shop_id/2.png', 'http://demo.farmar.in/UploadedFiles/Vendors/shop_id/3.png'),
(8, '', '', ''),
(9, '', '', ''),
(10, '', '', ''),
(11, '', '', ''),
(12, '', '', ''),
(13, '', '', ''),
(14, '', '', ''),
(15, '', '', ''),
(16, '', '', ''),
(21, 'http://demo.farmar.in/UploadedFiles/Vendors/21/Cust_59948.jpg', '', ''),
(22, 'http://demo.farmar.in/UploadedFiles/Vendors/22/Cust_42068.jpg', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `Stocks`
--

DROP TABLE IF EXISTS `Stocks`;
CREATE TABLE IF NOT EXISTS `Stocks` (
  `StockId` int(11) NOT NULL AUTO_INCREMENT,
  `VendorId` int(11) NOT NULL,
  `ProductId` int(11) NOT NULL,
  `TotalWeight` decimal(10,2) NOT NULL,
  `GradeAWeight` decimal(10,2) NOT NULL,
  `GradeBWeight` decimal(10,2) DEFAULT NULL,
  `DumpWeight` decimal(10,2) DEFAULT NULL,
  `CreatedDateTime` datetime NOT NULL,
  `CreatedUserId` varchar(50) NOT NULL,
  PRIMARY KEY (`StockId`),
  KEY `FK_S_VendorId` (`VendorId`),
  KEY `FK_S_ProductId` (`ProductId`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Stocks`
--

INSERT INTO `Stocks` (`StockId`, `VendorId`, `ProductId`, `TotalWeight`, `GradeAWeight`, `GradeBWeight`, `DumpWeight`, `CreatedDateTime`, `CreatedUserId`) VALUES
(1, 1, 7, '100.00', '80.00', '10.00', '10.00', '2020-07-25 21:51:30', 'abhijitjd003@gmail.com'),
(2, 2, 7, '70.00', '70.00', '0.00', '0.00', '2020-07-25 21:50:53', 'abhijitjd003@gmail.com'),
(3, 2, 72, '200.00', '150.00', '25.00', '25.00', '2020-07-27 03:15:12', 'abhijitjd003@gmail.com'),
(4, 3, 14, '150.00', '135.00', '10.00', '5.00', '2020-07-27 16:41:04', 'test@gmail.com'),
(5, 1, 8, '250.00', '200.00', '40.00', '10.00', '2020-07-28 01:33:58', 'test@gmail.com'),
(6, 3, 30, '100.00', '80.00', '15.00', '5.00', '2020-07-29 21:13:43', 'abhijitjd003@gmail.com'),
(7, 1, 30, '10.00', '8.00', '2.00', '0.00', '2020-07-29 21:14:12', 'abhijitjd003@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `Users`
--

DROP TABLE IF EXISTS `Users`;
CREATE TABLE IF NOT EXISTS `Users` (
  `UserId` int(11) NOT NULL AUTO_INCREMENT,
  `FullName` varchar(30) NOT NULL,
  `MobileNo` bigint(20) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Role` varchar(20) NOT NULL,
  PRIMARY KEY (`UserId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Users`
--

INSERT INTO `Users` (`UserId`, `FullName`, `MobileNo`, `Email`, `Password`, `Role`) VALUES
(1, 'Abhijit Dharangutte', 8123506123, 'abhijitjd003@gmail.com', '123', 'Admin'),
(2, 'Shamnoon', 9876543210, 'shamnoon@gmail.com', '321', 'Staff'),
(3, 'XYZ', 9876543210, 'xyz@gmail.com', '123', 'Delivery'),
(4, 'ABC', 1234567890, 'abc@gmail.com', '321', 'Delivery'),
(5, 'Test', 1234567890, 'test@gmail.com', '123', 'Admin'),
(6, 'Prashanth B S', 9845404609, 'md@spicetrip.com', 'Delivery456$', 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `Vendors`
--

DROP TABLE IF EXISTS `Vendors`;
CREATE TABLE IF NOT EXISTS `Vendors` (
  `VendorId` int(11) NOT NULL AUTO_INCREMENT,
  `TypeId` int(11) NOT NULL,
  `ContactName` varchar(50) NOT NULL,
  `MobileNo` bigint(20) NOT NULL,
  `Address` varchar(200) NOT NULL,
  `Disable` tinyint(4) DEFAULT NULL,
  `CreatedDateTime` datetime NOT NULL,
  `CreatedUserId` varchar(50) NOT NULL,
  PRIMARY KEY (`VendorId`),
  KEY `FK_TypeId` (`TypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Vendors`
--

INSERT INTO `Vendors` (`VendorId`, `TypeId`, `ContactName`, `MobileNo`, `Address`, `Disable`, `CreatedDateTime`, `CreatedUserId`) VALUES
(1, 1, 'Kanthraj', 9876543210, 'Mysore', 0, '2020-07-25 21:43:39', 'abhijitjd003@gmail.com'),
(2, 2, 'Abhijit', 8123506123, 'Horamavu, Bangalore', 0, '2020-07-25 21:43:47', 'abhijitjd003@gmail.com'),
(3, 3, 'Shravan', 9999999999, 'Daaripura', 0, '2020-07-27 16:40:42', 'test@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `VendorTypes`
--

DROP TABLE IF EXISTS `VendorTypes`;
CREATE TABLE IF NOT EXISTS `VendorTypes` (
  `TypeId` int(11) NOT NULL AUTO_INCREMENT,
  `TypeName` varchar(50) NOT NULL,
  `Description` varchar(1024) DEFAULT NULL,
  `Disable` tinyint(4) DEFAULT NULL,
  `CreatedDateTime` datetime NOT NULL,
  `CreatedUserId` varchar(50) NOT NULL,
  PRIMARY KEY (`TypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `VendorTypes`
--

INSERT INTO `VendorTypes` (`TypeId`, `TypeName`, `Description`, `Disable`, `CreatedDateTime`, `CreatedUserId`) VALUES
(1, 'APMC Seller', 'APMC Seller', 0, '2020-07-25 21:43:17', 'abhijitjd003@gmail.com'),
(2, 'Market Seller', 'Market Seller', 0, '2020-07-25 21:43:23', 'abhijitjd003@gmail.com'),
(3, 'Farmer', 'They grow in their farms and sell it to us', 0, '2020-07-27 16:40:20', 'test@gmail.com');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `OrderProducts`
--
ALTER TABLE `OrderProducts`
  ADD CONSTRAINT `FK_OrderNo` FOREIGN KEY (`OrderNo`) REFERENCES `Orders` (`OrderNo`),
  ADD CONSTRAINT `FK_ProductId` FOREIGN KEY (`ProductId`) REFERENCES `Products` (`ProductId`);

--
-- Constraints for table `Orders`
--
ALTER TABLE `Orders`
  ADD CONSTRAINT `FK_ShopId` FOREIGN KEY (`ShopId`) REFERENCES `ShopDetails` (`ShopId`);

--
-- Constraints for table `Products`
--
ALTER TABLE `Products`
  ADD CONSTRAINT `FK_CategoryId` FOREIGN KEY (`CategoryId`) REFERENCES `ProductCategories` (`CategoryId`);

--
-- Constraints for table `Stocks`
--
ALTER TABLE `Stocks`
  ADD CONSTRAINT `FK_S_VendorId` FOREIGN KEY (`VendorId`) REFERENCES `Vendors` (`VendorId`),
  ADD CONSTRAINT `FK_S_ProductId` FOREIGN KEY (`ProductId`) REFERENCES `Products` (`ProductId`);

--
-- Constraints for table `Vendors`
--
ALTER TABLE `Vendors`
  ADD CONSTRAINT `FK_TypeId` FOREIGN KEY (`TypeId`) REFERENCES `VendorTypes` (`TypeId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
