import React, { Component } from 'react';
import { Route } from 'react-router';
import Layout from './components/Layout';
import MyProfile from './components/MyProfile';
import Dashboard from './components/Dashboard';

export default class DefaultApp extends Component {
    static displayName = DefaultApp.name;

    render() {
        return (
            <Layout>
                <Route path='/MyProfile' component={MyProfile} />
                <Route path='/Dashboard' component={Dashboard} />
            </Layout>
        );
    }
}
