import React, { Component } from 'react';
import './common/Common.css';
import { Grid, withStyles} from '@material-ui/core';
import './common/CommonModal.css';
import { withRouter } from 'react-router-dom';
import Loader from './loader/Loader';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import ActionRenderer from './common/ActionRenderer';
import ConfirmModal from './modal/ConfirmModal';
import ErrorModal from './modal/ErrorModal';

const useStyles = theme => ({
    topMargin: {
        marginTop: 16,
    },
});

class Dashboard extends Component {
    constructor(props) {
        super(props);
        this.state = {
            profileId: 0,
            columnDefs: [
                { 
                    headerName: 'Actions', field: 'Actions', width: 110, sorting: false, filter: false, 
                    cellRenderer: 'actionRenderer'
                },
                { headerName: 'Membership ID', field: 'MembershipId', width: 160 },
                { headerName: 'Full Name', field: 'FullName' },
                { headerName: 'Mobile No', field: 'MobileNo', width: 140 },
                { headerName: 'Email', field: 'Email', width: 190 },
                { headerName: 'Med Council No', field: 'MedCouncilNo', width: 170 },
                { headerName: 'Gender', field: 'Gender', width: 110 },
                { headerName: 'DOB', field: 'DOB', width: 120 },
                { headerName: 'Speciality', field: 'Speciality', width: 120 },
                { headerName: 'Address', field: 'Address' },
                { headerName: 'PinCode', field: 'PinCode', width: 110 },
                { headerName: 'City', field: 'City', width: 110 },
                { headerName: 'State', field: 'State', width: 110 },
                { headerName: 'Nationality', field: 'Nationality', width: 130 },                
                { headerName: 'Residence Tel No', field: 'ResidenceTelNo', width: 170 },
                { headerName: 'Office Tel No', field: 'OfficeTelNo', width: 140 },
                { headerName: 'Alt Mobile No', field: 'AlternateMobileNo', width: 150 },
                { headerName: 'DOJ', field: 'DOJ', width: 120 },
            ],
            context: { componentParent: this },
            frameworkComponents: { actionRenderer: ActionRenderer },
            rowData: [],
            defaultColDef: { sortable: true, resizable: true, filter: true },
            rowClassRules: {
                'grid-row-even': function (params) { return params.node.rowIndex % 2 === 0; },
                'grid-row-odd': function (params) { return params.node.rowIndex % 2 !== 0; }
            },
        };
    }

    loadUsers(){
        fetch('http://localhost:55002/api/DataValidation/Dashboard/GetUsers/')
            .then(res => res.json())
            .then(result => this.setState({ rowData: result, }))
            .catch(err => console.log(err));
    }

    editGridRow = row => {
        let mobileNo = row.MobileNo;
        let email = row.Email;
        sessionStorage.setItem('userEmail', email);
        sessionStorage.setItem('userMobileNo', mobileNo);
        const { history } = this.props;
        if (history) history.push('/MyProfile');
    };

    showConfirmPopup = row => {
        this.setState({ profileId: row.ProfileId })
        this.refs.cnfrmModalComp.openModal();
    }

    DeleteRecord(){
        let ProfileId = this.state.profileId;
        fetch('http://localhost:55002/api/DataValidation/Dashboard/RemoveUser?ProfileId=' + ProfileId, {
            method: 'DELETE',
            mode: 'cors'
        }).then(data => {
            this.loadUsers();
        });
    }

    componentDidMount() {
        this.loadUsers();
    }

    render() {
        const { classes } = this.props;
        
        return (
            <div>
                {this.state.loading ? (
                    <Loader />
                ) : (
                    <div>
                        <ErrorModal ref="errModalComp" />
                        <ConfirmModal ref="cnfrmModalComp" onClick={(e) => this.DeleteRecord(e)} />

                        <h2 style={{ color: '#ff9800' }}>Dashboard</h2>

                        <Grid container spacing={0}>
                            <Grid item xs={12}>
                                <div className="ag-theme-alpine" style={{ width: "100%", height: 600, marginTop: 30 }}>
                                    <AgGridReact
                                        columnDefs={this.state.columnDefs} rowData={this.state.rowData}
                                        onGridReady={this.onGridReady} defaultColDef={this.state.defaultColDef}
                                        frameworkComponents={this.state.frameworkComponents} context={this.state.context}
                                        pagination={true} gridOptions={this.gridOptions} paginationAutoPageSize={true}
                                        components={this.state.components} rowClassRules={this.state.rowClassRules} 
                                        suppressClickEdit={true}
                                    />
                                </div>
                            </Grid>                        
                        </Grid>
                    </div>
                    )}
            </div>
        );
    }
}

export default withRouter(withStyles(useStyles)(Dashboard))