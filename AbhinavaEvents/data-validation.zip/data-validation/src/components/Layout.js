import React, { Component } from 'react';
import NavMenu from './NavMenu';
import { withStyles } from '@material-ui/core/styles';

const useStyles = theme => ({
    root: {
        display: 'flex',
    },
    toolbar: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'flex-end',
        padding: theme.spacing(0, 1),
        ...theme.mixins.toolbar,
    },
    content: {
        flexGrow: 1,
        padding: theme.spacing(0, 5, 0, 5),
        backgroundColor: '#f6f6f6',
    },
});

class Layout extends Component {
    static displayName = Layout.name;

    render() {
        const { classes } = this.props;
        return (
            <div>
                <div className={classes.root}>
                    <NavMenu />
                    <main className={classes.content}>
                        <div className={classes.toolbar} />
                        {this.props.children}
                    </main>
                </div>
            </div>
        );
    }
}

export default withStyles(useStyles)(Layout)
