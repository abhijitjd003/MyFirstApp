-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 148.72.232.169:3306
-- Generation Time: Jul 05, 2020 at 09:22 PM
-- Server version: 5.5.51-38.1-log
-- PHP Version: 7.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `EventMagnet`
--
CREATE DATABASE IF NOT EXISTS `EventMagnet` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `EventMagnet`;

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `usp_CMSDeletePaperPoster`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_CMSDeletePaperPoster`(
	IN Cond_Oper INT,
    IN p_PaperPosterId INT
)
BEGIN
	IF Cond_Oper = 1 THEN
    BEGIN
		DELETE FROM PaperPosters WHERE PaperPosterId = p_PaperPosterId;
    END;
    END IF;
    IF Cond_Oper = 2 THEN
    BEGIN
		SELECT * FROM PaperPosters WHERE PaperPosterId = p_PaperPosterId;
    END;
    END IF;
END
$$

DROP PROCEDURE IF EXISTS `usp_CMSDeleteSchedule`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_CMSDeleteSchedule`(
	IN Cond_Oper INT,
    IN p_ScheduleId INT
)
BEGIN
	IF Cond_Oper = 1 THEN
    BEGIN
		DELETE FROM Schedules WHERE ScheduleId = p_ScheduleId;
    END;
    END IF;
    IF Cond_Oper = 2 THEN
    BEGIN
		SELECT * FROM Schedules WHERE ScheduleId = p_ScheduleId;
    END;
    END IF;
END
$$

DROP PROCEDURE IF EXISTS `usp_CMSDeleteWorkshop`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_CMSDeleteWorkshop`(
	IN Cond_Oper INT,
    IN p_WorkshopId INT
)
BEGIN
	IF Cond_Oper = 1 THEN
    BEGIN
		DELETE FROM Workshops WHERE WorkshopId = p_WorkshopId;
    END;
    END IF;
    IF Cond_Oper = 2 THEN
    BEGIN
		SELECT * FROM Workshops WHERE WorkshopId = p_WorkshopId;
    END;
    END IF;
END
$$

DROP PROCEDURE IF EXISTS `usp_CMSGetConferences`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_CMSGetConferences`(
	IN Cond_Oper INT
)
BEGIN
	IF Cond_Oper = 1 THEN
    BEGIN
		SELECT ConfTypeId, ConfName FROM Conferences;
	END;
    END IF;
    IF Cond_Oper = 2 THEN
    BEGIN
		SELECT * FROM Conferences WHERE IsActive = 1;
	END;
    END IF;
END
$$

DROP PROCEDURE IF EXISTS `usp_CMSGetDelegateByCategoryName`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_CMSGetDelegateByCategoryName`(
	IN Cond_Oper INT,
    IN p_ConfTypeId INT,
    IN p_SearchValue varchar(100)
)
BEGIN
	IF Cond_Oper = 2 THEN
    BEGIN
		SET @row_number = 0;
		SELECT (@row_number := @row_number + 1) AS SINo, DelegateId, Category, Name, RegistrationId,
			DelegateType, PhotoPath
        FROM Delegates
        WHERE ConfTypeId = p_ConfTypeId AND (Category = p_SearchValue OR Name = p_SearchValue OR
			DelegateType = p_SearchValue);
    END;
    END IF;
    IF Cond_Oper = 1 THEN
    BEGIN
		SELECT Category SearchedValue
        FROM Delegates
        WHERE ConfTypeId = p_ConfTypeId AND Category like p_SearchValue
        UNION
        SELECT Name SearchedValue
        FROM Delegates
        WHERE ConfTypeId = p_ConfTypeId AND Name like p_SearchValue
        UNION
        SELECT DelegateType SearchedValue
        FROM Delegates
        WHERE ConfTypeId = p_ConfTypeId AND DelegateType like p_SearchValue;
    END;
    END IF;
END
$$

DROP PROCEDURE IF EXISTS `usp_CMSGetPaperPosterBySpeakerType`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_CMSGetPaperPosterBySpeakerType`(
	IN Cond_Oper INT,
    IN p_ConfTypeId INT,
    IN p_SearchValue varchar(100)
)
BEGIN
	IF Cond_Oper = 2 THEN
    BEGIN
		SELECT * FROM PaperPosters
        WHERE ConfTypeId = p_ConfTypeId AND (PaperPosterType = p_SearchValue OR Speaker = p_SearchValue OR
			FromTime = p_SearchValue);
    END;
    END IF;
    IF Cond_Oper = 1 THEN
    BEGIN
		SELECT PaperPosterType SearchedValue
        FROM PaperPosters
        WHERE ConfTypeId = p_ConfTypeId AND PaperPosterType like p_SearchValue
        UNION
        SELECT Speaker SearchedValue
        FROM PaperPosters
        WHERE ConfTypeId = p_ConfTypeId AND Speaker like p_SearchValue
        UNION
        SELECT FromTime SearchedValue
        FROM PaperPosters
        WHERE ConfTypeId = p_ConfTypeId AND FromTime like p_SearchValue;
    END;
    END IF;
END
$$

DROP PROCEDURE IF EXISTS `usp_CMSGetSaveDeleteConference`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_CMSGetSaveDeleteConference`(
	IN Cond_Oper INT,
    IN p_ConfName VARCHAR(30),
    IN p_ConfTypeId INT,
    In p_LogoPath VARCHAR(100),
    IN p_IsActive INT,
    In p_ColorTheme VARCHAR(30)
)
BEGIN
	IF Cond_Oper = 4 THEN
    BEGIN
		SET @row_number = 0;
		SELECT (@row_number := @row_number + 1) AS SINo, ConfName, ConfTypeId, LogoPath, IsActive,
			ColorTheme
        FROM Conferences;
    END;
    END IF;
    IF Cond_Oper = 1 THEN
    BEGIN
		IF p_ConfTypeId = 0 THEN
        BEGIN
			INSERT INTO Conferences
            (
				ConfName,
                LogoPath,
                IsActive,
                ColorTheme
            )
            SELECT
				p_ConfName,
                p_LogoPath,
                p_IsActive,
                p_ColorTheme;
                
			INSERT INTO Resources
            (
				ResourceType,
                ResourcePath,
                IsRequired,
                ConfTypeId
            )
			SELECT 'Souvenir', '', 1, last_insert_id()
			UNION
			SELECT 'Brochure', '', 1, last_insert_id()
            UNION
            SELECT 'Conference Updates', '', 1, last_insert_id()
            UNION
            SELECT 'Tickets', '', 1, last_insert_id();
			
            SELECT '' LogoPath;
        END;
        ELSE
        BEGIN
			SELECT LogoPath FROM Conferences WHERE ConfTypeId = p_ConfTypeId;
            
			UPDATE Conferences
            SET ConfName = p_ConfName,
                LogoPath = CASE WHEN p_LogoPath IS NULL OR p_LogoPath = '' 
					THEN LogoPath ELSE p_LogoPath END,
                IsActive = p_IsActive,
                ColorTheme = p_ColorTheme
			WHERE ConfTypeId = p_ConfTypeId;
        END;
        END IF;
    END;
    END IF;
    IF Cond_Oper = 2 THEN
    BEGIN
		DELETE FROM Conferences
        WHERE ConfTypeId = p_ConfTypeId;
    END;
    END IF;
    IF Cond_Oper = 3 THEN
    BEGIN
		SELECT * FROM Conferences
        WHERE ConfTypeId = p_ConfTypeId;
    END;
    END IF;
END
$$

DROP PROCEDURE IF EXISTS `usp_CMSGetSaveDeleteConferenceEventCodeAssoc`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_CMSGetSaveDeleteConferenceEventCodeAssoc`(
	IN Cond_Oper INT,
    IN p_ConfTypeId INT,
    IN p_EventId INT,
    IN p_AssociationId INT
)
BEGIN
	IF Cond_Oper = 4 THEN
    BEGIN
		SET @row_number = 0;
		SELECT (@row_number := @row_number + 1) AS SINo, AssociationId, CE.EventId, CE.ConfTypeId,
			C.ConfName, E.EventCode
        FROM ConferenceEventCode CE
        INNER JOIN Conferences C ON CE.ConfTypeId = C.ConfTypeId
        INNER JOIN EventCodes E On E.EventId = CE.EventId;
        
        SELECT ConfTypeId, ConfName FROM Conferences;
        
        SELECT EventId, EventCode FROM EventCodes;
    END;
    END IF;
    IF Cond_Oper = 1 THEN
    BEGIN
		IF p_AssociationId = 0 THEN
        BEGIN
			INSERT INTO ConferenceEventCode
            (
				ConfTypeId,
                EventId
            )
            SELECT
				p_ConfTypeId,
                p_EventId;
        END;
        ELSE
        BEGIN
			UPDATE ConferenceEventCode
            SET ConfTypeId = p_ConfTypeId,
                EventId = p_EventId
			WHERE AssociationId = p_AssociationId;
        END;
        END IF;
    END;
    END IF;
    IF Cond_Oper = 2 THEN
    BEGIN
		DELETE FROM ConferenceEventCode
        WHERE AssociationId = p_AssociationId;
    END;
    END IF;
    IF Cond_Oper = 3 THEN
    BEGIN
		SELECT AssociationId, CE.EventId, CE.ConfTypeId, C.ConfName, E.EventCode
        FROM ConferenceEventCode CE
        INNER JOIN Conferences C ON CE.ConfTypeId = C.ConfTypeId
        INNER JOIN EventCodes E On E.EventId = CE.EventId
        WHERE AssociationId = p_AssociationId;
    END;
    END IF;
END
$$

DROP PROCEDURE IF EXISTS `usp_CMSGetSaveDeleteDelegates`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_CMSGetSaveDeleteDelegates`(
	IN Cond_Oper INT,
    IN p_DelegateId INT,
    IN p_Name varchar(50),
    IN p_RegistrationId INT,
    IN p_Category varchar(20),
    IN p_DelegateType varchar(20),
    IN p_Information varchar(1024),
    IN p_PhotoPath varchar(200),
    IN p_ConfTypeId INT
)
BEGIN
	IF Cond_Oper = 4 THEN
    BEGIN
		SET @row_number = 0;
		SELECT (@row_number := @row_number + 1) AS SINo, DelegateId, Category, Name, RegistrationId,
			DelegateType, PhotoPath
        FROM Delegates
        WHERE ConfTypeId = p_ConfTypeId;
	END;
    END IF;
    IF Cond_Oper = 1 THEN
    BEGIN
		IF p_DelegateId = 0 THEN
        BEGIN
			INSERT INTO Delegates
            (
				Name,
                RegistrationId,
                Category,
                DelegateType,
                Information,
                PhotoPath,
                ConfTypeId
            )
            SELECT
				p_Name,
                p_RegistrationId,
                p_Category,
                p_DelegateType,
                p_Information,
                p_PhotoPath,
                p_ConfTypeId;
			
            UPDATE Delegates
            SET PhotoPath = replace(p_PhotoPath, 'DelegateId', LAST_INSERT_ID())
            WHERE DelegateId = LAST_INSERT_ID();
            
            SELECT LAST_INSERT_ID() DelegateId;
        END;
        ELSE
        BEGIN
			SELECT PhotoPath FROM Delegates
            WHERE DelegateId = p_DelegateId;
            
			UPDATE Delegates
            SET Name = p_Name,
                RegistrationId = p_RegistrationId,
                Category = p_Category,
                DelegateType = p_DelegateType,
                Information = p_Information,
                PhotoPath = replace(CASE WHEN p_PhotoPath IS NULL OR p_PhotoPath = '' 
					THEN PhotoPath ELSE p_PhotoPath END, 'DelegateId', p_DelegateId)
			WHERE DelegateId = p_DelegateId;            
        END;
        END IF;
	END;
    END IF;
    IF Cond_Oper = 2 THEN
    BEGIN
		DELETE FROM Delegates
		WHERE DelegateId = p_DelegateId;
    END;
    END IF;
    IF Cond_Oper = 3 THEN
    BEGIN
		SELECT * FROM Delegates
		WHERE DelegateId = p_DelegateId;
    END;
    END IF;
END
$$

DROP PROCEDURE IF EXISTS `usp_CMSGetSaveDeleteNotification`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_CMSGetSaveDeleteNotification`(
	IN Cond_Oper INT,
    IN p_Message VARCHAR(1024),
    IN p_ConfTypeId INT,
    IN p_NotificationId INT
)
BEGIN
	IF Cond_Oper = 4 THEN
    BEGIN
		SELECT * FROM Notifications
        WHERE ConfTypeId = p_ConfTypeId;
    END;
    END IF;
    IF Cond_Oper = 1 THEN
    BEGIN
		IF p_NotificationId = 0 THEN
        BEGIN
			INSERT INTO Notifications
            (
				Message,
                ConfTypeId,
                CreatedDateTime
            )
            SELECT
				p_Message,                
                p_ConfTypeId,
                now();
        END;
        ELSE
        BEGIN
			UPDATE Notifications
            SET Message = p_Message
			WHERE NotificationId = p_NotificationId;
        END;
        END IF;
    END;
    END IF;
    IF Cond_Oper = 2 THEN
    BEGIN
		DELETE FROM Notifications
        WHERE NotificationId = p_NotificationId;
    END;
    END IF;
    IF Cond_Oper = 3 THEN
    BEGIN
		SELECT * FROM Notifications
        WHERE NotificationId = p_NotificationId;
    END;
    END IF;
END
$$

DROP PROCEDURE IF EXISTS `usp_CMSGetSaveDeleteOurSponsors`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_CMSGetSaveDeleteOurSponsors`(
	IN Cond_Oper INT,
    IN p_SponsorName VARCHAR(50),
    IN p_SponsorLogoPath VARCHAR(200),
    IN p_SponsorId INT
)
BEGIN
	IF Cond_Oper = 4 THEN
    BEGIN
		SET @row_number = 0;
		SELECT (@row_number := @row_number + 1) AS SINo, SponsorId, SponsorName, SponsorLogoPath
        FROM OurSponsors;
    END;
    END IF;
    IF Cond_Oper = 1 THEN
    BEGIN
		IF p_SponsorId = 0 THEN
        BEGIN
			INSERT INTO OurSponsors
            (
				SponsorName,
                SponsorLogoPath
            )
            SELECT
				p_SponsorName,                
                p_SponsorLogoPath;
                
			SELECT '' SponsorLogoPath;
        END;
        ELSE
        BEGIN
			SELECT SponsorLogoPath FROM OurSponsors
            WHERE SponsorId = p_SponsorId;
            
			UPDATE OurSponsors
            SET SponsorName = p_SponsorName,
				SponsorLogoPath = p_SponsorLogoPath
			WHERE SponsorId = p_SponsorId;
        END;
        END IF;
    END;
    END IF;
    IF Cond_Oper = 2 THEN
    BEGIN
		DELETE FROM OurSponsors
        WHERE SponsorId = p_SponsorId;
    END;
    END IF;
    IF Cond_Oper = 3 THEN
    BEGIN
		SELECT * FROM OurSponsors
        WHERE SponsorId = p_SponsorId;
    END;
    END IF;
END
$$

DROP PROCEDURE IF EXISTS `usp_CMSGetSaveDeletePlaces`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_CMSGetSaveDeletePlaces`(
	IN Cond_Oper INT,
    IN p_PlaceName VARCHAR(50),
    IN p_ConfTypeId INT,
    In p_AreaName VARCHAR(100),
    IN p_PlaceId INT,
    In p_AboutArea VARCHAR(1024),
    In p_PhotoPath VARCHAR(200)
)
BEGIN
	IF Cond_Oper = 4 THEN
    BEGIN
		SELECT * FROM VisitPlaces
        WHERE ConfTypeId = p_ConfTypeId;
    END;
    END IF;
    IF Cond_Oper = 1 THEN
    BEGIN
		IF p_PlaceId = 0 THEN
        BEGIN
			INSERT INTO VisitPlaces
            (
				PlaceName,
                AreaName,
                AboutArea,
                AreaImagePath,
                ConfTypeId
            )
            SELECT
				p_PlaceName,
                p_AreaName,
                p_AboutArea,
                p_PhotoPath,
                p_ConfTypeId;
            
            SELECT '' AreaImagePath;
        END;
        ELSE
        BEGIN
			SELECT AreaImagePath FROM VisitPlaces WHERE PlaceId = p_PlaceId;
            
			UPDATE VisitPlaces
            SET PlaceName = p_PlaceName,
                AreaName = p_AreaName,
                AboutArea = p_AboutArea,
                AreaImagePath = CASE WHEN p_PhotoPath IS NULL OR p_PhotoPath = '' 
					THEN AreaImagePath ELSE p_PhotoPath END
			WHERE PlaceId = p_PlaceId;
        END;
        END IF;
    END;
    END IF;
    IF Cond_Oper = 2 THEN
    BEGIN
		DELETE FROM VisitPlaces
        WHERE PlaceId = p_PlaceId;
    END;
    END IF;
    IF Cond_Oper = 3 THEN
    BEGIN
		SELECT * FROM VisitPlaces
        WHERE PlaceId = p_PlaceId;
    END;
    END IF;
END
$$

DROP PROCEDURE IF EXISTS `usp_CMSGetSaveDeleteResources`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_CMSGetSaveDeleteResources`(
	IN Cond_Oper INT,
    IN p_ResourceType VARCHAR(30),
    IN p_ConfTypeId INT,
    In p_ResourcePath VARCHAR(200),
    IN p_IsRequired INT
)
BEGIN
	IF Cond_Oper = 4 THEN
    BEGIN
		SET @row_number = 0;
		SELECT (@row_number := @row_number + 1) AS SINo, ResourceType, ResourcePath, IsRequired
        FROM Resources
        WHERE ConfTypeId = p_ConfTypeId;
    END;
    END IF;
    IF Cond_Oper = 1 THEN
    BEGIN
		SELECT ResourcePath FROM Resources
        WHERE ConfTypeId = p_ConfTypeId AND ResourceType = p_ResourceType;
        
		UPDATE Resources
        SET ResourcePath = p_ResourcePath,
			IsRequired = p_IsRequired
		WHERE ConfTypeId = p_ConfTypeId AND ResourceType = p_ResourceType;
    END;
    END IF;
    IF Cond_Oper = 3 THEN
    BEGIN
		SELECT * FROM Resources
        WHERE ConfTypeId = p_ConfTypeId AND ResourceType = p_ResourceType;
    END;
    END IF;
END
$$

DROP PROCEDURE IF EXISTS `usp_CMSGetSaveDeleteSponsors`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_CMSGetSaveDeleteSponsors`(
	IN Cond_Oper INT,
    IN p_Category VARCHAR(30),
    IN p_ConfTypeId INT,
    In p_OrgName VARCHAR(50),
    IN p_OrgId INT,
    In p_AboutOrg VARCHAR(1024),
    In p_OrgLogoPath VARCHAR(200)
)
BEGIN
	IF Cond_Oper = 4 THEN
    BEGIN
		SET @row_number = 0;
		SELECT (@row_number := @row_number + 1) AS SINo, OrgId, Category, OrgName, AboutOrg,
			OrgLogoPath
        FROM Sponsors
        WHERE ConfTypeId = p_ConfTypeId;
    END;
    END IF;
    IF Cond_Oper = 1 THEN
    BEGIN
		IF p_OrgId = 0 THEN
        BEGIN
			INSERT INTO Sponsors
            (
				Category,
                OrgName,
                AboutOrg,
                OrgLogoPath,
                ConfTypeId
            )
            SELECT
				p_Category,
                p_OrgName,
                p_AboutOrg,
                p_OrgLogoPath,
                p_ConfTypeId;
            
            SELECT '' OrgLogoPath;
        END;
        ELSE
        BEGIN
			SELECT OrgLogoPath FROM Sponsors WHERE OrgId = p_OrgId;
            
			UPDATE Sponsors
            SET Category = p_Category,
                OrgName = p_OrgName,
                AboutOrg = p_AboutOrg,
                OrgLogoPath = CASE WHEN p_OrgLogoPath IS NULL OR p_OrgLogoPath = '' 
					THEN OrgLogoPath ELSE p_OrgLogoPath END
			WHERE OrgId = p_OrgId;
        END;
        END IF;
    END;
    END IF;
    IF Cond_Oper = 2 THEN
    BEGIN
		DELETE FROM Sponsors
        WHERE OrgId = p_OrgId;
    END;
    END IF;
    IF Cond_Oper = 3 THEN
    BEGIN
		SELECT * FROM Sponsors
        WHERE OrgId = p_OrgId;
    END;
    END IF;
END
$$

DROP PROCEDURE IF EXISTS `usp_CMSGetScheduleByNameHall`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_CMSGetScheduleByNameHall`(
	IN Cond_Oper INT,
    IN p_ConfTypeId INT,
    IN p_SearchValue varchar(100)
)
BEGIN
	IF Cond_Oper = 2 THEN
    BEGIN
		SELECT * FROM Schedules
        WHERE ConfTypeId = p_ConfTypeId AND (Hall = p_SearchValue OR ScheduleTitle = p_SearchValue OR
			FromTime = p_SearchValue);
    END;
    END IF;
    IF Cond_Oper = 1 THEN
    BEGIN
		SELECT Hall SearchedValue
        FROM Schedules
        WHERE ConfTypeId = p_ConfTypeId AND Hall like p_SearchValue
        UNION
        SELECT ScheduleTitle SearchedValue
        FROM Schedules
        WHERE ConfTypeId = p_ConfTypeId AND ScheduleTitle like p_SearchValue
        UNION
        SELECT FromTime SearchedValue
        FROM Schedules
        WHERE ConfTypeId = p_ConfTypeId AND FromTime like p_SearchValue;
    END;
    END IF;
END
$$

DROP PROCEDURE IF EXISTS `usp_CMSGetUpdateAboutConference`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_CMSGetUpdateAboutConference`(
	IN Cond_Oper INT,
    IN p_Id INT,
    IN p_Title varchar(100),
    IN p_Theme varchar(100),
    IN p_AboutConference1 varchar(1024),
    IN p_AboutConference2 varchar(1024),
    IN p_ConfTypeId INT
)
BEGIN
	IF Cond_Oper = 1 THEN
    BEGIN
		IF p_Id = 0 THEN
        BEGIN
			INSERT INTO AboutConference
			(
				ConfTypeId,
				Title,
				Theme,
				AboutConference1,
				AboutConference2
			)
			SELECT
				p_ConfTypeId,
				p_Title,
				p_Theme,
				p_AboutConference1,
				p_AboutConference2;
		END;
		ELSE
        BEGIN
			UPDATE AboutConference
            SET Title = p_Title,
				Theme = p_Theme,
				AboutConference1 = p_AboutConference1,
				AboutConference2 = p_AboutConference2
			WHERE Id = p_Id;
        END;
        END IF;        
	END;
    END IF;
    IF Cond_Oper = 2 THEN
    BEGIN
		SELECT * FROM AboutConference
        WHERE ConfTypeId = p_ConfTypeId;
	END;
    END IF;
END
$$

DROP PROCEDURE IF EXISTS `usp_CMSGetUpdateContact`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_CMSGetUpdateContact`(
	IN Cond_Oper INT,
    IN p_ContactId INT,
    IN p_Venue varchar(100),
    IN p_VenueMapPath varchar(200),
    IN p_VenueMapLink varchar(1024),
    IN p_Name varchar(50),
    IN p_CommunicationAddress varchar(100),
    IN p_VenueAddress varchar(100),
    IN p_Email varchar(30),
    IN p_ConfTypeId INT
)
BEGIN
	IF Cond_Oper = 1 THEN
    BEGIN
		IF p_ContactId = 0 THEN
        BEGIN
			INSERT INTO Contacts
			(
				ConfTypeId,
				Venue,
				VenueMapPath,
				VenueMapLink,
				Name,
                CommunicationAddress,
                VenueAddress,
                Email
			)
			SELECT
				p_ConfTypeId,
				p_Venue,
				p_VenueMapPath,
				p_VenueMapLink,
				p_Name,
                p_CommunicationAddress,
                p_VenueAddress,
                p_Email;
                
			SELECT '' VenueMapPath;
		END;
		ELSE
        BEGIN
			UPDATE Contacts
            SET Venue = p_Venue,
				VenueMapPath = CASE WHEN p_VenueMapPath IS NULL OR p_VenueMapPath = '' 
					THEN VenueMapPath ELSE p_VenueMapPath END,
				VenueMapLink = p_VenueMapLink,
				Name = p_Name,
                CommunicationAddress = p_CommunicationAddress,
                VenueAddress = p_VenueAddress,
                Email = p_Email
			WHERE ContactId = p_ContactId;
            
            SELECT VenueMapPath FROM Contacts WHERE ContactId = p_ContactId;
        END;
        END IF;        
	END;
    END IF;
    IF Cond_Oper = 2 THEN
    BEGIN
		SELECT * FROM Contacts
        WHERE ConfTypeId = p_ConfTypeId;
	END;
    END IF;
END
$$

DROP PROCEDURE IF EXISTS `usp_CMSGetUpdateDeleteEventCode`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_CMSGetUpdateDeleteEventCode`(
	IN Cond_Oper INT,
    IN p_EventCode VARCHAR(30),
    IN p_EventId INT,
    IN p_IsActive INT
)
BEGIN
	IF Cond_Oper = 1 THEN
    BEGIN
		UPDATE EventCodes
        SET EventCode = p_EventCode,
			IsActive = p_IsActive
		WHERE EventId = p_EventId;
    END;
    END IF;
    IF Cond_Oper = 3 THEN
    BEGIN
		SELECT * FROM EventCodes
		WHERE EventId = p_EventId;
    END;
    END IF;
    IF Cond_Oper = 4 THEN
    BEGIN
		SET @row_number = 0;
		SELECT (@row_number := @row_number + 1) AS SINo, EventId, EventCode, IsActive
        FROM EventCodes;
    END;
    END IF;
END
$$

DROP PROCEDURE IF EXISTS `usp_CMSGetUpdateRegistrationLink`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_CMSGetUpdateRegistrationLink`(
	IN Cond_Oper INT,
    IN p_RegistrationURL VARCHAR(200),
    IN p_ConfTypeId INT,
    In p_ConferenceLogoPath VARCHAR(200),
    IN p_URLId INT
)
BEGIN
	IF Cond_Oper = 2 THEN
    BEGIN
		SELECT * FROM Registrations
        WHERE ConfTypeId = p_ConfTypeId;
    END;
    END IF;
    IF Cond_Oper = 1 THEN
    BEGIN
		IF p_URLId = 0 THEN
        BEGIN
			INSERT INTO Registrations
            (
				RegistrationURL,
                ConferenceLogoPath,
                ConfTypeId
            )
            SELECT
				p_RegistrationURL,
                p_ConferenceLogoPath,
                p_ConfTypeId;
			
            SELECT '' ConferenceLogoPath;
        END;
        ELSE
        BEGIN
			SELECT ConferenceLogoPath FROM Registrations
            WHERE URLId = p_URLId;
        
			UPDATE Registrations
            SET RegistrationURL = p_RegistrationURL,
                ConferenceLogoPath = CASE WHEN p_ConferenceLogoPath IS NULL OR p_ConferenceLogoPath = '' 
					THEN ConferenceLogoPath ELSE p_ConferenceLogoPath END
			WHERE URLId = p_URLId;
        END;
        END IF;        
    END;
    END IF;
END
$$

DROP PROCEDURE IF EXISTS `usp_CMSGetUploadedPaperPoster`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_CMSGetUploadedPaperPoster`(
	IN p_ConfTypeId INT
)
BEGIN
	SELECT * FROM PaperPosters
    WHERE ConfTypeId = p_ConfTypeId;
END
$$

DROP PROCEDURE IF EXISTS `usp_CMSGetUploadedSchedule`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_CMSGetUploadedSchedule`(
	IN p_ConfTypeId INT
)
BEGIN
	SELECT * FROM Schedules
    WHERE ConfTypeId = p_ConfTypeId;
END
$$

DROP PROCEDURE IF EXISTS `usp_CMSGetUploadedWorkshop`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_CMSGetUploadedWorkshop`(
	IN p_ConfTypeId INT
)
BEGIN
	SELECT * FROM Workshops
    WHERE ConfTypeId = p_ConfTypeId;
END
$$

DROP PROCEDURE IF EXISTS `usp_CMSGetWorkshopByNameSession`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_CMSGetWorkshopByNameSession`(
	IN Cond_Oper INT,
    IN p_ConfTypeId INT,
    IN p_SearchValue varchar(100)
)
BEGIN
	IF Cond_Oper = 2 THEN
    BEGIN
		SELECT * FROM Workshops
        WHERE ConfTypeId = p_ConfTypeId AND (WorkshopName = p_SearchValue OR Session = p_SearchValue OR
			FromTime = p_SearchValue);
    END;
    END IF;
    IF Cond_Oper = 1 THEN
    BEGIN
		SELECT WorkshopName SearchedValue
        FROM Workshops
        WHERE ConfTypeId = p_ConfTypeId AND WorkshopName like p_SearchValue
        UNION
        SELECT Session SearchedValue
        FROM Workshops
        WHERE ConfTypeId = p_ConfTypeId AND Session like p_SearchValue
        UNION
        SELECT FromTime SearchedValue
        FROM Workshops
        WHERE ConfTypeId = p_ConfTypeId AND FromTime like p_SearchValue;
    END;
    END IF;
END
$$

DROP PROCEDURE IF EXISTS `usp_CMSIsAssociationAlreadyExists`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_CMSIsAssociationAlreadyExists`(
	IN p_ConfTypeId INT,
    IN p_EventId INT
)
BEGIN
	SELECT AssociationId FROM ConferenceEventCode
    WHERE ConfTypeId = p_ConfTypeId AND EventId = p_EventId;
END
$$

DROP PROCEDURE IF EXISTS `usp_CMSIsConferenceAlreadyExists`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_CMSIsConferenceAlreadyExists`(
	IN p_ConfName VARCHAR(30)
)
BEGIN
	SELECT ConfTypeId FROM Conferences
    WHERE ConfName = p_ConfName;
END
$$

DROP PROCEDURE IF EXISTS `usp_CMSIsDelegateAlreadyExists`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_CMSIsDelegateAlreadyExists`(
	IN p_Name varchar(50),
    IN p_ConfTypeId INT,
    IN p_Category varchar(20),
    IN p_DelegateType varchar(20)
)
BEGIN
	SELECT DelegateId FROM Delegates
    WHERE Name = p_Name AND ConfTypeId = p_ConfTypeId AND
		Category = p_Category AND DelegateType = p_DelegateType;
END
$$

DROP PROCEDURE IF EXISTS `usp_CMSIsOrgnizationAlreadyExists`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_CMSIsOrgnizationAlreadyExists`(
	IN p_ConfTypeId INT,
    In p_OrgName VARCHAR(50)
)
BEGIN
	SELECT OrgId FROM Sponsors
    WHERE ConfTypeId = p_ConfTypeId AND OrgName = p_OrgName;
END
$$

DROP PROCEDURE IF EXISTS `usp_CMSIsPlaceAlreadyExists`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_CMSIsPlaceAlreadyExists`(
	IN p_ConfTypeId INT,
    In p_PlaceName VARCHAR(50),
    In p_AreaName VARCHAR(50)
)
BEGIN
	SELECT PlaceId FROM VisitPlaces
    WHERE ConfTypeId = p_ConfTypeId AND AreaName = p_AreaName
		AND PlaceName = p_PlaceName;
END
$$

DROP PROCEDURE IF EXISTS `usp_CMSUpdateBanner`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_CMSUpdateBanner`(
	IN p_BannerPath VARCHAR(100)
)
BEGIN
	SELECT BannerPath 
    FROM EventMagnetBanner;
    
	UPDATE EventMagnetBanner
    SET BannerPath = p_BannerPath;
END
$$

DROP PROCEDURE IF EXISTS `usp_CMSUpdatePaperPoster`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_CMSUpdatePaperPoster`(
	IN p_PaperPosterId INT,
    IN p_Session VARCHAR(50),
    IN p_Category VARCHAR(50),
    In p_Topic VARCHAR(200),
    IN p_Date VARCHAR(20),
    In p_Speaker VARCHAR(50),
    IN p_FromTime VARCHAR(20),
    IN p_ToTime VARCHAR(20),
    IN p_PaperPosterType VARCHAR(50)
)
BEGIN
	UPDATE PaperPosters
    SET Session = p_Session,
		Category = p_Category,
        Topic = p_Topic,
        Date = p_Date,
        Speaker = p_Speaker,
        FromTime = p_FromTime,
        ToTime = p_ToTime,
        PaperPosterType = p_PaperPosterType
	WHERE PaperPosterId = p_PaperPosterId;
END
$$

DROP PROCEDURE IF EXISTS `usp_CMSUpdateSchedule`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_CMSUpdateSchedule`(
	IN p_ScheduleId INT,
    IN p_ScheduleTitle VARCHAR(200),
    IN p_Hall VARCHAR(30),    
    IN p_Date VARCHAR(20),
    IN p_FromTime VARCHAR(20),
    IN p_ToTime VARCHAR(20)
)
BEGIN
	UPDATE Schedules
    SET ScheduleTitle = p_ScheduleTitle,
		Hall = p_Hall,
        Date = p_Date,
        FromTime = p_FromTime,
        ToTime = p_ToTime
	WHERE ScheduleId = p_ScheduleId;
END
$$

DROP PROCEDURE IF EXISTS `usp_CMSUpdateWorkshop`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_CMSUpdateWorkshop`(
	IN p_WorkshopId INT,
    IN p_Session VARCHAR(200),
    IN p_WorkshopName VARCHAR(100),    
    IN p_Date VARCHAR(20),
    IN p_FromTime VARCHAR(20),
    IN p_ToTime VARCHAR(20)
)
BEGIN
	UPDATE Workshops
    SET Session = p_Session,
		WorkshopName = p_WorkshopName,
        Date = p_Date,
        FromTime = p_FromTime,
        ToTime = p_ToTime
	WHERE WorkshopId = p_WorkshopId;
END
$$

DROP PROCEDURE IF EXISTS `usp_CMSValidateAdminLoginUser`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_CMSValidateAdminLoginUser`(
	IN Cond_Oper INT,
    IN p_Email varchar(30),
    IN p_Password varchar(20),
    IN p_ConfTypeId INT
)
BEGIN
	IF Cond_Oper = 1 THEN
    BEGIN
		SELECT Name FROM AdminUsers
        WHERE Email = p_Email AND Password = p_Password;
        
        SELECT ConfName Conference FROM Conferences
        WHERE ConfTypeId = p_ConfTypeId;
	END;
    END IF;
    IF Cond_Oper = 2 THEN
    BEGIN
		SELECT 1 FROM AdminUsers
        WHERE Email = p_Email;
	END;
    END IF;
    IF Cond_Oper = 3 THEN
    BEGIN
		UPDATE AdminUsers
		SET Password = p_Password
        WHERE Email = p_Email;
	END;
    END IF;
END
$$

DROP PROCEDURE IF EXISTS `usp_GenerateEventCode`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_GenerateEventCode`(
	IN p_ConfName VARCHAR(30)
)
BEGIN
	SELECT EventCode FROM EventCodes E
    INNER JOIN ConferenceEventCode CE ON E.EventId = CE.EventId
    INNER JOIN Conferences C ON C.ConfTypeId = CE.ConfTypeId
	WHERE C.ConfName = p_ConfName AND E.IsActive = 1 AND C.IsActive = 1;
END
$$

DROP PROCEDURE IF EXISTS `usp_GetConference`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_GetConference`(
	IN p_ConfName VARCHAR(30)
)
BEGIN
	SELECT * FROM Conferences
    WHERE ConfName = p_ConfName;
END
$$

DROP PROCEDURE IF EXISTS `usp_GetContactInfo`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_GetContactInfo`(
	IN p_ConfName VARCHAR(30)
)
BEGIN
	SELECT A.* FROM Contacts A
    INNER JOIN Conferences C ON C.ConfTypeId = A.ConfTypeId
    WHERE C.ConfName = p_ConfName;
END
$$

DROP PROCEDURE IF EXISTS `usp_GetDelegateFacultyCommittee`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_GetDelegateFacultyCommittee`(
	IN p_ConfName VARCHAR(30),
    IN p_Category VARCHAR(50)
)
BEGIN
	SELECT A.* FROM Delegates A
    INNER JOIN Conferences C ON C.ConfTypeId = A.ConfTypeId
    WHERE C.ConfName = p_ConfName AND A.Category = p_Category;
END
$$

DROP PROCEDURE IF EXISTS `usp_GetEventMagnetBanner`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_GetEventMagnetBanner`()
BEGIN
	SELECT * FROM EventMagnetBanner;
END
$$

DROP PROCEDURE IF EXISTS `usp_GetInfoAboutConference`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_GetInfoAboutConference`(
	IN p_ConfName VARCHAR(30)
)
BEGIN
	SELECT A.* FROM AboutConference A
    INNER JOIN Conferences C ON C.ConfTypeId = A.ConfTypeId
    WHERE C.ConfName = p_ConfName;
END
$$

DROP PROCEDURE IF EXISTS `usp_GetNotifications`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_GetNotifications`(
	IN p_ConfName VARCHAR(30)
)
BEGIN
	SELECT A.* FROM Notifications A
    INNER JOIN Conferences C ON C.ConfTypeId = A.ConfTypeId
    WHERE C.ConfName = p_ConfName;
END
$$

DROP PROCEDURE IF EXISTS `usp_GetOurSponsors`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_GetOurSponsors`()
BEGIN
	SELECT * FROM OurSponsors;
END
$$

DROP PROCEDURE IF EXISTS `usp_GetPaperPoster`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_GetPaperPoster`(
	IN p_ConfName VARCHAR(30),
    IN p_Category VARCHAR(30)
)
BEGIN
	SELECT A.* FROM PaperPosters A
    INNER JOIN Conferences C ON C.ConfTypeId = A.ConfTypeId
    WHERE C.ConfName = p_ConfName AND Category = p_Category;
END
$$

DROP PROCEDURE IF EXISTS `usp_GetQRCodePath`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_GetQRCodePath`()
BEGIN
	SELECT * FROM QRCode;
END
$$

DROP PROCEDURE IF EXISTS `usp_GetRegistrationURL`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_GetRegistrationURL`(
	IN p_ConfName VARCHAR(30)
)
BEGIN
	SELECT A.* FROM Registrations A
    INNER JOIN Conferences C ON C.ConfTypeId = A.ConfTypeId
    WHERE C.ConfName = p_ConfName;
END
$$

DROP PROCEDURE IF EXISTS `usp_GetResources`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_GetResources`(
	IN p_ConfName VARCHAR(30),
    IN p_ResourceType VARCHAR(30)
)
BEGIN
	SELECT A.* FROM Resources A
    INNER JOIN Conferences C ON C.ConfTypeId = A.ConfTypeId
    WHERE C.ConfName = p_ConfName AND A.ResourceType = p_ResourceType;
END
$$

DROP PROCEDURE IF EXISTS `usp_GetSaveAnswer`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_GetSaveAnswer`(
	IN Cond_Oper INT,
    IN p_Username VARCHAR(100),
    IN p_RegistrationId INT,
    IN p_Answer VARCHAR(1024),    
    IN p_BlogId INT
)
BEGIN
	IF Cond_Oper = 1 THEN
    BEGIN
		SET @DelegateId := 0;
        SELECT @DelegateId := DelegateId FROM Delegates
        WHERE RegistrationId = p_RegistrationId AND Category = 'Faculty';
        
        IF @DelegateId = 0 OR @DelegateId IS NULL THEN
        BEGIN
			SELECT 'Invalid' StatusMsg;			
		END;
        ELSE
        BEGIN
			INSERT INTO Answers
			(
				BlogId,
				Username,
				Answer,
				CreatedDateTime,
				UpdatedDateTime
			)
			SELECT
				p_BlogId,
				p_Username,
				p_Answer,
				now(),
				now();
			
            UPDATE Questions SET UpdatedDateTime = now()
            WHERE BlogId = p_BlogId;
            
            SELECT 'Success' StatusMsg;	
        END;
        END IF;
    END;
    END IF;
END
$$

DROP PROCEDURE IF EXISTS `usp_GetSaveConversation`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_GetSaveConversation`(
	IN Cond_Oper INT,
    IN p_Username VARCHAR(100),    
    IN p_Message VARCHAR(1024),
    IN p_ConfName VARCHAR(30),
    IN p_ConversationId INT,
    IN p_ChatType VARCHAR(20)
)
BEGIN
	IF Cond_Oper = 1 THEN
    BEGIN
		INSERT INTO Conversations
        (
			Username,
            Message,
            ConfTypeId,
            CreatedDateTime,
            UpdatedDateTime
        )
        SELECT
			p_Username,
            p_Message,
            (SELECT ConfTypeId FROM Conferences WHERE ConfName = p_ConfName),
            now(),
            now();
            
		SELECT 'Success' StatusMsg;
    END;
    END IF;
    IF Cond_Oper = 2 THEN
    BEGIN
		SELECT ConversationId, Username, CreatedDateTime, Message, 'Conversation' ChatType, Likes
        FROM Conversations Q
        INNER JOIN Conferences C ON C.ConfTypeId = Q.ConfTypeId
        WHERE C.ConfName = p_ConfName
        ORDER BY UpdatedDateTime DESC;
        
        SELECT * FROM ConversationReplies;
    END;
    END IF;
    IF Cond_Oper = 3 THEN
    BEGIN
		UPDATE Conversations
        SET Likes = Likes + 1
        WHERE ConversationId = p_ConversationId;
        
        SELECT Likes FROM Conversations
        WHERE ConversationId = p_ConversationId;
    END;
    END IF;
END
$$

DROP PROCEDURE IF EXISTS `usp_GetSaveConversationReply`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_GetSaveConversationReply`(
	IN Cond_Oper INT,
    IN p_Username VARCHAR(100),
    IN p_ReplyMessage VARCHAR(1024),    
    IN p_ConversationId INT
)
BEGIN
	IF Cond_Oper = 1 THEN
    BEGIN
		INSERT INTO ConversationReplies
		(
			ConversationId,
			Username,
			ReplyMessage,
			CreatedDateTime,
			UpdatedDateTime
		)
		SELECT
			p_ConversationId,
			p_Username,
			p_ReplyMessage,
			now(),
			now();
			
		UPDATE Conversations SET UpdatedDateTime = now()
		WHERE ConversationId = p_ConversationId;
            
		SELECT 'Success' StatusMsg;	
    END;
    END IF;
END
$$

DROP PROCEDURE IF EXISTS `usp_GetSaveMobileDeviceId`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_GetSaveMobileDeviceId`(
	IN Cond_Oper INT,
    IN p_DeviceId VARCHAR(9999)
)
BEGIN
	IF Cond_Oper = 1 THEN
    BEGIN
		INSERT INTO MobileDevices
        (
			DeviceId
        )
        SELECT
			p_DeviceId;
    END;
    END IF;
    IF Cond_Oper = 2 THEN
    BEGIN
		SELECT * FROM MobileDevices;
    END;
    END IF;
END
$$

DROP PROCEDURE IF EXISTS `usp_GetSaveMySchedule`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_GetSaveMySchedule`(
	IN Cond_Oper INT,
    IN p_Username VARCHAR(100),
    IN p_MobileNo VARCHAR(20),
    IN p_Session VARCHAR(200),
    IN p_Date VARCHAR(20),
    IN p_FromTime VARCHAR(20),
    IN p_ToTime VARCHAR(20),
    IN p_ConfName VARCHAR(30),
    IN p_MyScheduleId INT,
    IN p_ScheduleType VARCHAR(30)
)
BEGIN
	IF Cond_Oper = 1 THEN
    BEGIN
		SET @MyScheduleId := 0;
        SELECT @MyScheduleId := MyScheduleId 
        FROM MySchedules MS
        INNER JOIN Conferences C ON MS.ConfTypeId = C.ConfTypeId
        WHERE MobileNo = p_MobileNo AND Session = p_Session
			AND ScheduleType = p_ScheduleType
            AND C.ConfName = p_ConfName;
		
        IF @MyScheduleId = 0 OR @MyScheduleId IS NULL THEN
        BEGIN
			INSERT INTO MySchedules
			(
				Username,
				MobileNo,
                Session,
                Date,
                FromTime,
                ToTime,
				ConfTypeId,
				ScheduleType
			)
			SELECT
				p_Username,
				p_MobileNo,
                p_Session,
                p_Date,
                p_FromTime,
                p_ToTime,
				(SELECT ConfTypeId FROM Conferences WHERE ConfName = p_ConfName),
				p_ScheduleType;
				
			SELECT 'Success' StatusMsg;
		END;
        ELSE
        BEGIN
			SELECT 'Failed' StatusMsg;
        END;
        END IF;
    END;
    END IF;
    IF Cond_Oper = 2 THEN
    BEGIN
		SELECT MS.* FROM MySchedules MS
        INNER JOIN Conferences C ON MS.ConfTypeId = C.ConfTypeId
        WHERE MobileNo = p_MobileNo AND C.ConfName = p_ConfName;
    END;
    END IF;    
    IF Cond_Oper = 3 THEN
    BEGIN
		DELETE FROM MySchedules
        WHERE MyScheduleId = p_MyScheduleId;
    END;
    END IF;
END
$$

DROP PROCEDURE IF EXISTS `usp_GetSaveQuestion`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_GetSaveQuestion`(
	IN Cond_Oper INT,
    IN p_Username VARCHAR(100),
    IN p_RegistrationId INT,
    IN p_Question VARCHAR(1024),
    IN p_ConfName VARCHAR(30),
    IN p_BlogId INT,
    IN p_FilterType VARCHAR(20)
)
BEGIN
	IF Cond_Oper = 1 THEN
    BEGIN
		INSERT INTO Questions
        (
			Username,
            Question,
            ConfTypeId,
            CreatedDateTime,
            UpdatedDateTime
        )
        SELECT
			p_Username,
            p_Question,
            (SELECT ConfTypeId FROM Conferences WHERE ConfName = p_ConfName),
            now(),
            now();
            
		SELECT 'Success' StatusMsg;
    END;
    END IF;
    IF Cond_Oper = 2 THEN
    BEGIN
		SET @Category := '';
        SELECT @Category := Category FROM Delegates
        WHERE RegistrationId = p_RegistrationId;
        
		SELECT BlogId, Username, CreatedDateTime, Question, @Category Category, Likes
        FROM Questions Q
        INNER JOIN Conferences C ON C.ConfTypeId = Q.ConfTypeId
        WHERE C.ConfName = p_ConfName
        ORDER BY CASE WHEN p_FilterType = 'Recent' THEN UpdatedDateTime
			ELSE Likes END DESC;
        
        SELECT * FROM Answers;
    END;
    END IF;
    IF Cond_Oper = 4 THEN
    BEGIN
		SELECT * FROM Questions
        WHERE BlogId = p_BlogId;
    END;
    END IF;
    IF Cond_Oper = 3 THEN
    BEGIN
		UPDATE Questions
        SET Likes = Likes + 1
        WHERE BlogId = p_BlogId;
        
        SELECT Likes FROM Questions
        WHERE BlogId = p_BlogId;
    END;
    END IF;
END
$$

DROP PROCEDURE IF EXISTS `usp_GetSchedule`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_GetSchedule`(
	IN Cond_Oper INT,
	IN p_ConfName VARCHAR(30),
    IN p_Date VARCHAR(30)
)
BEGIN
	IF Cond_Oper = 1 THEN
    BEGIN
		SELECT DISTINCT A.Date FROM Schedules A
		INNER JOIN Conferences C ON C.ConfTypeId = A.ConfTypeId
		WHERE C.ConfName = p_ConfName;
        
        SELECT A.PlaceName FROM VisitPlaces A
		INNER JOIN Conferences C ON C.ConfTypeId = A.ConfTypeId
		WHERE C.ConfName = p_ConfName;
    END;    
    ELSE
    BEGIN
		SELECT CASE WHEN R.RatingValue IS NULL THEN 0 ELSE R.RatingValue END RatingValue, A.* 
        FROM EventMagnet.Schedules A
		INNER JOIN EventMagnet.Conferences C ON C.ConfTypeId = A.ConfTypeId
        LEFT JOIN (
			SELECT AVG(RatingValue) RatingValue, ConfTypeId, ScheduleId
            FROM EventMagnet.Ratings            
            WHERE SessionType = 'Schedule'
            GROUP BY ConfTypeId, ScheduleId
		)R ON R.ConfTypeId = A.ConfTypeId AND R.ScheduleId = A.ScheduleId
		WHERE C.ConfName = p_ConfName AND Date = p_Date;
    END;
    END IF;
END
$$

DROP PROCEDURE IF EXISTS `usp_GetSponsors`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_GetSponsors`(
	IN p_ConfName VARCHAR(30)
)
BEGIN
	SELECT A.* FROM Sponsors A
    INNER JOIN Conferences C ON C.ConfTypeId = A.ConfTypeId
    WHERE C.ConfName = p_ConfName;
END
$$

DROP PROCEDURE IF EXISTS `usp_GetVisitPlaces`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_GetVisitPlaces`(
	IN p_ConfName VARCHAR(30)
)
BEGIN
	SELECT A.* FROM VisitPlaces A
    INNER JOIN Conferences C ON C.ConfTypeId = A.ConfTypeId
    WHERE C.ConfName = p_ConfName;
END
$$

DROP PROCEDURE IF EXISTS `usp_GetWorkshop`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_GetWorkshop`(
	IN p_ConfName VARCHAR(30)
)
BEGIN
	SELECT CASE WHEN R.RatingValue IS NULL THEN 0 ELSE R.RatingValue END RatingValue, A.* 
    FROM Workshops A
    INNER JOIN Conferences C ON C.ConfTypeId = A.ConfTypeId
    LEFT JOIN (
		SELECT AVG(RatingValue) RatingValue, ConfTypeId, ScheduleId
		FROM EventMagnet.Ratings            
		WHERE SessionType = 'Workshop'
		GROUP BY ConfTypeId, ScheduleId
	)R ON R.ConfTypeId = A.ConfTypeId AND R.ScheduleId = A.WorkshopId
    WHERE C.ConfName = p_ConfName;
END
$$

DROP PROCEDURE IF EXISTS `usp_SaveRatings`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_SaveRatings`(
	IN Cond_Oper INT,
    IN p_Username VARCHAR(100),
    IN p_RatingValue decimal(10,2),
    IN p_ConfName VARCHAR(30),
    IN p_ScheduleId INT,
    IN p_SessionType VARCHAR(30)
)
BEGIN
	INSERT INTO Ratings
    (
		ConfTypeId,
        ScheduleId,
        SessionType,
        Username,
        RatingValue
    )
    SELECT
		(SELECT ConfTypeId FROM Conferences WHERE ConfName = p_ConfName),
        p_ScheduleId,
        p_SessionType,
        p_Username,
        p_RatingValue;
	
    SELECT avg(RatingValue) RatingValue 
    FROM Ratings R
    INNER JOIN Conferences C ON R.ConfTypeId = C.ConfTypeId
    WHERE C.ConfName = p_ConfName AND SessionType = p_SessionType
		AND ScheduleId = p_ScheduleId;
END
$$

DROP PROCEDURE IF EXISTS `usp_ValidateEventCode`$$
CREATE DEFINER=`event_magnet`@`%` PROCEDURE `usp_ValidateEventCode`(
	IN p_ConfName VARCHAR(30),
    IN p_EventCode VARCHAR(30)
)
BEGIN
	SELECT E.EventId, E.EventCode, ConfName, ColorTheme ColorCode, LogoPath
    FROM EventCodes E
    INNER JOIN ConferenceEventCode CE ON E.EventId = CE.EventId
    INNER JOIN Conferences C ON C.ConfTypeId = CE.ConfTypeId
	WHERE E.EventCode = p_EventCode AND C.ConfName = p_ConfName
		AND E.IsActive = 1 AND C.IsActive = 1;
END
$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `AboutConference`
--

DROP TABLE IF EXISTS `AboutConference`;
CREATE TABLE IF NOT EXISTS `AboutConference` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `ConfTypeId` int(11) NOT NULL,
  `Title` varchar(100) NOT NULL,
  `Theme` varchar(100) DEFAULT NULL,
  `AboutConference1` varchar(1024) NOT NULL,
  `AboutConference2` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`Id`,`ConfTypeId`),
  KEY `FK_AC_ConfTypeId` (`ConfTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `AboutConference`
--

INSERT INTO `AboutConference` (`Id`, `ConfTypeId`, `Title`, `Theme`, `AboutConference1`, `AboutConference2`) VALUES
(1, 1, 'SIMULUS', 'SIMULUS', 'SIMULUS 1', 'SIMULUS 2'),
(2, 3, 'Welcome to The Emergency Medicine Association', 'Emergency Medicine', 'The Emergency Medicine Association (EMA) of India marks the birth of a new era for healthcare in Ind', 'EMA is an organized Guild of Emergency Leaders in Health and Medicine Working towards provision of q'),
(3, 2, 'PEDICON 2020', 'PEDICON Conference', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).');

-- --------------------------------------------------------

--
-- Table structure for table `AdminUsers`
--

DROP TABLE IF EXISTS `AdminUsers`;
CREATE TABLE IF NOT EXISTS `AdminUsers` (
  `Name` varchar(50) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `AdminUsers`
--

INSERT INTO `AdminUsers` (`Name`, `Email`, `Password`) VALUES
('Abhijit', 'abhijitjd003@gmail.com', '1'),
('Abhinava Events', 'eventmagnet@gmail.com', 'em#123');

-- --------------------------------------------------------

--
-- Table structure for table `Answers`
--

DROP TABLE IF EXISTS `Answers`;
CREATE TABLE IF NOT EXISTS `Answers` (
  `BlogId` int(11) NOT NULL,
  `Username` varchar(100) NOT NULL,
  `Answer` varchar(1024) NOT NULL,
  `CreatedDateTime` datetime NOT NULL,
  `UpdatedDateTime` datetime NOT NULL,
  KEY `FK_ANS_BlogId` (`BlogId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ConferenceEventCode`
--

DROP TABLE IF EXISTS `ConferenceEventCode`;
CREATE TABLE IF NOT EXISTS `ConferenceEventCode` (
  `AssociationId` int(11) NOT NULL AUTO_INCREMENT,
  `ConfTypeId` int(11) NOT NULL,
  `EventId` int(11) NOT NULL,
  PRIMARY KEY (`AssociationId`),
  KEY `FK_ConfTypeId` (`ConfTypeId`),
  KEY `FK_EventId` (`EventId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ConferenceEventCode`
--

INSERT INTO `ConferenceEventCode` (`AssociationId`, `ConfTypeId`, `EventId`) VALUES
(1, 2, 1),
(3, 1, 2),
(4, 3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `Conferences`
--

DROP TABLE IF EXISTS `Conferences`;
CREATE TABLE IF NOT EXISTS `Conferences` (
  `ConfTypeId` int(11) NOT NULL AUTO_INCREMENT,
  `ConfName` varchar(30) NOT NULL,
  `IsActive` tinyint(1) DEFAULT NULL,
  `LogoPath` varchar(100) NOT NULL,
  `ColorTheme` varchar(20) NOT NULL,
  PRIMARY KEY (`ConfTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Conferences`
--

INSERT INTO `Conferences` (`ConfTypeId`, `ConfName`, `IsActive`, `LogoPath`, `ColorTheme`) VALUES
(1, 'SIMULUS', 1, 'http://eventmagnet.eventregistrations.in/UploadedFiles/SIMULUS/Conference_Logo.png', 'Normal'),
(2, 'PEDICON', 1, 'http://eventmagnet.eventregistrations.in/UploadedFiles/PEDICON/Conference_Logo.png', 'Light'),
(3, 'EMINDIA', 1, 'http://eventmagnet.eventregistrations.in/UploadedFiles/EMINDIA/Conference_Logo.png', 'Light'),
(4, 'TIECON', 0, '', 'Light');

-- --------------------------------------------------------

--
-- Table structure for table `Contacts`
--

DROP TABLE IF EXISTS `Contacts`;
CREATE TABLE IF NOT EXISTS `Contacts` (
  `ContactId` int(11) NOT NULL AUTO_INCREMENT,
  `ConfTypeId` int(11) NOT NULL,
  `Venue` varchar(100) NOT NULL,
  `VenueMapPath` varchar(200) DEFAULT NULL,
  `VenueMapLink` varchar(1024) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `CommunicationAddress` varchar(100) DEFAULT NULL,
  `VenueAddress` varchar(100) DEFAULT NULL,
  `Email` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`ContactId`,`ConfTypeId`),
  KEY `FK_C_ConfTypeId` (`ConfTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Contacts`
--

INSERT INTO `Contacts` (`ContactId`, `ConfTypeId`, `Venue`, `VenueMapPath`, `VenueMapLink`, `Name`, `CommunicationAddress`, `VenueAddress`, `Email`) VALUES
(1, 1, 'Bangalore Palace', 'http://eventmagnet.eventregistrations.in/UploadedFiles/SIMULUS/Contacts/Conference_Logo.png', 'Bangalore', 'Abhijit', 'Horamavu, Bangalore', 'Bangalore', 'abhijitjd003@gmail.com'),
(2, 3, 'HOTEL HILTON, GUINDY, CHENNAI', 'http://eventmagnet.eventregistrations.in/UploadedFiles/EM INDIA/Contacts/Venue.jpg', 'https://www.google.com/maps/embed?', 'Ranjan Mp', '#943, \"Eshwari\", 1st Floor, Vivekananda Circle, Vivekananda Nagar, Mysuru, Karnataka 570023', 'Hilton Chennai, 124, 1, Inner Ring Rd, Poomagal Nagar, Guindy, Chennai, Tamil Nadu 600032', 'ranjan.mp@abhinavaevents.com'),
(3, 2, 'Bangalore', 'http://eventmagnet.eventregistrations.in/UploadedFiles/PEDICON/Contacts/Conference_Logo.png', 'Bangalore', 'Abhijit', 'Bangalore', 'Bangalore', 'test@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `ConversationReplies`
--

DROP TABLE IF EXISTS `ConversationReplies`;
CREATE TABLE IF NOT EXISTS `ConversationReplies` (
  `ConversationId` int(11) NOT NULL,
  `Username` varchar(100) NOT NULL,
  `ReplyMessage` varchar(1024) NOT NULL,
  `CreatedDateTime` datetime NOT NULL,
  `UpdatedDateTime` datetime NOT NULL,
  KEY `FK_CR_ConversationId` (`ConversationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ConversationReplies`
--

INSERT INTO `ConversationReplies` (`ConversationId`, `Username`, `ReplyMessage`, `CreatedDateTime`, `UpdatedDateTime`) VALUES
(1, 'A', 'Done', '2020-07-02 10:21:48', '2020-07-02 10:21:48'),
(1, 'A', 'Not', '2020-07-02 10:21:56', '2020-07-02 10:21:56'),
(2, 'A', 'Ok', '2020-07-02 11:50:44', '2020-07-02 11:50:44'),
(2, 'A', 'Done', '2020-07-02 11:51:00', '2020-07-02 11:51:00'),
(3, 'A', 'Am good', '2020-07-02 11:51:44', '2020-07-02 11:51:44'),
(2, 'A', 'Hahhaha', '2020-07-02 11:52:04', '2020-07-02 11:52:04');

-- --------------------------------------------------------

--
-- Table structure for table `Conversations`
--

DROP TABLE IF EXISTS `Conversations`;
CREATE TABLE IF NOT EXISTS `Conversations` (
  `ConversationId` int(11) NOT NULL AUTO_INCREMENT,
  `ConfTypeId` int(11) NOT NULL,
  `Username` varchar(100) NOT NULL,
  `Message` varchar(1024) NOT NULL,
  `CreatedDateTime` datetime NOT NULL,
  `UpdatedDateTime` datetime NOT NULL,
  `Likes` int(11) DEFAULT '0',
  PRIMARY KEY (`ConversationId`),
  KEY `FK_CONV_ConfTypeId` (`ConfTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Conversations`
--

INSERT INTO `Conversations` (`ConversationId`, `ConfTypeId`, `Username`, `Message`, `CreatedDateTime`, `UpdatedDateTime`, `Likes`) VALUES
(1, 3, 'Xyz', 'Testing', '2020-07-02 10:21:26', '2020-07-02 10:21:56', 0),
(2, 2, 'Monali', 'Testing', '2020-07-02 11:50:29', '2020-07-02 11:52:04', 4),
(3, 2, 'Abhi', 'How ru?', '2020-07-02 11:51:33', '2020-07-02 11:51:44', 3);

-- --------------------------------------------------------

--
-- Table structure for table `Delegates`
--

DROP TABLE IF EXISTS `Delegates`;
CREATE TABLE IF NOT EXISTS `Delegates` (
  `DelegateId` int(11) NOT NULL AUTO_INCREMENT,
  `ConfTypeId` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `RegistrationId` int(11) DEFAULT NULL,
  `Category` varchar(20) NOT NULL,
  `DelegateType` varchar(20) DEFAULT NULL,
  `Information` varchar(1024) DEFAULT NULL,
  `PhotoPath` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`DelegateId`),
  KEY `FK_DEL_ConfTypeId` (`ConfTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Delegates`
--

INSERT INTO `Delegates` (`DelegateId`, `ConfTypeId`, `Name`, `RegistrationId`, `Category`, `DelegateType`, `Information`, `PhotoPath`) VALUES
(1, 2, 'Abhijit', 101, 'Faculty', NULL, 'Testing', 'http://eventmagnet.eventregistrations.in/UploadedFiles/PEDICON/Faculty/1/Abhijit.jpg'),
(3, 2, 'DR. Abhijit JD', 101, 'Faculty', '', 'Something about faculty', NULL),
(5, 2, 'DR. Praveen G', 0, 'Org Committee', 'Organizing Committee', 'Something about delegate', NULL),
(6, 1, 'DR. Abhijit JD', 101, 'Faculty', NULL, 'Something about faculty', 'http://eventmagnet.eventregistrations.in/UploadedFiles/SIMULUS/Faculty/6/Abhijit.jpg'),
(7, 1, 'DR. Shamanoon', 102, 'Delegate', '', 'Something about delegate', NULL),
(8, 1, 'DR. Praveen G', 103, 'Committee', 'Organizing Committee', 'Something about delegate', NULL),
(30, 1, 'Shruthi Raj', 105, 'Faculty', NULL, NULL, 'http://eventmagnet.eventregistrations.in/UploadedFiles/SIMULUS/Faculty/30/image.png'),
(31, 3, 'Dr. VINAY NADKARNI', 211, 'Faculty', NULL, 'Medical Director, Centre for Simulation, Advanced Education & Innovation, Childrens Hospital Of Philadelphia, USA Endowed Chair, Professor, Department of Anesthesia and Critical Care Medicine\r\n', 'http://eventmagnet.eventregistrations.in/UploadedFiles/EM INDIA/Faculty/31/WhatsApp Image 2020-02-04 at 1.25.26 PM.jpeg'),
(32, 3, 'Dr. PETER WEINSTOCK', 212, 'Faculty', '', 'Executive Director, Simulator Program (SIMPeds) Anesthesia Chair, Pediatric Simulation Senior Associate, Critical Care Associate Professor, Harvard Medical School, Boston, MA\n', NULL),
(33, 3, 'Dr. MIKE SHEPHERD', 214, 'Faculty', '', 'Director of Starship Child Health Paediatric Emergency Specialist, Starship Child Health, Auckland, New Zealand\n', NULL),
(34, 3, 'Dr. ANNE M ADES', 215, 'Faculty', '', 'Director of Neonatology Medical Education, Childrens Hospital of Philadelphia, USA\n', NULL),
(35, 3, 'Dr. BRISEIDA MEMA', 216, 'Faculty', '', 'Staff Physician PICU, Critical Care Medicine The Hospital for Sick Children, Toronto, Canada\n', NULL),
(36, 3, 'Dr. ELLEN DEUTSCH', 217, 'Faculty', '', 'Adjunct Associate Professor, Anesthesiology and Critical Care, University of Pennsylvania Perelman School of Medicine, Senior Scientist, Dept of Anesthesiology & Critical Care Medicine\n', NULL),
(37, 3, 'Dr. UTPAL BHALALA', 218, 'Faculty', '', 'Associate Medical Director The Childrens Hospital of San Antonio, Voelcker Clinical Research Center Director of Pediatric Critical Care Research, Baylor College of Medicine, The Childrens Hospital of San Antonio Texas, United States', NULL),
(38, 3, 'Dr. ASIT MISRA', 219, 'Faculty', '', '', NULL),
(39, 3, 'Ms. ELLA SCOTT', 220, 'Faculty', '', 'Interim Director, Simulation and Life Support Training, Sidra Medicine, Doha, Qatar\n', NULL),
(40, 3, 'Ms. GABRIELLE NUTHALL', 221, 'Faculty', '', 'Paediatric Intensivist Paediatric Intensive Care Unit Starship Childrens Hospital, New Zealand\n', NULL),
(41, 3, 'Dr. MURTHY NYASAVAJJALA', 222, 'Faculty', '', 'Consultant Upper GI Surgeon Northern Lincolnshire and Goole NHS Foundation Trust Scunthorpe, UK\n', NULL),
(42, 3, 'Dr. RAMESH', 223, 'Org Committee', 'Patrons', '', NULL),
(43, 3, 'DR. DINESH CHIRLA', 224, 'Org Committee', 'Patrons', '', NULL),
(44, 3, 'Dr. BALA RAMACHANDRAN', 225, 'Org Committee', 'Chief Organising Cha', '', NULL),
(45, 3, 'Dr. INDIRA JAYAKUMAR', 226, 'Org Committee', 'Chief Organising Cha', '', NULL),
(46, 3, 'Dr. KARTHIK NARAYANAN', 227, 'Org Committee', 'Chief Organising Sec', '', NULL),
(47, 3, 'Dr. NATRAJAN PALANIAPPAN ', 228, 'Org Committee', 'Joint Organising Sec', '', NULL),
(48, 3, 'Dr. RAHUL YADAV', 229, 'Org Committee', 'Joint Organising Sec', '', NULL),
(49, 3, 'Dr. RAKSHAY SHETTY', 230, 'Org Committee', 'PediSTARS President', '', NULL),
(50, 3, 'Dr. SUJATHA THYAGARAJAN', 231, 'Org Committee', 'PediSTARS President', '', NULL),
(51, 3, 'Dr. GEETHANJALI RAMACHANDRA', 232, 'Org Committee', 'Scientific Program C', '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `EventCodes`
--

DROP TABLE IF EXISTS `EventCodes`;
CREATE TABLE IF NOT EXISTS `EventCodes` (
  `EventId` int(11) NOT NULL AUTO_INCREMENT,
  `EventCode` varchar(30) NOT NULL,
  `IsActive` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`EventId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `EventCodes`
--

INSERT INTO `EventCodes` (`EventId`, `EventCode`, `IsActive`) VALUES
(1, 'PEDICON2020', 1),
(2, 'SIMULUS2020', 1),
(3, 'EMINDIA2020', 1);

-- --------------------------------------------------------

--
-- Table structure for table `EventMagnetBanner`
--

DROP TABLE IF EXISTS `EventMagnetBanner`;
CREATE TABLE IF NOT EXISTS `EventMagnetBanner` (
  `BannerPath` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `EventMagnetBanner`
--

INSERT INTO `EventMagnetBanner` (`BannerPath`) VALUES
('http://eventmagnet.eventregistrations.in/UploadedFiles/EventMagnet/Conference_Logo.png');

-- --------------------------------------------------------

--
-- Table structure for table `MobileDevices`
--

DROP TABLE IF EXISTS `MobileDevices`;
CREATE TABLE IF NOT EXISTS `MobileDevices` (
  `DeviceId` varchar(9999) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `MobileDevices`
--

INSERT INTO `MobileDevices` (`DeviceId`) VALUES
('cTjEuHuQ_wc:APA91bEHGOhS20kgnQED_zcFTmTj4zAyLX5oH0l6F-sEsfE63t95qxb41tWbA7Yr2jDGOF6c4zxQfsoDAh1hdbiyxXsouDfbWqJ1Ic9hFeLGOYoBHwtZ5aXcUO9JIp-48mMDI3MZXFJc'),
('ddvIRI_YgK0:APA91bGsTHcP2G5m1WGsc7ZyF56oeP7kXssZMelzTxVcpT5kGmpUDNSXsU5oz2Bw8evQTdmXWLyk31vPCf2pBI13Mzi1jtJPcUE3e7tUQxT6wAMRDeyzeB9qeSdriUGOb-43K-579HZe');

-- --------------------------------------------------------

--
-- Table structure for table `MySchedules`
--

DROP TABLE IF EXISTS `MySchedules`;
CREATE TABLE IF NOT EXISTS `MySchedules` (
  `MyScheduleId` int(11) NOT NULL AUTO_INCREMENT,
  `ConfTypeId` int(11) NOT NULL,
  `Username` varchar(100) NOT NULL,
  `MobileNo` varchar(20) NOT NULL,
  `Session` varchar(200) NOT NULL,
  `Date` varchar(20) NOT NULL,
  `FromTime` varchar(20) NOT NULL,
  `ToTime` varchar(20) NOT NULL,
  `ScheduleType` varchar(30) NOT NULL,
  PRIMARY KEY (`MyScheduleId`),
  KEY `FK_MS_ConfTypeId` (`ConfTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `MySchedules`
--

INSERT INTO `MySchedules` (`MyScheduleId`, `ConfTypeId`, `Username`, `MobileNo`, `Session`, `Date`, `FromTime`, `ToTime`, `ScheduleType`) VALUES
(2, 2, 'Monali', '9036751578', 'Liver function test', '1598898600000', '10:00 AM', '11:00 AM', 'Schedule'),
(3, 2, 'Monali', '9036751578', 'HBV marker interpretation', '1598898600000', '11:00 AM', '12:00 PM', 'Schedule'),
(4, 2, 'Monali', '9036751578', 'Liver function test', '09/01/2020', '10:00 AM', '11:00 AM', 'Workshop');

-- --------------------------------------------------------

--
-- Table structure for table `Notifications`
--

DROP TABLE IF EXISTS `Notifications`;
CREATE TABLE IF NOT EXISTS `Notifications` (
  `NotificationId` int(11) NOT NULL AUTO_INCREMENT,
  `ConfTypeId` int(11) NOT NULL,
  `Message` varchar(1024) NOT NULL,
  `CreatedDateTime` datetime NOT NULL,
  PRIMARY KEY (`NotificationId`),
  KEY `FK_N_ConfTypeId` (`ConfTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Notifications`
--

INSERT INTO `Notifications` (`NotificationId`, `ConfTypeId`, `Message`, `CreatedDateTime`) VALUES
(1, 2, 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.', '2020-07-03 07:20:35');

-- --------------------------------------------------------

--
-- Table structure for table `OurSponsors`
--

DROP TABLE IF EXISTS `OurSponsors`;
CREATE TABLE IF NOT EXISTS `OurSponsors` (
  `SponsorId` int(11) NOT NULL AUTO_INCREMENT,
  `SponsorName` varchar(50) NOT NULL,
  `SponsorLogoPath` varchar(200) NOT NULL,
  PRIMARY KEY (`SponsorId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `OurSponsors`
--

INSERT INTO `OurSponsors` (`SponsorId`, `SponsorName`, `SponsorLogoPath`) VALUES
(2, 'AMT', 'http://eventmagnet.eventregistrations.in/UploadedFiles/EventMagnet/Our Sponsors/Conference_Logo.png'),
(3, 'AE', 'http://eventmagnet.eventregistrations.in/UploadedFiles/EventMagnet/Our Sponsors/Conference_Logo.png');

-- --------------------------------------------------------

--
-- Table structure for table `PaperPosters`
--

DROP TABLE IF EXISTS `PaperPosters`;
CREATE TABLE IF NOT EXISTS `PaperPosters` (
  `PaperPosterId` int(11) NOT NULL AUTO_INCREMENT,
  `ConfTypeId` int(11) NOT NULL,
  `Session` varchar(50) NOT NULL,
  `Category` varchar(50) NOT NULL,
  `Topic` varchar(200) NOT NULL,
  `Speaker` varchar(50) NOT NULL,
  `Date` varchar(50) NOT NULL,
  `FromTime` varchar(20) NOT NULL,
  `ToTime` varchar(20) NOT NULL,
  `PaperPosterType` varchar(50) NOT NULL,
  PRIMARY KEY (`PaperPosterId`),
  KEY `FK_PP_ConfTypeId` (`ConfTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `PaperPosters`
--

INSERT INTO `PaperPosters` (`PaperPosterId`, `ConfTypeId`, `Session`, `Category`, `Topic`, `Speaker`, `Date`, `FromTime`, `ToTime`, `PaperPosterType`) VALUES
(7, 2, 'Session 1', 'Papers', 'Healthcare technologies for rural India', 'DR. Ranjan MP', '09/01/2020', '10:00 AM', '11:00 AM', 'Clinical - Papers'),
(8, 2, 'Session 1', 'Papers', 'Production Deployment', 'DR. Abhijit JD', '09/01/2020', '10:00 AM', '11:00 AM', 'Clinical - Papers'),
(9, 2, 'Session 1', 'Papers', 'Staging Deployment', 'DR. Shamnoon', '09/01/2020', '10:00 AM', '11:00 AM', 'Clinical - Papers'),
(10, 2, 'Session 2', 'Posters', 'Healthcare technologies for rural India', 'DR. Ranjan MP', '09/01/2020', '11:00 AM', '12:00 PM', 'Cardio - Papers'),
(11, 2, 'Session 2', 'Posters', 'Production Deployment', 'DR. Abhijit JD', '09/01/2020', '11:00 AM', '12:00 PM', 'Cardio - Papers'),
(12, 2, 'Session 2', 'Posters', 'Staging Deployment', 'DR. Shamnoon', '09/01/2020', '11:00 AM', '12:00 PM', 'Cardio - Papers');

-- --------------------------------------------------------

--
-- Table structure for table `QRCode`
--

DROP TABLE IF EXISTS `QRCode`;
CREATE TABLE IF NOT EXISTS `QRCode` (
  `QRCodePath` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `QRCode`
--

INSERT INTO `QRCode` (`QRCodePath`) VALUES
('http://eventmagnet.eventregistrations.in/UploadedFiles/conf_name/QRCodes/reg_id@.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `Questions`
--

DROP TABLE IF EXISTS `Questions`;
CREATE TABLE IF NOT EXISTS `Questions` (
  `BlogId` int(11) NOT NULL AUTO_INCREMENT,
  `ConfTypeId` int(11) NOT NULL,
  `Username` varchar(100) NOT NULL,
  `Question` varchar(1024) NOT NULL,
  `CreatedDateTime` datetime NOT NULL,
  `UpdatedDateTime` datetime NOT NULL,
  `Likes` int(11) DEFAULT '0',
  PRIMARY KEY (`BlogId`),
  KEY `FK_QUE_ConfTypeId` (`ConfTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Questions`
--

INSERT INTO `Questions` (`BlogId`, `ConfTypeId`, `Username`, `Question`, `CreatedDateTime`, `UpdatedDateTime`, `Likes`) VALUES
(1, 2, 'Abhijit', 'How ru?', '2020-07-03 10:06:49', '2020-07-03 10:06:49', 2),
(2, 2, 'Abhijit', 'How do you do?', '2020-07-03 10:09:03', '2020-07-03 10:09:03', 3);

-- --------------------------------------------------------

--
-- Table structure for table `Ratings`
--

DROP TABLE IF EXISTS `Ratings`;
CREATE TABLE IF NOT EXISTS `Ratings` (
  `ConfTypeId` int(11) NOT NULL,
  `ScheduleId` int(11) NOT NULL,
  `Username` varchar(100) NOT NULL,
  `SessionType` varchar(30) NOT NULL,
  `RatingValue` decimal(10,2) NOT NULL,
  KEY `FK_RTNGS_ConfTypeId` (`ConfTypeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Ratings`
--

INSERT INTO `Ratings` (`ConfTypeId`, `ScheduleId`, `Username`, `SessionType`, `RatingValue`) VALUES
(2, 18, 'Monali', 'Workshop', '3.00'),
(2, 18, 'Monali', 'Schedule', '2.00'),
(2, 19, 'Abhijit', 'Schedule', '3.00'),
(2, 19, 'Abhijit', 'Schedule', '2.00'),
(2, 18, 'Abhijit', 'Schedule', '5.00'),
(2, 20, 'Abhijit', 'Schedule', '4.00'),
(2, 21, 'Abhijit', 'Schedule', '3.00'),
(2, 21, 'Abhijit', 'Schedule', '2.00'),
(2, 20, 'Abhijit', 'Schedule', '3.00'),
(2, 19, 'Abhijit', 'Workshop', '2.00'),
(2, 20, 'Abhijit', 'Workshop', '3.00'),
(2, 21, 'Abhijit', 'Workshop', '5.00'),
(2, 21, 'Abhijit', 'Workshop', '3.00'),
(2, 20, 'Abhijit', 'Workshop', '1.00'),
(2, 19, 'Abhijit', 'Workshop', '5.00');

-- --------------------------------------------------------

--
-- Table structure for table `Registrations`
--

DROP TABLE IF EXISTS `Registrations`;
CREATE TABLE IF NOT EXISTS `Registrations` (
  `URLId` int(11) NOT NULL AUTO_INCREMENT,
  `RegistrationURL` varchar(100) NOT NULL,
  `ConferenceLogoPath` varchar(200) NOT NULL,
  `ConfTypeId` int(11) NOT NULL,
  PRIMARY KEY (`URLId`),
  KEY `FK_REG_ConfTypeId` (`ConfTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Registrations`
--

INSERT INTO `Registrations` (`URLId`, `RegistrationURL`, `ConferenceLogoPath`, `ConfTypeId`) VALUES
(1, 'Testing', 'http://eventmagnet.eventregistrations.in/UploadedFiles/SIMULUS/Registration/Conference_Logo.png', 1),
(2, 'https://emaindia.net/home/registration', 'http://eventmagnet.eventregistrations.in/UploadedFiles/EM INDIA/Registration/EMA-Logo_new.png', 3),
(3, 'https://fontawesome.com/v4.7.0/icons/', 'http://eventmagnet.eventregistrations.in/UploadedFiles/PEDICON/Registration/SimulusLogo.png', 2);

-- --------------------------------------------------------

--
-- Table structure for table `Resources`
--

DROP TABLE IF EXISTS `Resources`;
CREATE TABLE IF NOT EXISTS `Resources` (
  `ConfTypeId` int(11) NOT NULL,
  `ResourceType` varchar(30) NOT NULL,
  `ResourcePath` varchar(200) NOT NULL,
  `IsRequired` int(11) DEFAULT NULL,
  KEY `FK_R_ConfTypeId` (`ConfTypeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Resources`
--

INSERT INTO `Resources` (`ConfTypeId`, `ResourceType`, `ResourcePath`, `IsRequired`) VALUES
(1, 'Souvenir', 'http://eventmagnet.eventregistrations.in/UploadedFiles/SIMULUS/Souvenir/brochure_4.pdf', 1),
(1, 'Brochure', '', 1),
(1, 'Conference Updates', '', 1),
(2, 'Souvenir', 'http://eventmagnet.eventregistrations.in/UploadedFiles/PEDICON/Souvenir/Test (2).pdf', 1),
(2, 'Brochure', 'http://eventmagnet.eventregistrations.in/UploadedFiles/PEDICON/Brochure/FARMAR.pdf', 1),
(2, 'Conference Updates', '', 1),
(3, 'Souvenir', '', 1),
(3, 'Brochure', 'http://eventmagnet.eventregistrations.in/UploadedFiles/EMINDIA/Brochure/FARMAR.pdf', 1),
(3, 'Conference Updates', '', 1),
(3, 'Tickets', '', 1),
(2, 'Tickets', 'http://eventmagnet.eventregistrations.in/UploadedFiles/PEDICON/Tickets/Tickets_03.png', 1),
(1, 'Tickets', '', 1),
(4, 'Tickets', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `Schedules`
--

DROP TABLE IF EXISTS `Schedules`;
CREATE TABLE IF NOT EXISTS `Schedules` (
  `ScheduleId` int(11) NOT NULL AUTO_INCREMENT,
  `ConfTypeId` int(11) NOT NULL,
  `ScheduleTitle` varchar(200) NOT NULL,
  `Hall` varchar(30) NOT NULL,
  `Date` varchar(20) NOT NULL,
  `FromTime` varchar(20) NOT NULL,
  `ToTime` varchar(20) NOT NULL,
  PRIMARY KEY (`ScheduleId`),
  KEY `FK_SCH_ConfTypeId` (`ConfTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Schedules`
--

INSERT INTO `Schedules` (`ScheduleId`, `ConfTypeId`, `ScheduleTitle`, `Hall`, `Date`, `FromTime`, `ToTime`) VALUES
(1, 1, 'Liver function test - schedule', 'HALL A', '09/01/2020', '10:00', '12:00'),
(2, 1, 'HBV marker interpretation', 'HALL A', '09/01/2020', '11:00', '12:00'),
(3, 1, 'Liver function test', 'HALL B', '09/01/2020', '10:00', '11:00'),
(5, 3, 'Registration', 'PICU Boot Camp', '02/06/2020', '07:30', '08:00'),
(6, 3, 'Introduction', 'PICU Boot Camp', '02/06/2020', '08:00', '08:15'),
(7, 3, 'Team activity', 'PICU Boot Camp', '02/06/2020', '08:15', '08:30'),
(8, 3, 'Team approach- CRM principles', 'PICU Boot Camp', '02/06/2020', '08:30', '09:00'),
(9, 3, 'Physiologically difficult airway', 'PICU Boot Camp', '02/06/2020', '09:00', '09:30'),
(10, 3, 'Tea Break ', 'PICU Boot Camp', '02/06/2020', '09:30', '09:45'),
(11, 3, 'skill stations', 'PICU Boot Camp', '02/06/2020', '09:45', '12:25'),
(12, 3, 'Lunch Break', 'PICU Boot Camp', '02/06/2020', '12:25', '01:00'),
(13, 3, 'Approach To Trauma', 'PICU Boot Camp', '02/06/2020', '01:00', '01:30'),
(14, 3, 'Raised ICP management ', 'PICU Boot Camp', '02/06/2020', '01:30', '02:00'),
(15, 3, 'Team activity', 'PICU Boot Camp', '02/06/2020', '02:00', '02:15'),
(16, 3, 'Scenario', 'PICU Boot Camp', '02/06/2020', '02:15', '05:05'),
(17, 3, 'Summarizing the day', 'PICU Boot Camp', '02/06/2020', '05:05', '05:30'),
(18, 2, 'Liver function test', 'HALL A', '09/01/2020', '10:00 AM', '11:00 AM'),
(19, 2, 'HBV marker interpretation', 'HALL A', '09/02/2020', '11:00 AM', '12:00 PM'),
(20, 2, 'Liver function test', 'HALL B', '09/01/2020', '10:00 AM', '11:00 AM'),
(21, 2, 'HBV marker interpretation', 'HALL C', '09/01/2020', '11:00 AM', '12:00 PM');

-- --------------------------------------------------------

--
-- Table structure for table `Sponsors`
--

DROP TABLE IF EXISTS `Sponsors`;
CREATE TABLE IF NOT EXISTS `Sponsors` (
  `OrgId` int(11) NOT NULL AUTO_INCREMENT,
  `ConfTypeId` int(11) NOT NULL,
  `Category` varchar(30) NOT NULL,
  `OrgName` varchar(50) NOT NULL,
  `AboutOrg` varchar(1024) NOT NULL,
  `OrgLogoPath` varchar(200) NOT NULL,
  PRIMARY KEY (`OrgId`),
  KEY `FK_ORG_ConfTypeId` (`ConfTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Sponsors`
--

INSERT INTO `Sponsors` (`OrgId`, `ConfTypeId`, `Category`, `OrgName`, `AboutOrg`, `OrgLogoPath`) VALUES
(2, 1, 'MSD', 'AMT', 'About AMT', 'http://eventmagnet.eventregistrations.in/UploadedFiles/SIMULUS/Sponsors/AMT/Conference_Logo.png'),
(3, 1, 'Organising Committee', 'Abhinava Events', 'About Abhinava', ''),
(5, 2, 'Event Management', 'Abhinava Global Academy', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'http://eventmagnet.eventregistrations.in/UploadedFiles/PEDICON/Sponsors/Abhinava Global Academy/Ad-Sponser-logo_03.png');

-- --------------------------------------------------------

--
-- Table structure for table `VisitPlaces`
--

DROP TABLE IF EXISTS `VisitPlaces`;
CREATE TABLE IF NOT EXISTS `VisitPlaces` (
  `PlaceId` int(11) NOT NULL AUTO_INCREMENT,
  `ConfTypeId` int(11) NOT NULL,
  `PlaceName` varchar(50) NOT NULL,
  `AreaName` varchar(100) NOT NULL,
  `AboutArea` varchar(1024) NOT NULL,
  `AreaImagePath` varchar(200) NOT NULL,
  PRIMARY KEY (`PlaceId`),
  KEY `FK_PLC_ConfTypeId` (`ConfTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `VisitPlaces`
--

INSERT INTO `VisitPlaces` (`PlaceId`, `ConfTypeId`, `PlaceName`, `AreaName`, `AboutArea`, `AreaImagePath`) VALUES
(2, 1, 'Bangalore', 'Lalbagh', 'About Lalbagh Bangalore - Testing', 'http://eventmagnet.eventregistrations.in/UploadedFiles/SIMULUS/Places/Lalbagh/Conference_Logo.png'),
(3, 3, 'mysore', 'mysore', 'Garden City', 'http://eventmagnet.eventregistrations.in/UploadedFiles/EM INDIA/Places/mysore/download.jpg'),
(4, 2, 'sdgig', 'idugiug', 'ziducigd', 'http://eventmagnet.eventregistrations.in/UploadedFiles/PEDICON/Places/idugiug/Conference_Logo.png');

-- --------------------------------------------------------

--
-- Table structure for table `Workshops`
--

DROP TABLE IF EXISTS `Workshops`;
CREATE TABLE IF NOT EXISTS `Workshops` (
  `WorkshopId` int(11) NOT NULL AUTO_INCREMENT,
  `ConfTypeId` int(11) NOT NULL,
  `WorkshopName` varchar(100) NOT NULL,
  `Session` varchar(200) NOT NULL,
  `Date` varchar(20) NOT NULL,
  `FromTime` varchar(20) NOT NULL,
  `ToTime` varchar(20) NOT NULL,
  PRIMARY KEY (`WorkshopId`),
  KEY `FK_W_ConfTypeId` (`ConfTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Workshops`
--

INSERT INTO `Workshops` (`WorkshopId`, `ConfTypeId`, `WorkshopName`, `Session`, `Date`, `FromTime`, `ToTime`) VALUES
(5, 1, 'Gastroenterology', 'Liver function test', '09/01/2020', '10:00 AM', '11:00 AM'),
(6, 1, 'Gastroenterology', 'HBV marker interpretation', '09/01/2020', '11:00 AM', '12:00 PM'),
(7, 1, 'Difficult Airway', 'Liver function test', '09/01/2020', '10:00 AM', '11:00 AM'),
(8, 1, 'Difficult Airway', 'HBV marker interpretation', '09/01/2020', '11:00 AM', '12:00 PM'),
(9, 3, 'INSPIRE', 'Welcome and Introductions', '02/09/2020', '02:00 PM', '02:10 PM'),
(10, 3, 'INSPIRE', 'INSPIRE (International Network for Simulation-based Pediatric Innovation, Research & Education) overview', '02/09/2020', '02:10 PM', '02:20 PM'),
(11, 3, 'INSPIRE', '13 ALERT (Advanced Look Exploratory Research Template) presentation 3 minute each. 1 minute for quick faculty questions between presentations', '02/09/2020', '02:20 PM', '03:20 PM'),
(12, 3, 'INSPIRE', 'Inhouse Tea/Coffee Break. Judges to decide 6 ALERT Presentation', '02/09/2020', '03:20 PM', '03:30 PM'),
(13, 3, 'INSPIRE', 'Reorganize to 6 different tables', '02/09/2020', '03:30 PM', '03:35 PM'),
(14, 3, 'INSPIRE', '45 minute ALERT small group discussions', '02/09/2020', '03:35 PM', '04:20 PM'),
(15, 3, 'INSPIRE', '2 Min Presentation by Each Mentor (2x6 tables)', '02/09/2020', '04:20 PM', '04:35 PM'),
(16, 3, 'INSPIRE', 'Interactive talk by ', '02/09/2020', '04:35 PM', '04:55 PM'),
(17, 3, 'INSPIRE', 'Wrap Up', '02/09/2020', '04:55 PM', '05:00 PM'),
(18, 2, 'Gastroenterology', 'Liver function test', '09/01/2020', '10:00 AM', '11:00 AM'),
(19, 2, 'Gastroenterology', 'HBV marker interpretation', '09/01/2020', '11:00 AM', '12:00 PM'),
(20, 2, 'Difficult Airway', 'Liver function test', '09/01/2020', '10:00 AM', '11:00 AM'),
(21, 2, 'Difficult Airway', 'HBV marker interpretation', '09/01/2020', '11:00 AM', '12:00 PM');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `AboutConference`
--
ALTER TABLE `AboutConference`
  ADD CONSTRAINT `FK_AC_ConfTypeId` FOREIGN KEY (`ConfTypeId`) REFERENCES `Conferences` (`ConfTypeId`);

--
-- Constraints for table `Answers`
--
ALTER TABLE `Answers`
  ADD CONSTRAINT `FK_ANS_BlogId` FOREIGN KEY (`BlogId`) REFERENCES `Questions` (`BlogId`);

--
-- Constraints for table `ConferenceEventCode`
--
ALTER TABLE `ConferenceEventCode`
  ADD CONSTRAINT `FK_ConfTypeId` FOREIGN KEY (`ConfTypeId`) REFERENCES `Conferences` (`ConfTypeId`),
  ADD CONSTRAINT `FK_EventId` FOREIGN KEY (`EventId`) REFERENCES `EventCodes` (`EventId`);

--
-- Constraints for table `Contacts`
--
ALTER TABLE `Contacts`
  ADD CONSTRAINT `FK_C_ConfTypeId` FOREIGN KEY (`ConfTypeId`) REFERENCES `Conferences` (`ConfTypeId`);

--
-- Constraints for table `ConversationReplies`
--
ALTER TABLE `ConversationReplies`
  ADD CONSTRAINT `FK_CR_ConversationId` FOREIGN KEY (`ConversationId`) REFERENCES `Conversations` (`ConversationId`);

--
-- Constraints for table `Conversations`
--
ALTER TABLE `Conversations`
  ADD CONSTRAINT `FK_CONV_ConfTypeId` FOREIGN KEY (`ConfTypeId`) REFERENCES `Conferences` (`ConfTypeId`);

--
-- Constraints for table `Delegates`
--
ALTER TABLE `Delegates`
  ADD CONSTRAINT `FK_DEL_ConfTypeId` FOREIGN KEY (`ConfTypeId`) REFERENCES `Conferences` (`ConfTypeId`);

--
-- Constraints for table `MySchedules`
--
ALTER TABLE `MySchedules`
  ADD CONSTRAINT `FK_MS_ConfTypeId` FOREIGN KEY (`ConfTypeId`) REFERENCES `Conferences` (`ConfTypeId`);

--
-- Constraints for table `Notifications`
--
ALTER TABLE `Notifications`
  ADD CONSTRAINT `FK_N_ConfTypeId` FOREIGN KEY (`ConfTypeId`) REFERENCES `Conferences` (`ConfTypeId`);

--
-- Constraints for table `PaperPosters`
--
ALTER TABLE `PaperPosters`
  ADD CONSTRAINT `FK_PP_ConfTypeId` FOREIGN KEY (`ConfTypeId`) REFERENCES `Conferences` (`ConfTypeId`);

--
-- Constraints for table `Questions`
--
ALTER TABLE `Questions`
  ADD CONSTRAINT `FK_QUE_ConfTypeId` FOREIGN KEY (`ConfTypeId`) REFERENCES `Conferences` (`ConfTypeId`);

--
-- Constraints for table `Ratings`
--
ALTER TABLE `Ratings`
  ADD CONSTRAINT `FK_RTNGS_ConfTypeId` FOREIGN KEY (`ConfTypeId`) REFERENCES `Conferences` (`ConfTypeId`);

--
-- Constraints for table `Registrations`
--
ALTER TABLE `Registrations`
  ADD CONSTRAINT `FK_REG_ConfTypeId` FOREIGN KEY (`ConfTypeId`) REFERENCES `Conferences` (`ConfTypeId`);

--
-- Constraints for table `Resources`
--
ALTER TABLE `Resources`
  ADD CONSTRAINT `FK_R_ConfTypeId` FOREIGN KEY (`ConfTypeId`) REFERENCES `Conferences` (`ConfTypeId`);

--
-- Constraints for table `Schedules`
--
ALTER TABLE `Schedules`
  ADD CONSTRAINT `FK_SCH_ConfTypeId` FOREIGN KEY (`ConfTypeId`) REFERENCES `Conferences` (`ConfTypeId`);

--
-- Constraints for table `Sponsors`
--
ALTER TABLE `Sponsors`
  ADD CONSTRAINT `FK_ORG_ConfTypeId` FOREIGN KEY (`ConfTypeId`) REFERENCES `Conferences` (`ConfTypeId`);

--
-- Constraints for table `VisitPlaces`
--
ALTER TABLE `VisitPlaces`
  ADD CONSTRAINT `FK_PLC_ConfTypeId` FOREIGN KEY (`ConfTypeId`) REFERENCES `Conferences` (`ConfTypeId`);

--
-- Constraints for table `Workshops`
--
ALTER TABLE `Workshops`
  ADD CONSTRAINT `FK_W_ConfTypeId` FOREIGN KEY (`ConfTypeId`) REFERENCES `Conferences` (`ConfTypeId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
