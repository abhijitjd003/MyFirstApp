-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 148.72.232.169:3306
-- Generation Time: Jun 26, 2020 at 10:33 AM
-- Server version: 5.5.51-38.1-log
-- PHP Version: 7.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `DataValidation`
--
CREATE DATABASE IF NOT EXISTS `DataValidation` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `DataValidation`;

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `UspGetAllUsers`$$
CREATE DEFINER=`data_validation`@`%` PROCEDURE `UspGetAllUsers`()
BEGIN
	SELECT * FROM UserProfile;
END
$$

DROP PROCEDURE IF EXISTS `UspGetUserProfile`$$
CREATE DEFINER=`data_validation`@`%` PROCEDURE `UspGetUserProfile`(
	IN p_MobileNo BIGINT,
    IN p_Email VARCHAR(30)
)
BEGIN
	SELECT * FROM UserProfile
    WHERE MobileNo = p_MobileNo OR Email = p_Email;
END
$$

DROP PROCEDURE IF EXISTS `UspRemoveUser`$$
CREATE DEFINER=`data_validation`@`%` PROCEDURE `UspRemoveUser`(
	IN p_ProfileId INT
)
BEGIN
	DELETE FROM UserProfile
    WHERE ProfileId = p_ProfileId;
END
$$

DROP PROCEDURE IF EXISTS `UspSaveUserProfile`$$
CREATE DEFINER=`data_validation`@`%` PROCEDURE `UspSaveUserProfile`(
	IN p_ProfileId INT,
	IN p_MembershipId VARCHAR(20),
    IN p_Title VARCHAR(10),
    IN p_FullName VARCHAR(50),
    IN p_Gender VARCHAR(10),
    IN p_MobileNo BIGINT,
    IN p_Email VARCHAR(30),
    IN p_Address VARCHAR(100),
    IN p_PinCode INT,
    IN p_DOB DATE,
    IN p_DOJ DATE,
    IN p_Nationality VARCHAR(20),
    IN p_City VARCHAR(30),
    IN p_State VARCHAR(30),
    IN p_MedCouncilNo VARCHAR(20),
    IN p_Speciality VARCHAR(30),
    IN p_ResidenceTelNo BIGINT,
    IN p_OfficeTelNo BIGINT,
    IN p_AlternateMobileNo BIGINT,
    IN p_CreatedDateTime DATETIME,
    IN p_UpdatedDateTime DATETIME
)
BEGIN
	IF p_ProfileId = 0 THEN
    BEGIN
		INSERT INTO UserProfile
		(
			MobileNo,
			Email,
			MedCouncilNo,
			Title,
			FullName,
			MembershipId,
            Gender,
            DOB,
            Speciality,
            Address,
            PinCode,
            City,
            State,
            Nationality,
            ResidenceTelNo,
            OfficeTelNo,
            AlternateMobileNo,
            DOJ,
			CreatedDateTime,
			UpdatedDateTime
		)
		SELECT
			p_MobileNo,
			p_Email,
			p_MedCouncilNo,
			p_Title,
			p_FullName,
			p_MembershipId,
            p_Gender,
            p_DOB,
            p_Speciality,
            p_Address,
            p_PinCode,
            p_City,
            p_State,
            p_Nationality,
            p_ResidenceTelNo,
            p_OfficeTelNo,
            p_AlternateMobileNo,
            p_DOJ,
			p_CreatedDateTime,
			p_UpdatedDateTime;
                
		SELECT 'success' Message;
	END;
    ELSE
    BEGIN
        UPDATE UserProfile
		SET MobileNo = p_MobileNo,
			Email = p_Email,
			MedCouncilNo = p_MedCouncilNo,
			Title = p_Title,
			FullName = p_FullName,
			MembershipId = p_MembershipId,
            Gender = p_Gender,
            DOB = p_DOB,
            Speciality = p_Speciality,
            Address = p_Address,
            PinCode = p_PinCode,
            City = p_City,
            State = p_State,
            Nationality = p_Nationality,
            ResidenceTelNo = p_ResidenceTelNo,
            OfficeTelNo = p_OfficeTelNo,
            AlternateMobileNo = p_AlternateMobileNo,
            DOJ = p_DOJ,			
			UpdatedDateTime = p_UpdatedDateTime
		WHERE ProfileId = p_ProfileId;
        
        SELECT 'success' Message;
    END;
    END IF;
END
$$

DROP PROCEDURE IF EXISTS `UspValidateLoginUser`$$
CREATE DEFINER=`data_validation`@`%` PROCEDURE `UspValidateLoginUser`(
	IN p_MobileNo BIGINT
)
BEGIN
	SET @IsUserAdmin := '';
    
    SELECT @IsUserAdmin := MobileNo FROM AdminUsers
    WHERE MobileNo = p_MobileNo;
    
    IF @IsUserAdmin = '' THEN
		SELECT 0 IsUserAdmin;
	ELSE
		SELECT 1 IsUserAdmin;
	END IF;
END
$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `AdminUsers`
--

DROP TABLE IF EXISTS `AdminUsers`;
CREATE TABLE IF NOT EXISTS `AdminUsers` (
  `Name` varchar(50) NOT NULL,
  `MobileNo` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `UserProfile`
--

DROP TABLE IF EXISTS `UserProfile`;
CREATE TABLE IF NOT EXISTS `UserProfile` (
  `ProfileId` int(11) NOT NULL AUTO_INCREMENT,
  `MembershipId` varchar(20) NOT NULL,
  `Title` varchar(10) NOT NULL,
  `FullName` varchar(50) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `MobileNo` bigint(20) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `PinCode` int(11) NOT NULL,
  `DOB` date NOT NULL,
  `Nationality` varchar(20) NOT NULL,
  `City` varchar(30) NOT NULL,
  `State` varchar(30) NOT NULL,
  `MedCouncilNo` varchar(20) NOT NULL,
  `DOJ` date NOT NULL,
  `Speciality` varchar(30) NOT NULL,
  `ResidenceTelNo` bigint(20) NOT NULL,
  `OfficeTelNo` bigint(20) NOT NULL,
  `AlternateMobileNo` bigint(20) NOT NULL,
  `CreatedDateTime` datetime NOT NULL,
  `UpdatedDateTime` datetime NOT NULL,
  PRIMARY KEY (`ProfileId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
