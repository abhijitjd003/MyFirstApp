﻿using System;
using System.Collections.Specialized;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace GupShupCSharpAPITestForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void sendMailButton_Click(object sender, EventArgs e)
        {
            string emails = "abhijitjd003@gmail.com,dharangutte.abhijit@gmail.com,";

            emails = emails.ToString().Remove(emails.ToString().Length - 1);

            string gupshupAPIURL = "http://enterprise.webaroo.com/GatewayAPI/rest";
            NameValueCollection reqParams = new NameValueCollection();
            reqParams.Add("userid", "2000701028");
            reqParams.Add("password", "Tde2wR");
            reqParams.Add("method", "EMS_POST_CAMPAIGN");
            reqParams.Add("v", "1.1");
            reqParams.Add("recipients", "abhijitjd003@gmail.com,dharangutte.abhijit@gmail.com");
            reqParams.Add("format", "json");
            reqParams.Add("name", "Test From CSharp App");
            reqParams.Add("content_type", "text/html");
            reqParams.Add("subject", "Subject of the Mail");
            reqParams.Add("content", "Content of the Mail");
            
            string reqResponse = GupShupCSharpAPILib.APIClient.UploadFilesToRemoteUrl(gupshupAPIURL, reqParams);
            MessageBox.Show(reqResponse);
        }
    }
}
