self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "4742ddefc279cf703bb8db3577eb416a",
    "url": "/View/index.html"
  },
  {
    "revision": "50122ed691e001b770c4",
    "url": "/View/static/css/main.348c4ead.chunk.css"
  },
  {
    "revision": "b3c00b79770e57f4bde5",
    "url": "/View/static/js/2.e5d55538.chunk.js"
  },
  {
    "revision": "4876403f9086112791ca85dbfe34527d",
    "url": "/View/static/js/2.e5d55538.chunk.js.LICENSE.txt"
  },
  {
    "revision": "50122ed691e001b770c4",
    "url": "/View/static/js/main.e0e834a9.chunk.js"
  },
  {
    "revision": "33acd2e4666054d8913d",
    "url": "/View/static/js/runtime-main.1202552d.js"
  },
  {
    "revision": "2575e0270359c539e738533432db8ff9",
    "url": "/View/static/media/add1.2575e027.jpg"
  },
  {
    "revision": "ace18863bab9d5c0b305570d274d547d",
    "url": "/View/static/media/add2.ace18863.jpg"
  },
  {
    "revision": "648fa9faea73bcefeebcdd3c28c94c38",
    "url": "/View/static/media/icons8-google.648fa9fa.svg"
  }
]);