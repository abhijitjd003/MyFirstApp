self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "23daf06ba934f99ea067bcb655f08cc6",
    "url": "/View/index.html"
  },
  {
    "revision": "33e65fdc30c5ae395b2e",
    "url": "/View/static/css/main.f3ff009a.chunk.css"
  },
  {
    "revision": "8ffd784c935825e7505e",
    "url": "/View/static/js/2.1a6161c1.chunk.js"
  },
  {
    "revision": "4876403f9086112791ca85dbfe34527d",
    "url": "/View/static/js/2.1a6161c1.chunk.js.LICENSE.txt"
  },
  {
    "revision": "33e65fdc30c5ae395b2e",
    "url": "/View/static/js/main.377bbc05.chunk.js"
  },
  {
    "revision": "33acd2e4666054d8913d",
    "url": "/View/static/js/runtime-main.1202552d.js"
  },
  {
    "revision": "2575e0270359c539e738533432db8ff9",
    "url": "/View/static/media/add1.2575e027.jpg"
  },
  {
    "revision": "ace18863bab9d5c0b305570d274d547d",
    "url": "/View/static/media/add2.ace18863.jpg"
  },
  {
    "revision": "a1c50a0b2d98b5cef387d1d4822531a8",
    "url": "/View/static/media/img1.a1c50a0b.jpg"
  }
]);