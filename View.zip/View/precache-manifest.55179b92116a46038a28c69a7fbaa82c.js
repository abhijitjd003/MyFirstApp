self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e3c628995c55802def0c1fa5d9537b15",
    "url": "/View/index.html"
  },
  {
    "revision": "36d6e431acb4474f290b",
    "url": "/View/static/css/main.f3ff009a.chunk.css"
  },
  {
    "revision": "3538a934e85decef1bfe",
    "url": "/View/static/js/2.878672f9.chunk.js"
  },
  {
    "revision": "4876403f9086112791ca85dbfe34527d",
    "url": "/View/static/js/2.878672f9.chunk.js.LICENSE.txt"
  },
  {
    "revision": "36d6e431acb4474f290b",
    "url": "/View/static/js/main.fcfbfc96.chunk.js"
  },
  {
    "revision": "33acd2e4666054d8913d",
    "url": "/View/static/js/runtime-main.1202552d.js"
  },
  {
    "revision": "2575e0270359c539e738533432db8ff9",
    "url": "/View/static/media/add1.2575e027.jpg"
  },
  {
    "revision": "ace18863bab9d5c0b305570d274d547d",
    "url": "/View/static/media/add2.ace18863.jpg"
  },
  {
    "revision": "a1c50a0b2d98b5cef387d1d4822531a8",
    "url": "/View/static/media/img1.a1c50a0b.jpg"
  }
]);