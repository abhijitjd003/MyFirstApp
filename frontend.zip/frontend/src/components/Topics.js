import React, { Component, Fragment } from 'react';
import { 
    Grid, withStyles, useMediaQuery, Card, CardContent, Typography, CardHeader, IconButton, Divider,
    Backdrop, CircularProgress
} from '@material-ui/core';
import { withRouter } from 'react-router-dom';
import { useStyles } from './common/useStyles';
import './common/Common.css'
import classNames from 'classnames';
import VisibilityIcon from '@material-ui/icons/Visibility';
import Add1 from './images/add1.jpg';
import Add2 from './images/add2.jpg';
import QuestionIcon from './images/Question.png';
import MessageIcon from './images/mesage.png';
import LikeIcon from './images/like.png';
import VoteIcon from './images/votes_icon.png';
import LikeIconColor from './images/like_h.png';
import VoteIconColor from './images/votes_h.png';
import PollIcon from './images/poll.png';
import api from './common/APIValues';
import InfiniteScroll from "react-infinite-scroll-component";
import HyvorTalk from 'hyvor-talk-react';
import axios from 'axios';

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);    
    return <Component mediaQuery={mediaQuery} {...props} />;
};

class Topics extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            userTopics: [], loader: false, disableAddQue: false, currentPage: 1, isPopular: 0, pages: 0,
        }
    }

    componentDidMount() {
        window.scrollTo(0, 0);
        sessionStorage.setItem('topic_id', '');
        this.setState({ 
            disableAddQue: this.props.userEmail && this.props.userAliasName ? false : true
        });
        this.loadUserTopics(0);
    }

    componentDidUpdate = (prevProps, prevState) => {
        if (this.props.userEmail !== prevProps.userEmail || this.props.userAliasName !== prevProps.userAliasName) {            
            this.setState({ 
                disableAddQue: this.props.userEmail && this.props.userAliasName ? false : true
            });
        }

        if(this.props.isPopular !== prevProps.isPopular || this.props.searchValue !== prevProps.searchValue) {
            this.loadUserTopics(this.props.isPopular);
        }
    }

    loadUserTopics(sortInd) {
        this.setState({ loader: true });
        let searchValue = this.props.searchValue ? this.props.searchValue : '%%';
        
        fetch(api.partialURL + 'UserTopic/GetUserTopics?SORT_IND=' + sortInd + '&PAGE_NUM=' + this.state.currentPage
            + '&USER_ID=' + this.props.userEmail + '&SRCH_VAL=%' + searchValue + '%')
            .then(res => res.json())
            .then(result => {
                this.setState({ userTopics: [] });
                this.setState({ 
                    userTopics: result.userTopics, loader: false, pages: result.pages
                });
            })
            .catch(err => console.log(err));
    }

    viewTopicDetails = (topicId, topicPostType, topicTitle) => {
        const { history } = this.props;
        if (history) history.push({
            pathname: topicPostType === 'QUESTION' ? '/topics/question/comments/' + topicId + '/' + topicTitle.toLowerCase().replace(/ /g, '-')
                : '/topics/poll/comments/' + topicId + '/' + topicTitle.toLowerCase().replace(/ /g, '-')
        });
    }

    fetchMoreData = () => {
        if(this.state.pages - this.state.currentPage !== 0) {
            this.setState({ currentPage: this.state.currentPage + 1 });
            this.loadUserTopics(this.props.isPopular);
        }
    };

    saveUserQueLike = (topicId, postType, title, likeInd) => {
        if(postType === 'POLL') {
            this.viewTopicDetails(topicId, postType, title);
        } else {
            if(likeInd === 0 && this.props.userEmail && this.props.userAliasName) {
                this.setState({ loader: true });
                let rowData = {
                    TOPIC_ID: topicId,
                    TOPIC_UPDT_USER_ID: this.props.userEmail,
                    TOPIC_UPDT_USER_NM: this.props.userAliasName
                }

                axios({
                    method: 'post',
                    url: api.partialURL + 'UserQueTopic/SaveUserQueLike',
                    data: JSON.stringify(rowData),
                    headers: { 'Content-Type': 'application/json' },
                    mode: 'cors',
                })
                .then(res => {
                    if(res) {                
                        if (res.data === 'success') {
                            this.loadUserTopics(this.props.isPopular);
                        }
                    }
                })
                .catch(function (response) {
                    this.setState({ err_msg: response, loader: false });
                });
            }
        }
    }

    saveUserPollLike = (topicId, likeInd) => {
        if(likeInd === 0 && this.props.userEmail && this.props.userAliasName) {
            this.setState({ loader: true });
            let rowData = {
                TOPIC_ID: topicId,
                TOPIC_VOTE_USER_ID: this.props.userEmail,
                TOPIC_VOTE_USER_NM: this.props.userAliasName
            }

            axios({
                method: 'post',
                url: api.partialURL + 'UserPollTopic/SaveUserPollLike',
                data: JSON.stringify(rowData),
                headers: { 'Content-Type': 'application/json' },
                mode: 'cors',
            })
            .then(res => {
                if(res) {                
                    if (res.data === 'success') {
                        this.loadUserTopics(this.props.isPopular);
                    }
                }
            })
            .catch(function (response) {
                this.setState({ err_msg: response, loader: false });
            });
        }
    }

    render() {
        const { classes, mediaQuery } = this.props;
        const col9 = mediaQuery ? 9 : 12;
        const col3 = mediaQuery ? 3 : 12;
        const subHeader = classNames(classes.posTop, classes.subHeader);
        const wrapIcon = classNames(classes.wrapIcon, classes.subHeader);

        return (
            <Fragment>
                <Backdrop className={classes.backdrop} open={this.state.loader}>
                    <CircularProgress color="inherit" />
                </Backdrop>

                <Grid container spacing={1} style={{ marginTop: mediaQuery ? '45px' : '90px' }}>
                    <Grid item xs={col9}>
                            <InfiniteScroll style={{ overflow: 'hidden' }}
                                dataLength={this.state.userTopics.length}
                                next={this.fetchMoreData}
                                hasMore={this.state.pages - this.state.currentPage !== 0}
                            >
                                <Grid container spacing={1}>
                                { this.state.userTopics.map((topic, row) => (
                                    <Grid item xs={12} key={topic.TOPIC_ID}>
                                        <Card>
                                            <CardHeader style={{ cursor: 'pointer' }} classes={{ title: classes.title, subheader: classes.subTitle }}
                                                onClick={() => this.viewTopicDetails(topic.TOPIC_ID, topic.TOPIC_POST_TYPE, topic.TOPIC_TITLE)}
                                                title={topic.TOPIC_TITLE}
                                                action={
                                                <IconButton aria-label="questions">                                                
                                                    { topic.TOPIC_POST_TYPE === 'QUESTION' ?
                                                        <img src={QuestionIcon} height={20} alt="QuestionIcon" /> :
                                                        <img src={PollIcon} height={20} alt="PollIcon" />
                                                    }
                                                </IconButton>
                                                }
                                                subheader={ 'posted by ' + topic.TOPIC_UPDT_USER_NM + ' ' + topic.TOPIC_UPDT_DTM + ' ago' }
                                            />
                                            <CardContent>
                                                <div onClick={() => this.viewTopicDetails(topic.TOPIC_ID, topic.TOPIC_POST_TYPE, topic.TOPIC_TITLE)}
                                                    style={{ cursor: 'pointer' }}>
                                                    <Typography className={subHeader} gutterBottom color="textSecondary">                                                    
                                                        <div dangerouslySetInnerHTML={{ __html: topic.TOPIC_DESC }} />
                                                    </Typography>
                                                    { topic.TOPIC_POST_TYPE === 'QUESTION' && topic.TOPIC_IMG_URL &&
                                                        <Typography>
                                                            <img src={topic.TOPIC_IMG_URL} 
                                                                style={{width: '100%', padding: '10px 40px 10px 40px'}} />
                                                        </Typography>
                                                    }
                                                </div>
                                                <Typography style={{ marginTop: topic.TOPIC_POST_TYPE === 'POLL' ? '10px' : '0px' }}
                                                    className={wrapIcon} color="textSecondary">
                                                    
                                                    <IconButton onClick={() => this.saveUserQueLike(topic.TOPIC_ID, topic.TOPIC_POST_TYPE, topic.TOPIC_TITLE, topic.LIKE_IND)} 
                                                        style={{ padding: 0, fontSize: '0.8rem', marginLeft:'10px' }} aria-label="share" >
                                                        <img src={ topic.TOPIC_POST_TYPE === 'QUESTION' ? (topic.LIKE_IND === 1 ? LikeIconColor : LikeIcon) : 
                                                            (topic.VOTE_IND === 1 ? VoteIconColor : VoteIcon) } 
                                                            height={17} style={{ marginRight: '5px' }} /> 
                                                            {topic.TOPIC_LIKE_VOTE} {topic.TOPIC_POST_TYPE === 'QUESTION' ? 'Likes' : 'Votes'}
                                                    </IconButton>
                                                    <Divider orientation="vertical" flexItem className={classes.marginLeftRight} />
                                                    
                                                    { topic.TOPIC_POST_TYPE === 'POLL' &&
                                                        <IconButton onClick={() => this.saveUserPollLike(topic.TOPIC_ID, topic.LIKE_IND)} 
                                                            style={{ padding: 0, fontSize: '0.8rem', marginLeft:'10px' }} aria-label="share" >
                                                            <img src={ topic.LIKE_IND === 1 ? LikeIconColor : LikeIcon } height={17} style={{ marginRight: '5px' }} /> 
                                                                {topic.TOPIC_POLL_LIKE + ' Likes'}
                                                        </IconButton>
                                                    }
                                                    { topic.TOPIC_POST_TYPE === 'POLL' &&
                                                        <Divider orientation="vertical" flexItem className={classes.marginLeftRight} />
                                                    }

                                                    <img src={MessageIcon} height={17} style={{ marginRight: '5px' }} alt="MessageIcon" /> 
                                                    <HyvorTalk.CommentCount
                                                        websiteId={4842}
                                                        id={ topic.TOPIC_POST_TYPE === 'QUESTION' ? 'que'+topic.TOPIC_ID : 'poll'+topic.TOPIC_ID}
                                                    />
                                                    <Divider orientation="vertical" flexItem className={classes.marginLeftRight} />

                                                    <VisibilityIcon className={classes.iconSize} style={{ marginRight: '5px' }} /> {topic.TOPIC_VIEW}
                                                </Typography>
                                            </CardContent>
                                        </Card>
                                    </Grid>
                                ))}
                                </Grid>
                            </InfiniteScroll>
                    </Grid>
                    <Grid item xs={col3}>
                        <Grid container spacing={1}>
                            <Grid item xs={12}>
                                <Card>
                                    <CardContent>
                                        <Typography>
                                            <img src={Add1} alt="Logo" style={{ 
                                                width: '100%', marginBottom: '-8px' }} />
                                        </Typography>
                                    </CardContent>
                                </Card>
                            </Grid>
                            <Grid item xs={12}>
                                <Card>
                                    <CardContent>
                                        <Typography>
                                            <img src={Add2} alt="Logo" style={{ 
                                                width: '100%', marginBottom: '-8px' }} />
                                        </Typography>
                                    </CardContent>
                                </Card>
                            </Grid>
                        </Grid>
                    </Grid>
                </Grid>
            </Fragment>
        );
    }
}

export default withRouter(withStyles(useStyles)(withMediaQuery('(min-width:600px)')(Topics)))