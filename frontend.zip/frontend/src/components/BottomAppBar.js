import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import { Grid, ListItem, ListItemText } from '@material-ui/core';

const useStyles = makeStyles((theme) => ({
  text: {
    padding: theme.spacing(2, 2, 0),
  },
  paper: {
    paddingBottom: 50,
  },
  marginLeft: {
    marginLeft: theme.spacing(7),
    //marginTop: theme.spacing(1),
  },
  subheader: {
    backgroundColor: theme.palette.background.paper,
  },
  appBar: {
    top: 'auto',
    bottom: 0
  },
  grow: {
    flexGrow: 1,
  },
  footerBar: {
    backgroundColor: '#c2272d', 
    width: '100%', 
    position: 'absolute', 
    bottom: 0, 
    margin: 0, 
    height: '5rem'
  },
}));

export default function BottomAppBar() {
  const classes = useStyles();

  return (
    <React.Fragment>
      {/* <AppBar position="fixed" style={{ backgroundColor: '#c2272d' }} className={classes.appBar}> */}
        {/* <Toolbar className="bottom-app-bar" style={{ backgroundColor: '#c2272d' }}> */}
            <Grid container spacing={4} className={classes.footerBar}>
                <Grid item className={classes.marginLeft}>
                    <ListItem button>
                        <ListItemText className="drawerItems" primary='About' />
                    </ListItem>
                </Grid>
                <Grid item>
                    <ListItem button>
                        <ListItemText className="drawerItems" primary='Careers' />
                    </ListItem>
                </Grid>
                <Grid item>
                    <ListItem button>
                        <ListItemText className="drawerItems" primary='Terms' />
                    </ListItem>
                </Grid>
                <Grid item>
                    <ListItem button>
                        <ListItemText className="drawerItems" primary='Privacy' />
                    </ListItem>
                </Grid>
                <Grid item>
                    <ListItem button>
                        <ListItemText className="drawerItems" primary='Acceptable Use' />
                    </ListItem>
                </Grid>
                <Grid item>
                    <ListItem button>
                        <ListItemText className="drawerItems" primary='Businesses' />
                    </ListItem>
                </Grid>
                <Grid item>
                    <ListItem button>
                        <ListItemText className="drawerItems" primary='Your Ad Choices' />
                    </ListItem>
                </Grid>
            </Grid>
        {/* </Toolbar> */}
      {/* </AppBar> */}
    </React.Fragment>
  );
}
