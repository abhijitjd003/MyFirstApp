import React, { Component } from 'react';
import CloseIcon from '@material-ui/icons/Close';
import Popup from "reactjs-popup";
import { Button, TextField, Grid, withStyles, MenuItem, Select } from '@material-ui/core';
import './Modal.css';
import PropTypes from 'prop-types';
import DoneIcon from '@material-ui/icons/Done';
import api from '../common/APIValues';
import { useStyles } from '../common/useStyles';

// const useStyles = theme => ({
//     leftIcon: {
//         marginRight: theme.spacing.unit,
//     },
//     root: {
//         fontSize: 12, height: '2.1rem',
//         backgroundColor: "#0079c2",
//         "&:hover": {
//             backgroundColor: "#0079c2"
//         },
//         "&:disabled": {
//             backgroundColor: "rgba(0, 0, 0, 0.12)"
//         },
//     },
// });

const validateForm = (errors) => {
    let valid = true;
    Object.keys(errors).map(function (e) {
        if (errors[e].length > 0) {
            valid = false;
        }        
    });
    return valid;
}

class SalesOfficerModal extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            open: false, salesOfficers: [], salesOfficer: 'Choose Sales Officer',
            errors: {
                salesOfficer: '',
            }
        };
        this.openModal = this.openModal.bind(this);
        this.closeModal = this.closeModal.bind(this);
        this.popupOnClose = this.popupOnClose.bind(this);
        this.onChanged = this.onChanged.bind(this);
    }

    openModal() {        
        this.setState({ open: true });
    }

    closeModal() {
        let errors = this.state.errors;
        errors.salesOfficer = '';
        this.setState({ open: false, salesOfficer: 'Choose Sales Officer', errors });
    }
    popupOnClose() { }

    assignSalesOfficer = () => {
        if (validateForm(this.state.errors) && this.state.salesOfficer !== 'Choose Sales Officer') {
            if (typeof this.props.onClick === 'function') {
                this.props.onClick(this.state.salesOfficer);
                this.closeModal();
            }
        } else {
            let errors = this.state.errors;
            if (this.state.salesOfficer === 'Choose Sales Officer') {
                errors.salesOfficer = 'Select sales officer';
            }
            this.setState({ errors, errorMessage: null });
        }
    }

    loadSalesOfficers(){
        let partialUrl = api.URL;
        fetch(partialUrl + 'Customer/GetSalesOfficers')
            .then(res => res.json())
            .then(result => this.setState({ salesOfficers: result, }))
            .catch(err => console.log(err));
    }

    componentDidMount() {        
        this.loadSalesOfficers();        
    }

    onChanged(e) {
        let salesOfficer = e.target.value;
        let errors = this.state.errors;
        if(salesOfficer === 'Choose Sales Officer'){
            errors.salesOfficer = 'Select sales officer';
        }else{
            errors.salesOfficer = '';
        }        
        this.setState({ salesOfficer: salesOfficer, errors });
    };

    render() {
        const { classes } = this.props;
        let _salesOfficers = this.state.salesOfficers;
        let salesOfficers = _salesOfficers.map((route) =>
                <MenuItem value={route.FullName}>{route.FullName}</MenuItem>
            );

        return (
            <div>
                <Popup contentStyle={{ width: "500px", height: "220px", borderRadius: "5px" }} open={this.state.open}
                    className="popup-modal-container-box" modal onOpen={e => this.popupOnClose(e)}
                    onClose={this.popupOnClose} lockScroll={true} closeOnDocumentClick={false}>
                    <div className="modal-custom">
                        <div className="header">Assign Sales Officer</div>
                        <div className="content-reject">
                            <Grid container spacing={0}>                                                                                            
                                <Grid item xs={12}>
                                    <Select fullWidth id="ddSalesOfficer" value={this.state.salesOfficer} onChange={ this.onChanged }
                                        className="selectTopMargin">
                                        {salesOfficers}
                                    </Select>
                                    {this.state.errors.salesOfficer.length > 0 &&
                                        <span className='error'>{this.state.errors.salesOfficer}</span>}
                                </Grid>                                
                            </Grid>
                        </div>
                        <Grid className="actions" container spacing={1}>
                            <Grid item xs={6}>                                
                            </Grid>
                            <Grid item xs={3}>
                                <Button className={classes.rootModal} color="primary" variant="contained" 
                                    onClick={() => this.assignSalesOfficer()}>
                                    <DoneIcon className={classes.leftIcon} />Assign</Button>
                            </Grid>
                            <Grid item xs={3}>
                                <Button className={classes.rootModal} color="primary" variant="contained" onClick={this.closeModal}>
                                    <CloseIcon className={classes.leftIcon} />Close</Button>
                            </Grid>
                        </Grid>
                    </div>
                </Popup>
            </div>
        );
    }
}

SalesOfficerModal.propTypes = {
    onClick: PropTypes.func
};

export default withStyles(useStyles)(SalesOfficerModal)