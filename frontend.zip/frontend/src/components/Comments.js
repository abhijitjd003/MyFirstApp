import React, { Component } from 'react'
import HyvorTalk from 'hyvor-talk-react'

export default class Comments extends Component {
  render () {
    return (
      <div style={{ marginTop: 80 }}>
        <div className="comment-count-view">

          { /* Comment Counts */ }
          <HyvorTalk.CommentCount 
            websiteId={4842}
            id={false}
          />

        </div>

        { /* Load Comments now */ }
        <HyvorTalk.Embed 
          websiteId={4842}
          id={false}
        />
      </div>
    )
  }
}