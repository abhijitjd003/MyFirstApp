import React, { Component, Fragment } from 'react';
import {
    AppBar, withStyles, Toolbar, CssBaseline, Grid, useMediaQuery, InputBase, Typography, Tooltip, Avatar, Badge, IconButton,
    Breadcrumbs, Button, Link, MenuItem, Menu,
} from '@material-ui/core';
import { withRouter } from 'react-router-dom';
import './common/Common.css'
import EDWhatLogo from './images/logo.png';
import EDWhatLogoIcon from './images/EdWhat-01-01.png';
import SearchIcon from '@material-ui/icons/Search';
import NotificationsIcon from '@material-ui/icons/Notifications';
import AddQuestionIcon from './images/Add-a-Question.png';
import NavigateNextIcon from '@material-ui/icons/NavigateNext';
import MenuIcon from './images/menu_icon.png';
import classNames from 'classnames';
import MoreIcon from '@material-ui/icons/MoreVert';

const drawerWidth = 240;

const useStyles = theme => ({
    root: {
        display: 'flex',
    },
    appBar: {
        zIndex: theme.zIndex.drawer + 1,
        transition: theme.transitions.create(['width', 'margin'], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen,
        }),
        backgroundColor: 'white',
    },
    appBarShift: {
        marginLeft: drawerWidth,
        width: `calc(100% - ${drawerWidth}px)`,
        transition: theme.transitions.create(['width', 'margin'], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.enteringScreen,
        }),
    },
    menuButton: {
        marginRight: 36,
    },
    hide: {
        display: 'none',
    },
    toolbar: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'flex-end',
        padding: theme.spacing(0, 1),
        ...theme.mixins.toolbar,
        marginTop: 50,
    },
    content: {
        flexGrow: 1,
        padding: theme.spacing(3),
    },
    alignment: {
        flexGrow: 1,
    },
    leftIcon: {
        marginRight: theme.spacing.unit,
    },
    iconColor: {
        color: 'white'
    },
    textColor: {
        color: 'white'
    },
    btnText: {
        fontSize: 12, color: 'white'
    },
    search: {
        position: 'relative',
        marginLeft: '0px',
        width: '100%',
        [theme.breakpoints.up('sm')]: {
          marginLeft: theme.spacing(5),
          width: 'auto',
        },
      },
      searchIcon: {
        padding: theme.spacing(0, 2),
        height: '100%',
        position: 'absolute',
        pointerEvents: 'none',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#c2272d',
        borderRadius: '17px 0px 0px 17px',
      },
      inputRoot: {
        color: 'inherit',
      },
    inputInput: {
        padding: theme.spacing(1, 1, 1, 0),
        paddingLeft: `calc(1em + ${theme.spacing(7)}px)`,
        transition: theme.transitions.create('width'),
        color: '#292929',
        border: '1px solid #d9d9d9',
        borderRadius: '15px',
        width: '100%',
        height: '25px',
        [theme.breakpoints.up('md')]: {
          width: '100%',
        }
    },
    iconColor: {
        color: '#333233',
        fontSize: '2.4rem',        
    },
    customButtonError: {
        borderRadius: '8px',
        color: '#c2272d',
        backgroundColor: "#f9f9f9",
        "&:hover": {
            backgroundColor: "#f9f9f9"
        },
        "&:disabled": {
            backgroundColor: "rgba(0, 0, 0, 0.12)"
        },
    },
    buttonSpacing: {
        margin: theme.spacing(1),
    },
    customButtonInfo: {
        borderRadius: '8px',
        color: '#0000008A',
        backgroundColor: "#f9f9f9",
        "&:hover": {
            backgroundColor: "#f9f9f9"
        },
        "&:disabled": {
            backgroundColor: "rgba(0, 0, 0, 0.12)"
        },
    },
    customButtonFocus: {
        borderRadius: '8px',
        color: 'white',
        backgroundColor: "#c2272d",
        "&:hover": {
            backgroundColor: "#c2272d"
        },
        "&:disabled": {
            backgroundColor: "rgba(0, 0, 0, 0.12)"
        },
    },
});

const StyledBadge = withStyles((theme) => ({
    badge: {
      right: 6,
      top: 12,      
      padding: '0 4px',
    },
}))(Badge);

const withMediaQuery = (...args) => Component => props => {
    const mediaQuery = useMediaQuery(...args);    
    return <Component mediaQuery={mediaQuery} {...props} />;
  };

class NavMenu extends Component {
    static displayName = NavMenu.name;
    constructor(props) {
        super(props);
        this.state = { 
            open: true, currentStatus: '', openProducts: false, openVendors: false, openStocks: false, openCustomers: false,
            openOrders: false, openPayments: false, openConfigurations: false, openReports: false,
            inputBase: 'initial value',
        };
    }

    navigateToHome = () => {
        const { history } = this.props;
        if (history) history.push({ pathname: '/topics' });
    }

    navigateToHomePage = () => {
        const { history } = this.props;        
        if (history) history.push({
            pathname: '/topics'
        });
    }

    navigateToDetailPage = () => {
        const { history } = this.props;
        if (history) history.push({
            pathname: this.props.prev_page
        });
    }

    notifications = () => {
        const { history } = this.props;
        if (history) history.push({
            pathname: '/notifications'
        });
    }

    render() {
        const { classes, mediaQuery } = this.props;        
        const pathName = this.props.location.pathname;
        const buttonSpacing = classNames(this.props.isPopular ? classes.customButtonFocus : classes.customButtonError, 
            classes.buttonSpacing);
        const col10 = mediaQuery ? 11 : 10;
        
        return (
            <div className={classes.root}>
                <CssBaseline />
                <AppBar position="fixed" className={classes.appBar} style={{ boxShadow: '0px 0px 0px 0px' }}>
                    <Toolbar className="header-color" style={{ marginLeft:!mediaQuery ? 0 : null, marginRight:!mediaQuery ? 0 : null }}>
                        { mediaQuery ?
                            <Typography className={classes.alignment} style={{ marginLeft: 5 }}>
                                <img onClick={this.navigateToHome} style={{ cursor: 'pointer'}} src={EDWhatLogo} height={50} alt="Logo" />
                            </Typography> :
                            <Typography className={classes.alignment}>
                                <img onClick={this.navigateToHome} style={{ cursor: 'pointer'}} src={EDWhatLogoIcon} height={50} alt="Logo" />
                            </Typography>
                        }
                        <Grid container spacing={0} style={{ marginLeft: !mediaQuery ? 10 : 0 }}>
                            <Grid item xs={col10}>
                                <div className={classes.search}>
                                    <div className={classes.searchIcon}>
                                        <SearchIcon />
                                    </div>
                                    <InputBase onChange={this.props.searchTopics} fullWidth
                                        placeholder="search with keywords or #tags"
                                        style={{ position: 'initial' }}
                                        classes={{
                                            root: classes.inputRoot,
                                            input: classes.inputInput,
                                        }}
                                        inputProps={{ 'aria-label': 'search' }}
                                        endAdornment={<SearchIcon />}
                                    />
                                </div>
                            </Grid>
                            { mediaQuery ?
                                (<Fragment>
                                    <Typography className={classes.alignment}>
                                        <StyledBadge badgeContent={4} color="error" onClick={this.notifications}>
                                            <NotificationsIcon className={classes.iconColor} />
                                        </StyledBadge>
                                    </Typography>                            
                                    <Tooltip title={this.props.userAliasName ? this.props.userAliasName : '' }>
                                        <Avatar style={{ cursor: 'pointer', backgroundColor: '#a19b9b' }} onClick={this.props.userLogin}
                                            src="/static/images/avatar/1.jpg" />
                                    </Tooltip>
                                </Fragment>) :
                                (<Fragment>
                                    <IconButton
                                        aria-label="show more"                                        
                                        aria-haspopup="true"
                                        onClick={this.props.handleMobileMenuOpen}
                                        className={classes.activeColor}
                                    >
                                        <MoreIcon />
                                    </IconButton>
                                    <Menu
                                        id="simple-menu"
                                        anchorEl={this.props.anchorEl}
                                        keepMounted
                                        open={Boolean(this.props.anchorEl)}
                                        onClose={this.props.handleMobileMenuClose}
                                    >
                                        <MenuItem onClick={this.props.userLogin} >
                                            <StyledBadge badgeContent={4} color="error">
                                                <NotificationsIcon className={classes.iconColor} />
                                            </StyledBadge>
                                            &nbsp;&nbsp;Notifications
                                        </MenuItem>                                        
                                        <MenuItem onClick={this.props.addQuestion} >
                                            <img src={AddQuestionIcon} style={{marginLeft:8}} className={classes.leftIcon} alt="QuestionIcon" />
                                            &nbsp;&nbsp;Add a Question
                                        </MenuItem>
                                        <MenuItem onClick={this.props.userLogin} >
                                            <Avatar style={{ cursor: 'pointer', backgroundColor: '#a19b9b' }} 
                                            src="/static/images/avatar/1.jpg" />
                                            &nbsp;&nbsp;My Profile
                                        </MenuItem>
                                    </Menu>
                                </Fragment>)
                            }
                        </Grid>
                    </Toolbar>
                </AppBar>
                
                    <AppBar position="fixed" className={classes.appBar} 
                        style={{ boxShadow: '0px 0px 0px 0px', marginTop: '80px', borderTop: '1px solid #0000001F', zIndex: 1024 }}>
                        <Toolbar className={mediaQuery ? "topic-header-color" : "topic-header-color-mobileView"}>
                            { (pathName === '/topics' || pathName === '/') ?
                            (
                                <Typography variant="h6" className={classes.alignment}>
                                    <IconButton aria-label="menu-icon">                                
                                        <img src={MenuIcon} alt="MenuIcon" />
                                    </IconButton>
                                    <Button variant="contained" color="primary" className={buttonSpacing}
                                        onClick={this.props.sortByPopular}>Popular
                                    </Button>
                                    <Button variant="contained" className={!this.props.isPopular ? classes.customButtonFocus : classes.customButtonInfo}
                                        onClick={this.props.sortByNew}>New
                                    </Button>
                                </Typography>
                            ) : (
                            <Typography className={classes.alignment} style={{ marginLeft: 10 }}>
                                <Breadcrumbs separator={<NavigateNextIcon fontSize="small" />} aria-label="breadcrumb">
                                    <Link onClick={this.navigateToHomePage} style={{ textDecoration: 'none', cursor: 'pointer' }} color="inherit">
                                        Home
                                    </Link>
                                    {/* { (this.props.prev_page === '/QuestionDetails' || this.props.prev_page === '/PollDetails') &&
                                        <Link onClick={this.navigateToDetailPage} style={{ textDecoration: 'none', cursor: 'pointer' }} color="inherit">
                                            { this.props.prev_page === '/QuestionDetails' ? 'Question Details' : 'Poll Details'}
                                        </Link>
                                    } */}
                                    <Typography color="textPrimary">
                                        { 
                                            pathName.indexOf('/topics/question/comments/') > -1 ? 'Question Details' : 
                                            pathName.indexOf('/topics/poll/comments/') > -1 ? 'Poll Details' :
                                            pathName === '/myprofile' ? 'My Profile' :
                                            pathName === '/topics/askEDWhat' ? 'Ask EDWhat' : null 
                                        }
                                    </Typography>
                                </Breadcrumbs>
                            </Typography>)}
                            { pathName !== '/AddQuestion' && mediaQuery &&
                                <Fragment>
                                    <Button variant="contained" color="secondary" className={classes.customButtonError} 
                                        onClick={this.props.addQuestion}>                                
                                        <img src={AddQuestionIcon} height={20} className={classes.leftIcon} alt="QuestionIcon" />
                                            Add a Question
                                    </Button>
                                </Fragment>
                            }
                        </Toolbar>
                    </AppBar>
            </div>
        );
    }
}

export default withRouter(withStyles(useStyles)(withMediaQuery('(min-width:600px)')(NavMenu)))