import React, { Component } from 'react';
import clsx from 'clsx';
import {
    Button, AppBar, withStyles, Toolbar, List, CssBaseline, Typography, IconButton,
    ListItem, ListItemText, Drawer,
} from '@material-ui/core';
import { withRouter } from 'react-router-dom';
import MenuIcon from '@material-ui/icons/Menu';
import AccountCircle from '@material-ui/icons/AccountCircleOutlined';
import PowerSettingsNewIcon from '@material-ui/icons/PowerSettingsNew';
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import './common/Common.css'
import PersonAddIcon from '@material-ui/icons/PersonAdd';
import DashboardIcon from '@material-ui/icons/Dashboard';

const drawerWidth = 210;

const useStyles = theme => ({
    root: {
        display: 'flex',
    },
    appBar: {
        zIndex: theme.zIndex.drawer + 1,
        transition: theme.transitions.create(['width', 'margin'], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen,
        }),
        backgroundColor: 'white',
    },
    appBarShift: {
        marginLeft: drawerWidth,
        width: `calc(100% - ${drawerWidth}px)`,
        transition: theme.transitions.create(['width', 'margin'], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.enteringScreen,
        }),
    },
    menuButton: {
        marginRight: 36,
    },
    hide: {
        display: 'none',
    },
    drawer: {
        width: drawerWidth,
        flexShrink: 0,
        whiteSpace: 'nowrap',
    },
    drawerOpen: {
        width: drawerWidth,
        transition: theme.transitions.create('width', {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.enteringScreen,
        }),
        backgroundColor: '#0079c2',
    },
    drawerClose: {
        transition: theme.transitions.create('width', {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen,
        }),
        overflowX: 'hidden',
        width: theme.spacing(7) + 1,
        [theme.breakpoints.up('sm')]: {
            width: theme.spacing(8) + 0,
        },
        backgroundColor: '#0079c2',
    },
    toolbar: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'flex-end',
        padding: theme.spacing(0, 1),
        ...theme.mixins.toolbar,
    },
    content: {
        flexGrow: 1,
        padding: theme.spacing(3),
    },
    alignment: {
        flexGrow: 1,
    },
    leftIcon: {
        marginRight: theme.spacing.unit,
    },
    drawerMenu: {
        textAlign: 'center',
        width: 89,
    },
    iconColor: {
        color: '#0079c2'
    },
    textColor: {
        color: '#969799'
    },
    btnText: {
        fontSize: 12, color: '#0079c2'
    }
});

class NavMenu extends Component {
    static displayName = NavMenu.name;
    constructor(props) {
        super(props);
        this.state = { open: false, currentStatus: '' };
    }

    handleDrawerOpen = () => {
        this.setState({ open: true })
    };

    handleDrawerClose = () => {
        this.setState({ open: false })
    };

    logOut = (event) => {
        event.preventDefault();
        const { history } = this.props;
        if (history) history.push('/Home');
    }

    redirectToDashboard = (event) => {
        event.preventDefault();
        const { history } = this.props;
        if (history) history.push('/Dashboard');
    }

    redirectToMyProfile = (event) => {
        event.preventDefault();
        const { history } = this.props;
        if (history) history.push('/MyProfile');
    }

    render() {
        const { classes } = this.props;

        return (
            <div className={classes.root}>
                <CssBaseline />
                <AppBar position="fixed" className={classes.appBar}>
                    <Toolbar>
                        <Typography variant="h6" className={classes.alignment}>
                            <span className="header-font">Data Validation</span>
                        </Typography>
                        <div>
                            <IconButton aria-label="account of current user" aria-controls="menu-appbar"
                                aria-haspopup="true" onClick={this.handleMenu} color="inherit">
                                <AccountCircle className={classes.iconColor} />
                            </IconButton>

                            <span className={classes.textColor}>{ sessionStorage.getItem('userEmail') ? sessionStorage.getItem('userEmail') : ''}</span>
                            <Button color="primary" className={classes.btnText} onClick={this.logOut}>
                                <PowerSettingsNewIcon className={classes.leftIcon} />
                                Logout
                            </Button>
                        </div>
                    </Toolbar>
                </AppBar>

                <Drawer
                    variant="permanent"
                    className={clsx(classes.drawer, {
                        [classes.drawerOpen]: this.state.open,
                        [classes.drawerClose]: !this.state.open,
                    })}
                    classes={{
                        paper: clsx({
                            [classes.drawerOpen]: this.state.open,
                            [classes.drawerClose]: !this.state.open,
                        }),
                    }}
                >
                    <div className={classes.toolbar}>
                    </div>
                    <div className={classes.toolbar}>
                        {this.state.open ?
                            <IconButton onClick={this.handleDrawerClose}>
                                < ChevronLeftIcon className="drawerItems" />
                            </IconButton> : <IconButton onClick={this.handleDrawerOpen}>
                                < MenuIcon className="drawerItems" />
                            </IconButton>}
                    </div>
                    <List style={{ marginLeft: 5 }}>
                        <ListItem button onClick={this.redirectToMyProfile}>
                            <PersonAddIcon className="drawerItems" />
                            <ListItemText className="drawerItemsText" primary='My Profile' />
                        </ListItem>
                        { sessionStorage.getItem('isAdminUser') === 'Y' &&
                            <ListItem button onClick={this.redirectToDashboard}>
                                <DashboardIcon className="drawerItems" />
                                <ListItemText className="drawerItemsText" primary='Dashboard' />
                            </ListItem>
                        }             
                    </List>
                </Drawer>
            </div>
        );
    }
}

export default withRouter(withStyles(useStyles)(NavMenu))