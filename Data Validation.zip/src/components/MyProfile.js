import React, { Component } from 'react';
import './common/Common.css';
import { Button, TextField, Grid, withStyles, Select, MenuItem } from '@material-ui/core';
import './common/CommonModal.css';
import { withRouter } from 'react-router-dom';
import Loader from './loader/Loader';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import ErrorModal from './modal/ErrorModal';
import 'date-fns';
import DateFnsUtils from '@date-io/date-fns';
import { MuiPickersUtilsProvider, KeyboardDatePicker, } from '@material-ui/pickers';
import InputAdornment from '@material-ui/core/InputAdornment';
import AccountCircle from '@material-ui/icons/AccountCircle';

const useStyles = theme => ({
    topMargin: {
        marginTop: 16,
    },
});

const validateForm = (errors) => {
    let valid = true;
    Object.keys(errors).map(function (e) {
        if (errors[e].length > 0) {
            valid = false;
        }        
    });
    return valid;
}

class MyProfile extends Component {
    constructor(props) {
        super(props);
        this.state = {
            title: '0', medCouncilNo: null, mobileNo: null, email: null, fullName: null, membershipId: null, gender: '0',
            specialityType: null, DOB: null, address: null, pinCode: null, city: null, state: null, residenceTelNo: null,
            officeTelNo: null, alternateMobileNo: null, nationality: null, DOJ: null, profileId: 0,
            errorMessage: null, loading: false, rowData: {},
            errors: {
                medCouncilNo: '',
                mobileNo: '',
                email: '',
                title: '',
                fullName: '',
                membershipId: '',
                gender: '',
                specialityType: '',
                address: '',
                pinCode: '', 
                city: '', 
                state: '',
                residenceTelNo: '',
                officeTelNo: '', 
                alternateMobileNo: '',
                nationality: '',
                DOJ: '',
                DOB: '',
            },            
        };

        this.onTitleChanged = this.onTitleChanged.bind(this);
        this.onGenderChanged = this.onGenderChanged.bind(this);
    }

    validateAllInputs(){
        if(this.state.medCouncilNo && this.state.mobileNo && this.state.email && this.state.title !== '0' && this.state.fullName &&
            this.state.membershipId && this.state.gender !== '0' && this.state.city && this.state.state && this.state.nationality &&
            this.state.address && this.state.pinCode && this.state.DOB && this.state.residenceTelNo && this.state.officeTelNo &&
            this.state.specialityType && this.state.DOJ && this.state.DOJ){
                return true;
        }
        else{
            return false;
        }
    }

    save = (event) => {
        event.preventDefault();
        if (validateForm(this.state.errors) && this.validateAllInputs()) {
            this.setState({ loading: true });
            let myProfile = {};
            myProfile.ProfileId = this.state.profileId;
            myProfile.MobileNo = this.state.mobileNo;
            myProfile.Email = this.state.email;
            myProfile.MedCouncilNo = this.state.medCouncilNo;
            myProfile.Title = this.state.title;
            myProfile.FullName = this.state.fullName;
            myProfile.MembershipId = this.state.membershipId;
            myProfile.Gender = this.state.gender;
            myProfile.DOB = this.state.DOB.toLocaleString();
            myProfile.Speciality = this.state.specialityType;
            myProfile.Address = this.state.address;
            myProfile.PinCode = this.state.pinCode;
            myProfile.City = this.state.city;
            myProfile.State = this.state.state;
            myProfile.Nationality = this.state.nationality;
            myProfile.ResidenceTelNo = this.state.residenceTelNo;
            myProfile.OfficeTelNo = this.state.officeTelNo;
            myProfile.AlternateMobileNo = this.state.alternateMobileNo;
            myProfile.DOJ = this.state.DOJ.toLocaleString();
            this.saveProfile(myProfile);
        } else {
            let errors = this.state.errors;
            if (!this.state.medCouncilNo) {
                errors.medCouncilNo = 'Medical council number is required';
            }
            if (!this.state.mobileNo) {
                errors.mobileNo = 'Mobile number is required';
            }
            if (!this.state.email) {
                errors.email = 'Email address is required';
            }
            if (this.state.title === '0') {
                errors.title = 'Select title';
            }
            if (this.state.gender === '0') {
                errors.gender = 'Select gender';
            }
            if (!this.state.fullName) {
                errors.fullName = 'Full name is required';
            }
            if (!this.state.membershipId) {
                errors.membershipId = 'Membership ID is required';
            }
            if (!this.state.DOB) {
                errors.DOB = 'Date of birth is required';
            }
            if (!this.state.DOJ) {
                errors.DOJ = 'Date of join is required';
            }
            if (!this.state.specialityType) {
                errors.specialityType = 'Specialty type is required';
            }
            if (!this.state.address) {
                errors.address = 'Address is required';
            }
            if (!this.state.pinCode) {
                errors.pinCode = 'PinCode is required';
            }
            if (!this.state.city) {
                errors.city = 'City is required';
            }
            if (!this.state.state) {
                errors.state = 'State is required';
            }
            if (!this.state.nationality) {
                errors.nationality = 'Nationality is required';
            }
            if (!this.state.residenceTelNo) {
                errors.residenceTelNo = 'Residence telephone number is required';
            }
            if (!this.state.officeTelNo) {
                errors.officeTelNo = 'Office telephone number is required';
            }
            if (!this.state.alternateMobileNo) {
                errors.alternateMobileNo = 'Alternate mobile number is required';
            }
            this.setState({ errors, errorMessage: null });
        }
    }

    loadProfile(userMobileNo, userEmail){
        fetch('http://localhost:55002/api/DataValidation/MyProfile/GetProfile?MobileNo=' + userMobileNo + '&Email=' + userEmail)
            .then(res => res.json())
            .then(result => { 
                this.setState({ 
                    profileId: result.ProfileId,            
                    medCouncilNo: result.MedCouncilNo,
                    title: result.Title ? result.Title : '0',
                    fullName: result.FullName,
                    membershipId: result.MembershipId,
                    gender: result.Gender ? result.Gender : '0',
                    DOB: result.DOB.includes('0001') ? null : result.DOB,
                    specialityType: result.Speciality,
                    address: result.Address,
                    pinCode: result.PinCode === 0 ? null : result.PinCode,
                    city: result.City,
                    state: result.State,
                    nationality: result.Nationality,
                    residenceTelNo: result.ResidenceTelNo === 0 ? null : result.ResidenceTelNo,
                    officeTelNo: result.OfficeTelNo === 0 ? null : result.OfficeTelNo,
                    alternateMobileNo: result.AlternateMobileNo === 0 ? null : result.AlternateMobileNo,
                    DOJ: result.DOJ.includes('0001') ? null : result.DOJ
            })
            console.log('test');
        })
            .catch(err => console.log(err));
    }

    componentDidMount() {
        let userMobileNo = sessionStorage.getItem('userMobileNo');
        let userEmail = sessionStorage.getItem('userEmail');
        this.setState({ 
            mobileNo: userMobileNo,
            email: userEmail
        });
        this.loadProfile(userMobileNo, userEmail);
    }

    onTitleChanged(e) {
        let title = e.target.value; 
        this.setState({ title: title });
        if(title === '0'){
            this.state.errors.title = 'Select title';
        }else{
            this.state.errors.title = '';
        }
    };
    
    onGenderChanged(e) {
        let gender = e.target.value; 
        this.setState({ gender: gender });
        if(gender === '0'){
            this.state.errors.gender = 'Select gender';
        }else{
            this.state.errors.gender = '';
        }
    };

    onDOBChanged = (date) => { this.setState({ DOB: date }); };
    onDOJChanged = (date) => { this.setState({ DOJ: date }); };

    showConfirmPopup = row => {
        this.setState({ productId: row.ProductId })
        this.refs.cnfrmModalComp.openModal();
    }

    saveProfile(myProfile) {
        fetch('http://localhost:55002/api/DataValidation/MyProfile/SaveProfile', {
            method: 'POST',
            mode: 'cors',
            body: JSON.stringify(myProfile),
            headers: { 'Content-Type': 'application/json' }
        }).then((response) => response.json())
            .then((responseJson) => {
                if (responseJson) {
                    let userMobileNo = sessionStorage.getItem('userMobileNo');
                    let userEmail = sessionStorage.getItem('userEmail');
                    this.setState({ loading: false });
                    this.loadProfile(userMobileNo, userEmail);
                    var successMsg = 'Profile saved successfully.';
                    this.refs.errModalComp.openModal(successMsg);                    
                }
            })
    }

    handleChange = (event) => {
        event.preventDefault();
        const { name, value } = event.target;
        let errors = this.state.errors;

        switch (name) {
            case 'medCouncilNo':
                this.state.medCouncilNo = value;
                errors.medCouncilNo = value.length <= 0 ? 'Medical council number is required' : '';
                break;
            case 'mobileNo':
                this.state.mobileNo = value;
                errors.mobileNo = value.length <= 0 ? 'Mobile number is required' : '';
                break;
            case 'email':
                this.state.email = value;
                errors.email = value.length <= 0 ? 'Email address is required' : '';
                break;
            case 'fullName':
                this.state.fullName = value;
                errors.fullName = value.length <= 0 ? 'Full name is required' : '';
                break;
            case 'membershipId':
                this.state.membershipId = value;
                errors.membershipId = value.length <= 0 ? 'Membership ID is required' : '';
                break;
            case 'specialityType':
                this.state.specialityType = value;
                errors.specialityType = value.length <= 0 ? 'Speciality type is required' : '';
                break;
            case 'address':
                this.state.address = value;
                errors.address = value.length <= 0 ? 'Address is required' : '';
                break;
            case 'pinCode':
                this.state.pinCode = value;
                errors.pinCode = value.length <= 0 ? 'PinCode is required' : '';
                break;
            case 'city':
                this.state.city = value;
                errors.city = value.length <= 0 ? 'City is required' : '';
                break;
            case 'state':
                this.state.state = value;
                errors.state = value.length <= 0 ? 'State is required' : '';
                break;
            case 'nationality':
                this.state.nationality = value;
                errors.nationality = value.length <= 0 ? 'Nationality is required' : '';
                break;
            case 'residenceTelNo':
                this.state.residenceTelNo = value;
                errors.residenceTelNo = value.length <= 0 ? 'Residence telephone number is required' : '';
                break;
            case 'officeTelNo':
                this.state.officeTelNo = value;
                errors.officeTelNo = value.length <= 0 ? 'Office telephone number is required' : '';
                break;
            case 'alternateMobileNo':
                this.state.alternateMobileNo = value;
                errors.alternateMobileNo = value.length <= 0 ? 'Alternate mobile number is required' : '';
                break;
            default:
                break;
        }
        this.setState({ errors, [name]: value });
    }

    render() {
        const { classes } = this.props;
        
        return (
            <div>
                {this.state.loading ? (
                    <Loader />
                ) : (
                    <div>
                        <ErrorModal ref="errModalComp" />

                        <form onSubmit={this.loginToDashboard} noValidate>
                            <h2 style={{ color: '#ff9800' }}>My Profile</h2>
                            <Grid container spacing={3}>                                                            
                                <Grid item xs={3}>
                                    <TextField fullWidth required="true" name="mobileNo" id="txtMobileNo" label="Mobile Number"
                                        onChange={this.handleChange} noValidate value={this.state.mobileNo} disabled />
                                    {this.state.errors.mobileNo.length > 0 &&
                                        <span className='error'>{this.state.errors.mobileNo}</span>}
                                </Grid>                            
                                <Grid item xs={3}>
                                    <TextField fullWidth required="true" name="email" id="txtEmail" label="Email Address"
                                        onChange={this.handleChange} noValidate value={this.state.email} disabled />
                                    {this.state.errors.email.length > 0 &&
                                        <span className='error'>{this.state.errors.email}</span>}
                                </Grid>
                                <Grid item xs={3}>                                
                                    <TextField fullWidth required="true" name="medCouncilNo" id="txtMedCouncilNo" label="Medical Council Number"
                                        onChange={this.handleChange} noValidate value={this.state.medCouncilNo} 
                                        InputProps={{
                                            startAdornment: (
                                              <InputAdornment position="start">
                                                <AccountCircle />
                                              </InputAdornment>
                                            ),
                                          }}/>
                                    {this.state.errors.medCouncilNo.length > 0 &&
                                        <span className='error'>{this.state.errors.medCouncilNo}</span>}
                                </Grid>                            
                            </Grid>
                            <Grid container spacing={3}>
                                <Grid item xs={2}>                                
                                    <Select fullWidth id="ddlTitle" value={this.state.title} className="selectTopMargin"
                                        onChange={ this.onTitleChanged }>
                                        <MenuItem value="0">Choose Title</MenuItem>
                                        <MenuItem value="Dr.">Dr.</MenuItem>
                                        <MenuItem value="Mr.">Mr.</MenuItem>
                                        <MenuItem value="Mrs.">Mrs.</MenuItem>
                                        <MenuItem value="Prof.">Prof.</MenuItem>
                                    </Select>
                                    {this.state.errors.title.length > 0 &&
                                        <span className='error'>{this.state.errors.title}</span>}
                                </Grid>
                                <Grid item xs={4}>
                                    <TextField fullWidth required="true" name="fullName" id="txtFullName" label="Full Name"
                                        onChange={this.handleChange} noValidate value={this.state.fullName} />
                                    {this.state.errors.fullName.length > 0 &&
                                        <span className='error'>{this.state.errors.fullName}</span>}
                                </Grid>                            
                                <Grid item xs={3}>
                                    <TextField fullWidth required="true" name="membershipId" id="txtMembershipId" label="Membership Id"
                                        onChange={this.handleChange} noValidate value={this.state.membershipId} />
                                    {this.state.errors.membershipId.length > 0 &&
                                        <span className='error'>{this.state.errors.membershipId}</span>}
                                </Grid>                   
                            </Grid>
                            <Grid container spacing={3}>
                                <Grid item xs={3}>                                
                                    <Select fullWidth id="ddlGender" value={this.state.gender} className="selectTopMargin"
                                        onChange={ this.onGenderChanged }>
                                        <MenuItem value="0">Choose Gender</MenuItem>
                                        <MenuItem value="Male">Male</MenuItem>
                                        <MenuItem value="Female">Female</MenuItem>
                                        <MenuItem value="Others">Others</MenuItem>
                                    </Select>
                                    {this.state.errors.gender.length > 0 &&
                                        <span className='error'>{this.state.errors.gender}</span>}
                                </Grid>                            
                                <Grid item xs={3}>
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <KeyboardDatePicker fullWidth format="dd/MM/yyyy"
                                            id="dateDOB" label="Date of Birth"
                                            value={this.state.DOB}
                                            onChange={this.onDOBChanged}
                                            KeyboardButtonProps={{
                                                'aria-label': 'change date',
                                            }}
                                        />
                                    </MuiPickersUtilsProvider>
                                    {this.state.errors.DOB.length > 0 &&
                                        <span className='error'>{this.state.errors.DOB}</span>}
                                </Grid>                            
                                <Grid item xs={3}>
                                    <TextField fullWidth required="true" name="specialityType" id="txtSpecialityType" label="Speciality Type"
                                        onChange={this.handleChange} noValidate value={this.state.specialityType} />
                                    {this.state.errors.specialityType.length > 0 &&
                                        <span className='error'>{this.state.errors.specialityType}</span>}
                                </Grid>                            
                            </Grid>
                            <Grid container spacing={3}>                                
                                <Grid item xs={7}>
                                    <TextField fullWidth required="true" name="address" id="txtAddress" label="Address" multiline rowsMax={4}
                                        onChange={this.handleChange} noValidate value={this.state.address} />
                                    {this.state.errors.address.length > 0 &&
                                        <span className='error'>{this.state.errors.address}</span>}
                                </Grid>
                                <Grid item xs={2}>                                
                                    <TextField fullWidth required="true" name="pinCode" id="txtPinCode" label="Pin Code"
                                        onChange={this.handleChange} noValidate value={this.state.pinCode} />
                                    {this.state.errors.pinCode.length > 0 &&
                                        <span className='error'>{this.state.errors.pinCode}</span>}
                                </Grid>           
                            </Grid>
                            <Grid container spacing={3}>                                                            
                                <Grid item xs={3}>
                                    <TextField fullWidth required="true" name="city" id="txtCity" label="City"
                                        onChange={this.handleChange} noValidate value={this.state.city} />
                                    {this.state.errors.city.length > 0 &&
                                        <span className='error'>{this.state.errors.city}</span>}
                                </Grid>                            
                                <Grid item xs={3}>
                                    <TextField fullWidth required="true" name="state" id="txtState" label="State"
                                        onChange={this.handleChange} noValidate value={this.state.state} />
                                    {this.state.errors.state.length > 0 &&
                                        <span className='error'>{this.state.errors.state}</span>}
                                </Grid>
                                <Grid item xs={3}>
                                    <TextField fullWidth required="true" name="nationality" id="txtNationality" label="Nationality"
                                        onChange={this.handleChange} noValidate value={this.state.nationality} />
                                    {this.state.errors.nationality.length > 0 &&
                                        <span className='error'>{this.state.errors.nationality}</span>}
                                </Grid>                             
                            </Grid>
                            <Grid container spacing={3}>                                                            
                                <Grid item xs={3}>
                                    <TextField fullWidth required="true" name="residenceTelNo" id="txtResidenceTelNo" label="Residence Telephone Number"
                                        onChange={this.handleChange} noValidate value={this.state.residenceTelNo} />
                                    {this.state.errors.residenceTelNo.length > 0 &&
                                        <span className='error'>{this.state.errors.residenceTelNo}</span>}
                                </Grid>                            
                                <Grid item xs={3}>
                                    <TextField fullWidth required="true" name="officeTelNo" id="txtOfficeTelNo" label="Office Telephone Number"
                                        onChange={this.handleChange} noValidate value={this.state.officeTelNo} />
                                    {this.state.errors.officeTelNo.length > 0 &&
                                        <span className='error'>{this.state.errors.officeTelNo}</span>}
                                </Grid>
                                <Grid item xs={3}>
                                    <TextField fullWidth required="true" name="alternateMobileNo" id="txtAlternateMobileNo" label="Alternate Mobile Number"
                                        onChange={this.handleChange} noValidate value={this.state.alternateMobileNo} />
                                    {this.state.errors.alternateMobileNo.length > 0 &&
                                        <span className='error'>{this.state.errors.alternateMobileNo}</span>}
                                </Grid>                             
                            </Grid>
                            <Grid container spacing={3}>                                
                                <Grid item xs={3}>
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <KeyboardDatePicker fullWidth format="dd/MM/yyyy"
                                            id="DOJ" label="Date of Joining"
                                            value={this.state.DOJ}
                                            onChange={this.onDOJChanged}
                                            KeyboardButtonProps={{
                                                'aria-label': 'change date',
                                            }}
                                        />
                                    </MuiPickersUtilsProvider>
                                    {this.state.errors.DOJ.length > 0 &&
                                        <span className='error'>{this.state.errors.DOJ}</span>}
                                </Grid>                          
                            </Grid>
                            <Grid container spacing={4}>
                                <Grid item xs={7}>
                                </Grid>
                                <Grid item xs={2}>                                
                                    <Button fullWidth style={{ backgroundColor: '#0079c2' }} variant="contained"
                                        color="primary" onClick={this.save}>VALIDATE & SAVE</Button>
                                </Grid>
                                {this.state.errorMessage &&
                                    <Grid item xs={12} className='error-main'>{this.state.errorMessage}</Grid>}
                            </Grid>
                        </form>
                    </div>
                    )}
            </div>
        );
    }
}

export default withRouter(withStyles(useStyles)(MyProfile))