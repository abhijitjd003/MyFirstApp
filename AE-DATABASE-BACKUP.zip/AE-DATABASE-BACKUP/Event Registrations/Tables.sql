CREATE TABLE `EventRegistrations`.`Conferences` (
  `ConfTypeId` int(11) NOT NULL AUTO_INCREMENT,
  `ConfName` varchar(30) NOT NULL,  
  PRIMARY KEY (`ConfTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventRegistrations`.`ProgramDefinitions` (  
  `ConfTypeId` INT NOT NULL,
  `StandardRegTypeNo` INT DEFAULT 0,
  `WorkshopDays` INT DEFAULT 0,
  `ChildrenAge` INT DEFAULT 0,
  `IsWorkshopReq` tinyint(1) DEFAULT 0,
  `IsConfReq` tinyint(1) DEFAULT 0,
  `IsCMEReq` tinyint(1) DEFAULT 0,
  `IsAccPersonReq` tinyint(1) DEFAULT 0,
  PRIMARY KEY (ConfTypeId),
  CONSTRAINT FK_C_ConfTypeId
  FOREIGN KEY (ConfTypeId) 
  REFERENCES EventRegistrations.Conferences(ConfTypeId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventRegistrations`.`CategoryDetails` (
  `CategoryId` int(11) NOT NULL AUTO_INCREMENT,  
  `ConfTypeId` INT NOT NULL,
  `CategoryName` VARCHAR(50) NOT NULL,  
  PRIMARY KEY (CategoryId),
  CONSTRAINT FK_CAT_ConfTypeId
  FOREIGN KEY (ConfTypeId) 
  REFERENCES EventRegistrations.Conferences(ConfTypeId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventRegistrations`.`CMETypes` (
  `CMEId` int(11) NOT NULL AUTO_INCREMENT,
  `ConfTypeId` INT NOT NULL,
  `CMEName` VARCHAR(50) NOT NULL,
  PRIMARY KEY (CMEId),
  CONSTRAINT FK_CME_ConfTypeId
  FOREIGN KEY (ConfTypeId) 
  REFERENCES EventRegistrations.Conferences(ConfTypeId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventRegistrations`.`Workshops` (
  `WorkshopId` int(11) NOT NULL AUTO_INCREMENT,
  `ConfTypeId` INT NOT NULL,
  `Workshop` VARCHAR(50) NOT NULL,
  PRIMARY KEY (WorkshopId),
  CONSTRAINT FK_W_ConfTypeId
  FOREIGN KEY (ConfTypeId) 
  REFERENCES EventRegistrations.Conferences(ConfTypeId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventRegistrations`.`SubCategories` (
  `SubCatID` int(11) NOT NULL AUTO_INCREMENT,
  `SubCatName` varchar(30) NOT NULL,  
  PRIMARY KEY (`SubCatID`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventRegistrations`.`TextMessages` (  
  `ConfTypeId` INT NOT NULL,
  `PaymentTextMessage` VARCHAR(1024) NULL,
  `RegTextMessage` VARCHAR(1024) NULL,
  `Notification` VARCHAR(1024) NULL,
  `PaymentEmail` VARCHAR(1024) NULL,
  `RegEmail` VARCHAR(1024) NULL,
  `PaymentEmailSubject` VARCHAR(1024) NULL,
  `RegEmailSubject` VARCHAR(1024) NULL,
  PRIMARY KEY (ConfTypeId),
  CONSTRAINT FK_TM_ConfTypeId
  FOREIGN KEY (ConfTypeId) 
  REFERENCES EventRegistrations.Conferences(ConfTypeId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventRegistrations`.`EventDetails` (
  `EventID` int(11) NOT NULL AUTO_INCREMENT,
  `ConfTypeId` INT NOT NULL,
  `RegistrationType` VARCHAR(30) NOT NULL,
  `StartDate` DATE NOT NULL,
  `EndDate` DATE NOT NULL,
  PRIMARY KEY (EventID),
  CONSTRAINT FK_ED_ConfTypeId
  FOREIGN KEY (ConfTypeId) 
  REFERENCES EventRegistrations.Conferences(ConfTypeId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventRegistrations`.`RegistrationFields` (  
  `ConfTypeId` INT NOT NULL,
  `Title` tinyint(1) DEFAULT 0,
  `FullName` tinyint(1) DEFAULT 0,
  `Gender` tinyint(1) DEFAULT 0,
  `DOB` tinyint(1) DEFAULT 0,
  `Age` tinyint(1) DEFAULT 0,
  `City` tinyint(1) DEFAULT 0,
  `State` tinyint(1) DEFAULT 0,
  `Country` tinyint(1) DEFAULT 0,
  `RegistrationNo` tinyint(1) DEFAULT 0,  
  `MemberNo` tinyint(1) DEFAULT 0,
  `Designation` tinyint(1) DEFAULT 0,
  `Department` tinyint(1) DEFAULT 0,
  `Nationality` tinyint(1) DEFAULT 0,
  `Email` tinyint(1) DEFAULT 0,
  `MobileNo` tinyint(1) DEFAULT 0,
  `MedicalCouncilName` tinyint(1) DEFAULT 0,
  `MedicalCouncilNo` tinyint(1) DEFAULT 0,
  `Address` tinyint(1) DEFAULT 0,
  `PinCode` tinyint(1) DEFAULT 0,
  `Institution` tinyint(1) DEFAULT 0,
  PRIMARY KEY (ConfTypeId),
  CONSTRAINT FK_RF_ConfTypeId
  FOREIGN KEY (ConfTypeId) 
  REFERENCES EventRegistrations.Conferences(ConfTypeId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventRegistrations`.`PaymentGateway` (  
  `ConfTypeId` INT NOT NULL,
  `Gateway` VARCHAR(30) DEFAULT NULL,
  `AccessCode` VARCHAR(50) DEFAULT NULL,
  `WorkingKey` VARCHAR(50) DEFAULT NULL,
  `MerchantId` VARCHAR(20) DEFAULT NULL,
  `ClientId` VARCHAR(50) DEFAULT NULL,
  `ClientSecretKey` VARCHAR(200) DEFAULT NULL,
  PRIMARY KEY (ConfTypeId),
  CONSTRAINT FK_PG_ConfTypeId
  FOREIGN KEY (ConfTypeId) 
  REFERENCES EventRegistrations.Conferences(ConfTypeId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventRegistrations`.`RegistrationFees` (
  `RegFeeId` int(11) NOT NULL AUTO_INCREMENT,
  `ConfTypeId` INT NOT NULL,
  `EventId` INT NOT NULL,
  `CatId` INT NOT NULL,
  `SubCatId` INT NOT NULL,
  `WorkshopId` INT NOT NULL,
  `Amount` INT NOT NULL,
  `Currency` VARCHAR(10) NOT NULL,
  PRIMARY KEY (RegFeeId),
  CONSTRAINT FK_RegF_ConfTypeId
  FOREIGN KEY (ConfTypeId) 
  REFERENCES EventRegistrations.Conferences(ConfTypeId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventRegistrations`.`ProgramFeeImage` (  
  `ConfTypeId` INT NOT NULL,
  `ProgramImage` BLOB NULL,
  PRIMARY KEY (ConfTypeId),
  CONSTRAINT FK_PFI_ConfTypeId
  FOREIGN KEY (ConfTypeId) 
  REFERENCES EventRegistrations.Conferences(ConfTypeId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventRegistrations`.`Countries` (  
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `CountryName` VARCHAR(30) NOT NULL,
  PRIMARY KEY (Id)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventRegistrations`.`States` (  
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `StateName` VARCHAR(30) NOT NULL,
  `CountryId` INT NOT NULL,
  PRIMARY KEY (Id),
  CONSTRAINT FK_ST_ConfTypeId
  FOREIGN KEY (CountryId) 
  REFERENCES EventRegistrations.Countries(Id)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventRegistrations`.`Cities` (  
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `CityName` VARCHAR(30) NOT NULL,
  `StateId` INT NOT NULL,
  PRIMARY KEY (Id),
  CONSTRAINT FK_CT_ConfTypeId
  FOREIGN KEY (StateId) 
  REFERENCES EventRegistrations.States(Id)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventRegistrations`.`UserRegistrationDetails` (  
  `UserId` int(11) NOT NULL AUTO_INCREMENT,
  `Title` VARCHAR(20) NULL,
  `FullName` VARCHAR(50) NOT NULL,
  `Gender` VARCHAR(20) NULL,
  `DOB` DATE NULL,
  `Age` INT NULL,
  `City` VARCHAR(30) NULL,
  `State` VARCHAR(30) NULL,
  `Country` VARCHAR(30) NULL,
  `UserRegisterNo` VARCHAR(30) NOT NULL,
  `RegistrationNo` VARCHAR(30) NOT NULL,
  `Designation` VARCHAR(50) NULL,
  `Department` VARCHAR(50) NULL,
  `Nationality` VARCHAR(30) NULL,
  `Email` VARCHAR(30) NOT NULL,
  `MobileNo` VARCHAR(30) NOT NULL,
  `MedicalCouncilName` VARCHAR(50) NULL,
  `MedicalCouncilNo` VARCHAR(30) NULL,
  `Address` VARCHAR(100) NULL,
  `PinCode` VARCHAR(20) NULL,
  `Institution` VARCHAR(30) NULL,
  `Status` VARCHAR(20) NULL,
  `CreatedDateTime` DATETIME NOT NULL,
  `UpdatedDateTime` DATETIME NOT NULL,
  PRIMARY KEY (UserId)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventRegistrations`.`UserMemberNo` (
  `ConfTypeId` INT NOT NULL,
  `UserId` INT NOT NULL,
  `MemberNo` VARCHAR(30) NOT NULL,
  PRIMARY KEY (ConfTypeId, UserId),
  CONSTRAINT FK_UR_ConfTypeId
  FOREIGN KEY (ConfTypeId) 
  REFERENCES EventRegistrations.Conferences(ConfTypeId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT,
  CONSTRAINT FK_UR_UserId
  FOREIGN KEY (UserId) 
  REFERENCES EventRegistrations.UserRegistrationDetails(UserId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventRegistrations`.`Users` (
  `MobileNo` VARCHAR(20) NOT NULL,
  `Password` VARCHAR(20) NOT NULL, 
  `Role` VARCHAR(20) NOT NULL,
  PRIMARY KEY (MobileNo)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventRegistrations`.`PaymentDetails` (
  `UserID` INT NOT NULL,
  `EventID` INT NOT NULL, 
  `CategoryID` INT NOT NULL,
  `SubCatID` INT NOT NULL,
  `CMEId` INT NOT NULL, 
  `TotalAmount` DECIMAL(10,2) NOT NULL,
  `CreatedDate` DATETIME NOT NULL,
  `LastUpdatedDate` DATETIME NOT NULL,
  `Status` VARCHAR(20) NOT NULL,
  CONSTRAINT FK_PD_UserID
  FOREIGN KEY (UserID) 
  REFERENCES EventRegistrations.UserRegistrationDetails(UserID)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventRegistrations`.`ProgramDetailsTemp` (
  `UserID` INT NOT NULL,
  `Category` VARCHAR(30) NOT NULL,
  `SubCategory` VARCHAR(30) NOT NULL,
  `CMEType` VARCHAR(30) NOT NULL,
  `Amount` VARCHAR(20) NOT NULL,
  `TotalAmount` VARCHAR(20) NOT NULL  
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventRegistrations`.`UserWorkshopDetails` (
  `UserID` INT NOT NULL,
  `WorkshopID` INT NOT NULL,
  `WorkshopDay` VARCHAR(20) NOT NULL,
  `CreatedDate` DATETIME NOT NULL,
  `Status` VARCHAR(20) NOT NULL,
  CONSTRAINT FK_W_UserID
  FOREIGN KEY (UserID) 
  REFERENCES EventRegistrations.UserRegistrationDetails(UserID)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventRegistrations`.`WorkshopDetailsTemp` (
  `UserID` INT NOT NULL,
  `WorkshopID` INT NOT NULL,
  `Workshop` VARCHAR(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventRegistrations`.`AccompanyingPersonDetails` (
  `UserID` INT NOT NULL,
  `Name` VARCHAR(50) NOT NULL,
  `Age` INT NOT NULL,
  `ConfTypeId` INT NOT NULL,
  `CreatedDate` DATETIME NOT NULL,
  `Status` VARCHAR(20) NOT NULL,
  CONSTRAINT FK_ACC_ConfTypeId
  FOREIGN KEY (ConfTypeId) 
  REFERENCES EventRegistrations.Conferences(ConfTypeId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT,
  CONSTRAINT FK_ACC_UserID
  FOREIGN KEY (UserID) 
  REFERENCES EventRegistrations.UserRegistrationDetails(UserID)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventRegistrations`.`AccPersonDetailsTemp` (
  `UserID` INT NOT NULL,
  `AccPerson` VARCHAR(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventRegistrations`.`OfflineTransactionDetails` (
  `OfflineTranId` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` INT NOT NULL,
  `ConfTypeId` INT NOT NULL,
  `DDNo` VARCHAR(30) NULL,
  `ChequeNo` VARCHAR(30) NULL,
  `UTRNo` VARCHAR(30) NULL,
  `Bank` VARCHAR(30) NULL,
  `Branch` VARCHAR(50) NULL,
  `ChequeDate` DATE NULL,
  `TransactionDateTime` DATETIME NULL,
  PRIMARY KEY (OfflineTranId),
  CONSTRAINT FK_OFF_ConfTypeId
  FOREIGN KEY (ConfTypeId) 
  REFERENCES EventRegistrations.Conferences(ConfTypeId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT,
  CONSTRAINT FK_OFF_UserID
  FOREIGN KEY (UserID) 
  REFERENCES EventRegistrations.UserRegistrationDetails(UserID)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventRegistrations`.`TransactionDetails` (
  `TranDtlId` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` INT NOT NULL,
  `ConfTypeId` INT NOT NULL,
  `TransactionId` VARCHAR(50) NULL,
  `PaymentId` VARCHAR(50) NULL,
  `PaymentStatus` VARCHAR(20) NULL,
  `OrderId` VARCHAR(50) NULL,
  `TrackingId` VARCHAR(50) NULL,
  `BankRefNo` VARCHAR(50) NULL,
  `Currency` VARCHAR(20) NULL,
  `OrderStatus` VARCHAR(20) NULL,
  `PaymentGateway` VARCHAR(20) NULL,
  `Signature` VARCHAR(200) NULL,
  `TransactionType` VARCHAR(20) NULL,
  `TransactionDateTime` DATETIME NULL,
  PRIMARY KEY (TranDtlId),
  CONSTRAINT FK_TRAN_ConfTypeId
  FOREIGN KEY (ConfTypeId) 
  REFERENCES EventRegistrations.Conferences(ConfTypeId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT,
  CONSTRAINT FK_TRAN_UserID
  FOREIGN KEY (UserID) 
  REFERENCES EventRegistrations.UserRegistrationDetails(UserID)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
