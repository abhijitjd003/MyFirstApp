-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 148.72.232.169:3306
-- Generation Time: Jan 13, 2021 at 08:58 PM
-- Server version: 5.5.51-38.1-log
-- PHP Version: 7.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `EventRegistrations`
--
CREATE DATABASE IF NOT EXISTS `EventRegistrations` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `EventRegistrations`;

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `sp_CategoryWorkshopDetails`$$
$$

DROP PROCEDURE IF EXISTS `sp_CreateConference`$$
$$

DROP PROCEDURE IF EXISTS `sp_CreateWorkshop`$$
$$

DROP PROCEDURE IF EXISTS `sp_EchoTransactionDetails`$$
$$

DROP PROCEDURE IF EXISTS `sp_GetCityStateCountry`$$
$$

DROP PROCEDURE IF EXISTS `sp_GetConference`$$
$$

DROP PROCEDURE IF EXISTS `sp_GetConferenceName`$$
$$

DROP PROCEDURE IF EXISTS `sp_GetPaymentGateway1008`$$
$$

DROP PROCEDURE IF EXISTS `sp_GetPaymentGatewayConstants`$$
$$

DROP PROCEDURE IF EXISTS `sp_GetRegistrationTypes`$$
$$

DROP PROCEDURE IF EXISTS `sp_GetSMSText`$$
$$

DROP PROCEDURE IF EXISTS `sp_GetUserDetailsByUserID`$$
$$

DROP PROCEDURE IF EXISTS `sp_GetUserIdByMobileNo`$$
$$

DROP PROCEDURE IF EXISTS `sp_LoadRegistrationFields`$$
$$

DROP PROCEDURE IF EXISTS `sp_OfflinePaymentDetails`$$
$$

DROP PROCEDURE IF EXISTS `sp_ProgramDefinitions`$$
$$

DROP PROCEDURE IF EXISTS `sp_ProgramRegistrationFee`$$
$$

DROP PROCEDURE IF EXISTS `sp_RegistrationDetails`$$
$$

DROP PROCEDURE IF EXISTS `sp_RemoveAccPersonDetails`$$
$$

DROP PROCEDURE IF EXISTS `sp_RemoveCategoryDetails`$$
$$

DROP PROCEDURE IF EXISTS `sp_RemoveWorkshopDetails`$$
$$

DROP PROCEDURE IF EXISTS `sp_RoleManagement`$$
$$

DROP PROCEDURE IF EXISTS `sp_TransactionDetails`$$
$$

DROP PROCEDURE IF EXISTS `sp_UpdateRegistrationFields`$$
$$

DROP PROCEDURE IF EXISTS `sp_UploadProgramFeeImage`$$
$$

DROP PROCEDURE IF EXISTS `sp_UserAlreadyRegistered`$$
$$

DROP PROCEDURE IF EXISTS `sp_UserRegistrationDetails`$$
$$

DROP PROCEDURE IF EXISTS `sp_Users`$$
$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `AccompanyingPersonDetails`
--

DROP TABLE IF EXISTS `AccompanyingPersonDetails`;
CREATE TABLE `AccompanyingPersonDetails` (
  `UserID` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Age` int(11) NOT NULL,
  `ConfTypeId` int(11) NOT NULL,
  `CreatedDate` datetime NOT NULL,
  `Status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `AccPersonDetailsTemp`
--

DROP TABLE IF EXISTS `AccPersonDetailsTemp`;
CREATE TABLE `AccPersonDetailsTemp` (
  `UserID` int(11) NOT NULL,
  `AccPerson` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `AccPersonDetailsTemp`
--

INSERT INTO `AccPersonDetailsTemp` (`UserID`, `AccPerson`) VALUES
(2, 'Abhijit (30)'),
(1, 'test (30)');

-- --------------------------------------------------------

--
-- Table structure for table `CategoryDetails`
--

DROP TABLE IF EXISTS `CategoryDetails`;
CREATE TABLE `CategoryDetails` (
  `CategoryId` int(11) NOT NULL,
  `ConfTypeId` int(11) NOT NULL,
  `CategoryName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `CategoryDetails`
--

INSERT INTO `CategoryDetails` (`CategoryId`, `ConfTypeId`, `CategoryName`) VALUES
(2, 1, 'PG Students'),
(4, 1, 'Non-PG Students');

-- --------------------------------------------------------

--
-- Table structure for table `Cities`
--

DROP TABLE IF EXISTS `Cities`;
CREATE TABLE `Cities` (
  `Id` int(11) NOT NULL,
  `CityName` varchar(30) NOT NULL,
  `StateId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `CMETypes`
--

DROP TABLE IF EXISTS `CMETypes`;
CREATE TABLE `CMETypes` (
  `CMEId` int(11) NOT NULL,
  `ConfTypeId` int(11) NOT NULL,
  `CMEName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `CMETypes`
--

INSERT INTO `CMETypes` (`CMEId`, `ConfTypeId`, `CMEName`) VALUES
(1, 1, 'CME1'),
(3, 1, 'CME2');

-- --------------------------------------------------------

--
-- Table structure for table `Conferences`
--

DROP TABLE IF EXISTS `Conferences`;
CREATE TABLE `Conferences` (
  `ConfTypeId` int(11) NOT NULL,
  `ConfName` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Conferences`
--

INSERT INTO `Conferences` (`ConfTypeId`, `ConfName`) VALUES
(1, 'EMINDIA'),
(2, 'ISACON');

-- --------------------------------------------------------

--
-- Table structure for table `Countries`
--

DROP TABLE IF EXISTS `Countries`;
CREATE TABLE `Countries` (
  `Id` int(11) NOT NULL,
  `CountryName` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `EventDetails`
--

DROP TABLE IF EXISTS `EventDetails`;
CREATE TABLE `EventDetails` (
  `EventID` int(11) NOT NULL,
  `ConfTypeId` int(11) NOT NULL,
  `RegistrationType` varchar(30) NOT NULL,
  `StartDate` date NOT NULL,
  `EndDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `EventDetails`
--

INSERT INTO `EventDetails` (`EventID`, `ConfTypeId`, `RegistrationType`, `StartDate`, `EndDate`) VALUES
(1, 1, 'Early Bird', '2020-07-17', '2020-08-31'),
(2, 1, 'Standard1', '2020-07-17', '2020-07-17'),
(3, 1, 'Standard2', '2020-07-17', '2020-07-17'),
(4, 1, 'Standard3', '2020-07-17', '2020-07-17'),
(5, 1, 'Standard4', '2020-07-17', '2020-07-17'),
(6, 1, 'Standard5', '2020-07-17', '2020-07-17'),
(7, 1, 'Late & Spot', '2020-07-17', '2020-07-17'),
(8, 2, 'Early Bird', '2020-07-19', '2020-07-19'),
(9, 2, 'Standard1', '2020-07-19', '2020-07-19'),
(10, 2, 'Standard2', '2020-07-19', '2020-07-19'),
(11, 2, 'Standard3', '2020-07-19', '2020-07-19'),
(12, 2, 'Standard4', '2020-07-19', '2020-07-19'),
(13, 2, 'Standard5', '2020-07-19', '2020-07-19'),
(14, 2, 'Late & Spot', '2020-07-19', '2020-07-19');

-- --------------------------------------------------------

--
-- Table structure for table `OfflineTransactionDetails`
--

DROP TABLE IF EXISTS `OfflineTransactionDetails`;
CREATE TABLE `OfflineTransactionDetails` (
  `OfflineTranId` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `ConfTypeId` int(11) NOT NULL,
  `DDNo` varchar(30) DEFAULT NULL,
  `ChequeNo` varchar(30) DEFAULT NULL,
  `UTRNo` varchar(30) DEFAULT NULL,
  `Bank` varchar(30) DEFAULT NULL,
  `Branch` varchar(50) DEFAULT NULL,
  `ChequeDate` date DEFAULT NULL,
  `TransactionDateTime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `PaymentDetails`
--

DROP TABLE IF EXISTS `PaymentDetails`;
CREATE TABLE `PaymentDetails` (
  `UserID` int(11) NOT NULL,
  `EventID` int(11) NOT NULL,
  `CategoryID` int(11) NOT NULL,
  `SubCatID` int(11) NOT NULL,
  `CMEId` int(11) NOT NULL,
  `TotalAmount` decimal(10,2) NOT NULL,
  `CreatedDate` datetime NOT NULL,
  `LastUpdatedDate` datetime NOT NULL,
  `Status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `PaymentGateway`
--

DROP TABLE IF EXISTS `PaymentGateway`;
CREATE TABLE `PaymentGateway` (
  `ConfTypeId` int(11) NOT NULL,
  `Gateway` varchar(30) DEFAULT NULL,
  `AccessCode` varchar(50) DEFAULT NULL,
  `WorkingKey` varchar(50) DEFAULT NULL,
  `MerchantId` varchar(20) DEFAULT NULL,
  `ClientId` varchar(50) DEFAULT NULL,
  `ClientSecretKey` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `PaymentGateway`
--

INSERT INTO `PaymentGateway` (`ConfTypeId`, `Gateway`, `AccessCode`, `WorkingKey`, `MerchantId`, `ClientId`, `ClientSecretKey`) VALUES
(1, 'CCAvenue', 'AVUD83GB30AK99DUKA', '5FF41808A25A0E829D4D4AF60D81E940', '206626', '', ''),
(2, 'CCAvenue', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ProgramDefinitions`
--

DROP TABLE IF EXISTS `ProgramDefinitions`;
CREATE TABLE `ProgramDefinitions` (
  `ConfTypeId` int(11) NOT NULL,
  `StandardRegTypeNo` int(11) DEFAULT '0',
  `WorkshopDays` int(11) DEFAULT '0',
  `ChildrenAge` int(11) DEFAULT '0',
  `IsWorkshopReq` tinyint(1) DEFAULT '0',
  `IsConfReq` tinyint(1) DEFAULT '0',
  `IsCMEReq` tinyint(1) DEFAULT '0',
  `IsAccPersonReq` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ProgramDefinitions`
--

INSERT INTO `ProgramDefinitions` (`ConfTypeId`, `StandardRegTypeNo`, `WorkshopDays`, `ChildrenAge`, `IsWorkshopReq`, `IsConfReq`, `IsCMEReq`, `IsAccPersonReq`) VALUES
(1, 3, 3, 10, 1, 1, 1, 1),
(2, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `ProgramDetailsTemp`
--

DROP TABLE IF EXISTS `ProgramDetailsTemp`;
CREATE TABLE `ProgramDetailsTemp` (
  `UserID` int(11) NOT NULL,
  `Category` varchar(30) NOT NULL,
  `SubCategory` varchar(30) NOT NULL,
  `CMEType` varchar(30) NOT NULL,
  `Amount` varchar(20) NOT NULL,
  `TotalAmount` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ProgramDetailsTemp`
--

INSERT INTO `ProgramDetailsTemp` (`UserID`, `Category`, `SubCategory`, `CMEType`, `Amount`, `TotalAmount`) VALUES
(2, 'PG Students', 'Conference', '', '5500', '5500'),
(1, 'PG Students', 'Conference', '', '5500', '5500');

-- --------------------------------------------------------

--
-- Table structure for table `ProgramFeeImage`
--

DROP TABLE IF EXISTS `ProgramFeeImage`;
CREATE TABLE `ProgramFeeImage` (
  `ConfTypeId` int(11) NOT NULL,
  `ProgramImage` blob
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ProgramFeeImage`
--

INSERT INTO `ProgramFeeImage` (`ConfTypeId`, `ProgramImage`) VALUES
(1, 0xffd8ffe000104a46494600010200006400640000ffec00114475636b7900010004000000640000ffee000e41646f62650064c000000001ffdb008400010101010101010101010101010101010101010101010101010101010101010101010101010101010101010202020202020202020202030303030303030303030101010101010102010102020201020203030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303ffc00011080069028003011100021101031101ffc400a9000101010003010101000000000000000000070603040501020801010002020301010000000000000000000006090508030407010210010000030702030605040300000000000001020703d506579708181104711213213151618105223282731441916272b2334311010000030407060403060309000000000001030491020595121353d41555061152d356071721315161417122f08132141608428273a1c1d1e1f123b37436ffda000c03010002110311003f0087f26771b9f558f52f18df0f3ce1d43b2976415cfa35bcc317cc6bf793933b8dcfaac7a978c6f838750eca5d90346b79862f98d7ef2726771b9f558f52f18df070ea1d94bb2068d6f30c5f31afde4e4cee373eab1ea5e31be0e1d43b297640d1ade618be635fbc9c99dc6e7d563d4bc637c1c3a87652ec81a35bcc317cc6bf793933b8dcfaac7a978c6f838750eca5d90346b79862f98d7ef2726771b9f558f52f18df070ea1d94bb2068d6f30c5f31afde4e4cee373eab1ea5e31be0e1d43b297640d1ade618be635fbc9c99dc6e7d563d4bc637c1c3a87652ec81a35bcc317cc6bf793933b8dcfaac7a978c6f838750eca5d90346b79862f98d7ef2726771b9f558f52f18df070ea1d94bb2068d6f30c5f31afde4e4cee373eab1ea5e31be0e1d43b297640d1ade618be635fbc9c99dc6e7d563d4bc637c1c3a87652ec81a35bcc317cc6bf793933b8dcfaac7a978c6f838750eca5d90346b79862f98d7ef2726771b9f558f52f18df070ea1d94bb2068d6f30c5f31afde4e4cee373eab1ea5e31be0e1d43b297640d1ade618be635fbc9c99dc6e7d563d4bc637c1c3a87652ec81a35bcc317cc6bf793933b8dcfaac7a978c6f838750eca5d90346b79862f98d7ef2726771b9f558f52f18df070ea1d94bb2068d6f30c5f31afde4e4cee373eab1ea5e31be0e1d43b297640d1ade618be635fbc9c99dc6e7d563d4bc637c1c3a87652ec81a35bcc317cc6bf793933b8dcfaac7a978c6f838750eca5d90346b79862f98d7ef2726771b9f558f52f18df070ea1d94bb2068d6f30c5f31afde4e4cee373eab1ea5e31be0e1d43b297640d1ade618be635fbc9c99dc6e7d563d4bc637c1c3a87652ec81a35bcc317cc6bf793933b8dcfaac7a978c6f838750eca5d90346b79862f98d7ef2726771b9f558f52f18df070ea1d94bb2068d6f30c5f31afde4e4cee373eab1ea5e31be0e1d43b297640d1ade618be635fbc9c99dc6e7d563d4bc637c1c3a87652ec81a35bcc317cc6bf793933b8dcfaac7a978c6f838750eca5d90346b79862f98d7ef2726771b9f558f52f18df070ea1d94bb2068d6f30c5f31afde4e4cee373eab1ea5e31be0e1d43b297640d1ade618be635fbc9c99dc6e7d563d4bc637c1c3a87652ec81a35bcc317cc6bf793933b8dcfaac7a978c6f838750eca5d90346b79862f98d7ef2726771b9f558f52f18df070ea1d94bb2068d6f30c5f31afde4e4cee373eab1ea5e31be0e1d43b297640d1ade618be635fbc9c99dc6e7d563d4bc637c1c3a87652ec81a35bcc317cc6bf793933b8dcfaac7a978c6f838750eca5d90346b79862f98d7ef2726771b9f558f52f18df070ea1d94bb2068d6f30c5f31afde4e4cee373eab1ea5e31be0e1d43b297640d1ade618be635fbc9c99dc6e7d563d4bc637c1c3a87652ec81a35bcc317cc6bf793933b8dcfaac7a978c6f838750eca5d90346b79862f98d7ef2726771b9f558f52f18df070ea1d94bb2068d6f30c5f31afde4e4cee373eab1ea5e31be0e1d43b297640d1ade618be635fbc9c99dc6e7d563d4bc637c1c3a87652ec81a35bcc317cc6bf793933b8dcfaac7a978c6f838750eca5d90346b79862f98d7ef2726771b9f558f52f18df070ea1d94bb2068d6f30c5f31afde4e4cee373eab1ea5e31be0e1d43b297640d1ade618be635fbc9c99dc6e7d563d4bc637c1c3a87652ec81a35bcc317cc6bf793933b8dcfaac7a978c6f838750eca5d90346b79862f98d7ef2726771b9f558f52f18df070ea1d94bb2068d6f30c5f31afde4e4cee373eab1ea5e31be0e1d43b297640d1ade618be635fbc9c99dc6e7d563d4bc637c1c3a87652ec81a35bcc317cc6bf793933b8dcfaac7a978c6f838750eca5d90346b79862f98d7ef2726771b9f558f52f18df070ea1d94bb2068d6f30c5f31afde5a9fb3ee1f70b6bdafafdcd75ac5691b59e3e9f9aa5e33f64927e1eb0e9f7987e69a11fa7462ab29e92ecdd0972ee421087c7e10f9b533d67f537ab70aeab8605d338de354d2a964ddd746e6235bfaa6ccfd7d918c67c7e172e46e7cbe57a37a117adc84afb9e157f52f1a5f4ea6a24f72ed90790fbb1ea9f997a8331abf18e4257dcf0abfa978d2fa35127b976c81eec7aa7e65ea0cc6afc639095f73c2afea5e34be8d449ee5db207bb1ea9f997a8331abf18e4257dcf0abfa978d2fa35127b976c81eec7aa7e65ea0cc6afc639095f73c2afea5e34be8d449ee5db207bb1ea9f997a8331abf18e4257dcf0abfa978d2fa35127b976c81eec7aa7e65ea0cc6afc639095f73c2afea5e34be8d449ee5db207bb1ea9f997a8331abf18e4257dcf0abfa978d2fa35127b976c81eec7aa7e65ea0cc6afc639095f73c2afea5e34be8d449ee5db207bb1ea9f997a8331abf18e4257dcf0abfa978d2fa35127b976c81eec7aa7e65ea0cc6afc639095f73c2afea5e34be8d449ee5db207bb1ea9f997a8331abf18e4257dcf0abfa978d2fa35127b976c81eec7aa7e65ea0cc6afc639095f73c2afea5e34be8d449ee5db207bb1ea9f997a8331abf18e4257dcf0abfa978d2fa35127b976c81eec7aa7e65ea0cc6afc639095f73c2afea5e34be8d449ee5db207bb1ea9f997a8331abf18e4257dcf0abfa978d2fa35127b976c81eec7aa7e65ea0cc6afc639095f73c2afea5e34be8d449ee5db207bb1ea9f997a8331abf18e4257dcf0abfa978d2fa35127b976c81eec7aa7e65ea0cc6afc639095f73c2afea5e34be8d449ee5db207bb1ea9f997a8331abf18e4257dcf0abfa978d2fa35127b976c81eec7aa7e65ea0cc6afc639095f73c2afea5e34be8d449ee5db207bb1ea9f997a8331abf18e4257dcf0abfa978d2fa35127b976c81eec7aa7e65ea0cc6afc639095f73c2afea5e34be8d449ee5db207bb1ea9f997a8331abf18e4257dcf0abfa978d2fa35127b976c81eec7aa7e65ea0cc6afc67f28a58b1600000000000000000000000000000000000000000000000000000000000000000000000000000001c9656735b5ad9d949f9ad2796497c668c21d63f28757e6fde85cbb1bf1f9421dac7e2f89d360b85d462f591eca5a6937e65efcae5d8de8c21f78f676421f8c630828f65672d8d959d949ec96ce496497c258421d63f38f446efde8dfbd1bf7be718ab2b16c4aa719c52a316ac8f6d554cebf32f7e77ef46f4610fb43b7b210fc210841c8fcb1e0000000000000000000000000000000000260942d5400000000000000000000000000000000000000000000000000000000000000000000000000000007bdf60edfd4ee67ee2687e1b097a4bfb969d65878f49211fef07431099a32a12e1f3bd1ff00641af9fdc3752f0de9893d3d22f7654e2137b6ff00d7532630bd1fcb4a6465c21f5842fc3ead8b0cd2d0000000000000000000000000000000000004c1285aa80000000000000000000000000000000000000000000000000000000000000000000000000000000de7da7b7fe37656508c3a4f6b0f5a7f8f5b484232c23f39648421e2c0d5ccd64f8c61fc30f843f77fcd5f3eb0752ff5375d55cd957b4a8a923fcb4afa764a8c617e30fc230bd3637ef423f8dd8ddfa3d3755e6000000000000000000000000000000000000098250b55000000000000000000000000000000000000000000000000000000000000000000000000000000773b0edff95ddd8d8c61d658cde6b4fdb93f14fe1d610e9e3170d44cd549bd7ff1ecf87e685fa85d490e93e8fadc66edeecaabb2a37257fad33f44becfae8de8e9c61ddbb15091e56fc6318c7b63f18c5f5f1f0000000000000000000000000000000000001304a16aa000000000000000000000000000000000000000000000000000000000000000000000000000000d561eedba496ddd4d0f6cf1f46ce3fe32f49ad230f94d37487d18ac46676c612a1f287c63fee6a4ff0071fd4badaca3e93a7bdfa24ddfe627421dfbddb725423f7bb734ef767d265d8b4ac6358000000000000000000000000000000000000004c1285aa80000000000000000000000000000000000000000000000000000000000000000000000000000fb2c2334612cb0eb34d18421087be318c7a4210f18918c210ed8fc9c53e7caa6917ea6a2f42e48977237af5e8fca176ec3b6318fda108463151bb5b0876ddbd8d843ff00392108c61fd668fb679bf54f18c51b9b32336646fc7f18ff00d15a3d5b8fceea8ea4acc7a776f6d4cfbd7aec23f3bb2e1fa65ddff2cb85dbbfb9d871a3a0000000000000000000000000000000000000260942d5400000000000000000000000000000000000000000000000000000000000000000000000000007aff64edbd7ef659e30eb276f0f563f0f3fbace1e3e6f6fe974eb6668498dd87f15ef87fc5e35eba752f01e87994326f7656e237f5177ebabecd29d1fcb421ab8ff00a906e183687800000000000000000000000000000000000000260942d5400000000000000000000000000000000000000000000000000000000000000000000000000006dbec7dbfa3d9c2d230e93f7137a91f8f921d65b3878461d6687fb3095d334e768c3e577e1fbff1fdbecd17f5e7a978df5adec324deeda2c365ea61f4d6deecbd3a3f9c23a32e3f796f65d2789000000000000000000000000000000000000000260942d54000000000000000000000000000000000000000000000000000000000000000000000000001cfdb58cddcdbd9584befb49e59631f84bef9a6fd32c231fa3f136fc25cb8df8fe1060ba9f1c91d35d3f598ed4766ae9a45ebf0847fc57bb3b2e5cff3df8ddbb0fbc5469659649659258749649612cb087ba12cb0e9087d21046e318de8c631f9c559d55533eb6a665654de8dfa99b32f5fbf7a3f3bd7af4637af463f78c6318bf4f8e00000000000000000000000000000000000000004c1285aa80000000000000000000000000000000000000000000000000000000000000000000000000034787bb7f35a5af75343d9670f4ace3fe73fb678c3e72c9d21fa98ec466765d84a87ce3f18fedfb7c9acff00dc7752ff002f865274ac8bdff76a6febe6c21b39718dd9708fdafccedbdf9ca6b1886a10000000000000000000000000000000000000000098250b55000000000000000000000000000000000000000000000000000000000000000000000000000507edddb7f17b3b1b28c3a4fe5f3da7c7d49ff14d08ff00af5e9f447aa666b675ebdf87ca1f9415c9ea4f52ff0055f59d6e2b2ef6951c266aa4fd3552bf45d8c3ed7fb23323f7bf1779c0828000000000000000000000000000000000000000098250b5500000000000000000000000000000000000000000000000000000000000000000000000001e8fdafb6fe4f7b652c61d64923eada7c3cb67d230847e534fd21f575eaa66aa4463fe28fc21fbde6feacf52ff004bf43d655cabda35b5177f9793f5d39b08c23187dee4b85fbf0fbdd837c8fabc8000000000000000000000000000000000000000001304a16aa0000000000000000000000000000000000000000000000000000000000000000000000000345877fefee3f665ff009c18ec47f82efe6d6dfee53ff9fc3bff0072f7fe38b5ac434f0000000000000000000000000000000000000000001fffd9),
(2, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `RegistrationFees`
--

DROP TABLE IF EXISTS `RegistrationFees`;
CREATE TABLE `RegistrationFees` (
  `RegFeeId` int(11) NOT NULL,
  `ConfTypeId` int(11) NOT NULL,
  `EventId` int(11) NOT NULL,
  `CatId` int(11) NOT NULL,
  `SubCatId` int(11) NOT NULL,
  `WorkshopId` int(11) NOT NULL,
  `Amount` int(11) NOT NULL,
  `Currency` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `RegistrationFees`
--

INSERT INTO `RegistrationFees` (`RegFeeId`, `ConfTypeId`, `EventId`, `CatId`, `SubCatId`, `WorkshopId`, `Amount`, `Currency`) VALUES
(2, 1, 1, 0, 4, 0, 2500, 'INR'),
(3, 1, 1, 2, 1, 0, 5500, 'INR'),
(4, 1, 1, 2, 2, 0, 7500, 'INR'),
(5, 1, 1, 2, 3, 0, 3750, 'INR');

-- --------------------------------------------------------

--
-- Table structure for table `RegistrationFields`
--

DROP TABLE IF EXISTS `RegistrationFields`;
CREATE TABLE `RegistrationFields` (
  `ConfTypeId` int(11) NOT NULL,
  `Title` tinyint(1) DEFAULT '0',
  `FullName` tinyint(1) DEFAULT '0',
  `Gender` tinyint(1) DEFAULT '0',
  `DOB` tinyint(1) DEFAULT '0',
  `Age` tinyint(1) DEFAULT '0',
  `City` tinyint(1) DEFAULT '0',
  `State` tinyint(1) DEFAULT '0',
  `Country` tinyint(1) DEFAULT '0',
  `RegistrationNo` tinyint(1) DEFAULT '0',
  `MemberNo` tinyint(1) DEFAULT '0',
  `Designation` tinyint(1) DEFAULT '0',
  `Department` tinyint(1) DEFAULT '0',
  `Nationality` tinyint(1) DEFAULT '0',
  `Email` tinyint(1) DEFAULT '0',
  `MobileNo` tinyint(1) DEFAULT '0',
  `MedicalCouncilName` tinyint(1) DEFAULT '0',
  `MedicalCouncilNo` tinyint(1) DEFAULT '0',
  `Address` tinyint(1) DEFAULT '0',
  `PinCode` tinyint(1) DEFAULT '0',
  `Institution` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `RegistrationFields`
--

INSERT INTO `RegistrationFields` (`ConfTypeId`, `Title`, `FullName`, `Gender`, `DOB`, `Age`, `City`, `State`, `Country`, `RegistrationNo`, `MemberNo`, `Designation`, `Department`, `Nationality`, `Email`, `MobileNo`, `MedicalCouncilName`, `MedicalCouncilNo`, `Address`, `PinCode`, `Institution`) VALUES
(1, 0, 1, 0, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `States`
--

DROP TABLE IF EXISTS `States`;
CREATE TABLE `States` (
  `Id` int(11) NOT NULL,
  `StateName` varchar(30) NOT NULL,
  `CountryId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `SubCategories`
--

DROP TABLE IF EXISTS `SubCategories`;
CREATE TABLE `SubCategories` (
  `SubCatID` int(11) NOT NULL,
  `SubCatName` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `SubCategories`
--

INSERT INTO `SubCategories` (`SubCatID`, `SubCatName`) VALUES
(1, 'Conference'),
(2, 'CME & Conference'),
(3, 'Workshop'),
(4, 'Accompanying Person');

-- --------------------------------------------------------

--
-- Table structure for table `TextMessages`
--

DROP TABLE IF EXISTS `TextMessages`;
CREATE TABLE `TextMessages` (
  `ConfTypeId` int(11) NOT NULL,
  `PaymentTextMessage` varchar(1024) DEFAULT NULL,
  `RegTextMessage` varchar(1024) DEFAULT NULL,
  `Notification` varchar(1024) DEFAULT NULL,
  `PaymentEmail` varchar(1024) DEFAULT NULL,
  `RegEmail` varchar(1024) DEFAULT NULL,
  `PaymentEmailSubject` varchar(1024) DEFAULT NULL,
  `RegEmailSubject` varchar(1024) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `TextMessages`
--

INSERT INTO `TextMessages` (`ConfTypeId`, `PaymentTextMessage`, `RegTextMessage`, `Notification`, `PaymentEmail`, `RegEmail`, `PaymentEmailSubject`, `RegEmailSubject`) VALUES
(1, 'test', 'test', 'test', 'test', 'test', 'test', 'test'),
(2, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `TransactionDetails`
--

DROP TABLE IF EXISTS `TransactionDetails`;
CREATE TABLE `TransactionDetails` (
  `TranDtlId` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `ConfTypeId` int(11) NOT NULL,
  `TransactionId` varchar(50) DEFAULT NULL,
  `PaymentId` varchar(50) DEFAULT NULL,
  `PaymentStatus` varchar(20) DEFAULT NULL,
  `OrderId` varchar(50) DEFAULT NULL,
  `TrackingId` varchar(50) DEFAULT NULL,
  `BankRefNo` varchar(50) DEFAULT NULL,
  `Currency` varchar(20) DEFAULT NULL,
  `OrderStatus` varchar(20) DEFAULT NULL,
  `PaymentGateway` varchar(20) DEFAULT NULL,
  `Signature` varchar(200) DEFAULT NULL,
  `TransactionType` varchar(20) DEFAULT NULL,
  `TransactionDateTime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `TransactionDetails`
--

INSERT INTO `TransactionDetails` (`TranDtlId`, `UserID`, `ConfTypeId`, `TransactionId`, `PaymentId`, `PaymentStatus`, `OrderId`, `TrackingId`, `BankRefNo`, `Currency`, `OrderStatus`, `PaymentGateway`, `Signature`, `TransactionType`, `TransactionDateTime`) VALUES
(1, 1, 1, NULL, NULL, 'Net Banking', '854873042', '309006213831', '1595169315368', 'INR', 'Success', 'CCAvenue', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `UserMemberNo`
--

DROP TABLE IF EXISTS `UserMemberNo`;
CREATE TABLE `UserMemberNo` (
  `ConfTypeId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `MemberNo` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `UserMemberNo`
--

INSERT INTO `UserMemberNo` (`ConfTypeId`, `UserId`, `MemberNo`) VALUES
(1, 1, '987654');

-- --------------------------------------------------------

--
-- Table structure for table `UserRegistrationDetails`
--

DROP TABLE IF EXISTS `UserRegistrationDetails`;
CREATE TABLE `UserRegistrationDetails` (
  `UserId` int(11) NOT NULL,
  `Title` varchar(20) DEFAULT NULL,
  `FullName` varchar(50) NOT NULL,
  `Gender` varchar(20) DEFAULT NULL,
  `DOB` date DEFAULT NULL,
  `Age` int(11) DEFAULT NULL,
  `City` varchar(30) DEFAULT NULL,
  `State` varchar(30) DEFAULT NULL,
  `Country` varchar(30) DEFAULT NULL,
  `UserRegisterNo` varchar(30) NOT NULL,
  `RegistrationNo` varchar(30) NOT NULL,
  `Designation` varchar(50) DEFAULT NULL,
  `Department` varchar(50) DEFAULT NULL,
  `Nationality` varchar(30) DEFAULT NULL,
  `Email` varchar(30) NOT NULL,
  `MobileNo` varchar(30) NOT NULL,
  `MedicalCouncilName` varchar(50) DEFAULT NULL,
  `MedicalCouncilNo` varchar(30) DEFAULT NULL,
  `Address` varchar(100) DEFAULT NULL,
  `PinCode` varchar(20) DEFAULT NULL,
  `Institution` varchar(30) DEFAULT NULL,
  `Status` varchar(20) DEFAULT NULL,
  `CreatedDateTime` datetime NOT NULL,
  `UpdatedDateTime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `UserRegistrationDetails`
--

INSERT INTO `UserRegistrationDetails` (`UserId`, `Title`, `FullName`, `Gender`, `DOB`, `Age`, `City`, `State`, `Country`, `UserRegisterNo`, `RegistrationNo`, `Designation`, `Department`, `Nationality`, `Email`, `MobileNo`, `MedicalCouncilName`, `MedicalCouncilNo`, `Address`, `PinCode`, `Institution`, `Status`, `CreatedDateTime`, `UpdatedDateTime`) VALUES
(1, '', 'Abhijit', '', '1991-01-05', 29, '', '', '', '537771471', '', '', '', '', 'abhijitjd003@gmail.com', '8123506123', '', '', '', '', '', 'Success', '2020-07-19 01:40:09', '2020-07-19 20:04:31');

-- --------------------------------------------------------

--
-- Table structure for table `Users`
--

DROP TABLE IF EXISTS `Users`;
CREATE TABLE `Users` (
  `MobileNo` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Role` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Users`
--

INSERT INTO `Users` (`MobileNo`, `Password`, `Role`) VALUES
('8123506123', '123', 'User');

-- --------------------------------------------------------

--
-- Table structure for table `UserWorkshopDetails`
--

DROP TABLE IF EXISTS `UserWorkshopDetails`;
CREATE TABLE `UserWorkshopDetails` (
  `UserID` int(11) NOT NULL,
  `WorkshopID` int(11) NOT NULL,
  `WorkshopDay` varchar(20) NOT NULL,
  `CreatedDate` datetime NOT NULL,
  `Status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `WorkshopDetailsTemp`
--

DROP TABLE IF EXISTS `WorkshopDetailsTemp`;
CREATE TABLE `WorkshopDetailsTemp` (
  `UserID` int(11) NOT NULL,
  `WorkshopID` int(11) NOT NULL,
  `Workshop` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `WorkshopDetailsTemp`
--

INSERT INTO `WorkshopDetailsTemp` (`UserID`, `WorkshopID`, `Workshop`) VALUES
(2, 2, 'Cardiology (Day1)'),
(1, 3, 'Radiology (Day2)');

-- --------------------------------------------------------

--
-- Table structure for table `Workshops`
--

DROP TABLE IF EXISTS `Workshops`;
CREATE TABLE `Workshops` (
  `WorkshopId` int(11) NOT NULL,
  `ConfTypeId` int(11) NOT NULL,
  `Workshop` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Workshops`
--

INSERT INTO `Workshops` (`WorkshopId`, `ConfTypeId`, `Workshop`) VALUES
(2, 1, 'Cardiology'),
(3, 1, 'Radiology');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `AccompanyingPersonDetails`
--
ALTER TABLE `AccompanyingPersonDetails`
  ADD KEY `FK_ACC_ConfTypeId` (`ConfTypeId`),
  ADD KEY `FK_ACC_UserID` (`UserID`);

--
-- Indexes for table `CategoryDetails`
--
ALTER TABLE `CategoryDetails`
  ADD PRIMARY KEY (`CategoryId`),
  ADD KEY `FK_CAT_ConfTypeId` (`ConfTypeId`);

--
-- Indexes for table `Cities`
--
ALTER TABLE `Cities`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `FK_CT_ConfTypeId` (`StateId`);

--
-- Indexes for table `CMETypes`
--
ALTER TABLE `CMETypes`
  ADD PRIMARY KEY (`CMEId`),
  ADD KEY `FK_CME_ConfTypeId` (`ConfTypeId`);

--
-- Indexes for table `Conferences`
--
ALTER TABLE `Conferences`
  ADD PRIMARY KEY (`ConfTypeId`);

--
-- Indexes for table `Countries`
--
ALTER TABLE `Countries`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `EventDetails`
--
ALTER TABLE `EventDetails`
  ADD PRIMARY KEY (`EventID`),
  ADD KEY `FK_ED_ConfTypeId` (`ConfTypeId`);

--
-- Indexes for table `OfflineTransactionDetails`
--
ALTER TABLE `OfflineTransactionDetails`
  ADD PRIMARY KEY (`OfflineTranId`),
  ADD KEY `FK_OFF_ConfTypeId` (`ConfTypeId`),
  ADD KEY `FK_OFF_UserID` (`UserID`);

--
-- Indexes for table `PaymentDetails`
--
ALTER TABLE `PaymentDetails`
  ADD KEY `FK_PD_UserID` (`UserID`);

--
-- Indexes for table `PaymentGateway`
--
ALTER TABLE `PaymentGateway`
  ADD PRIMARY KEY (`ConfTypeId`);

--
-- Indexes for table `ProgramDefinitions`
--
ALTER TABLE `ProgramDefinitions`
  ADD PRIMARY KEY (`ConfTypeId`);

--
-- Indexes for table `ProgramFeeImage`
--
ALTER TABLE `ProgramFeeImage`
  ADD PRIMARY KEY (`ConfTypeId`);

--
-- Indexes for table `RegistrationFees`
--
ALTER TABLE `RegistrationFees`
  ADD PRIMARY KEY (`RegFeeId`),
  ADD KEY `FK_RegF_ConfTypeId` (`ConfTypeId`);

--
-- Indexes for table `RegistrationFields`
--
ALTER TABLE `RegistrationFields`
  ADD PRIMARY KEY (`ConfTypeId`);

--
-- Indexes for table `States`
--
ALTER TABLE `States`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `FK_ST_ConfTypeId` (`CountryId`);

--
-- Indexes for table `SubCategories`
--
ALTER TABLE `SubCategories`
  ADD PRIMARY KEY (`SubCatID`);

--
-- Indexes for table `TextMessages`
--
ALTER TABLE `TextMessages`
  ADD PRIMARY KEY (`ConfTypeId`);

--
-- Indexes for table `TransactionDetails`
--
ALTER TABLE `TransactionDetails`
  ADD PRIMARY KEY (`TranDtlId`),
  ADD KEY `FK_TRAN_ConfTypeId` (`ConfTypeId`),
  ADD KEY `FK_TRAN_UserID` (`UserID`);

--
-- Indexes for table `UserMemberNo`
--
ALTER TABLE `UserMemberNo`
  ADD PRIMARY KEY (`ConfTypeId`,`UserId`),
  ADD KEY `FK_UR_UserId` (`UserId`);

--
-- Indexes for table `UserRegistrationDetails`
--
ALTER TABLE `UserRegistrationDetails`
  ADD PRIMARY KEY (`UserId`);

--
-- Indexes for table `Users`
--
ALTER TABLE `Users`
  ADD PRIMARY KEY (`MobileNo`);

--
-- Indexes for table `UserWorkshopDetails`
--
ALTER TABLE `UserWorkshopDetails`
  ADD KEY `FK_W_UserID` (`UserID`);

--
-- Indexes for table `Workshops`
--
ALTER TABLE `Workshops`
  ADD PRIMARY KEY (`WorkshopId`),
  ADD KEY `FK_W_ConfTypeId` (`ConfTypeId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `CategoryDetails`
--
ALTER TABLE `CategoryDetails`
  MODIFY `CategoryId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `Cities`
--
ALTER TABLE `Cities`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `CMETypes`
--
ALTER TABLE `CMETypes`
  MODIFY `CMEId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `Conferences`
--
ALTER TABLE `Conferences`
  MODIFY `ConfTypeId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `Countries`
--
ALTER TABLE `Countries`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `EventDetails`
--
ALTER TABLE `EventDetails`
  MODIFY `EventID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `OfflineTransactionDetails`
--
ALTER TABLE `OfflineTransactionDetails`
  MODIFY `OfflineTranId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `RegistrationFees`
--
ALTER TABLE `RegistrationFees`
  MODIFY `RegFeeId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `States`
--
ALTER TABLE `States`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `SubCategories`
--
ALTER TABLE `SubCategories`
  MODIFY `SubCatID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `TransactionDetails`
--
ALTER TABLE `TransactionDetails`
  MODIFY `TranDtlId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `UserRegistrationDetails`
--
ALTER TABLE `UserRegistrationDetails`
  MODIFY `UserId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `Workshops`
--
ALTER TABLE `Workshops`
  MODIFY `WorkshopId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `AccompanyingPersonDetails`
--
ALTER TABLE `AccompanyingPersonDetails`
  ADD CONSTRAINT `FK_ACC_ConfTypeId` FOREIGN KEY (`ConfTypeId`) REFERENCES `Conferences` (`ConfTypeId`),
  ADD CONSTRAINT `FK_ACC_UserID` FOREIGN KEY (`UserID`) REFERENCES `UserRegistrationDetails` (`UserId`);

--
-- Constraints for table `CategoryDetails`
--
ALTER TABLE `CategoryDetails`
  ADD CONSTRAINT `FK_CAT_ConfTypeId` FOREIGN KEY (`ConfTypeId`) REFERENCES `Conferences` (`ConfTypeId`);

--
-- Constraints for table `Cities`
--
ALTER TABLE `Cities`
  ADD CONSTRAINT `FK_CT_ConfTypeId` FOREIGN KEY (`StateId`) REFERENCES `States` (`Id`);

--
-- Constraints for table `CMETypes`
--
ALTER TABLE `CMETypes`
  ADD CONSTRAINT `FK_CME_ConfTypeId` FOREIGN KEY (`ConfTypeId`) REFERENCES `Conferences` (`ConfTypeId`);

--
-- Constraints for table `EventDetails`
--
ALTER TABLE `EventDetails`
  ADD CONSTRAINT `FK_ED_ConfTypeId` FOREIGN KEY (`ConfTypeId`) REFERENCES `Conferences` (`ConfTypeId`);

--
-- Constraints for table `OfflineTransactionDetails`
--
ALTER TABLE `OfflineTransactionDetails`
  ADD CONSTRAINT `FK_OFF_ConfTypeId` FOREIGN KEY (`ConfTypeId`) REFERENCES `Conferences` (`ConfTypeId`),
  ADD CONSTRAINT `FK_OFF_UserID` FOREIGN KEY (`UserID`) REFERENCES `UserRegistrationDetails` (`UserId`);

--
-- Constraints for table `PaymentDetails`
--
ALTER TABLE `PaymentDetails`
  ADD CONSTRAINT `FK_PD_UserID` FOREIGN KEY (`UserID`) REFERENCES `UserRegistrationDetails` (`UserId`);

--
-- Constraints for table `PaymentGateway`
--
ALTER TABLE `PaymentGateway`
  ADD CONSTRAINT `FK_PG_ConfTypeId` FOREIGN KEY (`ConfTypeId`) REFERENCES `Conferences` (`ConfTypeId`);

--
-- Constraints for table `ProgramDefinitions`
--
ALTER TABLE `ProgramDefinitions`
  ADD CONSTRAINT `FK_C_ConfTypeId` FOREIGN KEY (`ConfTypeId`) REFERENCES `Conferences` (`ConfTypeId`);

--
-- Constraints for table `ProgramFeeImage`
--
ALTER TABLE `ProgramFeeImage`
  ADD CONSTRAINT `FK_PFI_ConfTypeId` FOREIGN KEY (`ConfTypeId`) REFERENCES `Conferences` (`ConfTypeId`);

--
-- Constraints for table `RegistrationFees`
--
ALTER TABLE `RegistrationFees`
  ADD CONSTRAINT `FK_RegF_ConfTypeId` FOREIGN KEY (`ConfTypeId`) REFERENCES `Conferences` (`ConfTypeId`);

--
-- Constraints for table `RegistrationFields`
--
ALTER TABLE `RegistrationFields`
  ADD CONSTRAINT `FK_RF_ConfTypeId` FOREIGN KEY (`ConfTypeId`) REFERENCES `Conferences` (`ConfTypeId`);

--
-- Constraints for table `States`
--
ALTER TABLE `States`
  ADD CONSTRAINT `FK_ST_ConfTypeId` FOREIGN KEY (`CountryId`) REFERENCES `Countries` (`Id`);

--
-- Constraints for table `TextMessages`
--
ALTER TABLE `TextMessages`
  ADD CONSTRAINT `FK_TM_ConfTypeId` FOREIGN KEY (`ConfTypeId`) REFERENCES `Conferences` (`ConfTypeId`);

--
-- Constraints for table `TransactionDetails`
--
ALTER TABLE `TransactionDetails`
  ADD CONSTRAINT `FK_TRAN_ConfTypeId` FOREIGN KEY (`ConfTypeId`) REFERENCES `Conferences` (`ConfTypeId`),
  ADD CONSTRAINT `FK_TRAN_UserID` FOREIGN KEY (`UserID`) REFERENCES `UserRegistrationDetails` (`UserId`);

--
-- Constraints for table `UserMemberNo`
--
ALTER TABLE `UserMemberNo`
  ADD CONSTRAINT `FK_UR_ConfTypeId` FOREIGN KEY (`ConfTypeId`) REFERENCES `Conferences` (`ConfTypeId`),
  ADD CONSTRAINT `FK_UR_UserId` FOREIGN KEY (`UserId`) REFERENCES `UserRegistrationDetails` (`UserId`);

--
-- Constraints for table `UserWorkshopDetails`
--
ALTER TABLE `UserWorkshopDetails`
  ADD CONSTRAINT `FK_W_UserID` FOREIGN KEY (`UserID`) REFERENCES `UserRegistrationDetails` (`UserId`);

--
-- Constraints for table `Workshops`
--
ALTER TABLE `Workshops`
  ADD CONSTRAINT `FK_W_ConfTypeId` FOREIGN KEY (`ConfTypeId`) REFERENCES `Conferences` (`ConfTypeId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

CREATE DEFINER=`event_regs`@`%` PROCEDURE `sp_CategoryWorkshopDetails`(
	IN p_ConfTypeId INT
)
BEGIN
	SELECT 0 CategoryId, 'Choose Category' CategoryName
	UNION
	SELECT CategoryId, CategoryName FROM CategoryDetails
    WHERE ConfTypeId = p_ConfTypeId;
    
    SELECT * FROM SubCategories;
    
    SELECT 0 ID, 'Choose Workshop' Workshop
	UNION
    SELECT WorkshopId ID, Workshop
    FROM Workshops
    WHERE ConfTypeId = p_ConfTypeId;
    
    SELECT 0 EventID, 'Choose Registration Type' RegistrationType
	UNION
	SELECT EventID, RegistrationType FROM EventDetails
    WHERE ConfTypeId = p_ConfTypeId;
    
    SELECT 0 CMEId, 'Choose CME type' CMEName
	UNION
    SELECT CMEId, CMEName FROM CMETypes
    WHERE ConfTypeId = p_ConfTypeId;
END

CREATE DEFINER=`event_regs`@`%` PROCEDURE `sp_CreateConference`(
	IN p_CondOper INT,
    IN p_ConfTypeId INT,
    IN p_ConfName VARCHAR(30)
)
BEGIN
	IF p_CondOper = 3 THEN
    BEGIN
		DELETE FROM Conferences
        WHERE ConfTypeId = p_ConfTypeId;
    END;
    END IF;
    IF p_CondOper = 2 THEN
    BEGIN
		UPDATE Conferences
        SET ConfName = p_ConfName
        WHERE ConfTypeId = p_ConfTypeId;
    END;
    END IF;
    IF p_CondOper = 1 THEN
    BEGIN
		INSERT INTO Conferences (ConfName)
        SELECT p_ConfName;
            
		INSERT INTO ProgramDefinitions (ConfTypeId)
        SELECT last_insert_id();
        
        INSERT INTO TextMessages (ConfTypeId)
        SELECT last_insert_id();
        
        INSERT INTO PaymentGateway (ConfTypeId, Gateway)
        SELECT last_insert_id(), 'CCAvenue';
        
        INSERT INTO ProgramFeeImage (ConfTypeId)
        SELECT last_insert_id();
        
        INSERT INTO RegistrationFields (ConfTypeId)
        SELECT last_insert_id();
        
        INSERT INTO EventDetails 
        (
			ConfTypeId,
            RegistrationType,
            StartDate,
            EndDate
        )
        SELECT last_insert_id(), 'Early Bird', curdate(), curdate()
        UNION
        SELECT last_insert_id(), 'Standard1', curdate(), curdate()
        UNION
        SELECT last_insert_id(), 'Standard2', curdate(), curdate()
        UNION
        SELECT last_insert_id(), 'Standard3', curdate(), curdate()
        UNION
        SELECT last_insert_id(), 'Standard4', curdate(), curdate()
        UNION
        SELECT last_insert_id(), 'Standard5', curdate(), curdate()
        UNION
        SELECT last_insert_id(), 'Late & Spot', curdate(), curdate();
    END;
    END IF;
END

CREATE DEFINER=`event_regs`@`%` PROCEDURE `sp_CreateWorkshop`(
	IN p_CondOper INT,
    IN p_ConfTypeId INT,
    IN p_WorkshopId INT,
    IN p_Workshop VARCHAR(50)
)
BEGIN
	IF p_CondOper = 3 THEN
    BEGIN
		DELETE FROM Workshops
        WHERE WorkshopId = p_WorkshopId;
    END;
    END IF;
    IF p_CondOper = 2 THEN
    BEGIN
		UPDATE Workshops
        SET Workshop = p_Workshop
        WHERE WorkshopId = p_WorkshopId;
    END;
    END IF;
    IF p_CondOper = 1 THEN
    BEGIN
		INSERT INTO Workshops (Workshop, ConfTypeId)
        SELECT p_Workshop, p_ConfTypeId;
    END;
    END IF;
END

CREATE DEFINER=`event_regs`@`%` PROCEDURE `sp_EchoTransactionDetails`(
    IN p_TranId VARCHAR(50),
    IN p_PaymentId VARCHAR(50),
    IN p_PaymentMode VARCHAR(20),
    IN p_OrderId VARCHAR(50),
    IN p_TrackingId VARCHAR(50),
    IN p_BankRefNo VARCHAR(50),
    IN p_Currency VARCHAR(20),
    IN p_OrderStatus VARCHAR(20),
    IN p_Gateway VARCHAR(20),
    IN p_MobileNo VARCHAR(20),
    IN p_ConfTypeId INT
)
BEGIN
	INSERT INTO TransactionDetails
    (
		UserID,
        TransactionId,
        PaymentId,
        PaymentStatus,
        OrderId,
        TrackingId,
        BankRefNo,
        Currency,
        OrderStatus,
        PaymentGateway,
        ConfTypeId,
        TransactionDateTime
    )
    SELECT
		(SELECT UserId FROM UserRegistrationDetails WHERE MobileNo = p_MobileNo),
        p_TranId,
        p_PaymentId,
        p_PaymentMode,
        p_OrderId,
        p_TrackingId,
        p_BankRefNo,
        p_Currency,
        p_OrderStatus,
        p_Gateway,
        p_ConfTypeId,
        DATE_ADD(now(), INTERVAL 750 MINUTE);
	
    UPDATE PaymentDetails SET Status = 'Success'
    WHERE UserID = p_UserID;
    
    UPDATE UserWorkshopDetails SET Status = 'Success'
    WHERE UserID = p_UserID;
    
    UPDATE AccompanyingPersonDetails SET Status = 'Success'
    WHERE UserID = p_UserID;
    
    UPDATE UserRegistrationDetails SET Status = 'Success'
    WHERE UserID = p_UserID;
END

CREATE DEFINER=`event_regs`@`%` PROCEDURE `sp_GetCityStateCountry`()
BEGIN
	SELECT * FROM Countries;
    SELECT * FROM States;
    SELECT * FROM Cities;
END

CREATE DEFINER=`event_regs`@`%` PROCEDURE `sp_GetConference`(
	IN p_ConfName VARCHAR(30)
)
BEGIN
	SELECT ConfTypeId FROM EventRegistrations.Conferences
    WHERE ConfName = p_ConfName;
END

CREATE DEFINER=`event_regs`@`%` PROCEDURE `sp_GetConferenceName`(
	IN p_ConfTypeId INT
)
BEGIN
	SELECT ConfName FROM Conferences
    WHERE ConfTypeId = p_ConfTypeId;
END

CREATE DEFINER=`event_regs`@`%` PROCEDURE `sp_GetPaymentGateway1008`(
	IN p_CondOper INT,
    IN p_ConfTypeId INT,
    IN p_Gateway VARCHAR(30),
    IN p_AccessCode VARCHAR(50),
    IN p_WorkingKey VARCHAR(50),
    IN p_MerchantId VARCHAR(20),
    IN p_ClientId VARCHAR(50),
    IN p_ClientSecretKey VARCHAR(200)
)
BEGIN
	IF p_CondOper = 2 THEN
    BEGIN
		UPDATE PaymentGateway
        SET Gateway = p_Gateway,
			AccessCode = p_AccessCode,
            WorkingKey = p_WorkingKey,
            MerchantId = p_MerchantId,
            ClientId = p_ClientId,
            ClientSecretKey = p_ClientSecretKey
		WHERE ConfTypeId = p_ConfTypeId;
    END;
    END IF;
    IF p_CondOper = 1 THEN
    BEGIN
        SELECT C1.*, ConfName Conference
        FROM PaymentGateway C1
        INNER JOIN Conferences C2 ON C1.ConfTypeId = C2.ConfTypeId;
    END;
    END IF;
    IF p_CondOper = 3 THEN
    BEGIN
        SELECT Gateway FROM PaymentGateway
        WHERE ConfTypeId = p_ConfTypeId;
    END;
    END IF;
END

CREATE DEFINER=`event_regs`@`%` PROCEDURE `sp_GetPaymentGatewayConstants`(
	IN p_ConfTypeId INT
)
BEGIN
	SELECT * FROM PaymentGateway
    WHERE ConfTypeId = p_ConfTypeId;
END

CREATE DEFINER=`event_regs`@`%` PROCEDURE `sp_GetRegistrationTypes`(
	IN p_CondOper INT,
    IN p_RegTypeId INT,
    IN p_PaymentTextMsg VARCHAR(1024),
    IN p_RegTextMsg VARCHAR(1024),
    IN p_Notification VARCHAR(1024),
    IN p_StartDate DATE,
    IN p_EndDate DATE,
    IN p_PaymentEmail VARCHAR(1024),
    IN p_RegEmail VARCHAR(1024),
    IN p_PaymentEmailSubject VARCHAR(1024),
    IN p_RegEmailSubject VARCHAR(1024)
)
BEGIN
	IF p_CondOper = 1 THEN
    BEGIN
		SELECT 0 ConfTypeId, 'Choose Conference' ConfName
        UNION
		SELECT ConfTypeId, ConfName FROM Conferences;
        
        SELECT EventId RegTypeId, RegistrationType, StartDate, EndDate, ConfName Conference
        FROM EventDetails C1
        INNER JOIN Conferences C2 ON C1.ConfTypeId = C2.ConfTypeId;
        
        SELECT C1.*, ConfName Conference
        FROM TextMessages C1
        INNER JOIN Conferences C2 ON C1.ConfTypeId = C2.ConfTypeId;
    END;
    END IF;
    IF p_CondOper = 3 THEN
    BEGIN
		UPDATE TextMessages
        SET PaymentTextMessage = p_PaymentTextMsg,
			RegTextMessage = p_RegTextMsg,
            Notification = p_Notification,
            PaymentEmail = p_PaymentEmail,
            RegEmail = p_RegEmail,
            PaymentEmailSubject = p_PaymentEmailSubject,
            RegEmailSubject = p_RegEmailSubject
		WHERE ConfTypeId = p_RegTypeId;
    END;
    END IF;    
    IF p_CondOper = 2 THEN
    BEGIN
		UPDATE EventDetails
        SET StartDate = p_StartDate,
			EndDate = p_EndDate
		WHERE EventId = p_RegTypeId;
    END;
    END IF;
END

CREATE DEFINER=`event_regs`@`%` PROCEDURE `sp_GetSMSText`(
	IN p_CondOper INT,
    IN p_ConfTypeId INT
)
BEGIN
	IF p_CondOper = 1 THEN
    BEGIN
		SELECT * FROM TextMessages
        WHERE ConfTypeId = p_ConfTypeId;
    END;
    END IF;
END

CREATE DEFINER=`event_regs`@`%` PROCEDURE `sp_GetUserDetailsByUserID`(
	IN p_UserID INT,
    IN p_ConfTypeId INT
)
BEGIN
	SELECT R.*, C.ConfName Conference FROM UserRegistrationDetails R
    INNER JOIN UserMemberNo M ON R.UserId = M.UserId
    INNER JOIN Conferences C ON C.ConfTypeId = M.ConfTypeId
    WHERE R.UserID = p_UserID AND M.UserId = p_UserID
		AND M.ConfTypeId = p_ConfTypeId;
END

CREATE DEFINER=`event_regs`@`%` PROCEDURE `sp_GetUserIdByMobileNo`(
	IN p_MobileNo VARCHAR(20)
)
BEGIN
	SELECT UserID FROM UserRegistrationDetails
    WHERE MobileNo = p_MobileNo;
END

CREATE DEFINER=`event_regs`@`%` PROCEDURE `sp_LoadRegistrationFields`(
	IN p_CondOper INT
)
BEGIN
	IF p_CondOper = 1 THEN
    BEGIN
		SELECT C1.*, ConfName
        FROM RegistrationFields C1
        INNER JOIN Conferences C2 ON C1.ConfTypeId = C2.ConfTypeId;
    END;
    END IF;
    IF p_CondOper = 2 THEN
    BEGIN
        SELECT C1.*, ConfName
        FROM ProgramDefinitions C1
        INNER JOIN Conferences C2 ON C1.ConfTypeId = C2.ConfTypeId;
    END;
    END IF;
END

CREATE DEFINER=`event_regs`@`%` PROCEDURE `sp_OfflinePaymentDetails`(
	IN p_UserID INT,
    IN p_DDNo VARCHAR(30),
    IN p_ChequeNo VARCHAR(30),
    IN p_UTRNo VARCHAR(30),
    IN p_Bank VARCHAR(30),
    IN p_Branch VARCHAR(50),
    IN p_ChequeDate DATE,
    IN p_ConfTypeId INT
)
BEGIN
	INSERT INTO OfflineTransactionDetails
    (
		UserId,
        ConfTypeId,
        DDNo,
        ChequeNo,
        UTRNo,
        Bank,
        Branch,
        ChequeDate,
        TransactionDateTime
    )
    SELECT 
		p_UserID,
        p_ConfTypeId,
        p_DDNo,
        p_ChequeNo,
        p_UTRNo,
        p_Bank,
        p_Branch,
        p_ChequeDate,
        DATE_ADD(now(), INTERVAL 750 MINUTE);
        
	UPDATE PaymentDetails SET Status = 'Success'
    WHERE UserID = p_UserID;
    
    UPDATE UserWorkshopDetails SET Status = 'Success'
    WHERE UserID = p_UserID;
    
    UPDATE AccompanyingPersonDetails SET Status = 'Success'
    WHERE UserID = p_UserID;
    
    UPDATE UserRegistrationDetails SET Status = 'Success'
    WHERE UserID = p_UserID;
END

CREATE DEFINER=`event_regs`@`%` PROCEDURE `sp_ProgramDefinitions`(
	IN p_CondOper INT,
    IN p_StandardRegTypeNo INT,
    IN p_WorkshopDays INT,
    IN p_ChildrenAge INT,
    IN p_ConfTypeId INT,
    IN p_IsWorkshopReq INT,
    IN p_IsConfReq INT,
    IN p_IsCMEReq INT,
    IN p_IsAccPersonReq INT,
    IN p_Workshop VARCHAR(200)
)
BEGIN
	IF p_CondOper = 13 THEN
    BEGIN
		SELECT * FROM Conferences;
    END;
    END IF;
    IF p_CondOper = 9 THEN
    BEGIN
		SELECT 0 ConfTypeId, 'Choose Conference' ConfName
        UNION
		SELECT ConfTypeId, ConfName FROM Conferences;
    END;
    END IF;
    IF p_CondOper = 1 THEN
    BEGIN
		SELECT StandardRegTypeNo, ConfName Conference, WorkshopDays, ChildrenAge, C1.ConfTypeId,
			CASE WHEN IsWorkshopReq = 0 THEN 'No' ELSE 'Yes' END IsWorkshopReq,
            CASE WHEN IsConfReq = 0 THEN 'No' ELSE 'Yes' END IsConfReq,
            CASE WHEN IsCMEReq = 0 THEN 'No' ELSE 'Yes' END IsCMEReq,
            CASE WHEN IsAccPersonReq = 0 THEN 'No' ELSE 'Yes' END IsAccPersonReq
        FROM ProgramDefinitions C1
        INNER JOIN Conferences C2 ON C1.ConfTypeId = C2.ConfTypeId;
    END;
    END IF;
    IF p_CondOper = 2 THEN
    BEGIN
		UPDATE ProgramDefinitions
        SET StandardRegTypeNo = p_StandardRegTypeNo,
			WorkshopDays = p_WorkshopDays,
            ChildrenAge = p_ChildrenAge,
            IsWorkshopReq = p_IsWorkshopReq,
            IsConfReq = p_IsConfReq,
            IsCMEReq = p_IsCMEReq,
            IsAccPersonReq = p_IsAccPersonReq
		WHERE ConfTypeId = p_ConfTypeId;
    END;
    END IF;
    IF p_CondOper = 6 THEN
    BEGIN
		SELECT CategoryId, CategoryName, ConfName Conference, C1.ConfTypeId
        FROM CategoryDetails C1
        INNER JOIN Conferences C2 ON C1.ConfTypeId = C2.ConfTypeId;
    END;
    END IF;
    IF p_CondOper = 8 THEN
    BEGIN
		UPDATE CategoryDetails
        SET CategoryName = p_Workshop
        WHERE CategoryId = p_ConfTypeId;
    END;
    END IF;
    IF p_CondOper = 12 THEN
    BEGIN
		INSERT INTO CategoryDetails (CategoryName, ConfTypeId)
        SELECT p_Workshop, p_ConfTypeId;
    END;
    END IF;
    IF p_CondOper = 5 THEN
    BEGIN
		SELECT CMEId, CMEName, ConfName Conference, C1.ConfTypeId
        FROM CMETypes C1
        INNER JOIN Conferences C2 ON C1.ConfTypeId = C2.ConfTypeId;
    END;
    END IF;
    IF p_CondOper = 7 THEN
    BEGIN
		UPDATE CMETypes
        SET CMEName = p_Workshop
        WHERE CMEId = p_ConfTypeId;
    END;
    END IF;
    IF p_CondOper = 11 THEN
    BEGIN
		INSERT INTO CMETypes (CMEName, ConfTypeId)
        SELECT p_Workshop, p_ConfTypeId;
    END;
    END IF;
    IF p_CondOper = 14 THEN
    BEGIN
		SELECT WorkshopId, Workshop, ConfName Conference, C1.ConfTypeId
        FROM Workshops C1
        INNER JOIN Conferences C2 ON C1.ConfTypeId = C2.ConfTypeId;
    END;
    END IF;
END

CREATE DEFINER=`event_regs`@`%` PROCEDURE `sp_ProgramRegistrationFee`(
	IN p_CondOper INT,
    IN p_ConfTypeId INT,
    IN p_RegFeeId INT,
    IN p_Amount INT,
    IN p_Currency VARCHAR(10),
    IN p_EventId INT,
    IN p_CatId INT,
    IN p_SubCatId INT,
    IN p_WorkshopId INT
)
BEGIN
	IF p_CondOper = 2 THEN
    BEGIN
		IF p_RegFeeId = 0 THEN
        BEGIN
			INSERT INTO RegistrationFees
			(
				Amount,
				Currency,
				EventId,
				CatId,
				ConfTypeId,
				SubCatId,
				WorkshopId
			)
			SELECT
				p_Amount,
				p_Currency,
				p_EventId,
				p_CatId,
				p_ConfTypeId,
				p_SubCatId,
				p_WorkshopId;
		END;
        ELSE
        BEGIN
			UPDATE RegistrationFees
            SET Amount = p_Amount,
				Currency = p_Currency
			WHERE RegFeeId = p_RegFeeId;
        END;
        END IF;
    END;
    END IF;
    IF p_CondOper = 1 THEN
    BEGIN
		SELECT 0 ConfTypeId, 'Choose Conference' ConfName
        UNION
		SELECT ConfTypeId, ConfName FROM Conferences;
        
        SELECT ConfName Conference, RegistrationType, SubCatName SubCategory, Amount, Currency, RegFeeId,
			CASE WHEN RF.SubCatId = 3 THEN 
				CASE WHEN RF.WorkshopId = 0 THEN 'ALL' ELSE Workshop END
			ELSE '' END Workshop, RF.ConfTypeId,
            CASE WHEN RF.CatId = 0 THEN 'Delegate' ELSE CategoryName END Category
        FROM RegistrationFees RF
        INNER JOIN Conferences C2 ON RF.ConfTypeId = C2.ConfTypeId
        INNER JOIN EventDetails ED ON ED.EventId = RF.EventId
        LEFT JOIN CategoryDetails CD ON CD.CategoryId = RF.CatId
        INNER JOIN SubCategories SC ON SC.SubCatId = RF.SubCatId
        LEFT JOIN Workshops W ON W.WorkshopId = RF.WorkshopId;
    END;
    END IF;
END

CREATE DEFINER=`event_regs`@`%` PROCEDURE `sp_RegistrationDetails`(
	IN RegDate DATE,
    IN p_ConfTypeId INT
)
BEGIN
	SELECT ConfName Conference, RegistrationType, SubCatName, Amount, Currency, RegFeeId,
		CASE WHEN RF.SubCatId = 3 THEN 
			CASE WHEN RF.WorkshopId = 0 THEN 'ALL' ELSE Workshop END
		ELSE '' END Workshop, RF.ConfTypeId,
		CASE WHEN RF.CatId = 0 THEN 'Delegate' ELSE CategoryName END CategoryName
	FROM RegistrationFees RF
	INNER JOIN Conferences C2 ON RF.ConfTypeId = C2.ConfTypeId
	INNER JOIN EventDetails ED ON ED.EventId = RF.EventId
	LEFT JOIN CategoryDetails CD ON CD.CategoryId = RF.CatId
	INNER JOIN SubCategories SC ON SC.SubCatId = RF.SubCatId
	LEFT JOIN Workshops W ON W.WorkshopId = RF.WorkshopId
    WHERE RF.ConfTypeId = p_ConfTypeId AND RegDate Between StartDate and EndDate;
END

CREATE DEFINER=`event_regs`@`%` PROCEDURE `sp_RemoveAccPersonDetails`(
	IN p_UserID INT,
    IN CondOper INT
)
BEGIN
	DELETE FROM AccompanyingPersonDetails
    WHERE UserID = p_UserID AND Status <> 'Success';
    
    DELETE FROM AccPersonDetailsTemp
    WHERE UserID = p_UserID;
END

CREATE DEFINER=`event_regs`@`%` PROCEDURE `sp_RemoveCategoryDetails`(
	IN p_UserID INT
)
BEGIN
	DELETE FROM PaymentDetails
    WHERE UserID = p_UserID AND Status <> 'Success';
    
    DELETE FROM ProgramDetailsTemp
    WHERE UserID = p_UserID;
END

CREATE DEFINER=`event_regs`@`%` PROCEDURE `sp_RemoveWorkshopDetails`(
	IN p_UserID INT
)
BEGIN
	DELETE FROM UserWorkshopDetails
    WHERE UserID = p_UserID AND Status <> 'Success';
    
    DELETE FROM WorkshopDetailsTemp
    WHERE UserID = p_UserID;
END

CREATE DEFINER=`event_regs`@`%` PROCEDURE `sp_RoleManagement`(
	IN p_MobileNo VARCHAR(20)
)
BEGIN
	SELECT Role FROM Users
	WHERE MobileNo = p_MobileNo;
END

CREATE DEFINER=`event_regs`@`%` PROCEDURE `sp_TransactionDetails`(
	IN p_UserID INT,
    IN p_TranId VARCHAR(50),
    IN p_PaymentId VARCHAR(50),
    IN p_PaymentMode VARCHAR(20),
    IN p_OrderId VARCHAR(50),
    IN p_TrackingId VARCHAR(50),
    IN p_BankRefNo VARCHAR(50),
    IN p_Currency VARCHAR(20),
    IN p_OrderStatus VARCHAR(20),
    IN p_Gateway VARCHAR(20),
    IN p_Signature VARCHAR(200),
    IN p_ConfTypeId INT
)
BEGIN
	INSERT INTO TransactionDetails
    (
		UserID,
        TransactionId,
        PaymentId,
        PaymentStatus,
        OrderId,
        TrackingId,
        BankRefNo,
        Currency,
        OrderStatus,
        PaymentGateway,
        ConfTypeId,
        Signature,
        TransactionDateTime
    )
    SELECT
		p_UserId,
        p_TranId,
        p_PaymentId,
        p_PaymentMode,
        p_OrderId,
        p_TrackingId,
        p_BankRefNo,
        p_Currency,
        p_OrderStatus,
        p_Gateway,
        p_ConfTypeId,
        p_Signature,
        DATE_ADD(now(), INTERVAL 750 MINUTE);
	
    UPDATE PaymentDetails SET Status = 'Success'
    WHERE UserID = p_UserID;
    
    UPDATE UserWorkshopDetails SET Status = 'Success'
    WHERE UserID = p_UserID;
    
    UPDATE AccompanyingPersonDetails SET Status = 'Success'
    WHERE UserID = p_UserID;
    
    UPDATE UserRegistrationDetails SET Status = 'Success'
    WHERE UserID = p_UserID;
END

CREATE DEFINER=`event_regs`@`%` PROCEDURE `sp_UpdateRegistrationFields`(
	IN p_ConfName varchar(30),
    IN p_Title INT,
    IN p_FullName INT,
    IN p_Gender INT,
    IN p_Age INT,
    IN p_DOB INT,
    IN p_City INT,
    IN p_State INT,
    IN p_Country INT,
    IN p_Designation INT,
    IN p_Department INT,
    IN p_RegistrationNo INT,
    IN p_MemberNo INT,
    IN p_Nationality INT,
    IN p_Email INT,
    IN p_MobileNo INT,
    IN p_SMCN INT,
    IN p_SMCNo INT,
    IN p_Institution INT,
    IN p_PinCode INT,
    IN p_Address INT
)
BEGIN
	UPDATE RegistrationFields
    SET Title = p_Title,
		FullName = p_FullName,
        Gender = p_Gender,
        DOB = p_DOB,
        Age = p_Age,
        City = p_City,
        State = p_State,
        Country = p_Country,
        RegistrationNo = p_RegistrationNo,
        MemberNo = p_MemberNo,
        Designation = p_Designation,
        Department = p_Department,
        Nationality = p_Nationality,
        Email = p_Email,
        MobileNo = p_MobileNo,
        MedicalCouncilName = p_SMCN,
        MedicalCouncilNo = p_SMCNo,
        Address = p_Address,
        PinCode = p_PinCode,
        Institution = p_Institution
	WHERE ConfTypeId = (SELECT ConfTypeId FROM Conferences WHERE ConfName = p_ConfName);
END

CREATE DEFINER=`event_regs`@`%` PROCEDURE `sp_UploadProgramFeeImage`(
	IN p_CondOper INT,
    IN p_ConfTypeId INT,
    IN p_ProgramImage BLOB,
    IN p_ConfName VARCHAR(30)
)
BEGIN
	IF p_CondOper = 1 THEN
    BEGIN
		UPDATE ProgramFeeImage
        SET ProgramImage = p_ProgramImage
		WHERE ConfTypeId = p_ConfTypeId;
    END;
    END IF;
    IF p_CondOper = 2 THEN
    BEGIN
		SELECT ProgramImage FROM ProgramFeeImage P
        INNER JOIN Conferences C ON P.ConfTypeId = C.ConfTypeId
		WHERE ConfName = p_ConfName;
    END;
    END IF;
END

CREATE DEFINER=`event_regs`@`%` PROCEDURE `sp_UserAlreadyRegistered`(
	IN p_MobileNo VARCHAR(20),
    IN p_ConfTypeId INT,
    IN p_CondOper INT
)
BEGIN
	SELECT * FROM UserRegistrationDetails R
    INNER JOIN UserMemberNo M ON M.UserId = R.UserId
    WHERE R.MobileNo = p_MobileNo AND M.ConfTypeId = p_ConfTypeId;
END

CREATE DEFINER=`event_regs`@`%` PROCEDURE `sp_UserRegistrationDetails`(
	IN p_ConfTypeId INT,
    IN p_UserId INT,
    IN p_Title VARCHAR(20),
    IN p_FullName VARCHAR(50),
    IN p_Gender VARCHAR(20),
    IN p_Age INT,
    IN p_DOB DATE,
    IN p_City VARCHAR(30),
    IN p_State VARCHAR(30),
    IN p_Country VARCHAR(30),
    IN p_Designation VARCHAR(50),
    IN p_Dept VARCHAR(50),
    IN p_RegNo VARCHAR(30),
    IN p_MemberNo VARCHAR(30),
    IN p_Nationality VARCHAR(30),
    IN p_Email VARCHAR(30),
    IN p_MobileNumber VARCHAR(30),
    IN p_StateMedCouncilName VARCHAR(50),
    IN p_StateMedCouncilNo VARCHAR(30),
    IN p_Institution VARCHAR(30),
    IN p_PinCode VARCHAR(20),
    IN p_Address VARCHAR(100),
    IN p_UserRegisterNo BIGINT
)
BEGIN
	IF p_UserId = 0 THEN
    BEGIN
		INSERT INTO UserRegistrationDetails
        (
			Title,
            FullName,
            DOB,
            Age,
            City,
            State,
            Country,
            Gender,
            Nationality,
            Institution,
            Designation,
            PinCode,
            Address,
            MobileNo,
            Email,
            MedicalCouncilName,
            MedicalCouncilNo,
            Department,
            RegistrationNo,
            UserRegisterNo,
            CreatedDateTime,
            UpdatedDateTime
        )
        SELECT
			p_Title,
            p_FullName,
            p_DOB,
            p_Age,
            p_City,
            p_State,
            p_Country,
            p_Gender,
            p_Nationality,
            p_Institution,
            p_Designation,
            p_PinCode,
            p_Address,
            p_MobileNumber,
            p_Email,
            p_StateMedCouncilName,
            p_StateMedCouncilNo,
            p_Dept,
            p_RegNo,
            p_UserRegisterNo,
            DATE_ADD(now(), INTERVAL 750 MINUTE),
            DATE_ADD(now(), INTERVAL 750 MINUTE);
            
		INSERT INTO UserMemberNo
        (
			ConfTypeId,
            UserId,
            MemberNo
        )
        SELECT
			p_ConfTypeId,
            last_insert_id(),
            p_MemberNo;
		
        SELECT last_insert_id() UserID;
    END;
    ELSE
    BEGIN
		UPDATE UserRegistrationDetails
        SET Title = p_Title,
            FullName = p_FullName,
            DOB = p_DOB,
            Age = p_Age,
            City = p_City,
            State = p_State,
            Country = p_Country,
            Gender = p_Gender,
            Nationality = p_Nationality,
            Institution = p_Institution,
            Designation = p_Designation,
            PinCode = p_PinCode,
            Address = p_Address,
            MobileNo = p_MobileNumber,
            Email = p_Email,
            MedicalCouncilName = p_StateMedCouncilName,
            MedicalCouncilNo = p_StateMedCouncilNo,
            Department = p_Dept,
            RegistrationNo = p_RegNo,
            UpdatedDateTime = DATE_ADD(now(), INTERVAL 750 MINUTE)
		WHERE UserId = p_UserId;
        
        SET @UserId := 0;
        SELECT @UserId := UserId FROM UserMemberNo 
        WHERE UserId = p_UserId AND ConfTypeId = p_ConfTypeId;
        
        IF @UserId = 0 THEN
        BEGIN
			INSERT INTO UserMemberNo
			(
				ConfTypeId,
				UserId,
				MemberNo
			)
			SELECT
				p_ConfTypeId,
				p_UserId,
				p_MemberNo;
        END;
        ELSE
        BEGIN
			UPDATE UserMemberNo
            SET MemberNo = p_MemberNo
            WHERE UserId = p_UserId AND ConfTypeId = p_ConfTypeId;
        END;
        END IF;
        
        SELECT UserRegisterNo FROM UserRegistrationDetails
        WHERE UserId = p_UserId;
    END;
    END IF;
END

CREATE DEFINER=`event_regs`@`%` PROCEDURE `sp_Users`(
	IN p_MobileNo VARCHAR(20),
    IN p_Password VARCHAR(20),
    IN p_Role VARCHAR(20),
    IN p_CondOper INT
)
BEGIN
	IF p_CondOper = 1 THEN
    BEGIN
		SELECT 1 FROM Users
		WHERE MobileNo = p_MobileNo AND Password = p_Password;
    END;
    END IF;
	IF p_CondOper = 2 THEN
    BEGIN
		INSERT INTO Users
        (
			MobileNo,
            Password,
			Role
        )
        SELECT
			p_MobileNo,
            p_Password,
			p_Role;
    END;
    END IF;
    IF p_CondOper = 3 THEN
    BEGIN
		UPDATE Users
        SET Password = p_Password,
			Role = p_Role
		WHERE MobileNo = p_MobileNo;
    END;
    END IF;
    IF p_CondOper = 4 THEN
    BEGIN
		SELECT MobileNo FROM Users
		WHERE MobileNo = p_MobileNo;
    END;
    END IF;
    IF p_CondOper = 5 THEN
    BEGIN
		SELECT * FROM Conferences;
    END;
    END IF;
END