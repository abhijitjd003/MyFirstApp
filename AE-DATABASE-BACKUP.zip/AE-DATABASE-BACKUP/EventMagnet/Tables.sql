CREATE TABLE `EventMagnet`.`Conferences` (
  `ConfTypeId` int(11) NOT NULL AUTO_INCREMENT,
  `ConfName` varchar(30) NOT NULL,
  `IsActive` tinyint(1) DEFAULT NULL,
  `LogoPath` varchar(100) NOT NULL,
  `ColorTheme` varchar(20) NOT NULL,
  PRIMARY KEY (`ConfTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventMagnet`.`EventCodes` (
  `EventId` int(11) NOT NULL AUTO_INCREMENT,
  `EventCode` varchar(30) NOT NULL,
  `IsActive` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`EventId`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventMagnet`.`ConferenceEventCode` (
  `AssociationId` int(11) NOT NULL AUTO_INCREMENT,
  `ConfTypeId` INT NOT NULL,
  `EventId` INT NOT NULL,
  PRIMARY KEY (`AssociationId`),
  CONSTRAINT FK_ConfTypeId
  FOREIGN KEY (ConfTypeId) 
  REFERENCES EventMagnet.Conferences(ConfTypeId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT,
  CONSTRAINT FK_EventId
  FOREIGN KEY (EventId) 
  REFERENCES EventMagnet.EventCodes(EventId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventMagnet`.`AdminUsers` (  
  `Name` varchar(50) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventMagnet`.`AboutConference` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `ConfTypeId` INT NOT NULL,
  `Title` VARCHAR(100) NOT NULL,
  `Theme` VARCHAR(100) NULL,
  `AboutConference1` VARCHAR(1024) NOT NULL,
  `AboutConference2` VARCHAR(1024) NULL,
  PRIMARY KEY (Id, ConfTypeId),
  CONSTRAINT FK_AC_ConfTypeId
  FOREIGN KEY (ConfTypeId) 
  REFERENCES EventMagnet.Conferences(ConfTypeId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventMagnet`.`Contacts` (
  `ContactId` int(11) NOT NULL AUTO_INCREMENT,
  `ConfTypeId` INT NOT NULL,
  `Venue` VARCHAR(100) NOT NULL,
  `VenueMapPath` VARCHAR(200) NULL,
  `VenueMapLink` VARCHAR(1024) NOT NULL,
  `Name` VARCHAR(100) NULL,
  `CommunicationAddress` VARCHAR(100) NULL,
  `VenueAddress` VARCHAR(100) NULL,
  `Email` VARCHAR(30) NULL,
  PRIMARY KEY (ContactId, ConfTypeId),
  CONSTRAINT FK_C_ConfTypeId
  FOREIGN KEY (ConfTypeId) 
  REFERENCES EventMagnet.Conferences(ConfTypeId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventMagnet`.`Delegates` (
  `DelegateId` int(11) NOT NULL AUTO_INCREMENT,
  `ConfTypeId` INT NOT NULL,
  `Name` VARCHAR(50) NOT NULL,
  `RegistrationId`INT NULL,
  `Category` VARCHAR(20) NOT NULL,
  `DelegateType` VARCHAR(20) NULL,
  `Information` VARCHAR(1024) NULL,
  `PhotoPath` VARCHAR(200) NULL,
  PRIMARY KEY (DelegateId),
  CONSTRAINT FK_DEL_ConfTypeId
  FOREIGN KEY (ConfTypeId) 
  REFERENCES EventMagnet.Conferences(ConfTypeId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventMagnet`.`Resources` (
  `ConfTypeId` int(11) NOT NULL,
  `ResourceType` varchar(30) NOT NULL,
  `ResourcePath` varchar(200) NOT NULL,
  `IsRequired` int(11) DEFAULT NULL,
  CONSTRAINT FK_R_ConfTypeId
  FOREIGN KEY (ConfTypeId) 
  REFERENCES EventMagnet.Conferences(ConfTypeId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `EventMagnet`.`Notifications` (
  `NotificationId` int(11) NOT NULL AUTO_INCREMENT,
  `ConfTypeId` int(11) NOT NULL,
  `Message` varchar(1024) NOT NULL,
  `CreatedDateTime` DATETIME NOT NULL,
  PRIMARY KEY (NotificationId),
  CONSTRAINT FK_N_ConfTypeId
  FOREIGN KEY (ConfTypeId) 
  REFERENCES EventMagnet.Conferences(ConfTypeId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `EventMagnet`.`OurSponsors` (
  `SponsorId` int(11) NOT NULL AUTO_INCREMENT,
  `SponsorName` varchar(50) NOT NULL,
  `SponsorLogoPath` varchar(200) NOT NULL,
  PRIMARY KEY (SponsorId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `EventMagnet`.`EventMagnetBanner` (
  `BannerPath` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `EventMagnet`.`PaperPosters` (
  `PaperPosterId` int(11) NOT NULL AUTO_INCREMENT,
  `ConfTypeId` INT NOT NULL,
  `Session` VARCHAR(50) NOT NULL,
  `Category`VARCHAR(50) NOT NULL,
  `Topic` VARCHAR(200) NOT NULL,
  `Speaker` VARCHAR(50) NOT NULL,
  `Date` VARCHAR(20) NOT NULL,
  `FromTime` VARCHAR(20) NOT NULL,
  `ToTime` VARCHAR(20) NOT NULL,
  `PaperPosterType` VARCHAR(50) NOT NULL,
  PRIMARY KEY (PaperPosterId),
  CONSTRAINT FK_PP_ConfTypeId
  FOREIGN KEY (ConfTypeId) 
  REFERENCES EventMagnet.Conferences(ConfTypeId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventMagnet`.`Registrations` (
  `URLId` int(11) NOT NULL AUTO_INCREMENT,
  `RegistrationURL` VARCHAR(100) NOT NULL,
  `ConferenceLogoPath` varchar(200) NOT NULL,
  `ConfTypeId` INT NOT NULL,
  PRIMARY KEY (URLId),
  CONSTRAINT FK_REG_ConfTypeId
  FOREIGN KEY (ConfTypeId) 
  REFERENCES EventMagnet.Conferences(ConfTypeId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `EventMagnet`.`Schedules` (
  `ScheduleId` int(11) NOT NULL AUTO_INCREMENT,
  `ConfTypeId` INT NOT NULL,
  `ScheduleTitle` VARCHAR(200) NOT NULL,
  `Hall`VARCHAR(30) NOT NULL,  
  `Date` VARCHAR(20) NOT NULL,
  `FromTime` VARCHAR(20) NOT NULL,
  `ToTime` VARCHAR(20) NOT NULL,  
  PRIMARY KEY (ScheduleId),
  CONSTRAINT FK_SCH_ConfTypeId
  FOREIGN KEY (ConfTypeId) 
  REFERENCES EventMagnet.Conferences(ConfTypeId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventMagnet`.`Sponsors` (
  `OrgId` int(11) NOT NULL AUTO_INCREMENT,
  `ConfTypeId` INT NOT NULL,
  `Category` VARCHAR(30) NOT NULL,
  `OrgName`VARCHAR(50) NOT NULL,  
  `AboutOrg` VARCHAR(1024) NOT NULL,
  `OrgLogoPath` VARCHAR(200) NOT NULL,
  PRIMARY KEY (OrgId),
  CONSTRAINT FK_ORG_ConfTypeId
  FOREIGN KEY (ConfTypeId) 
  REFERENCES EventMagnet.Conferences(ConfTypeId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventMagnet`.`VisitPlaces` (
  `PlaceId` int(11) NOT NULL AUTO_INCREMENT,
  `ConfTypeId` INT NOT NULL,
  `PlaceName` VARCHAR(50) NOT NULL,
  `AreaName`VARCHAR(100) NOT NULL,  
  `AboutArea` VARCHAR(1024) NOT NULL,
  `AreaImagePath` VARCHAR(200) NOT NULL,
  PRIMARY KEY (PlaceId),
  CONSTRAINT FK_PLC_ConfTypeId
  FOREIGN KEY (ConfTypeId) 
  REFERENCES EventMagnet.Conferences(ConfTypeId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventMagnet`.`Workshops` (
  `WorkshopId` int(11) NOT NULL AUTO_INCREMENT,
  `ConfTypeId` INT NOT NULL,
  `WorkshopName` VARCHAR(100) NOT NULL,
  `Session`VARCHAR(200) NOT NULL,  
  `Date` VARCHAR(20) NOT NULL,
  `FromTime` VARCHAR(20) NOT NULL,
  `ToTime` VARCHAR(20) NOT NULL,
  PRIMARY KEY (WorkshopId),
  CONSTRAINT FK_W_ConfTypeId
  FOREIGN KEY (ConfTypeId) 
  REFERENCES EventMagnet.Conferences(ConfTypeId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventMagnet`.`MobileDevices` (
  `DeviceId` varchar(9999) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `EventMagnet`.`QRCode` (
  `QRCodePath` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `EventMagnet`.`Questions` (
  `BlogId` int(11) NOT NULL AUTO_INCREMENT,
  `ConfTypeId` INT NOT NULL,
  `Username` VARCHAR(100) NOT NULL,
  `Question` VARCHAR(1024) NOT NULL,
  `CreatedDateTime` DATETIME NOT NULL,
  `UpdatedDateTime` DATETIME NOT NULL,
  `Likes` INT DEFAULT 0,
  PRIMARY KEY (BlogId),
  CONSTRAINT FK_QUE_ConfTypeId
  FOREIGN KEY (ConfTypeId) 
  REFERENCES EventMagnet.Conferences(ConfTypeId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventMagnet`.`Answers` (  
  `BlogId` INT NOT NULL,
  `Username` VARCHAR(100) NOT NULL,
  `Answer` VARCHAR(1024) NOT NULL,
  `CreatedDateTime` DATETIME NOT NULL,
  `UpdatedDateTime` DATETIME NOT NULL,
  CONSTRAINT FK_ANS_BlogId
  FOREIGN KEY (BlogId)
  REFERENCES EventMagnet.Questions(BlogId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventMagnet`.`Conversations` (
  `ConversationId` int(11) NOT NULL AUTO_INCREMENT,
  `ConfTypeId` INT NOT NULL,
  `Username` VARCHAR(100) NOT NULL,
  `Message` VARCHAR(1024) NOT NULL,
  `CreatedDateTime` DATETIME NOT NULL,
  `UpdatedDateTime` DATETIME NOT NULL,
  `Likes` INT DEFAULT 0,
  PRIMARY KEY (ConversationId),
  CONSTRAINT FK_CONV_ConfTypeId
  FOREIGN KEY (ConfTypeId) 
  REFERENCES EventMagnet.Conferences(ConfTypeId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventMagnet`.`ConversationReplies` (  
  `ConversationId` INT NOT NULL,
  `Username` VARCHAR(100) NOT NULL,
  `ReplyMessage` VARCHAR(1024) NOT NULL,
  `CreatedDateTime` DATETIME NOT NULL,
  `UpdatedDateTime` DATETIME NOT NULL,
  CONSTRAINT FK_CR_ConversationId
  FOREIGN KEY (ConversationId)
  REFERENCES EventMagnet.Conversations(ConversationId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventMagnet`.`MySchedules` (
  `MyScheduleId` int(11) NOT NULL AUTO_INCREMENT,
  `ConfTypeId` INT NOT NULL,
  `Username` VARCHAR(100) NOT NULL,
  `MobileNo` VARCHAR(20) NOT NULL,
  `Session` VARCHAR(200) NOT NULL,
  `Date` VARCHAR(20) NOT NULL,
  `FromTime` VARCHAR(20) NOT NULL,
  `ToTime` VARCHAR(20) NOT NULL,
  `ScheduleType` VARCHAR(30) NOT NULL,
  PRIMARY KEY (MyScheduleId),
  CONSTRAINT FK_MS_ConfTypeId
  FOREIGN KEY (ConfTypeId) 
  REFERENCES EventMagnet.Conferences(ConfTypeId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `EventMagnet`.`Ratings` (
  `ConfTypeId` INT NOT NULL,
  `ScheduleId` INT NOT NULL,
  `Username` VARCHAR(100) NOT NULL,
  `SessionType` VARCHAR(30) NOT NULL,
  `RatingValue`DECIMAL(10,2) NOT NULL,
  CONSTRAINT FK_RTNGS_ConfTypeId
  FOREIGN KEY (ConfTypeId) 
  REFERENCES EventMagnet.Conferences(ConfTypeId)
  ON UPDATE RESTRICT
  ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;